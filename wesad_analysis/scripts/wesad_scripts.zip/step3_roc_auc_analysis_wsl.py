#!/usr/bin/env python3
"""
第三步：ROC/AUC分析 - WSL版本
专门针对RTX 5080 + CUDA 12.8 + PyTorch nightly环境优化
使用WSL环境，更好的CUDA兼容性
"""

import os
import sys
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
import json
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# 机器学习
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import roc_curve, auc, classification_report, confusion_matrix
from sklearn.metrics import precision_score, recall_score, f1_score

# 深度学习 - WSL优化版本
try:
    import torch
    import torch.nn as nn
    import torch.optim as optim
    from torch.utils.data import DataLoader, TensorDataset
    TORCH_AVAILABLE = True
    
    # WSL环境CUDA优化
    if torch.cuda.is_available():
        torch.backends.cudnn.benchmark = True
        torch.backends.cudnn.deterministic = False
        os.environ['CUDA_LAUNCH_BLOCKING'] = '1'
    
    print(f"PyTorch version: {torch.__version__}")
    print(f"CUDA available: {torch.cuda.is_available()}")
    if torch.cuda.is_available():
        print(f"CUDA device: {torch.cuda.get_device_name(0)}")
        print(f"CUDA version: {torch.version.cuda}")
        
except ImportError:
    TORCH_AVAILABLE = False
    print("PyTorch not available")

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['DejaVu Sans', 'Arial']
plt.rcParams['axes.unicode_minus'] = False

print("="*80)
print("第三步：ROC/AUC分析 - WSL版本")
print("RTX 5080 + CUDA 12.8 + PyTorch nightly优化")
print("="*80)

class ROCAUCAnalyzerWSL:
    def __init__(self):
        self.base_dir = Path(".")
        self.data_dir = self.base_dir / "data"
        self.results = []
        self.random_seed = 42
        np.random.seed(self.random_seed)
        torch.manual_seed(self.random_seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed(self.random_seed)
        
    def load_dataset(self, dataset_name):
        """加载数据集"""
        print(f"\n[{dataset_name}] 加载数据集...")
        
        dataset_paths = {
            "WESAD": self.data_dir / "WESAD",
            "MMASH": self.data_dir / "MMASH" / "extracted",
            "CRWD": self.data_dir / "CRWD" / "extracted",
            "Enhanced_Health": self.data_dir / "Enhanced_Health" / "processed" / "enhanced_large_health_dataset.csv",
            "Global_Mental_Health": self.data_dir / "Global_Mental_Health" / "processed" / "global_mental_health_dataset.csv",
            "Mental_Health_Pred": self.data_dir / "Mental_Health_Pred" / "processed" / "mental_health_wearable_data.csv"
        }
        
        if dataset_name not in dataset_paths:
            print(f"  ✗ 未知数据集: {dataset_name}")
            return None
            
        path = dataset_paths[dataset_name]
        
        try:
            if path.suffix == '.csv':
                df = pd.read_csv(path)
            else:
                # 查找CSV文件
                csv_files = list(path.glob("**/*.csv"))
                if csv_files:
                    largest_file = max(csv_files, key=lambda x: x.stat().st_size)
                    df = pd.read_csv(largest_file)
                else:
                    print(f"  ✗ 未找到CSV文件: {path}")
                    return None
                    
            print(f"  ✓ 加载成功: {len(df)} 行, {len(df.columns)} 列")
            return df
            
        except Exception as e:
            print(f"  ✗ 加载失败: {e}")
            return None
    
    def create_stress_labels(self, df, dataset_name):
        """创建压力标签"""
        print(f"  [{dataset_name}] 创建压力标签...")
        
        # 根据数据集特征创建标签
        if dataset_name == "WESAD":
            # WESAD有明确的标签
            if 'label' in df.columns:
                # 将标签转换为二分类：0=非压力，1=压力
                df['stress_label'] = (df['label'] == 1).astype(int)  # 假设1是压力标签
            else:
                # 基于生理指标创建标签
                numeric_cols = df.select_dtypes(include=[np.number]).columns
                if len(numeric_cols) > 0:
                    # 使用第一个数值列的中位数作为阈值
                    threshold = df[numeric_cols[0]].median()
                    df['stress_label'] = (df[numeric_cols[0]] > threshold).astype(int)
                else:
                    print(f"  ✗ 无法创建标签")
                    return None
                    
        elif dataset_name == "Enhanced_Health":
            # 基于健康状态创建标签
            if 'health_condition' in df.columns:
                stress_conditions = ['Worsening', 'Critical']
                df['stress_label'] = df['health_condition'].isin(stress_conditions).astype(int)
            else:
                # 基于heartbeat创建标签
                if 'heartbeat' in df.columns:
                    threshold = df['heartbeat'].quantile(0.7)  # 上30%作为压力
                    df['stress_label'] = (df['heartbeat'] > threshold).astype(int)
                else:
                    print(f"  ✗ 无法创建标签")
                    return None
                    
        elif dataset_name == "Global_Mental_Health":
            # 基于压力水平创建标签
            if 'stress_level' in df.columns:
                threshold = df['stress_level'].median()
                df['stress_label'] = (df['stress_level'] > threshold).astype(int)
            elif 'mental_health_condition' in df.columns:
                df['stress_label'] = (df['mental_health_condition'] == 1).astype(int)
            else:
                print(f"  ✗ 无法创建标签")
                return None
                
        elif dataset_name == "Mental_Health_Pred":
            # 基于心理健康状况创建标签
            if 'Mental_Health_Condition' in df.columns:
                df['stress_label'] = (df['Mental_Health_Condition'] == 1).astype(int)
            else:
                print(f"  ✗ 无法创建标签")
                return None
                
        else:
            # 其他数据集：基于数值特征创建标签
            numeric_cols = df.select_dtypes(include=[np.number]).columns
            if len(numeric_cols) > 0:
                # 使用第一个数值列的上30%作为压力
                threshold = df[numeric_cols[0]].quantile(0.7)
                df['stress_label'] = (df[numeric_cols[0]] > threshold).astype(int)
            else:
                print(f"  ✗ 无法创建标签")
                return None
        
        # 检查标签分布
        label_counts = df['stress_label'].value_counts()
        print(f"  标签分布: {dict(label_counts)}")
        
        if len(label_counts) < 2:
            print(f"  ✗ 标签类别不足")
            return None
            
        return df
    
    def preprocess_data(self, df, dataset_name):
        """预处理数据"""
        print(f"  [{dataset_name}] 预处理数据...")
        
        # 选择数值特征
        numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        
        # 移除标签列
        if 'stress_label' in numeric_cols:
            numeric_cols.remove('stress_label')
            
        if len(numeric_cols) < 1:
            print(f"  ✗ 数值特征不足: {len(numeric_cols)}")
            return None, None, None
            
        # 如果只有一个特征，创建一些衍生特征
        if len(numeric_cols) == 1:
            print(f"  只有一个特征，创建衍生特征...")
            base_col = numeric_cols[0]
            df[f'{base_col}_squared'] = df[base_col] ** 2
            df[f'{base_col}_log'] = np.log1p(np.abs(df[base_col]))
            df[f'{base_col}_rolling_mean'] = df[base_col].rolling(window=5, min_periods=1).mean()
            numeric_cols = [base_col, f'{base_col}_squared', f'{base_col}_log', f'{base_col}_rolling_mean']
            
        # 处理缺失值
        df_clean = df[numeric_cols + ['stress_label']].fillna(df[numeric_cols].median())
        
        # 限制样本数量
        max_samples = 10000
        if len(df_clean) > max_samples:
            print(f"  限制样本数量: {len(df_clean)} -> {max_samples}")
            df_clean = df_clean.sample(n=max_samples, random_state=self.random_seed)
        
        X = df_clean[numeric_cols].values
        y = df_clean['stress_label'].values
        
        print(f"  ✓ 预处理完成: X={X.shape}, y={y.shape}")
        return X, y, numeric_cols
    
    def train_baseline_models(self, X, y, dataset_name):
        """训练基线模型"""
        print(f"  [{dataset_name}] 训练基线模型...")
        
        # 数据分割
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=self.random_seed, stratify=y
        )
        
        # 标准化
        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train)
        X_test_scaled = scaler.transform(X_test)
        
        models = {
            'SVM': SVC(probability=True, random_state=self.random_seed),
            'RandomForest': RandomForestClassifier(n_estimators=100, random_state=self.random_seed),
            'LogisticRegression': LogisticRegression(random_state=self.random_seed)
        }
        
        results = {}
        
        for name, model in models.items():
            print(f"    训练 {name}...")
            
            # 训练模型
            model.fit(X_train_scaled, y_train)
            y_pred_proba = model.predict_proba(X_test_scaled)[:, 1]
            
            # 计算ROC曲线
            fpr, tpr, _ = roc_curve(y_test, y_pred_proba)
            roc_auc = auc(fpr, tpr)
            
            # 计算其他指标
            y_pred = (y_pred_proba > 0.5).astype(int)
            precision = precision_score(y_test, y_pred)
            recall = recall_score(y_test, y_pred)
            f1 = f1_score(y_test, y_pred)
            
            results[name] = {
                'fpr': fpr.tolist(),
                'tpr': tpr.tolist(),
                'auc': roc_auc,
                'precision': precision,
                'recall': recall,
                'f1': f1,
                'y_test': y_test.tolist(),
                'y_pred_proba': y_pred_proba.tolist()
            }
            
            print(f"      AUC: {roc_auc:.4f}, Precision: {precision:.4f}, Recall: {recall:.4f}, F1: {f1:.4f}")
        
        return results
    
    def create_lstm_model(self, input_size, hidden_size=64, num_layers=2):
        """创建LSTM模型 - WSL优化版本"""
        class LSTMModel(nn.Module):
            def __init__(self, input_size, hidden_size, num_layers):
                super(LSTMModel, self).__init__()
                self.hidden_size = hidden_size
                self.num_layers = num_layers
                
                self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True, dropout=0.2)
                self.dropout = nn.Dropout(0.3)
                self.fc = nn.Linear(hidden_size, 1)
                self.sigmoid = nn.Sigmoid()
                
            def forward(self, x):
                h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size, device=x.device)
                c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size, device=x.device)
                
                out, _ = self.lstm(x, (h0, c0))
                out = self.dropout(out[:, -1, :])
                out = self.fc(out)
                out = self.sigmoid(out)
                return out
        
        return LSTMModel(input_size, hidden_size, num_layers)
    
    def train_lstm_model(self, X, y, dataset_name):
        """训练LSTM模型 - WSL优化版本"""
        if not TORCH_AVAILABLE:
            print(f"  [{dataset_name}] PyTorch不可用，跳过LSTM训练")
            return None
            
        print(f"  [{dataset_name}] 训练LSTM模型...")
        
        # 数据分割
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=self.random_seed, stratify=y
        )
        
        # 标准化
        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train)
        X_test_scaled = scaler.transform(X_test)
        
        # 转换为序列数据
        sequence_length = 10
        X_train_seq = []
        y_train_seq = []
        
        for i in range(sequence_length, len(X_train_scaled)):
            X_train_seq.append(X_train_scaled[i-sequence_length:i])
            y_train_seq.append(y_train[i])
        
        X_test_seq = []
        y_test_seq = []
        
        for i in range(sequence_length, len(X_test_scaled)):
            X_test_seq.append(X_test_scaled[i-sequence_length:i])
            y_test_seq.append(y_test[i])
        
        X_train_seq = np.array(X_train_seq)
        y_train_seq = np.array(y_train_seq)
        X_test_seq = np.array(X_test_seq)
        y_test_seq = np.array(y_test_seq)
        
        # 转换为PyTorch张量 - WSL优化
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        print(f"    使用设备: {device}")
        
        try:
            X_train_tensor = torch.FloatTensor(X_train_seq).to(device)
            y_train_tensor = torch.FloatTensor(y_train_seq).to(device)
            X_test_tensor = torch.FloatTensor(X_test_seq).to(device)
            y_test_tensor = torch.FloatTensor(y_test_seq).to(device)
        except Exception as e:
            print(f"    CUDA错误，回退到CPU: {e}")
            device = torch.device('cpu')
            X_train_tensor = torch.FloatTensor(X_train_seq)
            y_train_tensor = torch.FloatTensor(y_train_seq)
            X_test_tensor = torch.FloatTensor(X_test_seq)
            y_test_tensor = torch.FloatTensor(y_test_seq)
        
        # 创建数据加载器
        train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
        train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
        
        # 创建模型
        model = self.create_lstm_model(X.shape[1]).to(device)
        criterion = nn.BCELoss()
        optimizer = optim.Adam(model.parameters(), lr=0.001, weight_decay=1e-5)
        scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, patience=5, factor=0.5)
        
        # 训练模型 - WSL优化
        model.train()
        best_loss = float('inf')
        patience_counter = 0
        
        for epoch in range(100):  # 增加epoch数
            total_loss = 0
            for batch_X, batch_y in train_loader:
                optimizer.zero_grad()
                outputs = model(batch_X).squeeze()
                loss = criterion(outputs, batch_y)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                optimizer.step()
                total_loss += loss.item()
            
            avg_loss = total_loss / len(train_loader)
            scheduler.step(avg_loss)
            
            if avg_loss < best_loss:
                best_loss = avg_loss
                patience_counter = 0
            else:
                patience_counter += 1
            
            if (epoch + 1) % 20 == 0:
                print(f"      Epoch {epoch+1}/100, Loss: {avg_loss:.4f}, LR: {optimizer.param_groups[0]['lr']:.6f}")
            
            if patience_counter >= 10:
                print(f"      早停于epoch {epoch+1}")
                break
        
        # 评估模型
        model.eval()
        with torch.no_grad():
            y_pred_proba = model(X_test_tensor).squeeze().cpu().numpy()
        
        # 计算ROC曲线
        fpr, tpr, _ = roc_curve(y_test_seq, y_pred_proba)
        roc_auc = auc(fpr, tpr)
        
        # 计算其他指标
        y_pred = (y_pred_proba > 0.5).astype(int)
        precision = precision_score(y_test_seq, y_pred)
        recall = recall_score(y_test_seq, y_pred)
        f1 = f1_score(y_test_seq, y_pred)
        
        result = {
            'fpr': fpr.tolist(),
            'tpr': tpr.tolist(),
            'auc': roc_auc,
            'precision': precision,
            'recall': recall,
            'f1': f1,
            'y_test': y_test_seq.tolist(),
            'y_pred_proba': y_pred_proba.tolist()
        }
        
        print(f"      AUC: {roc_auc:.4f}, Precision: {precision:.4f}, Recall: {recall:.4f}, F1: {f1:.4f}")
        
        return result
    
    def analyze_dataset(self, dataset_name):
        """分析单个数据集"""
        print(f"\n[{dataset_name}] 开始ROC/AUC分析...")
        
        # 加载数据
        df = self.load_dataset(dataset_name)
        if df is None:
            return None
            
        # 创建标签
        df = self.create_stress_labels(df, dataset_name)
        if df is None:
            return None
            
        # 预处理数据
        X, y, feature_names = self.preprocess_data(df, dataset_name)
        if X is None:
            return None
            
        # 训练基线模型
        baseline_results = self.train_baseline_models(X, y, dataset_name)
        
        # 训练LSTM模型
        lstm_result = self.train_lstm_model(X, y, dataset_name)
        
        result = {
            'dataset_name': dataset_name,
            'n_samples': len(X),
            'n_features': len(feature_names),
            'feature_names': feature_names,
            'baseline_results': baseline_results,
            'lstm_result': lstm_result
        }
        
        print(f"  ✓ 分析完成")
        return result
    
    def analyze_all_datasets(self):
        """分析所有数据集"""
        print("开始ROC/AUC分析...")
        
        datasets = ["WESAD", "MMASH", "CRWD", "Enhanced_Health", "Global_Mental_Health", "Mental_Health_Pred"]
        
        for dataset_name in datasets:
            result = self.analyze_dataset(dataset_name)
            if result:
                self.results.append(result)
        
        print(f"\n✅ 成功分析 {len(self.results)} 个数据集")
        return self.results
    
    def generate_csv_report(self):
        """生成CSV报告"""
        print("\n生成 roc_auc_results.csv...")
        
        csv_data = []
        for result in self.results:
            dataset_name = result['dataset_name']
            
            # 基线模型结果
            for model_name, model_result in result['baseline_results'].items():
                csv_data.append({
                    'Dataset': dataset_name,
                    'Model': model_name,
                    'AUC': model_result['auc'],
                    'Precision': model_result['precision'],
                    'Recall': model_result['recall'],
                    'F1_Score': model_result['f1'],
                    'Model_Type': 'Baseline'
                })
            
            # LSTM模型结果
            if result['lstm_result']:
                lstm_result = result['lstm_result']
                csv_data.append({
                    'Dataset': dataset_name,
                    'Model': 'LSTM',
                    'AUC': lstm_result['auc'],
                    'Precision': lstm_result['precision'],
                    'Recall': lstm_result['recall'],
                    'F1_Score': lstm_result['f1'],
                    'Model_Type': 'Deep Learning'
                })
        
        df = pd.DataFrame(csv_data)
        df.to_csv("roc_auc_results.csv", index=False, encoding='utf-8-sig')
        print("  ✓ roc_auc_results.csv 已生成")
        
        return df
    
    def create_roc_curves_plot(self):
        """创建ROC曲线图"""
        print("\n生成 roc_curves.png...")
        
        fig, axes = plt.subplots(2, 3, figsize=(18, 12))
        axes = axes.flatten()
        
        for i, result in enumerate(self.results):
            ax = axes[i]
            dataset_name = result['dataset_name']
            
            # 绘制基线模型ROC曲线
            for model_name, model_result in result['baseline_results'].items():
                fpr = model_result['fpr']
                tpr = model_result['tpr']
                auc_score = model_result['auc']
                ax.plot(fpr, tpr, label=f'{model_name} (AUC = {auc_score:.3f})')
            
            # 绘制LSTM模型ROC曲线
            if result['lstm_result']:
                lstm_result = result['lstm_result']
                fpr = lstm_result['fpr']
                tpr = lstm_result['tpr']
                auc_score = lstm_result['auc']
                ax.plot(fpr, tpr, label=f'LSTM (AUC = {auc_score:.3f})', linestyle='--', linewidth=2)
            
            # 绘制对角线
            ax.plot([0, 1], [0, 1], 'k--', alpha=0.5)
            
            ax.set_xlabel('False Positive Rate')
            ax.set_ylabel('True Positive Rate')
            ax.set_title(f'{dataset_name} ROC Curves')
            ax.legend()
            ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig('roc_curves.png', dpi=300, bbox_inches='tight')
        print("  ✓ roc_curves.png 已生成")
        
        return fig
    
    def create_comparison_plot(self):
        """创建模型对比图"""
        print("\n生成 model_comparison.png...")
        
        # 准备数据
        datasets = []
        models = []
        aucs = []
        precisions = []
        recalls = []
        f1s = []
        
        for result in self.results:
            dataset_name = result['dataset_name']
            
            # 基线模型
            for model_name, model_result in result['baseline_results'].items():
                datasets.append(dataset_name)
                models.append(model_name)
                aucs.append(model_result['auc'])
                precisions.append(model_result['precision'])
                recalls.append(model_result['recall'])
                f1s.append(model_result['f1'])
            
            # LSTM模型
            if result['lstm_result']:
                lstm_result = result['lstm_result']
                datasets.append(dataset_name)
                models.append('LSTM')
                aucs.append(lstm_result['auc'])
                precisions.append(lstm_result['precision'])
                recalls.append(lstm_result['recall'])
                f1s.append(lstm_result['f1'])
        
        # 创建对比图
        fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(16, 12))
        
        # 1. AUC对比
        df_plot = pd.DataFrame({
            'Dataset': datasets,
            'Model': models,
            'AUC': aucs
        })
        
        sns.barplot(data=df_plot, x='Dataset', y='AUC', hue='Model', ax=ax1)
        ax1.set_title('AUC对比')
        ax1.tick_params(axis='x', rotation=45)
        
        # 2. Precision对比
        df_plot['Precision'] = precisions
        sns.barplot(data=df_plot, x='Dataset', y='Precision', hue='Model', ax=ax2)
        ax2.set_title('Precision对比')
        ax2.tick_params(axis='x', rotation=45)
        
        # 3. Recall对比
        df_plot['Recall'] = recalls
        sns.barplot(data=df_plot, x='Dataset', y='Recall', hue='Model', ax=ax3)
        ax3.set_title('Recall对比')
        ax3.tick_params(axis='x', rotation=45)
        
        # 4. F1 Score对比
        df_plot['F1_Score'] = f1s
        sns.barplot(data=df_plot, x='Dataset', y='F1_Score', hue='Model', ax=ax4)
        ax4.set_title('F1 Score对比')
        ax4.tick_params(axis='x', rotation=45)
        
        plt.tight_layout()
        plt.savefig('model_comparison.png', dpi=300, bbox_inches='tight')
        print("  ✓ model_comparison.png 已生成")
        
        return fig
    
    def generate_summary_report(self):
        """生成摘要报告"""
        print("\n生成ROC/AUC分析摘要...")
        
        # 计算平均性能
        all_aucs = []
        all_precisions = []
        all_recalls = []
        all_f1s = []
        
        for result in self.results:
            for model_result in result['baseline_results'].values():
                all_aucs.append(model_result['auc'])
                all_precisions.append(model_result['precision'])
                all_recalls.append(model_result['recall'])
                all_f1s.append(model_result['f1'])
            
            if result['lstm_result']:
                lstm_result = result['lstm_result']
                all_aucs.append(lstm_result['auc'])
                all_precisions.append(lstm_result['precision'])
                all_recalls.append(lstm_result['recall'])
                all_f1s.append(lstm_result['f1'])
        
        summary = {
            'analysis_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'total_datasets': len(self.results),
            'total_models': len(all_aucs),
            'average_auc': np.mean(all_aucs),
            'average_precision': np.mean(all_precisions),
            'average_recall': np.mean(all_recalls),
            'average_f1': np.mean(all_f1s),
            'best_auc': max(all_aucs),
            'worst_auc': min(all_aucs),
            'pytorch_version': torch.__version__ if TORCH_AVAILABLE else 'Not available',
            'cuda_available': torch.cuda.is_available() if TORCH_AVAILABLE else False
        }
        
        print(f"  分析日期: {summary['analysis_date']}")
        print(f"  数据集数量: {summary['total_datasets']}")
        print(f"  模型数量: {summary['total_models']}")
        print(f"  平均AUC: {summary['average_auc']:.4f}")
        print(f"  平均Precision: {summary['average_precision']:.4f}")
        print(f"  平均Recall: {summary['average_recall']:.4f}")
        print(f"  平均F1: {summary['average_f1']:.4f}")
        print(f"  最佳AUC: {summary['best_auc']:.4f}")
        print(f"  最差AUC: {summary['worst_auc']:.4f}")
        print(f"  PyTorch版本: {summary['pytorch_version']}")
        print(f"  CUDA可用: {summary['cuda_available']}")
        
        return summary

def main():
    """主函数"""
    analyzer = ROCAUCAnalyzerWSL()
    
    # 分析所有数据集
    results = analyzer.analyze_all_datasets()
    
    if not results:
        print("❌ 没有成功分析任何数据集")
        return
    
    # 生成CSV报告
    csv_df = analyzer.generate_csv_report()
    
    # 创建可视化
    roc_fig = analyzer.create_roc_curves_plot()
    comp_fig = analyzer.create_comparison_plot()
    
    # 生成摘要报告
    summary = analyzer.generate_summary_report()
    
    # 保存详细结果
    with open('roc_auc_detailed.json', 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    
    # 保存摘要报告
    with open('roc_auc_summary.json', 'w', encoding='utf-8') as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    
    # 打印完成信息
    print("\n" + "="*80)
    print("第三步完成：ROC/AUC分析 - WSL版本")
    print("="*80)
    print(f"✅ 分析数据集数量: {len(results)}")
    print(f"✅ 总模型数量: {summary['total_models']}")
    print(f"✅ 平均AUC: {summary['average_auc']:.4f}")
    print(f"✅ 最佳AUC: {summary['best_auc']:.4f}")
    print(f"✅ PyTorch版本: {summary['pytorch_version']}")
    print(f"✅ CUDA可用: {summary['cuda_available']}")
    print(f"✅ 生成文件:")
    print("   - roc_auc_results.csv")
    print("   - roc_curves.png")
    print("   - model_comparison.png")
    print("   - roc_auc_detailed.json")
    print("   - roc_auc_summary.json")
    print("="*80)

if __name__ == "__main__":
    main()





