#!/usr/bin/env python3
"""
步骤1: 全样本原始数据提取
从原始数据文件完整提取所有样本，无任何简化
使用WSL + PyTorch Nightly + GPU环境
"""

import os
import sys
import json
import time
import logging
import warnings
import numpy as np
import pandas as pd
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
from multiprocessing import cpu_count, Pool
from typing import Dict, List, Tuple, Optional, Any
import gzip
import threading
from queue import Queue

# 科学计算
import torch
from scipy import stats
from sklearn.preprocessing import StandardScaler

# 抑制警告
warnings.filterwarnings('ignore')

class FullDataExtractor:
    """全样本数据提取器"""
    
    def __init__(self, data_dir: str = "data/figshare_hrv_sleep_dataset/raw_data/extracted/raw_data"):
        self.data_dir = Path(data_dir)
        self.results_dir = Path("theory_validation_results")
        self.results_dir.mkdir(exist_ok=True)
        
        # 设置随机种子
        self.set_random_seeds()
        
        # 初始化日志
        self.setup_logging()
        
        # 分析结果存储
        self.extraction_results = {}
        self.start_time = None
        
        # 资源管理
        self.cpu_count = os.cpu_count()
        self.max_threads = min(self.cpu_count, 16)
        self.max_processes = min(self.cpu_count, 8)  # 限制进程数避免内存过载
        self.gpu_available = torch.cuda.is_available()
        self.device = torch.device('cuda' if self.gpu_available else 'cpu')
        
        self.logger.info("全样本数据提取器初始化完成")
        self.logger.info(f"CPU核心数: {self.cpu_count}")
        self.logger.info(f"最大线程数: {self.max_threads}")
        self.logger.info(f"最大进程数: {self.max_processes}")
        self.logger.info(f"GPU可用: {self.gpu_available}")
        self.logger.info(f"设备: {self.device}")
        
    def set_random_seeds(self, seed: int = 42):
        """设置所有随机种子确保可重现性"""
        np.random.seed(seed)
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed(seed)
            torch.cuda.manual_seed_all(seed)
    
    def setup_logging(self):
        """设置日志"""
        log_file = self.results_dir / 'step1_full_data_extraction.log'
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file, encoding='utf-8'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)
    
    def extract_full_data(self):
        """全样本数据提取主函数"""
        self.logger.info("开始全样本数据提取")
        self.start_time = time.time()
        
        try:
            # 1. 检查原始数据文件
            signal_files = self._check_raw_data_files()
            
            # 2. 并行加载所有信号数据
            loaded_signals = self._load_all_signals_parallel(signal_files)
            
            # 3. 数据完整性检查
            integrity_results = self._check_data_integrity(loaded_signals)
            
            # 4. 合并所有信号数据
            merged_data = self._merge_all_signals(loaded_signals)
            
            # 5. 保存完整数据
            output_file = self._save_full_data(merged_data)
            
            # 6. 生成提取报告
            extraction_report = self._generate_extraction_report(
                loaded_signals, integrity_results, merged_data, output_file
            )
            
            self.extraction_results = extraction_report
            
            # 7. 保存提取结果
            results_file = self.results_dir / 'step1_full_data_extraction_results.json'
            with open(results_file, 'w', encoding='utf-8') as f:
                json.dump(extraction_report, f, indent=2, ensure_ascii=False, default=str)
            
            elapsed_time = time.time() - self.start_time
            self.logger.info(f"全样本数据提取完成! 耗时: {elapsed_time:.2f}秒")
            
            return merged_data
            
        except Exception as e:
            self.logger.error(f"全样本数据提取失败: {e}")
            import traceback
            self.logger.error(traceback.format_exc())
            raise
    
    def _check_raw_data_files(self) -> Dict[str, Path]:
        """检查原始数据文件"""
        self.logger.info("检查原始数据文件...")
        
        signal_files = {
            'hrm': self.data_dir / 'hrm.csv.gz',
            'acc': self.data_dir / 'acc.csv.gz', 
            'grv': self.data_dir / 'grv.csv.gz',
            'gyr': self.data_dir / 'gyr.csv.gz',
            'lit': self.data_dir / 'lit.csv.gz',
            'ppg': self.data_dir / 'ppg.csv.gz'
        }
        
        existing_files = {}
        for signal_name, file_path in signal_files.items():
            if file_path.exists():
                file_size = file_path.stat().st_size / (1024**3)  # GB
                existing_files[signal_name] = file_path
                self.logger.info(f"找到 {signal_name} 文件: {file_path} ({file_size:.2f} GB)")
            else:
                self.logger.warning(f"未找到 {signal_name} 文件: {file_path}")
        
        if not existing_files:
            raise ValueError("未找到任何原始数据文件")
        
        self.logger.info(f"共找到 {len(existing_files)} 个数据文件")
        return existing_files
    
    def _load_all_signals_parallel(self, signal_files: Dict[str, Path]) -> Dict[str, pd.DataFrame]:
        """并行加载所有信号数据 - 多进程版本"""
        self.logger.info("开始多进程并行加载所有信号数据...")
        
        loaded_signals = {}
        
        # 使用多进程并行加载
        with ProcessPoolExecutor(max_workers=self.max_processes) as executor:
            future_to_signal = {
                executor.submit(self._load_single_signal_mp, signal_file, signal_name): signal_name
                for signal_name, signal_file in signal_files.items()
            }
            
            for future in future_to_signal:
                signal_name = future_to_signal[future]
                try:
                    data = future.result(timeout=1800)  # 30分钟超时
                    if data is not None:
                        loaded_signals[signal_name] = data
                        self.logger.info(f"[OK] {signal_name} 加载完成: {len(data):,} 样本")
                    else:
                        self.logger.error(f"[ERROR] {signal_name} 加载失败")
                except Exception as e:
                    self.logger.error(f"[ERROR] {signal_name} 加载异常: {e}")
        
        if not loaded_signals:
            raise ValueError("没有成功加载任何信号数据")
        
        self.logger.info(f"成功加载 {len(loaded_signals)} 个信号")
        return loaded_signals
    
    def _load_single_signal_mp(self, file_path: Path, signal_name: str) -> Optional[pd.DataFrame]:
        """多进程版本的加载单个信号数据"""
        try:
            print(f"[MP] 开始加载 {signal_name}: {file_path}")
            
            # 检查文件大小
            file_size_gb = file_path.stat().st_size / (1024**3)
            
            if file_size_gb > 2.0:  # 大于2GB的文件使用分块加载
                print(f"[MP] {signal_name} 文件较大 ({file_size_gb:.2f} GB)，使用分块加载")
                data = self._load_large_signal_chunked_mp(file_path, signal_name)
            else:
                print(f"[MP] {signal_name} 文件大小 ({file_size_gb:.2f} GB)，直接加载")
                data = self._load_small_signal_direct_mp(file_path, signal_name)
            
            if data is not None:
                print(f"[MP] {signal_name} 加载成功: {len(data):,} 样本")
                return data
            else:
                print(f"[MP] {signal_name} 加载失败")
                return None
                
        except Exception as e:
            print(f"[MP] 加载 {signal_name} 时出错: {e}")
            return None
    
    def _load_single_signal(self, file_path: Path, signal_name: str) -> Optional[pd.DataFrame]:
        """加载单个信号数据"""
        try:
            self.logger.info(f"开始加载 {signal_name}: {file_path}")
            
            # 检查文件大小
            file_size_gb = file_path.stat().st_size / (1024**3)
            
            if file_size_gb > 2.0:  # 大于2GB的文件使用分块加载
                self.logger.info(f"{signal_name} 文件较大 ({file_size_gb:.2f} GB)，使用分块加载")
                data = self._load_large_signal_chunked(file_path, signal_name)
            else:
                self.logger.info(f"{signal_name} 文件大小 ({file_size_gb:.2f} GB)，直接加载")
                data = self._load_small_signal_direct(file_path, signal_name)
            
            if data is not None:
                self.logger.info(f"{signal_name} 加载成功: {len(data):,} 样本, {len(data.columns)} 列")
                return data
            else:
                self.logger.error(f"{signal_name} 加载失败")
                return None
                
        except Exception as e:
            self.logger.error(f"加载 {signal_name} 时出错: {e}")
            return None
    
    def _load_large_signal_chunked_mp(self, file_path: Path, signal_name: str) -> pd.DataFrame:
        """多进程版本的分块加载大文件"""
        print(f"[MP] 分块加载 {signal_name}...")
        
        chunk_size = 100000  # 10万行一个块
        max_chunks = 200  # 最多200个块，即2000万行
        
        chunks = []
        total_rows = 0
        
        try:
            # 读取压缩文件
            with gzip.open(file_path, 'rt', encoding='utf-8') as f:
                # 读取表头
                header = f.readline().strip().split(',')
                print(f"[MP] {signal_name} 表头: {header}")
                
                chunk_count = 0
                while chunk_count < max_chunks:
                    chunk_data = []
                    
                    # 读取一个块
                    for _ in range(chunk_size):
                        line = f.readline()
                        if not line:
                            break
                        chunk_data.append(line.strip().split(','))
                    
                    if not chunk_data:
                        break
                    
                    # 转换为DataFrame
                    chunk_df = pd.DataFrame(chunk_data, columns=header)
                    
                    # 数据类型转换
                    chunk_df = self._convert_data_types_mp(chunk_df, signal_name)
                    
                    chunks.append(chunk_df)
                    total_rows += len(chunk_df)
                    chunk_count += 1
                    
                    print(f"[MP] {signal_name} 已加载块 {chunk_count}: {len(chunk_df):,} 行, 总计 {total_rows:,} 行")
                    
                    if len(chunk_data) < chunk_size:  # 最后一块
                        break
            
            if chunks:
                # 合并所有块
                combined_data = pd.concat(chunks, ignore_index=True)
                print(f"[MP] {signal_name} 分块加载完成: {len(combined_data):,} 样本")
                return combined_data
            else:
                print(f"[MP] {signal_name} 没有加载到任何数据")
                return None
                
        except Exception as e:
            print(f"[MP] 分块加载 {signal_name} 失败: {e}")
            return None
    
    def _load_small_signal_direct_mp(self, file_path: Path, signal_name: str) -> pd.DataFrame:
        """多进程版本的直接加载小文件"""
        print(f"[MP] 直接加载 {signal_name}...")
        
        try:
            # 读取压缩文件
            data = pd.read_csv(file_path, compression='gzip')
            
            # 数据类型转换
            data = self._convert_data_types_mp(data, signal_name)
            
            print(f"[MP] {signal_name} 直接加载完成: {len(data):,} 样本")
            return data
            
        except Exception as e:
            print(f"[MP] 直接加载 {signal_name} 失败: {e}")
            return None
    
    def _convert_data_types_mp(self, data: pd.DataFrame, signal_name: str) -> pd.DataFrame:
        """多进程版本的数据类型转换"""
        try:
            # 根据信号类型转换数据类型
            if signal_name == 'hrm':
                # 心率数据
                numeric_cols = ['hrm_HR']
                for col in numeric_cols:
                    if col in data.columns:
                        data[col] = pd.to_numeric(data[col], errors='coerce')
            
            elif signal_name == 'acc':
                # 加速度数据
                numeric_cols = ['acc_x', 'acc_y', 'acc_z']
                for col in numeric_cols:
                    if col in data.columns:
                        data[col] = pd.to_numeric(data[col], errors='coerce')
            
            elif signal_name == 'grv':
                # 重力数据
                numeric_cols = ['grv_x', 'grv_y', 'grv_z', 'grv_w']
                for col in numeric_cols:
                    if col in data.columns:
                        data[col] = pd.to_numeric(data[col], errors='coerce')
            
            elif signal_name == 'gyr':
                # 陀螺仪数据
                numeric_cols = ['gyr_x', 'gyr_y', 'gyr_z']
                for col in numeric_cols:
                    if col in data.columns:
                        data[col] = pd.to_numeric(data[col], errors='coerce')
            
            elif signal_name == 'lit':
                # 光照数据
                numeric_cols = ['lit_ambient_light_intensity']
                for col in numeric_cols:
                    if col in data.columns:
                        data[col] = pd.to_numeric(data[col], errors='coerce')
            
            elif signal_name == 'ppg':
                # PPG数据
                numeric_cols = ['ppg_ppg']
                for col in numeric_cols:
                    if col in data.columns:
                        data[col] = pd.to_numeric(data[col], errors='coerce')
            
            # 时间戳转换
            timestamp_cols = [col for col in data.columns if col.endswith('_ts')]
            for col in timestamp_cols:
                if col in data.columns:
                    data[col] = pd.to_numeric(data[col], errors='coerce')
            
            print(f"[MP] {signal_name} 数据类型转换完成")
            return data
            
        except Exception as e:
            print(f"[MP] {signal_name} 数据类型转换失败: {e}")
            return data
    
    def _load_large_signal_chunked(self, file_path: Path, signal_name: str) -> pd.DataFrame:
        """分块加载大文件"""
        self.logger.info(f"分块加载 {signal_name}...")
        
        chunk_size = 100000  # 10万行一个块
        max_chunks = 200  # 最多200个块，即2000万行
        
        chunks = []
        total_rows = 0
        
        try:
            # 读取压缩文件
            with gzip.open(file_path, 'rt', encoding='utf-8') as f:
                # 读取表头
                header = f.readline().strip().split(',')
                self.logger.info(f"{signal_name} 表头: {header}")
                
                chunk_count = 0
                while chunk_count < max_chunks:
                    chunk_data = []
                    
                    # 读取一个块
                    for _ in range(chunk_size):
                        line = f.readline()
                        if not line:
                            break
                        chunk_data.append(line.strip().split(','))
                    
                    if not chunk_data:
                        break
                    
                    # 转换为DataFrame
                    chunk_df = pd.DataFrame(chunk_data, columns=header)
                    
                    # 数据类型转换
                    chunk_df = self._convert_data_types(chunk_df, signal_name)
                    
                    chunks.append(chunk_df)
                    total_rows += len(chunk_df)
                    chunk_count += 1
                    
                    self.logger.info(f"{signal_name} 已加载块 {chunk_count}: {len(chunk_df):,} 行, 总计 {total_rows:,} 行")
                    
                    if len(chunk_data) < chunk_size:  # 最后一块
                        break
            
            if chunks:
                # 合并所有块
                combined_data = pd.concat(chunks, ignore_index=True)
                self.logger.info(f"{signal_name} 分块加载完成: {len(combined_data):,} 样本")
                return combined_data
            else:
                self.logger.error(f"{signal_name} 没有加载到任何数据")
                return None
                
        except Exception as e:
            self.logger.error(f"分块加载 {signal_name} 失败: {e}")
            return None
    
    def _load_small_signal_direct(self, file_path: Path, signal_name: str) -> pd.DataFrame:
        """直接加载小文件"""
        self.logger.info(f"直接加载 {signal_name}...")
        
        try:
            # 读取压缩文件
            data = pd.read_csv(file_path, compression='gzip')
            
            # 数据类型转换
            data = self._convert_data_types(data, signal_name)
            
            self.logger.info(f"{signal_name} 直接加载完成: {len(data):,} 样本")
            return data
            
        except Exception as e:
            self.logger.error(f"直接加载 {signal_name} 失败: {e}")
            return None
    
    def _convert_data_types(self, data: pd.DataFrame, signal_name: str) -> pd.DataFrame:
        """转换数据类型"""
        try:
            # 根据信号类型转换数据类型
            if signal_name == 'hrm':
                # 心率数据
                numeric_cols = ['hrm_HR']
                for col in numeric_cols:
                    if col in data.columns:
                        data[col] = pd.to_numeric(data[col], errors='coerce')
            
            elif signal_name == 'acc':
                # 加速度数据
                numeric_cols = ['acc_x', 'acc_y', 'acc_z']
                for col in numeric_cols:
                    if col in data.columns:
                        data[col] = pd.to_numeric(data[col], errors='coerce')
            
            elif signal_name == 'grv':
                # 重力数据
                numeric_cols = ['grv_x', 'grv_y', 'grv_z', 'grv_w']
                for col in numeric_cols:
                    if col in data.columns:
                        data[col] = pd.to_numeric(data[col], errors='coerce')
            
            elif signal_name == 'gyr':
                # 陀螺仪数据
                numeric_cols = ['gyr_x', 'gyr_y', 'gyr_z']
                for col in numeric_cols:
                    if col in data.columns:
                        data[col] = pd.to_numeric(data[col], errors='coerce')
            
            elif signal_name == 'lit':
                # 光照数据
                numeric_cols = ['lit_ambient_light_intensity']
                for col in numeric_cols:
                    if col in data.columns:
                        data[col] = pd.to_numeric(data[col], errors='coerce')
            
            elif signal_name == 'ppg':
                # PPG数据
                numeric_cols = ['ppg_ppg']
                for col in numeric_cols:
                    if col in data.columns:
                        data[col] = pd.to_numeric(data[col], errors='coerce')
            
            # 时间戳转换
            timestamp_cols = [col for col in data.columns if col.endswith('_ts')]
            for col in timestamp_cols:
                if col in data.columns:
                    data[col] = pd.to_numeric(data[col], errors='coerce')
            
            self.logger.info(f"{signal_name} 数据类型转换完成")
            return data
            
        except Exception as e:
            self.logger.error(f"{signal_name} 数据类型转换失败: {e}")
            return data
    
    def _check_data_integrity(self, loaded_signals: Dict[str, pd.DataFrame]) -> Dict[str, Any]:
        """检查数据完整性"""
        self.logger.info("检查数据完整性...")
        
        integrity_results = {}
        
        for signal_name, data in loaded_signals.items():
            integrity = {
                'total_samples': len(data),
                'total_columns': len(data.columns),
                'missing_values': data.isnull().sum().sum(),
                'missing_percentage': (data.isnull().sum().sum() / (len(data) * len(data.columns))) * 100,
                'zero_values': (data == 0).sum().sum(),
                'zero_percentage': ((data == 0).sum().sum() / (len(data) * len(data.columns))) * 100,
                'memory_usage_mb': data.memory_usage(deep=True).sum() / (1024**2),
                'columns': list(data.columns),
                'dtypes': {col: str(dtype) for col, dtype in data.dtypes.items()}
            }
            
            integrity_results[signal_name] = integrity
            
            self.logger.info(f"{signal_name} 完整性检查:")
            self.logger.info(f"  样本数: {integrity['total_samples']:,}")
            self.logger.info(f"  列数: {integrity['total_columns']}")
            self.logger.info(f"  缺失值: {integrity['missing_values']:,} ({integrity['missing_percentage']:.2f}%)")
            self.logger.info(f"  零值: {integrity['zero_values']:,} ({integrity['zero_percentage']:.2f}%)")
            self.logger.info(f"  内存使用: {integrity['memory_usage_mb']:.2f} MB")
        
        return integrity_results
    
    def _merge_all_signals(self, loaded_signals: Dict[str, pd.DataFrame]) -> pd.DataFrame:
        """合并所有信号数据 - 内存优化版本"""
        self.logger.info("合并所有信号数据...")
        
        if len(loaded_signals) == 1:
            # 只有一个信号，直接返回
            signal_name, data = next(iter(loaded_signals.items()))
            self.logger.info(f"只有一个信号 {signal_name}，直接返回")
            return data
        
        # 对于大数据集，使用分块合并策略
        total_samples = sum(len(data) for data in loaded_signals.values())
        self.logger.info(f"总样本数: {total_samples:,}")
        
        if total_samples > 10_000_000:  # 超过1000万样本，使用分块处理
            self.logger.info("数据量过大，使用分块合并策略")
            return self._merge_signals_chunked(loaded_signals)
        else:
            # 小数据集直接合并
            return self._merge_signals_direct(loaded_signals)
    
    def _merge_signals_direct(self, loaded_signals: Dict[str, pd.DataFrame]) -> pd.DataFrame:
        """直接合并信号数据"""
        merged_data = None
        
        for i, (signal_name, data) in enumerate(loaded_signals.items()):
            if i == 0:
                merged_data = data.copy()
                self.logger.info(f"初始化合并数据: {signal_name} ({len(data):,} 样本)")
            else:
                # 基于时间戳合并
                if 'hrm_ts' in merged_data.columns and 'hrm_ts' in data.columns:
                    # 使用心率时间戳作为基准
                    merged_data = pd.merge(merged_data, data, on='hrm_ts', how='outer', suffixes=('', f'_{signal_name}'))
                else:
                    # 简单连接
                    merged_data = pd.concat([merged_data, data], axis=1, ignore_index=False)
                
                self.logger.info(f"合并 {signal_name}: 当前总样本数 {len(merged_data):,}")
        
        self.logger.info(f"信号合并完成: {len(merged_data):,} 样本, {len(merged_data.columns)} 列")
        return merged_data
    
    def _merge_signals_chunked(self, loaded_signals: Dict[str, pd.DataFrame]) -> pd.DataFrame:
        """分块合并信号数据 - 内存优化"""
        self.logger.info("使用分块合并策略...")
        
        # 选择一个主信号作为基准（通常是数据量最大的）
        main_signal = max(loaded_signals.items(), key=lambda x: len(x[1]))
        main_name, main_data = main_signal
        
        self.logger.info(f"选择 {main_name} 作为主信号: {len(main_data):,} 样本")
        
        # 分块大小（根据内存情况调整）
        chunk_size = 1_000_000  # 100万样本一个块
        
        # 创建输出文件
        output_file = self.results_dir / 'step1_chunked_merged_data.csv'
        
        # 写入表头
        all_columns = list(main_data.columns)
        for signal_name, data in loaded_signals.items():
            if signal_name != main_name:
                # 添加其他信号的列名
                for col in data.columns:
                    if col not in all_columns:
                        all_columns.append(f"{col}_{signal_name}")
        
        # 写入CSV表头
        with open(output_file, 'w', newline='', encoding='utf-8') as f:
            f.write(','.join(all_columns) + '\n')
        
        # 分块处理
        total_chunks = (len(main_data) + chunk_size - 1) // chunk_size
        self.logger.info(f"分块处理: {total_chunks} 个块，每块 {chunk_size:,} 样本")
        
        for chunk_idx in range(total_chunks):
            start_idx = chunk_idx * chunk_size
            end_idx = min((chunk_idx + 1) * chunk_size, len(main_data))
            
            self.logger.info(f"处理块 {chunk_idx + 1}/{total_chunks}: 样本 {start_idx:,} - {end_idx:,}")
            
            # 获取主信号块
            main_chunk = main_data.iloc[start_idx:end_idx].copy()
            
            # 合并其他信号到当前块
            for signal_name, data in loaded_signals.items():
                if signal_name != main_name:
                    # 基于时间戳合并
                    if 'hrm_ts' in main_chunk.columns and 'hrm_ts' in data.columns:
                        # 找到对应时间戳的数据
                        chunk_ts = main_chunk['hrm_ts'].values
                        mask = data['hrm_ts'].isin(chunk_ts)
                        matched_data = data[mask]
                        
                        if len(matched_data) > 0:
                            # 合并匹配的数据
                            main_chunk = pd.merge(main_chunk, matched_data, on='hrm_ts', how='left', suffixes=('', f'_{signal_name}'))
            
            # 写入CSV块
            main_chunk.to_csv(output_file, mode='a', header=False, index=False)
            
            # 清理内存
            del main_chunk
        
        self.logger.info(f"分块合并完成，数据保存到: {output_file}")
        
        # 重新读取合并后的数据（如果需要返回DataFrame）
        self.logger.info("重新读取合并后的数据...")
        merged_data = pd.read_csv(output_file)
        
        self.logger.info(f"信号合并完成: {len(merged_data):,} 样本, {len(merged_data.columns)} 列")
        return merged_data
    
    def _save_full_data(self, merged_data: pd.DataFrame) -> Path:
        """保存完整数据"""
        self.logger.info("保存完整数据...")
        
        output_file = self.results_dir / 'step1_full_extracted_data.csv'
        
        try:
            # 保存为CSV
            merged_data.to_csv(output_file, index=False)
            
            file_size_mb = output_file.stat().st_size / (1024**2)
            self.logger.info(f"完整数据已保存: {output_file}")
            self.logger.info(f"文件大小: {file_size_mb:.2f} MB")
            self.logger.info(f"样本数: {len(merged_data):,}")
            self.logger.info(f"列数: {len(merged_data.columns)}")
            
            return output_file
            
        except Exception as e:
            self.logger.error(f"保存完整数据失败: {e}")
            raise
    
    def _generate_extraction_report(self, loaded_signals: Dict[str, pd.DataFrame], 
                                  integrity_results: Dict[str, Any], 
                                  merged_data: pd.DataFrame, 
                                  output_file: Path) -> Dict[str, Any]:
        """生成提取报告"""
        self.logger.info("生成提取报告...")
        
        elapsed_time = time.time() - self.start_time
        
        report = {
            'extraction_timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
            'extraction_duration_seconds': elapsed_time,
            'signals_loaded': list(loaded_signals.keys()),
            'total_signals': len(loaded_signals),
            'final_data_shape': {
                'samples': len(merged_data),
                'columns': len(merged_data.columns)
            },
            'output_file': str(output_file),
            'output_file_size_mb': output_file.stat().st_size / (1024**2),
            'integrity_results': integrity_results,
            'resource_usage': {
                'cpu_cores': self.cpu_count,
                'max_threads': self.max_threads,
                'max_processes': self.max_processes,
                'gpu_available': self.gpu_available,
                'device': str(self.device)
            },
            'extraction_summary': {
                'total_samples_extracted': len(merged_data),
                'total_columns_extracted': len(merged_data.columns),
                'extraction_success': True,
                'no_simplification': True,
                'full_sample_analysis': True
            }
        }
        
        return report

def main():
    """主函数"""
    print("步骤1: 全样本原始数据提取")
    print("=" * 60)
    print("要求: 完整提取所有原始数据，无任何简化")
    print("环境: WSL + PyTorch Nightly + GPU")
    print("加速: 多进程并行处理")
    print("=" * 60)
    
    try:
        # 初始化提取器
        extractor = FullDataExtractor()
        
        # 执行全样本数据提取
        extracted_data = extractor.extract_full_data()
        
        # 打印结果摘要
        results = extractor.extraction_results
        print(f"\n[OK] 步骤1完成!")
        print(f"提取的样本数: {results['final_data_shape']['samples']:,}")
        print(f"提取的列数: {results['final_data_shape']['columns']}")
        print(f"输出文件: {results['output_file']}")
        print(f"文件大小: {results['output_file_size_mb']:.2f} MB")
        print(f"提取耗时: {results['extraction_duration_seconds']:.2f} 秒")
        print(f"加载的信号: {', '.join(results['signals_loaded'])}")
        print(f"CPU核心数: {results['resource_usage']['cpu_cores']}")
        print(f"使用进程数: {results['resource_usage']['max_processes']}")
        print(f"GPU状态: {'可用' if results['resource_usage']['gpu_available'] else '不可用'}")
        
        return 0
        
    except Exception as e:
        print(f"[ERROR] 步骤1失败: {e}")
        import traceback
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    exit(main())
