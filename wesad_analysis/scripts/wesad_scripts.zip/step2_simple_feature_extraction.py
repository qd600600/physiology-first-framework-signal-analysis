#!/usr/bin/env python3
"""
第二步：简化特征提取
专门处理WESAD的15个受试者数据，避免复杂计算导致卡死
"""

import os
import pandas as pd
import numpy as np
from pathlib import Path
import warnings

warnings.filterwarnings('ignore')

class SimpleFeatureExtractor:
    def __init__(self):
        self.feature_results = {}
        
    def load_wesad_subjects(self):
        """加载WESAD的所有15个受试者数据"""
        print("📂 加载WESAD受试者数据...")
        
        wesad_base = Path("data/WESAD")
        subjects = [f"S{i}" for i in range(2, 18) if i != 12]  # S2-S17, 除了S12
        
        all_data = []
        
        for subject in subjects:
            subject_path = wesad_base / subject
            if subject_path.exists():
                print(f"  📊 处理 {subject}...")
                
                # 尝试加载IBI数据
                ibi_file = subject_path / f"{subject}.pkl"
                if ibi_file.exists():
                    try:
                        # 直接使用已处理的IBI数据
                        processed_file = f"data/filtered/core_WESAD_filtered.csv"
                        if Path(processed_file).exists():
                            data = pd.read_csv(processed_file)
                            # 只取当前受试者的数据
                            subject_data = data[data['subject_id'] == subject].copy()
                            if len(subject_data) > 0:
                                subject_data['subject'] = subject
                                all_data.append(subject_data)
                                print(f"    ✅ {subject}: {len(subject_data)} 行")
                    except Exception as e:
                        print(f"    ❌ {subject}: 加载失败 - {e}")
        
        if all_data:
            combined_data = pd.concat(all_data, ignore_index=True)
            print(f"✅ 总共加载 {len(combined_data)} 行数据，{len(subjects)} 个受试者")
            return combined_data
        else:
            print("❌ 没有找到WESAD数据")
            return None
    
    def extract_basic_features(self, data):
        """提取基础特征"""
        print("🔬 提取基础特征...")
        
        features = {}
        
        # 基于IBI计算HR和HRV
        if 'ibi' in data.columns:
            # 计算HR
            data['HR'] = 60 / data['ibi']
            
            # 计算HRV (滑动窗口标准差)
            data['HRV'] = data['ibi'].rolling(window=30, min_periods=10).std()
            
            # 基础统计特征
            features['HR_mean'] = data['HR'].mean()
            features['HR_std'] = data['HR'].std()
            features['HR_min'] = data['HR'].min()
            features['HR_max'] = data['HR'].max()
            
            features['HRV_mean'] = data['HRV'].mean()
            features['HRV_std'] = data['HRV'].std()
            
            # 时间特征
            features['duration_minutes'] = (data['time'].max() - data['time'].min()) / 60
            features['sample_rate'] = len(data) / features['duration_minutes']
            
            # 创建压力标签（基于HRV阈值）
            hrv_threshold = data['HRV'].quantile(0.7)
            data['stress_label'] = (data['HRV'] > hrv_threshold).astype(int)
            
            features['stress_ratio'] = data['stress_label'].mean()
            
            print(f"    ✅ 提取了 {len(features)} 个基础特征")
        
        return features, data
    
    def load_other_datasets(self):
        """加载其他数据集"""
        print("📂 加载其他数据集...")
        
        other_datasets = {
            "CRWD": "data/CRWD/extracted/CRWD/sensor_hrv_filtered.csv",
            "Enhanced_Health": "data/Enhanced_Health/processed/enhanced_large_health_dataset.csv"
        }
        
        for name, path in other_datasets.items():
            if Path(path).exists():
                print(f"  📊 加载 {name}...")
                try:
                    # 只读取前5000行避免内存问题
                    data = pd.read_csv(path, nrows=5000)
                    
                    # 提取基础特征
                    features = self.extract_basic_features_other(data, name)
                    
                    self.feature_results[name] = {
                        'features': features,
                        'n_samples': len(data)
                    }
                    
                    print(f"    ✅ {name}: {len(data)} 行, {len(features)} 个特征")
                    
                except Exception as e:
                    print(f"    ❌ {name}: 加载失败 - {e}")
    
    def extract_basic_features_other(self, data, dataset_name):
        """为其他数据集提取基础特征"""
        features = {}
        
        # HR特征
        hr_cols = [col for col in data.columns if 'hr' in col.lower() and 'hrv' not in col.lower()]
        if hr_cols:
            hr_col = hr_cols[0]
            features['HR_mean'] = data[hr_col].mean()
            features['HR_std'] = data[hr_col].std()
        
        # HRV特征
        hrv_cols = [col for col in data.columns if 'hrv' in col.lower() or 'sdnn' in col.lower()]
        if hrv_cols:
            hrv_col = hrv_cols[0]
            features['HRV_mean'] = data[hrv_col].mean()
            features['HRV_std'] = data[hrv_col].std()
        
        # 标签特征
        label_cols = [col for col in data.columns if any(keyword in col.lower() 
                       for keyword in ['stress', 'health', 'condition', 'mood'])]
        if label_cols:
            label_col = label_cols[0]
            if data[label_col].dtype == 'object':
                features['unique_labels'] = data[label_col].nunique()
            else:
                features['label_mean'] = data[label_col].mean()
                features['label_std'] = data[label_col].std()
        
        return features
    
    def generate_simple_report(self):
        """生成简单报告"""
        print("📝 生成特征报告...")
        
        # 收集所有特征
        all_features = []
        
        for dataset_name, result in self.feature_results.items():
            features = result['features']
            features['dataset'] = dataset_name
            features['n_samples'] = result.get('n_samples', 0)
            all_features.append(features)
        
        if all_features:
            df = pd.DataFrame(all_features)
            df.to_csv("simple_features.csv", index=False)
            print("✅ simple_features.csv 已生成")
            
            # 显示特征摘要
            print("\n📋 特征摘要:")
            for _, row in df.iterrows():
                print(f"  {row['dataset']}: {len([col for col in df.columns if col not in ['dataset', 'n_samples']])} 个特征")
            
            return df
        else:
            print("❌ 没有提取到特征")
            return None
    
    def run_extraction(self):
        """运行特征提取"""
        print("🚀 开始简化特征提取")
        print("=" * 50)
        
        # 加载WESAD数据
        wesad_data = self.load_wesad_subjects()
        if wesad_data is not None:
            # 提取WESAD特征
            features, processed_data = self.extract_basic_features(wesad_data)
            self.feature_results['WESAD'] = {
                'features': features,
                'n_samples': len(wesad_data)
            }
        
        # 加载其他数据集
        self.load_other_datasets()
        
        # 生成报告
        df = self.generate_simple_report()
        
        print("=" * 50)
        print("✅ 简化特征提取完成！")
        print(f"📊 处理了 {len(self.feature_results)} 个数据集")
        
        if df is not None:
            print(f"📈 总共 {len(df.columns)-2} 个特征")
        
        return self.feature_results

if __name__ == "__main__":
    extractor = SimpleFeatureExtractor()
    results = extractor.run_extraction()





