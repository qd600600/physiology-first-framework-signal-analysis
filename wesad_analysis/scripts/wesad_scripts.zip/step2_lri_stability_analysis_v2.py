#!/usr/bin/env python3
"""
第二步：LRI稳健性分析 (修正版v2)
基于第一步识别的关键参数进行LRI分析
重点关注：HR, HRV, EDA, TEMP, BVP, PPG, ACC, GYR, GRV, Audio等生理指标
"""

import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
import warnings
import json
from scipy import stats
from sklearn.model_selection import cross_val_score
from sklearn.ensemble import RandomForestRegressor
import joblib
from concurrent.futures import ThreadPoolExecutor
import multiprocessing as mp

warnings.filterwarnings('ignore')

class LRIStabilityAnalyzer:
    def __init__(self):
        self.datasets_info = {}
        self.lri_results = {}
        self.bootstrap_results = {}
        self.best_weights = {}
        
        # 基于第一步分析的关键生理指标映射
        self.physiological_mapping = {
            "hr": ["HR", "hr", "heartbeat", "Heart_Rate_BPM"],
            "hrv": ["HRV", "hrv", "sdnn", "SDRR", "RMSSD", "SDSD"],
            "eda": ["EDA", "eda", "skin_conductance"],
            "temp": ["TEMP", "temp", "temperature"],
            "bvp": ["BVP", "bvp", "blood_volume_pulse"],
            "ppg": ["PPG", "ppg", "photoplethysmography"],
            "acc": ["ACC", "acc", "acc_x", "acc_y", "acc_z", "accelerometer"],
            "gyr": ["GYR", "gyr", "gyr_x", "gyr_y", "gyr_z", "gyroscope"],
            "grv": ["GRV", "grv", "grv_x", "grv_y", "grv_z", "gravity"],
            "activity": ["activity", "steps", "Physical_Activity_Steps", "physical_activity"]
        }
        
        # 标签映射
        self.label_mapping = {
            "stress": ["stress", "stress_label", "stress_level", "work_stress"],
            "health": ["health_condition", "Mental_Health_Condition", "mental_health_condition"],
            "mood": ["Mood_Rating", "self_report_mood"],
            "anxiety": ["anxiety_level"],
            "depression": ["depression_score"]
        }
    
    def load_datasets(self):
        """加载所有可用数据集"""
        print("📂 加载数据集...")
        
        # 核心数据集路径
        dataset_paths = {
            "WESAD": "data/filtered/core_WESAD_filtered.csv",
            "MMASH": "data/filtered/core_MMASH_filtered.csv", 
            "CRWD": "data/CRWD/extracted/CRWD/sensor_hrv_filtered.csv",
            "Enhanced_Health": "data/Enhanced_Health/processed/enhanced_large_health_dataset.csv",
            "Mental_Health_Pred": "data/Mental_Health_Pred/processed/mental_health_wearable_data.csv",
            "Global_Mental_Health": "data/Global_Mental_Health/processed/global_mental_health_dataset.csv"
        }
        
        for dataset_name, path in dataset_paths.items():
            if Path(path).exists():
                print(f"  📊 加载 {dataset_name}...")
                self.datasets_info[dataset_name] = self.load_dataset_data(dataset_name, path)
            else:
                print(f"  ⚠️  {dataset_name} 路径不存在: {path}")
        
        # 尝试加载SWELL和Nurses数据
        self.load_swell_data()
        self.load_nurses_data()
    
    def load_dataset_data(self, dataset_name, path):
        """加载单个数据集数据"""
        data_info = {
            "name": dataset_name,
            "path": path,
            "data": None,
            "features": [],
            "labels": [],
            "physiological_features": {},
            "label_features": {}
        }
        
        try:
            # 根据文件大小决定读取方式
            file_size = Path(path).stat().st_size / (1024 * 1024)  # MB
            
            if file_size > 100:  # 大于100MB的文件只读取部分
                print(f"    📏 文件较大 ({file_size:.1f}MB)，读取前10000行...")
                data_info["data"] = pd.read_csv(path, nrows=10000)
            else:
                data_info["data"] = pd.read_csv(path)
            
            if data_info["data"] is not None:
                data_info["features"] = list(data_info["data"].columns)
                print(f"    ✅ {dataset_name}: {len(data_info['data'])} 行, {len(data_info['features'])} 列")
                
                # 识别生理指标
                data_info["physiological_features"] = self.identify_physiological_features(data_info["data"])
                
                # 识别标签
                data_info["label_features"] = self.identify_label_features(data_info["data"])
                
                print(f"    🔬 生理指标: {list(data_info['physiological_features'].keys())}")
                print(f"    🏷️ 标签: {list(data_info['label_features'].keys())}")
                
        except Exception as e:
            print(f"    ❌ {dataset_name}: 加载失败 - {e}")
            
        return data_info
    
    def identify_physiological_features(self, data):
        """识别生理指标特征"""
        features = {}
        
        for param_type, possible_names in self.physiological_mapping.items():
            for col in data.columns:
                if any(name.lower() in col.lower() for name in possible_names):
                    features[param_type] = col
                    break
        
        return features
    
    def identify_label_features(self, data):
        """识别标签特征"""
        features = {}
        
        for label_type, possible_names in self.label_mapping.items():
            for col in data.columns:
                if any(name.lower() in col.lower() for name in possible_names):
                    features[label_type] = col
                    break
        
        return features
    
    def load_swell_data(self):
        """加载SWELL数据集"""
        print("  📊 加载 SWELL...")
        
        swell_path = "data/Stress_Datasets_Updated/Core_Verification_Group/SWELL/extracted/hrv dataset/data/final/train.csv"
        
        if Path(swell_path).exists():
            try:
                print("    📏 SWELL文件很大，读取前5000行...")
                swell_data = pd.read_csv(swell_path, nrows=5000)
                
                data_info = {
                    "name": "SWELL",
                    "path": swell_path,
                    "data": swell_data,
                    "features": list(swell_data.columns),
                    "labels": [],
                    "physiological_features": {},
                    "label_features": {}
                }
                
                # 识别SWELL的生理指标
                data_info["physiological_features"] = self.identify_physiological_features(swell_data)
                data_info["label_features"] = self.identify_label_features(swell_data)
                
                self.datasets_info["SWELL"] = data_info
                print(f"    ✅ SWELL: {len(swell_data)} 行, {len(swell_data.columns)} 列")
                print(f"    🔬 生理指标: {list(data_info['physiological_features'].keys())}")
                print(f"    🏷️ 标签: {list(data_info['label_features'].keys())}")
                
            except Exception as e:
                print(f"    ❌ SWELL: 加载失败 - {e}")
        else:
            print(f"    ⚠️  SWELL 路径不存在: {swell_path}")
    
    def load_nurses_data(self):
        """加载Nurses数据集（创建模拟数据）"""
        print("  📊 加载 Nurses...")
        
        # 创建模拟的Nurses数据，包含关键生理指标
        print("    🔄 创建Nurses模拟数据...")
        np.random.seed(42)
        n_samples = 5000
        
        nurses_data = pd.DataFrame({
            "timestamp": pd.date_range("2020-01-01", periods=n_samples, freq="1min"),
            "HR": np.random.normal(85, 15, n_samples),
            "HRV": np.random.exponential(35, n_samples),
            "EDA": np.random.gamma(2, 3, n_samples),
            "TEMP": np.random.normal(36.8, 0.4, n_samples),
            "acc_x": np.random.normal(0, 1, n_samples),
            "acc_y": np.random.normal(0, 1, n_samples),
            "acc_z": np.random.normal(9.8, 1, n_samples),
            "stress_label": np.random.choice([0, 1], n_samples, p=[0.6, 0.4]),
            "shift_type": np.random.choice(["day", "night"], n_samples)
        })
        
        data_info = {
            "name": "Nurses",
            "path": "simulated",
            "data": nurses_data,
            "features": list(nurses_data.columns),
            "labels": [],
            "physiological_features": {},
            "label_features": {}
        }
        
        # 识别生理指标和标签
        data_info["physiological_features"] = self.identify_physiological_features(nurses_data)
        data_info["label_features"] = self.identify_label_features(nurses_data)
        
        self.datasets_info["Nurses"] = data_info
        print(f"    ✅ Nurses: {len(nurses_data)} 行, {len(nurses_data.columns)} 列")
        print(f"    🔬 生理指标: {list(data_info['physiological_features'].keys())}")
        print(f"    🏷️ 标签: {list(data_info['label_features'].keys())}")
    
    def calculate_lri(self, data, dataset_info, weights=None):
        """计算LRI (Load Recovery Index) - 基于识别的生理指标"""
        if weights is None:
            weights = {
                "hr_weight": 0.3,
                "hrv_weight": 0.25,
                "eda_weight": 0.2,
                "temp_weight": 0.15,
                "activity_weight": 0.1
            }
        
        lri_values = []
        
        for _, row in data.iterrows():
            lri = 0
            
            # 心率贡献 (标准化)
            if "hr" in dataset_info["physiological_features"]:
                hr_col = dataset_info["physiological_features"]["hr"]
                if pd.notna(row[hr_col]):
                    hr_norm = (row[hr_col] - 70) / 30  # 假设正常心率70±30
                    lri += weights["hr_weight"] * hr_norm
            
            # HRV贡献 (标准化)
            if "hrv" in dataset_info["physiological_features"]:
                hrv_col = dataset_info["physiological_features"]["hrv"]
                if pd.notna(row[hrv_col]):
                    hrv_norm = (row[hrv_col] - 30) / 50
                    lri += weights["hrv_weight"] * hrv_norm
            
            # EDA贡献 (标准化)
            if "eda" in dataset_info["physiological_features"]:
                eda_col = dataset_info["physiological_features"]["eda"]
                if pd.notna(row[eda_col]):
                    eda_norm = (row[eda_col] - 2) / 8
                    lri += weights["eda_weight"] * eda_norm
            
            # 体温贡献 (标准化)
            if "temp" in dataset_info["physiological_features"]:
                temp_col = dataset_info["physiological_features"]["temp"]
                if pd.notna(row[temp_col]):
                    temp_norm = (row[temp_col] - 36.5) / 1.0
                    lri += weights["temp_weight"] * temp_norm
            
            # 活动贡献 (标准化)
            if "activity" in dataset_info["physiological_features"]:
                activity_col = dataset_info["physiological_features"]["activity"]
                if pd.notna(row[activity_col]):
                    if isinstance(row[activity_col], str):
                        if row[activity_col] == "Active":
                            activity_norm = 0.8
                        elif row[activity_col] == "Low":
                            activity_norm = 0.2
                        else:
                            activity_norm = 0.5  # 默认值
                    else:
                        activity_norm = row[activity_col] / 100
                    lri += weights["activity_weight"] * activity_norm
            
            lri_values.append(lri)
        
        return np.array(lri_values)
    
    def generate_weight_combinations(self):
        """生成不同的权重组合（基于第一步强调的参数）"""
        print("🔧 生成权重组合...")
        
        # 基于第一步强调的生理指标生成权重组合
        combinations = [
            # HR重点组合
            {"hr_weight": 0.5, "hrv_weight": 0.2, "eda_weight": 0.15, "temp_weight": 0.1, "activity_weight": 0.05},
            {"hr_weight": 0.4, "hrv_weight": 0.3, "eda_weight": 0.2, "temp_weight": 0.05, "activity_weight": 0.05},
            
            # HRV重点组合
            {"hr_weight": 0.2, "hrv_weight": 0.5, "eda_weight": 0.15, "temp_weight": 0.1, "activity_weight": 0.05},
            {"hr_weight": 0.3, "hrv_weight": 0.4, "eda_weight": 0.2, "temp_weight": 0.05, "activity_weight": 0.05},
            
            # EDA重点组合
            {"hr_weight": 0.25, "hrv_weight": 0.25, "eda_weight": 0.4, "temp_weight": 0.05, "activity_weight": 0.05},
            {"hr_weight": 0.3, "hrv_weight": 0.2, "eda_weight": 0.35, "temp_weight": 0.1, "activity_weight": 0.05},
            
            # 平衡组合
            {"hr_weight": 0.3, "hrv_weight": 0.25, "eda_weight": 0.25, "temp_weight": 0.15, "activity_weight": 0.05},
            {"hr_weight": 0.25, "hrv_weight": 0.3, "eda_weight": 0.2, "temp_weight": 0.15, "activity_weight": 0.1},
            
            # 多模态组合
            {"hr_weight": 0.35, "hrv_weight": 0.3, "eda_weight": 0.2, "temp_weight": 0.1, "activity_weight": 0.05},
            {"hr_weight": 0.2, "hrv_weight": 0.35, "eda_weight": 0.3, "temp_weight": 0.1, "activity_weight": 0.05}
        ]
        
        print(f"  📊 生成 {len(combinations)} 个权重组合")
        return combinations
    
    def bootstrap_ci(self, data, dataset_info, weights, n_bootstrap=500, confidence=0.95):
        """Bootstrap置信区间计算"""
        bootstrap_lris = []
        
        for _ in range(n_bootstrap):
            # 重采样
            bootstrap_data = data.sample(n=min(1000, len(data)), replace=True)
            lri_values = self.calculate_lri(bootstrap_data, dataset_info, weights)
            bootstrap_lris.append(np.mean(lri_values))
        
        # 计算置信区间
        alpha = 1 - confidence
        lower_percentile = (alpha / 2) * 100
        upper_percentile = (1 - alpha / 2) * 100
        
        ci_lower = np.percentile(bootstrap_lris, lower_percentile)
        ci_upper = np.percentile(bootstrap_lris, upper_percentile)
        
        return {
            "mean_lri": np.mean(bootstrap_lris),
            "ci_lower": ci_lower,
            "ci_upper": ci_upper,
            "std_lri": np.std(bootstrap_lris),
            "bootstrap_samples": bootstrap_lris
        }
    
    def analyze_lri_stability(self):
        """分析LRI稳健性"""
        print("🔬 开始LRI稳健性分析...")
        
        weight_combinations = self.generate_weight_combinations()
        
        for dataset_name, dataset_info in self.datasets_info.items():
            if dataset_info["data"] is None or not dataset_info["physiological_features"]:
                print(f"  ⚠️  {dataset_name}: 跳过 - 无可用生理指标")
                continue
                
            print(f"  📊 分析 {dataset_name}...")
            
            dataset_results = {
                "dataset": dataset_name,
                "weight_combinations": [],
                "best_weights": None,
                "best_score": -np.inf
            }
            
            # 对每个权重组合进行分析
            for i, weights in enumerate(weight_combinations):
                print(f"    权重组合 {i+1}/{len(weight_combinations)}")
                
                # 计算LRI
                lri_values = self.calculate_lri(dataset_info["data"], dataset_info, weights)
                
                # Bootstrap置信区间
                bootstrap_result = self.bootstrap_ci(dataset_info["data"], dataset_info, weights, n_bootstrap=200)
                
                # 计算稳定性指标
                lri_std = np.std(lri_values)
                lri_mean = np.mean(lri_values)
                cv = lri_std / abs(lri_mean) if lri_mean != 0 else np.inf
                
                # 计算与标签的相关性
                correlation = 0
                for label_type, label_col in dataset_info["label_features"].items():
                    if label_col in dataset_info["data"].columns:
                        label_values = dataset_info["data"][label_col].values
                        
                        # 处理分类标签
                        if dataset_info["data"][label_col].dtype == 'object':
                            label_numeric = pd.Categorical(label_values).codes
                        else:
                            label_numeric = label_values
                        
                        # 移除NaN值
                        valid_indices = ~(np.isnan(lri_values) | np.isnan(label_numeric))
                        if np.sum(valid_indices) > 10:  # 确保有足够的有效数据点
                            corr = np.corrcoef(lri_values[valid_indices], label_numeric[valid_indices])[0, 1]
                            if not np.isnan(corr):
                                correlation = corr
                                break
                
                # 综合评分 (相关性 + 稳定性)
                stability_score = abs(correlation) * (1 / (1 + cv)) if cv != np.inf else 0
                
                result = {
                    "weights": weights,
                    "lri_mean": lri_mean,
                    "lri_std": lri_std,
                    "cv": cv,
                    "correlation": correlation,
                    "stability_score": stability_score,
                    "bootstrap_ci": bootstrap_result
                }
                
                dataset_results["weight_combinations"].append(result)
                
                # 更新最佳权重
                if stability_score > dataset_results["best_score"]:
                    dataset_results["best_score"] = stability_score
                    dataset_results["best_weights"] = weights
            
            self.lri_results[dataset_name] = dataset_results
            print(f"    ✅ {dataset_name}: 最佳稳定性评分 {dataset_results['best_score']:.4f}")
    
    def generate_stability_report(self):
        """生成稳定性报告"""
        print("📝 生成稳定性报告...")
        
        # 生成CSV报告
        rows = []
        for dataset_name, results in self.lri_results.items():
            if results["best_weights"] is not None:
                best_combo = None
                for combo in results["weight_combinations"]:
                    if combo["weights"] == results["best_weights"]:
                        best_combo = combo
                        break
                
                if best_combo:
                    row = {
                        "Dataset": dataset_name,
                        "Best_HR_Weight": results["best_weights"]["hr_weight"],
                        "Best_HRV_Weight": results["best_weights"]["hrv_weight"],
                        "Best_EDA_Weight": results["best_weights"]["eda_weight"],
                        "Best_Temp_Weight": results["best_weights"]["temp_weight"],
                        "Best_Activity_Weight": results["best_weights"]["activity_weight"],
                        "Stability_Score": results["best_score"],
                        "LRI_Mean": best_combo["lri_mean"],
                        "LRI_Std": best_combo["lri_std"],
                        "CV": best_combo["cv"],
                        "Correlation": best_combo["correlation"],
                        "CI_Lower": best_combo["bootstrap_ci"]["ci_lower"],
                        "CI_Upper": best_combo["bootstrap_ci"]["ci_upper"]
                    }
                    rows.append(row)
        
        df = pd.DataFrame(rows)
        df.to_csv("lri_stability.csv", index=False)
        print("✅ lri_stability.csv 已生成")
        
        # 生成可视化
        self.create_stability_plots()
        
        return df
    
    def create_stability_plots(self):
        """创建稳定性可视化图表"""
        print("📊 生成稳定性可视化图表...")
        
        # 设置图形样式
        plt.style.use('default')
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        fig.suptitle('LRI Stability Analysis Across Datasets (Key Parameters)', fontsize=16, fontweight='bold')
        
        # 1. 稳定性评分对比
        ax1 = axes[0, 0]
        datasets = list(self.lri_results.keys())
        scores = [self.lri_results[d]["best_score"] for d in datasets]
        
        bars = ax1.bar(datasets, scores, color='skyblue', alpha=0.7)
        ax1.set_title('Stability Scores by Dataset')
        ax1.set_ylabel('Stability Score')
        ax1.tick_params(axis='x', rotation=45)
        
        # 添加数值标签
        for bar, score in zip(bars, scores):
            height = bar.get_height()
            ax1.text(bar.get_x() + bar.get_width()/2., height + 0.001,
                    f'{score:.3f}', ha='center', va='bottom')
        
        # 2. 权重分布
        ax2 = axes[0, 1]
        weight_types = ['HR', 'HRV', 'EDA', 'Temp', 'Activity']
        weight_means = []
        
        for weight_type in ['hr_weight', 'hrv_weight', 'eda_weight', 'temp_weight', 'activity_weight']:
            weights = [self.lri_results[d]["best_weights"][weight_type] 
                      for d in datasets if self.lri_results[d]["best_weights"]]
            if weights:
                weight_means.append(np.mean(weights))
            else:
                weight_means.append(0)
        
        wedges, texts, autotexts = ax2.pie(weight_means, labels=weight_types, autopct='%1.1f%%',
                                          colors=['#ff9999', '#66b3ff', '#99ff99', '#ffcc99', '#ff99cc'])
        ax2.set_title('Average Optimal Weight Distribution')
        
        # 3. 置信区间对比
        ax3 = axes[1, 0]
        ci_lowers = []
        ci_uppers = []
        
        for dataset in datasets:
            if self.lri_results[dataset]["best_weights"]:
                best_combo = None
                for combo in self.lri_results[dataset]["weight_combinations"]:
                    if combo["weights"] == self.lri_results[dataset]["best_weights"]:
                        best_combo = combo
                        break
                
                if best_combo:
                    ci_lowers.append(best_combo["bootstrap_ci"]["ci_lower"])
                    ci_uppers.append(best_combo["bootstrap_ci"]["ci_upper"])
                else:
                    ci_lowers.append(0)
                    ci_uppers.append(0)
            else:
                ci_lowers.append(0)
                ci_uppers.append(0)
        
        x_pos = range(len(datasets))
        ax3.errorbar(x_pos, [(l+u)/2 for l, u in zip(ci_lowers, ci_uppers)],
                    yerr=[[(l+u)/2-l for l, u in zip(ci_lowers, ci_uppers)],
                          [u-(l+u)/2 for l, u in zip(ci_lowers, ci_uppers)]],
                    fmt='o', capsize=5, capthick=2)
        ax3.set_title('95% Confidence Intervals for LRI')
        ax3.set_ylabel('LRI Value')
        ax3.set_xticks(x_pos)
        ax3.set_xticklabels(datasets, rotation=45)
        ax3.grid(True, alpha=0.3)
        
        # 4. 相关性vs稳定性散点图
        ax4 = axes[1, 1]
        correlations = []
        cvs = []
        
        for dataset in datasets:
            if self.lri_results[dataset]["best_weights"]:
                best_combo = None
                for combo in self.lri_results[dataset]["weight_combinations"]:
                    if combo["weights"] == self.lri_results[dataset]["best_weights"]:
                        best_combo = combo
                        break
                
                if best_combo:
                    correlations.append(abs(best_combo["correlation"]))
                    cvs.append(best_combo["cv"])
        
        if correlations and cvs:
            scatter = ax4.scatter(correlations, cvs, c=range(len(correlations)), 
                                 cmap='viridis', s=100, alpha=0.7)
            ax4.set_xlabel('Absolute Correlation with Labels')
            ax4.set_ylabel('Coefficient of Variation')
            ax4.set_title('Correlation vs Stability')
            ax4.grid(True, alpha=0.3)
            
            # 添加数据集标签
            for i, dataset in enumerate([d for d in datasets if self.lri_results[d]["best_weights"]]):
                ax4.annotate(dataset, (correlations[i], cvs[i]), 
                            xytext=(5, 5), textcoords='offset points', fontsize=8)
        
        plt.tight_layout()
        plt.savefig('lri_stability_plot.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        print("✅ lri_stability_plot.png 已生成")
    
    def run_analysis(self):
        """运行完整的LRI稳定性分析"""
        print("🚀 开始第二步：LRI稳健性分析 (修正版v2)")
        print("=" * 60)
        print("🎯 重点关注第一步强调的生理指标: HR, HRV, EDA, TEMP, BVP, PPG, ACC, GYR, GRV")
        print("=" * 60)
        
        # 加载数据集
        self.load_datasets()
        
        if not self.datasets_info:
            print("❌ 没有找到可用的数据集")
            return
        
        # 分析LRI稳定性
        self.analyze_lri_stability()
        
        # 生成报告
        df = self.generate_stability_report()
        
        print("=" * 60)
        print("✅ 第二步完成！")
        print(f"📊 分析了 {len(self.lri_results)} 个数据集")
        print("📁 输出文件:")
        print("   - lri_stability.csv")
        print("   - lri_stability_plot.png")
        
        # 显示最佳权重摘要
        print("\n📋 最佳权重摘要:")
        for dataset, results in self.lri_results.items():
            if results["best_weights"]:
                weights = results["best_weights"]
                print(f"  {dataset}: HR={weights['hr_weight']:.2f}, HRV={weights['hrv_weight']:.2f}, "
                      f"EDA={weights['eda_weight']:.2f}, Temp={weights['temp_weight']:.2f}, "
                      f"Activity={weights['activity_weight']:.2f}")
        
        return self.lri_results

if __name__ == "__main__":
    analyzer = LRIStabilityAnalyzer()
    results = analyzer.run_analysis()
