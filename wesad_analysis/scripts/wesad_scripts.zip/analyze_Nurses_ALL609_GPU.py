#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Nurses Dataset - COMPLETE ANALYSIS (All 609 ZIP Files)
GPU Accelerated
Processes all 16 nurses with all available sessions
"""

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader
from pathlib import Path
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.cluster import KMeans
from sklearn.model_selection import train_test_split
from sklearn.metrics import silhouette_score
from tqdm import tqdm
import json
import zipfile
import shutil

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"\n{'='*80}")
print(f"Nurses Dataset - COMPLETE ANALYSIS (609 ZIP Files)")
print(f"GPU: {torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'CPU'}")
print(f"{'='*80}\n")

class StressLSTM(nn.Module):
    def __init__(self, input_size, hidden=64):
        super().__init__()
        self.lstm = nn.LSTM(input_size, hidden, 2, batch_first=True, dropout=0.2)
        self.fc = nn.Linear(hidden, 1)
    def forward(self, x):
        out, _ = self.lstm(x)
        return self.fc(out[:, -1, :])

# Load ALL Nurses data
print("[1/5] Loading ALL Nurses sessions...")
nurses_base = Path("data/Stress_Datasets_Updated/Core_Verification_Group/Nurses/extracted/Stress_dataset")

nurse_dirs = [d for d in nurses_base.iterdir() 
              if d.is_dir() and not d.name.startswith('sample')]

print(f"  Nurse IDs: {len(nurse_dirs)}")

# Count total ZIPs
total_zips = sum(len(list(d.glob("*.zip"))) for d in nurse_dirs)
print(f"  Total ZIP files: {total_zips}")

# W(t) files to extract
wt_files = ['HR.csv', 'EDA.csv', 'IBI.csv', 'TEMP.csv', 'BVP.csv', 'ACC.csv']

all_data = []
temp_dir = Path("complete_stress_analysis_GPU/temp_nurses_all")
temp_dir.mkdir(parents=True, exist_ok=True)

# Process ALL nurses, ALL sessions
print(f"\n  Processing ALL {total_zips} sessions (may take 10-15 minutes)...")

with tqdm(total=total_zips, desc="  Progress") as pbar:
    for nurse_dir in nurse_dirs:
        zip_files = list(nurse_dir.glob("*.zip"))
        
        for zip_file in zip_files:
            try:
                session_data = {}
                session_data['nurse_id'] = nurse_dir.name
                session_data['session_id'] = zip_file.stem
                
                with zipfile.ZipFile(zip_file, 'r') as z:
                    for wt_file in wt_files:
                        if wt_file in z.namelist():
                            z.extract(wt_file, temp_dir)
                            
                            file_path = temp_dir / wt_file
                            try:
                                # Read and get mean
                                df_temp = pd.read_csv(file_path, header=None, nrows=5000)
                                param_name = wt_file.replace('.csv', '')
                                
                                # Get mean value
                                if len(df_temp.columns) == 1:
                                    session_data[param_name] = df_temp.iloc[:, 0].mean()
                                else:
                                    # Multi-column (like ACC with x,y,z)
                                    session_data[param_name] = df_temp.values.flatten().mean()
                            except:
                                pass
                            
                            if file_path.exists():
                                file_path.unlink()
                
                if len(session_data) > 2:  # At least nurse_id + 1 parameter
                    all_data.append(session_data)
            except Exception as e:
                pass
            pbar.update(1)

shutil.rmtree(temp_dir, ignore_errors=True)

if not all_data:
    print("[ERROR] No data loaded")
    exit(1)

df = pd.DataFrame(all_data)
print(f"\n  ✅ Loaded: {df.shape}")
print(f"  Sessions: {len(all_data)}")
print(f"  Parameters: {[c for c in df.columns if c not in ['nurse_id', 'session_id']]}")

# Drop ID columns
df_analysis = df.drop(columns=['nurse_id', 'session_id'], errors='ignore')

# Preprocess
print("\n[2/5] Preprocessing...")
df_analysis = df_analysis.fillna(df_analysis.mean())

# Gentle outlier removal for small dataset
print(f"  Outlier removal (10x IQR for robustness)...")
df_clean = df_analysis.copy()

for col in df_analysis.columns:
    Q1, Q3 = df_analysis[col].quantile(0.25), df_analysis[col].quantile(0.75)
    IQR = Q3 - Q1
    lower, upper = Q1 - 10*IQR, Q3 + 10*IQR  # Very lenient!
    df_clean = df_clean[(df_clean[col] >= lower) & (df_clean[col] <= upper)]

print(f"  Shape: {df_analysis.shape} -> {df_clean.shape}")
print(f"  Retention: {len(df_clean)/len(df_analysis)*100:.1f}%")

# W(t) GPU
print("\n[3/5] W(t) Simulation (GPU)...")

stress_col = 'HR' if 'HR' in df_clean.columns else df_clean.columns[0]
stress_data = df_clean[stress_col].values

scaler = MinMaxScaler((0, 10))
stress_norm = scaler.fit_transform(stress_data.reshape(-1, 1)).flatten()

stress_t = torch.FloatTensor(stress_norm).to(device)
threshold = float(torch.median(stress_t) + 0.5 * torch.std(stress_t))

W_t = torch.zeros_like(stress_t)
I_i = stress_t - threshold
alpha, beta = 0.05, 0.1

print(f"  GPU computation...")
for t in range(1, len(stress_t)):
    if I_i[t] > 0:
        W_t[t] = W_t[t-1] + alpha * I_i[t]
    else:
        W_t[t] = W_t[t-1] * (1 - beta)

W_t_cpu = W_t.cpu().numpy()
I_i_cpu = I_i.cpu().numpy()

max_load = float(np.max(W_t_cpu))
crossings = int(np.sum(np.diff(np.sign(I_i_cpu)) != 0))
recovery_pct = float(np.sum(I_i_cpu <= 0) / len(I_i_cpu) * 100)

print(f"  Using: {stress_col}")
print(f"  Max Load: {max_load:.4f}")
print(f"  Crossings: {crossings}")
print(f"  Recovery: {recovery_pct:.1f}%")

# LRI
print("\n[4/5] LRI Clustering...")
scaler2 = StandardScaler()
X_scaled = scaler2.fit_transform(df_clean)

# Use appropriate k based on sample size
k = min(3, len(df_clean) - 1)
kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
labels = kmeans.fit_predict(X_scaled)

if len(np.unique(labels)) > 1:
    sil = float(silhouette_score(X_scaled, labels))
else:
    sil = 0.0

unique, counts = np.unique(labels, return_counts=True)
dist = {int(k): int(v) for k, v in zip(unique, counts)}

print(f"  k={k}, Silhouette: {sil:.4f}")
print(f"  Distribution: {dist}")

# LSTM GPU (if enough samples)
print("\n[5/5] LSTM Training (GPU)...")

if len(df_clean) >= 100:
    data = df_clean.values.astype(np.float32)
    scaler3 = StandardScaler()
    data_scaled = scaler3.fit_transform(data)
    
    # Adaptive sequence length
    seq_len = min(20, len(data_scaled) // 5)
    X_seq, y_seq = [], []
    
    print(f"  Creating sequences (len={seq_len})...")
    for i in range(len(data_scaled) - seq_len):
        X_seq.append(data_scaled[i:i+seq_len])
        y_seq.append(np.mean(data_scaled[i+seq_len]))
    
    X_seq = np.array(X_seq)
    y_seq = np.array(y_seq)
    
    print(f"  Sequences: {X_seq.shape}")
    
    X_train, X_test, y_train, y_test = train_test_split(
        X_seq, y_seq, test_size=0.2, random_state=42
    )
    
    X_train_t = torch.FloatTensor(X_train).to(device)
    y_train_t = torch.FloatTensor(y_train).unsqueeze(1).to(device)
    X_test_t = torch.FloatTensor(X_test).to(device)
    y_test_t = torch.FloatTensor(y_test).unsqueeze(1).to(device)
    
    model = StressLSTM(X_train.shape[2], 64).to(device)
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    
    train_data = TensorDataset(X_train_t, y_train_t)
    train_loader = DataLoader(train_data, batch_size=min(32, len(X_train)), shuffle=True)
    
    print(f"  Training on GPU...")
    model.train()
    for epoch in tqdm(range(20), desc="  Epochs"):
        for batch_X, batch_y in train_loader:
            optimizer.zero_grad()
            pred = model(batch_X)
            loss = criterion(pred, batch_y)
            loss.backward()
            optimizer.step()
    
    model.eval()
    with torch.no_grad():
        pred_test = model(X_test_t)
        mse = criterion(pred_test, y_test_t).item()
        
        y_np = y_test_t.cpu().numpy()
        pred_np = pred_test.cpu().numpy()
        ss_res = np.sum((y_np - pred_np) ** 2)
        ss_tot = np.sum((y_np - np.mean(y_np)) ** 2)
        r2 = 1 - ss_res / ss_tot if ss_tot > 0 else 0
    
    print(f"  MSE: {mse:.6f}")
    print(f"  R2: {r2:.4f}")
    
    # Save model
    torch.save(model.state_dict(), Path("complete_stress_analysis_GPU") / "Nurses_ALL_lstm.pth")
else:
    print(f"  [SKIP] Only {len(df_clean)} samples (need 100+ for LSTM)")
    mse, r2 = None, None

# Save complete results
output_dir = Path("complete_stress_analysis_GPU")
results = {
    'Nurses_COMPLETE': {
        'total_zips_processed': total_zips,
        'total_nurses': len(nurse_dirs),
        'shape': list(df_clean.shape),
        'parameters': list(df_clean.columns),
        'sessions_loaded': len(all_data),
        'sessions_valid': len(df_clean),
        'retention_rate': float(len(df_clean) / len(all_data) * 100),
        'wt': {
            'max_load': max_load,
            'crossings': crossings,
            'recovery_pct': recovery_pct,
            'stress_indicator': stress_col
        },
        'lri': {
            'silhouette': sil,
            'distribution': dist,
            'n_clusters': k
        },
        'lstm': {
            'mse': float(mse) if mse else None,
            'r2': float(r2) if r2 else None,
            'trained': mse is not None
        }
    }
}

with open(output_dir / "Nurses_COMPLETE_results.json", 'w') as f:
    json.dump(results, f, indent=2)

print(f"\n{'='*80}")
print(f"[COMPLETE] Nurses FULL Analysis Finished!")
print(f"{'='*80}")
print(f"\nProcessed:")
print(f"  ZIP files: {total_zips}/609")
print(f"  Nurses: {len(nurse_dirs)}")
print(f"  Valid sessions: {len(df_clean)}")
print(f"  W(t) parameters: {list(df_clean.columns)}")
print(f"\nResults saved:")
print(f"  complete_stress_analysis_GPU/Nurses_COMPLETE_results.json")
if mse:
    print(f"  complete_stress_analysis_GPU/Nurses_ALL_lstm.pth")
print(f"\n{'='*80}\n")














