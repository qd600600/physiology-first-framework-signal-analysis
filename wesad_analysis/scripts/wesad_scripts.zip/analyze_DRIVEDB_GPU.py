#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""DRIVE-DB Dataset Analysis with GPU"""

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader
from pathlib import Path
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.cluster import KMeans
from sklearn.model_selection import train_test_split
from sklearn.metrics import silhouette_score
from tqdm import tqdm
import json
import wfdb

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"\nDevice: {device}\n")

class StressLSTM(nn.Module):
    def __init__(self, input_size, hidden=64):
        super().__init__()
        self.lstm = nn.LSTM(input_size, hidden, 2, batch_first=True, dropout=0.2)
        self.fc = nn.Linear(hidden, 1)
    def forward(self, x):
        out, _ = self.lstm(x)
        return self.fc(out[:, -1, :])

# Load DRIVE-DB
print("[1/5] Loading DRIVE-DB...")
drivedb_dir = Path("data/Stress_Datasets_Updated/Extended_Verification_Group/DRIVE_DB/extracted/stress-recognition-in-automobile-drivers-1.0.0")
dat_files = list(drivedb_dir.glob("*.dat"))[:5]

all_data = []
for dat_file in tqdm(dat_files, desc="  Loading"):
    try:
        record = wfdb.rdrecord(str(drivedb_dir / dat_file.stem))
        df_rec = pd.DataFrame(record.p_signal, columns=record.sig_name)
        all_data.append(df_rec)
    except:
        pass

df = pd.concat(all_data, ignore_index=True)
print(f"  Loaded: {df.shape}")

# Preprocess
print("\n[2/5] Preprocessing...")
df_num = df.select_dtypes(include=[np.number])
missing_pct = df_num.isnull().sum() / len(df_num) * 100
cols_drop = missing_pct[missing_pct > 30].index
df_num = df_num.drop(columns=cols_drop)
df_num = df_num.fillna(df_num.mean())

Q1, Q3 = df_num.quantile(0.25), df_num.quantile(0.75)
IQR = Q3 - Q1
mask = ~((df_num < (Q1 - 3*IQR)) | (df_num > (Q3 + 3*IQR))).any(axis=1)
df_clean = df_num[mask]
print(f"  Shape: {df.shape} -> {df_clean.shape}")

# W(t) GPU
print("\n[3/5] W(t) Simulation (GPU)...")
stress_data = df_clean.iloc[:, 0].values
scaler = MinMaxScaler((0, 10))
stress_norm = scaler.fit_transform(stress_data.reshape(-1, 1)).flatten()

stress_t = torch.FloatTensor(stress_norm).to(device)
threshold = float(torch.median(stress_t) + 0.5 * torch.std(stress_t))

W_t = torch.zeros_like(stress_t)
I_i = stress_t - threshold
alpha, beta = 0.05, 0.1

for t in range(1, len(stress_t)):
    if I_i[t] > 0:
        W_t[t] = W_t[t-1] + alpha * I_i[t]
    else:
        W_t[t] = W_t[t-1] * (1 - beta)

W_t_cpu = W_t.cpu().numpy()
I_i_cpu = I_i.cpu().numpy()

max_load = float(np.max(W_t_cpu))
crossings = int(np.sum(np.diff(np.sign(I_i_cpu)) != 0))
recovery_pct = float(np.sum(I_i_cpu <= 0) / len(I_i_cpu) * 100)

print(f"  Max Load: {max_load:.4f}")
print(f"  Crossings: {crossings}")
print(f"  Recovery: {recovery_pct:.1f}%")

# LRI
print("\n[4/5] LRI Clustering...")
scaler2 = StandardScaler()
X_scaled = scaler2.fit_transform(df_clean)

if len(X_scaled) > 50000:
    idx = np.random.choice(len(X_scaled), 50000, replace=False)
    X_sample = X_scaled[idx]
else:
    X_sample = X_scaled

kmeans = KMeans(n_clusters=3, random_state=42, n_init=10)
labels = kmeans.fit_predict(X_sample)
labels_full = kmeans.predict(X_scaled)

sil = silhouette_score(X_sample, labels)
unique, counts = np.unique(labels_full, return_counts=True)
dist = {int(k): int(v) for k, v in zip(unique, counts)}

print(f"  Silhouette: {sil:.4f}")
print(f"  Distribution: {dist}")

# LSTM GPU
print("\n[5/5] LSTM Training (GPU)...")

data = df_clean.values.astype(np.float32)
scaler3 = StandardScaler()
data_scaled = scaler3.fit_transform(data)

seq_len = 50
X_seq, y_seq = [], []

for i in range(len(data_scaled) - seq_len):
    X_seq.append(data_scaled[i:i+seq_len])
    y_seq.append(np.mean(data_scaled[i+seq_len]))

X_seq = np.array(X_seq)
y_seq = np.array(y_seq)

X_train, X_test, y_train, y_test = train_test_split(
    X_seq, y_seq, test_size=0.2, random_state=42
)

X_train_t = torch.FloatTensor(X_train).to(device)
y_train_t = torch.FloatTensor(y_train).unsqueeze(1).to(device)
X_test_t = torch.FloatTensor(X_test).to(device)
y_test_t = torch.FloatTensor(y_test).unsqueeze(1).to(device)

model = StressLSTM(X_train.shape[2], 64).to(device)
criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

train_data = TensorDataset(X_train_t, y_train_t)
train_loader = DataLoader(train_data, batch_size=128, shuffle=True)

model.train()
for epoch in tqdm(range(20), desc="  Epochs"):
    for batch_X, batch_y in train_loader:
        optimizer.zero_grad()
        pred = model(batch_X)
        loss = criterion(pred, batch_y)
        loss.backward()
        optimizer.step()

model.eval()
with torch.no_grad():
    pred_test = model(X_test_t)
    mse = criterion(pred_test, y_test_t).item()
    
    y_np = y_test_t.cpu().numpy()
    pred_np = pred_test.cpu().numpy()
    ss_res = np.sum((y_np - pred_np) ** 2)
    ss_tot = np.sum((y_np - np.mean(y_np)) ** 2)
    r2 = 1 - ss_res / ss_tot

print(f"  MSE: {mse:.6f}")
print(f"  R2: {r2:.4f}")

# Save
output_dir = Path("complete_stress_analysis_GPU")
results = {
    'DRIVE-DB': {
        'shape': df_clean.shape,
        'wt': {'max_load': max_load, 'crossings': crossings, 'recovery_pct': recovery_pct},
        'lri': {'silhouette': float(sil), 'distribution': dist},
        'lstm': {'mse': float(mse), 'r2': float(r2)}
    }
}

with open(output_dir / "DRIVEDB_results.json", 'w') as f:
    json.dump(results, f, indent=2)

torch.save(model.state_dict(), output_dir / "DRIVEDB_lstm.pth")

print(f"\n[COMPLETE] DRIVE-DB analysis finished!")














