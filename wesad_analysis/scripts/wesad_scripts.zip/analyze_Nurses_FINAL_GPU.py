#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Nurses Dataset Analysis - CORRECT FORMAT with GPU
Each ZIP contains: ACC.csv, EDA.csv, BVP.csv, TEMP.csv, IBI.csv, HR.csv
"""

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader
from pathlib import Path
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.cluster import KMeans
from sklearn.model_selection import train_test_split
from sklearn.metrics import silhouette_score
from tqdm import tqdm
import json
import zipfile
import shutil

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"\nDevice: {device}\n")

class StressLSTM(nn.Module):
    def __init__(self, input_size, hidden=64):
        super().__init__()
        self.lstm = nn.LSTM(input_size, hidden, 2, batch_first=True, dropout=0.2)
        self.fc = nn.Linear(hidden, 1)
    def forward(self, x):
        out, _ = self.lstm(x)
        return self.fc(out[:, -1, :])

# Load Nurses - CORRECT FORMAT
print("[1/5] Loading Nurses (W(t) parameters only)...")
nurses_base = Path("data/Stress_Datasets_Updated/Core_Verification_Group/Nurses/extracted/Stress_dataset")

nurse_dirs = [d for d in nurses_base.iterdir() 
              if d.is_dir() and not d.name.startswith('sample')]

print(f"  Found {len(nurse_dirs)} nurses")

# W(t) relevant files to extract
wt_files = ['HR.csv', 'EDA.csv', 'IBI.csv', 'TEMP.csv', 'BVP.csv', 'ACC.csv']

all_data = []
temp_dir = Path("complete_stress_analysis_GPU/temp_nurses")
temp_dir.mkdir(parents=True, exist_ok=True)

max_nurses = 5
max_zips = 10

total_zips = min(max_nurses, len(nurse_dirs)) * max_zips

with tqdm(total=total_zips, desc="  Loading") as pbar:
    for nurse_dir in nurse_dirs[:max_nurses]:
        zip_files = list(nurse_dir.glob("*.zip"))[:max_zips]
        
        for zip_file in zip_files:
            try:
                session_data = {}
                
                with zipfile.ZipFile(zip_file, 'r') as z:
                    # Extract only W(t) files
                    for wt_file in wt_files:
                        if wt_file in z.namelist():
                            z.extract(wt_file, temp_dir)
                            
                            # Read the file
                            file_path = temp_dir / wt_file
                            try:
                                df_temp = pd.read_csv(file_path, header=None, nrows=5000)
                                
                                # Get mean value as feature
                                param_name = wt_file.replace('.csv', '')
                                session_data[param_name] = df_temp.values.flatten().mean()
                            except:
                                pass
                            
                            # Clean
                            if file_path.exists():
                                file_path.unlink()
                
                # Create one row per session
                if session_data:
                    all_data.append(session_data)
            except:
                pass
            pbar.update(1)

shutil.rmtree(temp_dir, ignore_errors=True)

if not all_data:
    print("[ERROR] No data loaded")
    exit(1)

df = pd.DataFrame(all_data)
print(f"  Loaded: {df.shape}")
print(f"  Parameters: {list(df.columns)}")

# Preprocess
print("\n[2/5] Preprocessing...")
df = df.fillna(df.mean())

# Remove outliers per column
df_clean = df.copy()
for col in df.columns:
    Q1, Q3 = df[col].quantile(0.25), df[col].quantile(0.75)
    IQR = Q3 - Q1
    lower, upper = Q1 - 5*IQR, Q3 + 5*IQR
    df_clean = df_clean[(df_clean[col] >= lower) & (df_clean[col] <= upper)]

print(f"  Shape: {df.shape} -> {df_clean.shape}")

if len(df_clean) < 20:
    print(f"  [WARN] Only {len(df_clean)} samples, adjusting...")
    # Use original data if filtering too aggressive
    df_clean = df.copy()
    print(f"  Using all: {df_clean.shape}")

# W(t) GPU
print("\n[3/5] W(t) Simulation (GPU)...")

# Use HR or EDA as primary stress indicator
stress_col = 'HR' if 'HR' in df_clean.columns else df_clean.columns[0]
stress_data = df_clean[stress_col].values

scaler = MinMaxScaler((0, 10))
stress_norm = scaler.fit_transform(stress_data.reshape(-1, 1)).flatten()

stress_t = torch.FloatTensor(stress_norm).to(device)
threshold = float(torch.median(stress_t) + 0.5 * torch.std(stress_t))

W_t = torch.zeros_like(stress_t)
I_i = stress_t - threshold
alpha, beta = 0.05, 0.1

for t in range(1, len(stress_t)):
    if I_i[t] > 0:
        W_t[t] = W_t[t-1] + alpha * I_i[t]
    else:
        W_t[t] = W_t[t-1] * (1 - beta)

W_t_cpu = W_t.cpu().numpy()
I_i_cpu = I_i.cpu().numpy()

max_load = float(np.max(W_t_cpu))
crossings = int(np.sum(np.diff(np.sign(I_i_cpu)) != 0))
recovery_pct = float(np.sum(I_i_cpu <= 0) / len(I_i_cpu) * 100)

print(f"  Using: {stress_col}")
print(f"  Max Load: {max_load:.4f}")
print(f"  Crossings: {crossings}")
print(f"  Recovery: {recovery_pct:.1f}%")

# LRI
print("\n[4/5] LRI Clustering...")
scaler2 = StandardScaler()
X_scaled = scaler2.fit_transform(df_clean)

kmeans = KMeans(n_clusters=min(3, len(df_clean)-1), random_state=42, n_init=10)
labels = kmeans.fit_predict(X_scaled)

if len(np.unique(labels)) > 1:
    sil = silhouette_score(X_scaled, labels)
else:
    sil = 0.0

unique, counts = np.unique(labels, return_counts=True)
dist = {int(k): int(v) for k, v in zip(unique, counts)}

print(f"  Silhouette: {sil:.4f}")
print(f"  Distribution: {dist}")

# LSTM GPU (if enough samples)
print("\n[5/5] LSTM Training (GPU)...")

if len(df_clean) >= 100:
    data = df_clean.values.astype(np.float32)
    scaler3 = StandardScaler()
    data_scaled = scaler3.fit_transform(data)
    
    seq_len = min(20, len(data_scaled) // 5)  # Adaptive seq length
    X_seq, y_seq = [], []
    
    for i in range(len(data_scaled) - seq_len):
        X_seq.append(data_scaled[i:i+seq_len])
        y_seq.append(np.mean(data_scaled[i+seq_len]))
    
    X_seq = np.array(X_seq)
    y_seq = np.array(y_seq)
    
    print(f"  Sequences: {X_seq.shape}")
    
    X_train, X_test, y_train, y_test = train_test_split(
        X_seq, y_seq, test_size=0.2, random_state=42
    )
    
    X_train_t = torch.FloatTensor(X_train).to(device)
    y_train_t = torch.FloatTensor(y_train).unsqueeze(1).to(device)
    X_test_t = torch.FloatTensor(X_test).to(device)
    y_test_t = torch.FloatTensor(y_test).unsqueeze(1).to(device)
    
    model = StressLSTM(X_train.shape[2], 32).to(device)  # Smaller for less data
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    
    train_data = TensorDataset(X_train_t, y_train_t)
    train_loader = DataLoader(train_data, batch_size=min(32, len(X_train)), shuffle=True)
    
    model.train()
    for epoch in tqdm(range(15), desc="  Epochs"):  # Fewer epochs
        for batch_X, batch_y in train_loader:
            optimizer.zero_grad()
            pred = model(batch_X)
            loss = criterion(pred, batch_y)
            loss.backward()
            optimizer.step()
    
    model.eval()
    with torch.no_grad():
        pred_test = model(X_test_t)
        mse = criterion(pred_test, y_test_t).item()
        
        y_np = y_test_t.cpu().numpy()
        pred_np = pred_test.cpu().numpy()
        ss_res = np.sum((y_np - pred_np) ** 2)
        ss_tot = np.sum((y_np - np.mean(y_np)) ** 2)
        r2 = 1 - ss_res / ss_tot if ss_tot > 0 else 0
    
    print(f"  MSE: {mse:.6f}")
    print(f"  R2: {r2:.4f}")
    
    torch.save(model.state_dict(), Path("complete_stress_analysis_GPU") / "Nurses_lstm.pth")
else:
    print(f"  [SKIP] Too few samples for LSTM ({len(df_clean)})")
    mse, r2 = None, None

# Save
output_dir = Path("complete_stress_analysis_GPU")
results = {
    'Nurses': {
        'shape': df_clean.shape,
        'parameters': list(df_clean.columns),
        'sessions_loaded': len(all_data),
        'wt': {'max_load': max_load, 'crossings': crossings, 'recovery_pct': recovery_pct},
        'lri': {'silhouette': float(sil), 'distribution': dist},
        'lstm': {'mse': float(mse) if mse else None, 'r2': float(r2) if r2 else None}
    }
}

with open(output_dir / "Nurses_results.json", 'w') as f:
    json.dump(results, f, indent=2)

print(f"\n[COMPLETE] Nurses analysis finished!")
print(f"  Sessions: {len(all_data)}")
print(f"  W(t) parameters: {list(df_clean.columns)}")














