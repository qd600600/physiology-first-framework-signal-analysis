#!/usr/bin/env python3
"""
第二步：基于理论机制的特征提取
根据LRI理论背景，提取多层级特征用于后续分析
"""

import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
import warnings
from scipy import stats, signal
from sklearn.feature_selection import mutual_info_regression
from sklearn.preprocessing import StandardScaler
import multiprocessing as mp
from concurrent.futures import ThreadPoolExecutor

warnings.filterwarnings('ignore')

class TheoryBasedFeatureExtractor:
    def __init__(self):
        self.feature_results = {}
        self.selected_features = {}
        
    def extract_physiological_baseline_features(self, data, window_sizes=[10, 30, 60]):
        """提取生理基线层特征"""
        features = {}
        
        # HR基线特征
        if 'HR' in data.columns or 'hr' in data.columns:
            hr_col = 'HR' if 'HR' in data.columns else 'hr'
            hr_data = data[hr_col].dropna()
            
            for window in window_sizes:
                # 滚动窗口统计
                rolling_mean = hr_data.rolling(window=window, min_periods=window//2).mean()
                rolling_std = hr_data.rolling(window=window, min_periods=window//2).std()
                
                features[f'HR_mean_{window}s'] = rolling_mean.mean()
                features[f'HR_std_{window}s'] = rolling_std.mean()
                features[f'HR_baseline_stability_{window}s'] = 1 / (rolling_std.std() + 1e-6)
        
        # TEMP基线特征
        temp_cols = [col for col in data.columns if 'temp' in col.lower()]
        if temp_cols:
            temp_col = temp_cols[0]
            temp_data = data[temp_col].dropna()
            
            for window in window_sizes:
                rolling_mean = temp_data.rolling(window=window, min_periods=window//2).mean()
                features[f'TEMP_baseline_{window}s'] = rolling_mean.mean()
                features[f'TEMP_stability_{window}s'] = 1 / (rolling_mean.std() + 1e-6)
        
        # EDA基线特征
        eda_cols = [col for col in data.columns if 'eda' in col.lower()]
        if eda_cols:
            eda_col = eda_cols[0]
            eda_data = data[eda_col].dropna()
            
            for window in window_sizes:
                rolling_mean = eda_data.rolling(window=window, min_periods=window//2).mean()
                features[f'EDA_baseline_{window}s'] = rolling_mean.mean()
        
        return features
    
    def extract_dynamic_response_features(self, data, window_sizes=[10, 30, 60]):
        """提取动态响应层特征"""
        features = {}
        
        # HRV动态特征
        if 'HRV' in data.columns or 'hrv' in data.columns:
            hrv_col = 'HRV' if 'HRV' in data.columns else 'hrv'
            hrv_data = data[hrv_col].dropna()
            
            for window in window_sizes:
                rolling_std = hrv_data.rolling(window=window, min_periods=window//2).std()
                features[f'HRV_variability_{window}s'] = rolling_std.mean()
                features[f'HRV_reactivity_{window}s'] = rolling_std.std()
        
        # EDA相位响应
        eda_cols = [col for col in data.columns if 'eda' in col.lower()]
        if eda_cols:
            eda_col = eda_cols[0]
            eda_data = data[eda_col].dropna()
            
            for window in window_sizes:
                rolling_std = eda_data.rolling(window=window, min_periods=window//2).std()
                features[f'EDA_phasic_amp_{window}s'] = rolling_std.mean()
        
        # ACC峰值响应
        acc_cols = [col for col in data.columns if 'acc' in col.lower()]
        if acc_cols:
            for acc_col in acc_cols:
                acc_data = data[acc_col].dropna()
                for window in window_sizes:
                    rolling_max = acc_data.rolling(window=window, min_periods=window//2).max()
                    rolling_min = acc_data.rolling(window=window, min_periods=window//2).min()
                    features[f'{acc_col}_peak_range_{window}s'] = (rolling_max - rolling_min).mean()
        
        return features
    
    def extract_coupling_features(self, data, window_sizes=[10, 30, 60]):
        """提取耦合层特征"""
        features = {}
        
        # HR-EDA耦合
        hr_cols = [col for col in data.columns if 'hr' in col.lower() and 'hrv' not in col.lower()]
        eda_cols = [col for col in data.columns if 'eda' in col.lower()]
        
        if hr_cols and eda_cols:
            hr_col = hr_cols[0]
            eda_col = eda_cols[0]
            hr_data = data[hr_col].dropna()
            eda_data = data[eda_col].dropna()
            
            # 对齐数据
            min_len = min(len(hr_data), len(eda_data))
            hr_aligned = hr_data.iloc[:min_len]
            eda_aligned = eda_data.iloc[:min_len]
            
            for window in window_sizes:
                if min_len > window:
                    # 计算滑动窗口相关性
                    correlations = []
                    for i in range(0, min_len - window, window//2):
                        hr_window = hr_aligned.iloc[i:i+window]
                        eda_window = eda_aligned.iloc[i:i+window]
                        if len(hr_window) > 5 and len(eda_window) > 5:
                            corr = np.corrcoef(hr_window, eda_window)[0, 1]
                            if not np.isnan(corr):
                                correlations.append(abs(corr))
                    
                    if correlations:
                        features[f'HR_EDA_coherence_{window}s'] = np.mean(correlations)
        
        # ACC-GYR相位同步
        acc_cols = [col for col in data.columns if 'acc' in col.lower()]
        gyr_cols = [col for col in data.columns if 'gyr' in col.lower()]
        
        if acc_cols and gyr_cols:
            acc_col = acc_cols[0]
            gyr_col = gyr_cols[0]
            acc_data = data[acc_col].dropna()
            gyr_data = data[gyr_col].dropna()
            
            min_len = min(len(acc_data), len(gyr_data))
            if min_len > 100:  # 确保有足够的数据点
                acc_aligned = acc_data.iloc[:min_len]
                gyr_aligned = gyr_data.iloc[:min_len]
                
                # 计算相位差
                phase_diff = np.angle(np.fft.fft(acc_aligned)) - np.angle(np.fft.fft(gyr_aligned))
                features[f'ACC_GYR_phase_sync'] = np.std(phase_diff)
        
        return features
    
    def extract_complexity_features(self, data, window_sizes=[10, 30, 60]):
        """提取复杂性层特征"""
        features = {}
        
        # 计算熵特征
        for col in data.columns:
            if data[col].dtype in ['float64', 'int64']:
                col_data = data[col].dropna()
                if len(col_data) > 50:
                    # 近似熵
                    features[f'{col}_approximate_entropy'] = self.calculate_approximate_entropy(col_data)
                    
                    # Lempel-Ziv复杂度
                    features[f'{col}_lz_complexity'] = self.calculate_lz_complexity(col_data)
        
        return features
    
    def calculate_approximate_entropy(self, data, m=2, r=0.2):
        """计算近似熵"""
        try:
            N = len(data)
            if N < 10:
                return 0
            
            # 标准化数据
            data_std = (data - data.mean()) / data.std()
            
            def _maxdist(xi, xj, N):
                return max([abs(ua - va) for ua, va in zip(xi, xj)])
            
            def _get_patterns(data, m):
                patterns = []
                for i in range(len(data) - m + 1):
                    patterns.append(data[i:i+m])
                return patterns
            
            def _approximate_entropy(data, m, r):
                N = len(data)
                patterns = _get_patterns(data, m)
                C = np.zeros(N - m + 1)
                
                for i in range(N - m + 1):
                    template_i = patterns[i]
                    for j in range(N - m + 1):
                        if _maxdist(template_i, patterns[j], m) <= r:
                            C[i] += 1.0
                
                phi = np.mean(np.log(C / float(N - m + 1.0)))
                return phi
            
            return _approximate_entropy(data_std, m, r * data_std.std())
        except:
            return 0
    
    def calculate_lz_complexity(self, data, threshold=None):
        """计算Lempel-Ziv复杂度"""
        try:
            if threshold is None:
                threshold = np.median(data)
            
            # 二值化
            binary_string = ''.join(['1' if x > threshold else '0' for x in data])
            
            # 计算LZ复杂度
            complexity = 0
            i = 0
            while i < len(binary_string):
                for j in range(i + 1, len(binary_string) + 1):
                    substring = binary_string[i:j]
                    if binary_string.find(substring, 0, i) == -1:
                        complexity += 1
                        i = j - 1
                        break
                i += 1
            
            return complexity / len(binary_string)
        except:
            return 0
    
    def extract_anomaly_features(self, data, window_sizes=[10, 30, 60]):
        """提取异常激活层特征"""
        features = {}
        
        # 高频功率比
        for col in data.columns:
            if data[col].dtype in ['float64', 'int64']:
                col_data = data[col].dropna()
                if len(col_data) > 100:
                    # FFT分析
                    fft = np.fft.fft(col_data)
                    freqs = np.fft.fftfreq(len(col_data))
                    
                    # 低频和高频功率
                    low_freq_power = np.sum(np.abs(fft[freqs < 0.1])**2)
                    high_freq_power = np.sum(np.abs(fft[freqs >= 0.1])**2)
                    
                    if low_freq_power > 0:
                        features[f'{col}_high_freq_ratio'] = high_freq_power / low_freq_power
        
        # 温度斜率
        temp_cols = [col for col in data.columns if 'temp' in col.lower()]
        if temp_cols:
            temp_col = temp_cols[0]
            temp_data = data[temp_col].dropna()
            if len(temp_data) > 10:
                temp_diff = temp_data.diff().dropna()
                features[f'TEMP_slope_mean'] = temp_diff.mean()
                features[f'TEMP_slope_var'] = temp_diff.var()
        
        # 加速度抖动方差
        acc_cols = [col for col in data.columns if 'acc' in col.lower()]
        if acc_cols:
            for acc_col in acc_cols:
                acc_data = data[acc_col].dropna()
                if len(acc_data) > 10:
                    acc_diff2 = acc_data.diff().diff().dropna()  # 二阶差分
                    features[f'{acc_col}_jerk_variance'] = acc_diff2.var()
        
        return features
    
    def extract_all_features(self, data, dataset_name):
        """提取所有层级特征"""
        print(f"  🔬 提取 {dataset_name} 特征...")
        
        all_features = {}
        
        # 提取各层级特征
        baseline_features = self.extract_physiological_baseline_features(data)
        dynamic_features = self.extract_dynamic_response_features(data)
        coupling_features = self.extract_coupling_features(data)
        complexity_features = self.extract_complexity_features(data)
        anomaly_features = self.extract_anomaly_features(data)
        
        # 合并特征
        all_features.update(baseline_features)
        all_features.update(dynamic_features)
        all_features.update(coupling_features)
        all_features.update(complexity_features)
        all_features.update(anomaly_features)
        
        print(f"    ✅ 提取了 {len(all_features)} 个特征")
        
        return all_features
    
    def load_and_process_datasets(self):
        """加载并处理所有数据集"""
        print("📂 加载数据集并提取特征...")
        
        # 数据集路径
        dataset_paths = {
            "WESAD": "data/filtered/core_WESAD_filtered.csv",
            "MMASH": "data/filtered/core_MMASH_filtered.csv", 
            "CRWD": "data/CRWD/extracted/CRWD/sensor_hrv_filtered.csv",
            "Enhanced_Health": "data/Enhanced_Health/processed/enhanced_large_health_dataset.csv"
        }
        
        for dataset_name, path in dataset_paths.items():
            if Path(path).exists():
                print(f"  📊 处理 {dataset_name}...")
                
                try:
                    # 读取数据
                    if Path(path).stat().st_size / (1024 * 1024) > 100:
                        data = pd.read_csv(path, nrows=10000)
                    else:
                        data = pd.read_csv(path)
                    
                    # 处理IBI数据
                    if dataset_name in ["WESAD", "MMASH"]:
                        data = self.process_ibi_data(data, dataset_name)
                    
                    # 提取特征
                    features = self.extract_all_features(data, dataset_name)
                    
                    # 添加标签信息
                    features['dataset'] = dataset_name
                    features['n_samples'] = len(data)
                    
                    self.feature_results[dataset_name] = {
                        'features': features,
                        'data': data
                    }
                    
                except Exception as e:
                    print(f"    ❌ {dataset_name}: 处理失败 - {e}")
            else:
                print(f"  ⚠️  {dataset_name}: 路径不存在")
    
    def process_ibi_data(self, data, dataset_name):
        """处理IBI数据"""
        ibi_col = 'ibi' if 'ibi' in data.columns else 'ibi_s'
        if ibi_col in data.columns:
            # 计算HR和HRV
            data['HR'] = 60 / data[ibi_col]
            data['HRV'] = data[ibi_col].rolling(window=30, min_periods=10).std()
            
            # 创建压力标签
            if 'time' in data.columns:
                ibi_diff = data[ibi_col].diff().abs()
                threshold = ibi_diff.quantile(0.6)
                data['stress_label'] = (ibi_diff > threshold).astype(int)
            else:
                hrv_threshold = data['HRV'].quantile(0.7)
                data['stress_label'] = (data['HRV'] > hrv_threshold).astype(int)
        
        return data
    
    def generate_feature_report(self):
        """生成特征报告"""
        print("📝 生成特征报告...")
        
        # 收集所有特征
        all_features_df = []
        
        for dataset_name, result in self.feature_results.items():
            features = result['features']
            features['dataset'] = dataset_name
            
            # 只保留数值特征
            numeric_features = {}
            for key, value in features.items():
                if isinstance(value, (int, float)) and not np.isnan(value):
                    numeric_features[key] = value
            
            all_features_df.append(numeric_features)
        
        if all_features_df:
            df = pd.DataFrame(all_features_df)
            df.to_csv("selected_features.csv", index=False)
            print("✅ selected_features.csv 已生成")
            
            # 生成特征统计
            feature_stats = []
            for col in df.columns:
                if col not in ['dataset', 'n_samples']:
                    values = df[col].dropna()
                    if len(values) > 0:
                        feature_stats.append({
                            'feature': col,
                            'mean': values.mean(),
                            'std': values.std(),
                            'min': values.min(),
                            'max': values.max(),
                            'coverage': len(values) / len(df)
                        })
            
            feature_stats_df = pd.DataFrame(feature_stats)
            feature_stats_df.to_csv("feature_statistics.csv", index=False)
            print("✅ feature_statistics.csv 已生成")
            
            return df, feature_stats_df
        else:
            print("❌ 没有提取到有效特征")
            return None, None
    
    def run_extraction(self):
        """运行特征提取"""
        print("🚀 开始基于理论机制的特征提取")
        print("=" * 60)
        print("🎯 提取五层级特征:")
        print("   ① 生理基线层 - 稳态基准")
        print("   ② 动态响应层 - 短时反应")
        print("   ③ 耦合层 - 系统协调性")
        print("   ④ 复杂性层 - 非线性动态")
        print("   ⑤ 异常激活层 - 应激触发信号")
        print("=" * 60)
        
        # 加载和处理数据集
        self.load_and_process_datasets()
        
        # 生成报告
        features_df, stats_df = self.generate_feature_report()
        
        print("=" * 60)
        print("✅ 特征提取完成！")
        print(f"📊 处理了 {len(self.feature_results)} 个数据集")
        
        if features_df is not None:
            print(f"📈 提取了 {len(features_df.columns)-2} 个特征")
            print("📁 输出文件:")
            print("   - selected_features.csv")
            print("   - feature_statistics.csv")
        
        return self.feature_results

if __name__ == "__main__":
    extractor = TheoryBasedFeatureExtractor()
    results = extractor.run_extraction()





