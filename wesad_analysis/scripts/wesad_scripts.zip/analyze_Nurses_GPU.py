#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Nurses Dataset Analysis with GPU - Fixed nested directory structure"""

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader
from pathlib import Path
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.cluster import KMeans
from sklearn.model_selection import train_test_split
from sklearn.metrics import silhouette_score
from tqdm import tqdm
import json
import zipfile
import shutil

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"\nDevice: {device}\n")

class StressLSTM(nn.Module):
    def __init__(self, input_size, hidden=64):
        super().__init__()
        self.lstm = nn.LSTM(input_size, hidden, 2, batch_first=True, dropout=0.2)
        self.fc = nn.Linear(hidden, 1)
    def forward(self, x):
        out, _ = self.lstm(x)
        return self.fc(out[:, -1, :])

# Load Nurses - FIXED: scan all nurse ID subdirectories
print("[1/5] Loading Nurses (scanning all nurse IDs)...")
nurses_base = Path("data/Stress_Datasets_Updated/Core_Verification_Group/Nurses/extracted/Stress_dataset")

# Get all nurse ID directories (exclude sample directory)
nurse_dirs = [d for d in nurses_base.iterdir() 
              if d.is_dir() and not d.name.startswith('sample')]

print(f"  Found {len(nurse_dirs)} nurse IDs: {[d.name for d in nurse_dirs]}")

all_data = []
temp_dir = Path("complete_stress_analysis_GPU/temp_nurses")
temp_dir.mkdir(parents=True, exist_ok=True)

# Load from first 5 nurses, 10 sessions each (more data!)
max_nurses = 5
max_sessions = 10

with tqdm(total=max_nurses*max_sessions, desc="  Extracting") as pbar:
    for nurse_dir in nurse_dirs[:max_nurses]:
        zip_files = list(nurse_dir.glob("*.zip"))[:max_sessions]
        
        for zip_file in zip_files:
            try:
                with zipfile.ZipFile(zip_file, 'r') as z:
                    z.extractall(temp_dir)
                
                csv_files = list(temp_dir.rglob("*.csv"))
                for csv_file in csv_files:
                    try:
                        df_temp = pd.read_csv(csv_file, nrows=1000)
                        all_data.append(df_temp)
                    except:
                        pass
                
                # Clean
                for f in temp_dir.rglob("*"):
                    if f.is_file():
                        f.unlink()
            except:
                pass
            pbar.update(1)

shutil.rmtree(temp_dir, ignore_errors=True)

if not all_data:
    print("[ERROR] No Nurses data loaded")
    exit(1)

df = pd.concat(all_data, ignore_index=True)
print(f"  Loaded: {df.shape} from {len(all_data)} sessions")

# Preprocess - FIXED: Per-column outlier removal for high-dimensional data
print("\n[2/5] Preprocessing...")
df_num = df.select_dtypes(include=[np.number])
df_num = df_num.fillna(df_num.mean())

# For high-dimensional data (77 features), use per-column filtering
print(f"  Removing outliers per column (not all-at-once)...")
df_clean = df_num.copy()

for col in df_num.columns:
    Q1 = df_num[col].quantile(0.25)
    Q3 = df_num[col].quantile(0.75)
    IQR = Q3 - Q1
    lower = Q1 - 5 * IQR  # More lenient: 5x instead of 3x
    upper = Q3 + 5 * IQR
    df_clean = df_clean[(df_clean[col] >= lower) & (df_clean[col] <= upper)]

print(f"  Shape: {df.shape} -> {df_clean.shape}")

if len(df_clean) < 100:
    print("[ERROR] Too few samples")
    exit(1)

# W(t) GPU
print("\n[3/5] W(t) Simulation (GPU)...")
stress_data = df_clean.iloc[:, 0].values
scaler = MinMaxScaler((0, 10))
stress_norm = scaler.fit_transform(stress_data.reshape(-1, 1)).flatten()

stress_t = torch.FloatTensor(stress_norm).to(device)
threshold = float(torch.median(stress_t) + 0.5 * torch.std(stress_t))

W_t = torch.zeros_like(stress_t)
I_i = stress_t - threshold
alpha, beta = 0.05, 0.1

for t in range(1, len(stress_t)):
    if I_i[t] > 0:
        W_t[t] = W_t[t-1] + alpha * I_i[t]
    else:
        W_t[t] = W_t[t-1] * (1 - beta)

W_t_cpu = W_t.cpu().numpy()
I_i_cpu = I_i.cpu().numpy()

max_load = float(np.max(W_t_cpu))
crossings = int(np.sum(np.diff(np.sign(I_i_cpu)) != 0))
recovery_pct = float(np.sum(I_i_cpu <= 0) / len(I_i_cpu) * 100)

print(f"  Max Load: {max_load:.4f}")
print(f"  Crossings: {crossings}")
print(f"  Recovery: {recovery_pct:.1f}%")

# LRI
print("\n[4/5] LRI Clustering...")
scaler2 = StandardScaler()
X_scaled = scaler2.fit_transform(df_clean)

if len(X_scaled) > 50000:
    idx = np.random.choice(len(X_scaled), 50000, replace=False)
    X_sample = X_scaled[idx]
else:
    X_sample = X_scaled

kmeans = KMeans(n_clusters=3, random_state=42, n_init=10)
labels = kmeans.fit_predict(X_sample)
labels_full = kmeans.predict(X_scaled)

sil = silhouette_score(X_sample, labels)
unique, counts = np.unique(labels_full, return_counts=True)
dist = {int(k): int(v) for k, v in zip(unique, counts)}

print(f"  Silhouette: {sil:.4f}")
print(f"  Distribution: {dist}")

# LSTM GPU
print("\n[5/5] LSTM Training (GPU)...")

data = df_clean.values.astype(np.float32)
scaler3 = StandardScaler()
data_scaled = scaler3.fit_transform(data)

seq_len = 50
X_seq, y_seq = [], []

for i in range(len(data_scaled) - seq_len):
    X_seq.append(data_scaled[i:i+seq_len])
    y_seq.append(np.mean(data_scaled[i+seq_len]))

X_seq = np.array(X_seq)
y_seq = np.array(y_seq)

print(f"  Sequences: {X_seq.shape}")

X_train, X_test, y_train, y_test = train_test_split(
    X_seq, y_seq, test_size=0.2, random_state=42
)

X_train_t = torch.FloatTensor(X_train).to(device)
y_train_t = torch.FloatTensor(y_train).unsqueeze(1).to(device)
X_test_t = torch.FloatTensor(X_test).to(device)
y_test_t = torch.FloatTensor(y_test).unsqueeze(1).to(device)

model = StressLSTM(X_train.shape[2], 64).to(device)
criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

train_data = TensorDataset(X_train_t, y_train_t)
train_loader = DataLoader(train_data, batch_size=128, shuffle=True)

model.train()
for epoch in tqdm(range(20), desc="  Epochs"):
    for batch_X, batch_y in train_loader:
        optimizer.zero_grad()
        pred = model(batch_X)
        loss = criterion(pred, batch_y)
        loss.backward()
        optimizer.step()

model.eval()
with torch.no_grad():
    pred_test = model(X_test_t)
    mse = criterion(pred_test, y_test_t).item()
    
    y_np = y_test_t.cpu().numpy()
    pred_np = pred_test.cpu().numpy()
    ss_res = np.sum((y_np - pred_np) ** 2)
    ss_tot = np.sum((y_np - np.mean(y_np)) ** 2)
    r2 = 1 - ss_res / ss_tot

print(f"  MSE: {mse:.6f}")
print(f"  R2: {r2:.4f}")

# Save
output_dir = Path("complete_stress_analysis_GPU")
results = {
    'Nurses': {
        'shape': df_clean.shape,
        'nurse_ids_loaded': [d.name for d in nurse_dirs[:max_nurses]],
        'sessions_loaded': len(all_data),
        'wt': {'max_load': max_load, 'crossings': crossings, 'recovery_pct': recovery_pct},
        'lri': {'silhouette': float(sil), 'distribution': dist},
        'lstm': {'mse': float(mse), 'r2': float(r2)}
    }
}

with open(output_dir / "Nurses_results.json", 'w') as f:
    json.dump(results, f, indent=2)

torch.save(model.state_dict(), output_dir / "Nurses_lstm.pth")

print(f"\n[COMPLETE] Nurses analysis finished!")
print(f"  Nurse IDs: {[d.name for d in nurse_dirs[:max_nurses]]}")
print(f"  Sessions: {len(all_data)}")

