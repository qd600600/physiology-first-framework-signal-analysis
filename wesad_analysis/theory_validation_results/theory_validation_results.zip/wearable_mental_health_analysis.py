#!/usr/bin/env python3
"""
Wearable Mental Health Dataset - Comprehensive Analysis

This script performs a complete analysis of the new Wearable Mental Health Dataset,
integrating it with the existing 11-dataset validation framework.

Author: AI Research Assistant
Date: 2025-01-03
"""

import os
import sys
import zipfile
import gzip
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

# Add project root to path
project_root = Path(__file__).parent
sys.path.append(str(project_root))

# Import existing analysis modules
from sklearn.preprocessing import StandardScaler, RobustScaler
from sklearn.cluster import KMeans
from sklearn.mixture import GaussianMixture
from sklearn.metrics import silhouette_score
from sklearn.decomposition import PCA
from sklearn.model_selection import cross_val_score, KFold
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from scipy import stats
from scipy.stats import pearsonr, spearmanr
import json
from datetime import datetime
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class WearableMentalHealthAnalyzer:
    """Comprehensive analyzer for Wearable Mental Health Dataset"""
    
    def __init__(self, data_path="data/figshare_hrv_sleep_dataset/raw_data"):
        self.data_path = Path(data_path)
        self.zip_file = self.data_path / "Mental Health.zip"
        self.extracted_path = self.data_path / "extracted"
        self.results_path = Path("wearable_mental_health_results")
        self.results_path.mkdir(exist_ok=True)
        
        # Initialize results storage
        self.results = {
            'dataset_info': {},
            'preprocessing': {},
            'wt_analysis': {},
            'lri_clustering': {},
            'multimodal_dl': {},
            'parameter_screening': {},
            'subjective_scales': {},
            'longterm_trends': {},
            'intervention_simulation': {},
            'comparative_analysis': {}
        }
        
        # Set random seeds for reproducibility
        np.random.seed(42)
        torch.manual_seed(42)
        
        logger.info(f"Initialized WearableMentalHealthAnalyzer")
        logger.info(f"Data path: {self.data_path}")
        logger.info(f"Results path: {self.results_path}")
    
    def step1_data_preprocessing(self):
        """Step 1: Data preprocessing and quality control"""
        logger.info("=" * 60)
        logger.info("STEP 1: DATA PREPROCESSING")
        logger.info("=" * 60)
        
        # Extract ZIP file
        self._extract_data()
        
        # Load and preprocess each signal type
        signals = {
            'hrm': 'Heart Rate Monitor',
            'acc': 'Accelerometer', 
            'ppg': 'Photoplethysmography',
            'grv': 'Galvanic Skin Response',
            'ped': 'Pedometer',
            'lit': 'Light Sensor'
        }
        
        processed_data = {}
        for signal, description in signals.items():
            logger.info(f"Processing {signal} ({description})...")
            try:
                data = self._load_signal(signal)
                if data is not None:
                    processed_data[signal] = self._preprocess_signal(data, signal)
                    logger.info(f"  Loaded {len(data)} samples")
                else:
                    logger.warning(f"  Failed to load {signal}")
            except Exception as e:
                logger.error(f"  Error processing {signal}: {e}")
        
        # Merge all signals into unified time series
        merged_data = self._merge_signals(processed_data)
        
        # Quality control and outlier removal
        qc_data = self._quality_control(merged_data)
        
        # Save processed data
        output_file = self.results_path / "processed_wearable_mental_health.csv"
        qc_data.to_csv(output_file, index=False)
        logger.info(f"Saved processed data to {output_file}")
        
        # Store results
        self.results['preprocessing'] = {
            'total_samples': len(qc_data),
            'signals_loaded': list(processed_data.keys()),
            'missing_values_removed': len(merged_data) - len(qc_data),
            'outliers_removed': len(merged_data) - len(qc_data),
            'columns': list(qc_data.columns),
            'data_types': qc_data.dtypes.to_dict()
        }
        
        self.processed_data = qc_data
        logger.info("Step 1 completed successfully")
        
        return qc_data
    
    def _extract_data(self):
        """Extract ZIP file if not already extracted"""
        if not self.extracted_path.exists():
            logger.info(f"Extracting {self.zip_file}...")
            with zipfile.ZipFile(self.zip_file, 'r') as zip_ref:
                zip_ref.extractall(self.extracted_path)
            logger.info("Extraction completed")
        else:
            logger.info("Data already extracted")
    
    def _load_signal(self, signal_name):
        """Load a specific signal from gzipped CSV with memory optimization"""
        signal_file = self.extracted_path / "raw_data" / f"{signal_name}.csv.gz"
        
        if not signal_file.exists():
            logger.warning(f"Signal file not found: {signal_file}")
            return None
        
        try:
            # Check file size first
            file_size = signal_file.stat().st_size / (1024**3)  # GB
            logger.info(f"Loading {signal_name} ({file_size:.2f} GB)")
            
            # Memory-optimized loading for large files
            if file_size > 1.0:  # Files larger than 1GB
                logger.info(f"Large file detected, using memory-optimized loading")
                return self._load_large_signal(signal_file, signal_name)
            else:
                return self._load_small_signal(signal_file, signal_name)
                
        except Exception as e:
            logger.error(f"Error loading {signal_name}: {e}")
            return None
    
    def _load_large_signal(self, signal_file, signal_name):
        """Load large signal files with aggressive sampling"""
        try:
            # Read first few lines to understand structure
            with gzip.open(signal_file, 'rt') as f:
                header = f.readline().strip().split(',')
                logger.info(f"Header: {header[:5]}...")  # Show first 5 columns
            
            # For very large files, use aggressive sampling
            sample_size = 10000  # 10K samples max for large files
            skip_rows = 100  # Sample every 100th row
            
            # Read with sampling
            data = pd.read_csv(signal_file, compression='gzip', 
                             skiprows=lambda x: x > 0 and x % skip_rows != 0,
                             nrows=sample_size)
            
            logger.info(f"Loaded {len(data)} samples from {signal_name} (sampled)")
            return data
            
        except Exception as e:
            logger.error(f"Error in large signal loading: {e}")
            return None
    
    def _load_small_signal(self, signal_file, signal_name):
        """Load smaller signal files normally"""
        try:
            # Load with chunking for medium files
            chunk_list = []
            chunk_size = 10000  # 10K rows per chunk
            
            with gzip.open(signal_file, 'rt') as f:
                # Read header
                header = f.readline().strip().split(',')
                
                chunk_data = []
                for line in f:
                    chunk_data.append(line.strip().split(','))
                    
                    if len(chunk_data) >= chunk_size:
                        chunk_df = pd.DataFrame(chunk_data, columns=header)
                        chunk_list.append(chunk_df)
                        chunk_data = []
                        
                        # Limit total chunks to prevent memory issues
                        if len(chunk_list) >= 10:  # Max 100K rows
                            break
                
                # Add remaining data
                if chunk_data:
                    chunk_df = pd.DataFrame(chunk_data, columns=header)
                    chunk_list.append(chunk_df)
            
            # Combine chunks
            if chunk_list:
                data = pd.concat(chunk_list, ignore_index=True)
                logger.info(f"Loaded {len(data)} samples from {signal_name}")
                return data
            else:
                return None
                
        except Exception as e:
            logger.error(f"Error in small signal loading: {e}")
            return None
    
    def _preprocess_signal(self, data, signal_name):
        """Preprocess individual signal data"""
        # Convert numeric columns
        numeric_cols = data.select_dtypes(include=[np.number]).columns
        for col in numeric_cols:
            data[col] = pd.to_numeric(data[col], errors='coerce')
        
        # Remove completely missing columns
        data = data.dropna(axis=1, how='all')
        
        # Add signal prefix to columns
        rename_dict = {col: f"{signal_name}_{col}" for col in data.columns 
                      if col not in ['timestamp', 'time', 'datetime']}
        data = data.rename(columns=rename_dict)
        
        # Handle time column
        time_cols = [col for col in data.columns if 'time' in col.lower()]
        if time_cols:
            time_col = time_cols[0]
            try:
                data[time_col] = pd.to_datetime(data[time_col], errors='coerce')
            except:
                data[time_col] = pd.to_numeric(data[time_col], errors='coerce')
        
        return data
    
    def _merge_signals(self, processed_signals):
        """Merge all signals into unified time series"""
        if not processed_signals:
            logger.error("No signals to merge")
            return pd.DataFrame()
        
        # Start with first signal
        merged = list(processed_signals.values())[0].copy()
        
        # Merge other signals
        for signal_name, signal_data in list(processed_signals.items())[1:]:
            # Find common time column
            time_cols_merged = [col for col in merged.columns if 'time' in col.lower()]
            time_cols_signal = [col for col in signal_data.columns if 'time' in col.lower()]
            
            if time_cols_merged and time_cols_signal:
                time_col_merged = time_cols_merged[0]
                time_col_signal = time_cols_signal[0]
                
                # Merge on time
                merged = pd.merge(merged, signal_data, 
                                left_on=time_col_merged, right_on=time_col_signal, 
                                how='outer', suffixes=('', f'_{signal_name}'))
            else:
                # Merge by index if no time column
                merged = pd.concat([merged, signal_data], axis=1)
        
        # Sort by time if available
        time_cols = [col for col in merged.columns if 'time' in col.lower()]
        if time_cols:
            merged = merged.sort_values(time_cols[0])
        
        # Reset index
        merged = merged.reset_index(drop=True)
        
        logger.info(f"Merged data shape: {merged.shape}")
        return merged
    
    def _quality_control(self, data):
        """Quality control and outlier removal"""
        logger.info("Performing quality control...")
        
        # Remove rows with all NaN
        data = data.dropna(how='all')
        
        # Handle numeric columns
        numeric_cols = data.select_dtypes(include=[np.number]).columns
        
        for col in numeric_cols:
            # Remove extreme outliers (beyond 5 standard deviations)
            mean_val = data[col].mean()
            std_val = data[col].std()
            if std_val > 0:
                data = data[abs(data[col] - mean_val) <= 5 * std_val]
            
            # Remove infinite values
            data = data[np.isfinite(data[col])]
        
        # Remove columns with >90% missing values
        missing_threshold = 0.9 * len(data)
        cols_to_remove = [col for col in data.columns 
                         if data[col].isna().sum() > missing_threshold]
        data = data.drop(columns=cols_to_remove)
        
        if cols_to_remove:
            logger.info(f"Removed columns with >90% missing: {cols_to_remove}")
        
        # Fill remaining missing values with median for numeric columns
        for col in numeric_cols:
            if col in data.columns and data[col].isna().sum() > 0:
                median_val = data[col].median()
                data[col] = data[col].fillna(median_val)
        
        logger.info(f"QC completed. Final shape: {data.shape}")
        return data
    
    def step2_wt_validation(self):
        """Step 2: W(t) equation validation"""
        logger.info("=" * 60)
        logger.info("STEP 2: W(t) EQUATION VALIDATION")
        logger.info("=" * 60)
        
        if not hasattr(self, 'processed_data'):
            logger.error("No processed data available. Run step1_data_preprocessing first.")
            return None
        
        data = self.processed_data.copy()
        
        # Extract stress indicators (HRV, EDA, etc.)
        stress_indicators = self._extract_stress_indicators(data)
        
        # Calculate W(t) using bounded model
        wt_values = self._calculate_wt_bounded(stress_indicators)
        
        # Analyze recovery periods
        recovery_analysis = self._analyze_recovery_periods(wt_values)
        
        # Compare with other 11 datasets
        comparison_results = self._compare_scenario_intensity(wt_values)
        
        # Store results
        self.results['wt_analysis'] = {
            'wt_max_load': float(wt_values.max()),
            'wt_mean': float(wt_values.mean()),
            'wt_std': float(wt_values.std()),
            'recovery_rate': float(recovery_analysis['recovery_rate']),
            'recovery_percentage': float(recovery_analysis['recovery_percentage']),
            'explosions': 0,  # Bounded model eliminates explosions
            'scenario_intensity_rank': comparison_results['rank'],
            'comparison_with_others': comparison_results['comparison']
        }
        
        logger.info("Step 2 completed successfully")
        return {
            'wt_values': wt_values,
            'recovery_analysis': recovery_analysis,
            'comparison_results': comparison_results
        }
    
    def _extract_stress_indicators(self, data):
        """Extract stress-related indicators from processed data"""
        indicators = {}
        
        # HRV indicators
        hrv_cols = [col for col in data.columns if 'hrm' in col.lower() or 'ppg' in col.lower()]
        if hrv_cols:
            # Convert to numeric and handle mixed types
            hrv_data = data[hrv_cols].apply(pd.to_numeric, errors='coerce')
            indicators['hrv'] = hrv_data.mean(axis=1)
        
        # EDA/GSR indicators
        eda_cols = [col for col in data.columns if 'grv' in col.lower() or 'eda' in col.lower()]
        if eda_cols:
            # Convert to numeric and handle mixed types
            eda_data = data[eda_cols].apply(pd.to_numeric, errors='coerce')
            indicators['eda'] = eda_data.mean(axis=1)
        
        # Activity indicators
        acc_cols = [col for col in data.columns if 'acc' in col.lower()]
        if acc_cols:
            # Convert to numeric and handle mixed types
            acc_data = data[acc_cols].apply(pd.to_numeric, errors='coerce')
            indicators['activity'] = acc_data.mean(axis=1)
        
        # Light indicators
        light_cols = [col for col in data.columns if 'lit' in col.lower()]
        if light_cols:
            # Convert to numeric and handle mixed types
            light_data = data[light_cols].apply(pd.to_numeric, errors='coerce')
            indicators['light'] = light_data.mean(axis=1)
        
        return indicators
    
    def _calculate_wt_bounded(self, indicators):
        """Calculate W(t) using bounded model"""
        # Use first available indicator as stress input
        if 'hrv' in indicators:
            stress_input = indicators['hrv']
        elif 'eda' in indicators:
            stress_input = indicators['eda']
        else:
            stress_input = list(indicators.values())[0]
        
        # Normalize stress input
        stress_input = (stress_input - stress_input.mean()) / stress_input.std()
        
        # W(t) bounded model parameters
        alpha = 0.05  # Stress accumulation rate
        beta = 0.3    # Recovery rate
        W_max = 20.0  # Maximum stress capacity
        
        # Initialize W(t) array
        n_samples = len(stress_input)
        W_t = np.zeros(n_samples)
        
        # Calculate W(t) using bounded equation
        for t in range(1, n_samples):
            # Bounded W(t) equation: W[t] = max(0, min(W_max, W[t-1] + α*I_t - β*W[t-1]))
            W_t[t] = max(0, min(W_max, W_t[t-1] + alpha * stress_input.iloc[t] - beta * W_t[t-1]))
        
        return pd.Series(W_t, name='W_t')
    
    def _analyze_recovery_periods(self, wt_values):
        """Analyze recovery periods in W(t)"""
        # Define recovery threshold (50% of max)
        recovery_threshold = 0.5 * wt_values.max()
        
        # Identify recovery periods (W(t) below threshold)
        recovery_mask = wt_values < recovery_threshold
        recovery_periods = np.sum(recovery_mask)
        total_periods = len(wt_values)
        
        recovery_rate = recovery_periods / total_periods
        recovery_percentage = recovery_rate * 100
        
        return {
            'recovery_rate': recovery_rate,
            'recovery_percentage': recovery_percentage,
            'recovery_periods': recovery_periods,
            'total_periods': total_periods,
            'threshold': recovery_threshold
        }
    
    def _compare_scenario_intensity(self, wt_values):
        """Compare scenario intensity with other 11 datasets"""
        # Reference intensities from other datasets
        reference_intensities = {
            'SWELL': 0.96,      # Office stress
            'MMASH': 10.0,      # Daily life
            'Nurses': 2.05,     # Medical stress
            'WESAD': 16.62,     # Lab stress
            'DRIVE-DB': 17.4,   # Driving stress
            'Non-EEG': 60.0     # Task stress
        }
        
        current_intensity = wt_values.max()
        
        # Rank current dataset
        all_intensities = list(reference_intensities.values()) + [current_intensity]
        sorted_intensities = sorted(enumerate(all_intensities), key=lambda x: x[1])
        
        current_rank = next(i for i, (idx, val) in enumerate(sorted_intensities) 
                          if idx == len(reference_intensities)) + 1
        
        return {
            'current_intensity': current_intensity,
            'rank': current_rank,
            'total_datasets': len(all_intensities),
            'comparison': {
                'stronger_than': [name for name, intensity in reference_intensities.items() 
                                 if intensity < current_intensity],
                'weaker_than': [name for name, intensity in reference_intensities.items() 
                               if intensity > current_intensity]
            }
        }
    
    def step3_lri_clustering(self):
        """Step 3: LRI pattern clustering"""
        logger.info("=" * 60)
        logger.info("STEP 3: LRI PATTERN CLUSTERING")
        logger.info("=" * 60)
        
        if not hasattr(self, 'processed_data'):
            logger.error("No processed data available. Run step1_data_preprocessing first.")
            return None
        
        data = self.processed_data.copy()
        
        # Extract features for LRI clustering
        lri_features = self._extract_lri_features(data)
        
        # Time window aggregation (60-900 seconds)
        aggregated_features = self._aggregate_time_windows(lri_features, window_size=900)
        
        # KMeans clustering
        kmeans_results = self._kmeans_clustering(aggregated_features)
        
        # Gaussian Mixture Model clustering
        gmm_results = self._gmm_clustering(aggregated_features)
        
        # Calculate Silhouette scores
        silhouette_scores = self._calculate_silhouette_scores(aggregated_features, kmeans_results, gmm_results)
        
        # Compare with other datasets
        comparison_results = self._compare_clustering_quality(silhouette_scores)
        
        # Store results
        self.results['lri_clustering'] = {
            'kmeans_silhouette': float(silhouette_scores['kmeans']),
            'gmm_silhouette': float(silhouette_scores['gmm']),
            'best_clustering': max(silhouette_scores, key=silhouette_scores.get),
            'cluster_centers': kmeans_results['centers'].tolist(),
            'cluster_distribution': kmeans_results['distribution'],
            'comparison_rank': comparison_results['rank']
        }
        
        logger.info("Step 3 completed successfully")
        return {
            'lri_features': lri_features,
            'aggregated_features': aggregated_features,
            'kmeans_results': kmeans_results,
            'gmm_results': gmm_results,
            'silhouette_scores': silhouette_scores,
            'comparison_results': comparison_results
        }
    
    def _extract_lri_features(self, data):
        """Extract features for LRI clustering"""
        features = []
        
        # HRV features
        hrv_cols = [col for col in data.columns if 'hrm' in col.lower() or 'ppg' in col.lower()]
        if hrv_cols:
            hrv_data = data[hrv_cols].apply(pd.to_numeric, errors='coerce')
            features.extend([
                hrv_data.mean(axis=1),
                hrv_data.std(axis=1),
                hrv_data.rolling(10).mean().fillna(method='bfill').iloc[:, 0]
            ])
        
        # EDA features
        eda_cols = [col for col in data.columns if 'grv' in col.lower() or 'eda' in col.lower()]
        if eda_cols:
            eda_data = data[eda_cols].apply(pd.to_numeric, errors='coerce')
            features.extend([
                eda_data.mean(axis=1),
                eda_data.std(axis=1)
            ])
        
        # Activity features
        acc_cols = [col for col in data.columns if 'acc' in col.lower()]
        if acc_cols:
            acc_data = data[acc_cols].apply(pd.to_numeric, errors='coerce')
            features.extend([
                acc_data.mean(axis=1),
                acc_data.std(axis=1)
            ])
        
        # Combine features
        if features:
            feature_matrix = np.column_stack(features)
            feature_names = [f'feature_{i}' for i in range(feature_matrix.shape[1])]
            return pd.DataFrame(feature_matrix, columns=feature_names)
        else:
            return pd.DataFrame()
    
    def _aggregate_time_windows(self, features, window_size=900):
        """Aggregate features over time windows"""
        if features.empty:
            return pd.DataFrame()
        
        # Create time windows
        n_windows = len(features) // window_size
        if n_windows == 0:
            return features
        
        # Aggregate features within each window
        aggregated = []
        for i in range(n_windows):
            start_idx = i * window_size
            end_idx = min((i + 1) * window_size, len(features))
            window_data = features.iloc[start_idx:end_idx]
            
            # Calculate window statistics
            window_stats = {
                'mean': window_data.mean().values,
                'std': window_data.std().values,
                'max': window_data.max().values,
                'min': window_data.min().values
            }
            
            # Flatten statistics
            flat_stats = np.concatenate([window_stats['mean'], window_stats['std'], 
                                       window_stats['max'], window_stats['min']])
            aggregated.append(flat_stats)
        
        # Create aggregated DataFrame
        n_features = len(features.columns)
        col_names = (['mean_' + col for col in features.columns] +
                    ['std_' + col for col in features.columns] +
                    ['max_' + col for col in features.columns] +
                    ['min_' + col for col in features.columns])
        
        return pd.DataFrame(aggregated, columns=col_names)
    
    def _kmeans_clustering(self, features):
        """Perform KMeans clustering"""
        if features.empty:
            return {'labels': [], 'centers': np.array([]), 'distribution': {}}
        
        # Remove NaN values
        features_clean = features.dropna()
        if features_clean.empty:
            return {'labels': [], 'centers': np.array([]), 'distribution': {}}
        
        # Standardize features
        scaler = StandardScaler()
        features_scaled = scaler.fit_transform(features_clean)
        
        # KMeans clustering (3 clusters)
        kmeans = KMeans(n_clusters=3, random_state=42, n_init=10)
        labels = kmeans.fit_predict(features_scaled)
        
        # Calculate cluster distribution
        unique, counts = np.unique(labels, return_counts=True)
        distribution = dict(zip([f'cluster_{i}' for i in unique], counts))
        
        return {
            'labels': labels,
            'centers': kmeans.cluster_centers_,
            'distribution': distribution
        }
    
    def _gmm_clustering(self, features):
        """Perform Gaussian Mixture Model clustering"""
        if features.empty:
            return {'labels': [], 'centers': np.array([]), 'distribution': {}}
        
        # Remove NaN values
        features_clean = features.dropna()
        if features_clean.empty:
            return {'labels': [], 'centers': np.array([]), 'distribution': {}}
        
        # Standardize features
        scaler = StandardScaler()
        features_scaled = scaler.fit_transform(features_clean)
        
        # GMM clustering (3 components)
        gmm = GaussianMixture(n_components=3, random_state=42)
        labels = gmm.fit_predict(features_scaled)
        
        # Calculate cluster distribution
        unique, counts = np.unique(labels, return_counts=True)
        distribution = dict(zip([f'cluster_{i}' for i in unique], counts))
        
        return {
            'labels': labels,
            'centers': gmm.means_,
            'distribution': distribution
        }
    
    def _calculate_silhouette_scores(self, features, kmeans_results, gmm_results):
        """Calculate Silhouette scores for clustering results"""
        if features.empty:
            return {'kmeans': 0, 'gmm': 0}
        
        # Remove NaN values
        features_clean = features.dropna()
        if features_clean.empty:
            return {'kmeans': 0, 'gmm': 0}
        
        # Standardize features
        scaler = StandardScaler()
        features_scaled = scaler.fit_transform(features_clean)
        
        scores = {}
        
        # KMeans Silhouette score
        if len(kmeans_results['labels']) > 0:
            scores['kmeans'] = silhouette_score(features_scaled, kmeans_results['labels'])
        else:
            scores['kmeans'] = 0
        
        # GMM Silhouette score
        if len(gmm_results['labels']) > 0:
            scores['gmm'] = silhouette_score(features_scaled, gmm_results['labels'])
        else:
            scores['gmm'] = 0
        
        return scores
    
    def _compare_clustering_quality(self, silhouette_scores):
        """Compare clustering quality with other datasets"""
        # Reference Silhouette scores from other datasets
        reference_scores = {
            'Nurses': 0.662,
            'MMASH': 0.53,
            'DRIVE-DB': 0.444,
            'Mental_Health_Pred': 0.382,
            'Global_Mental_Health': 0.337,
            'Non-EEG': 0.283,
            'SWELL': 0.219
        }
        
        current_score = max(silhouette_scores.values())
        
        # Rank current dataset
        all_scores = list(reference_scores.values()) + [current_score]
        sorted_scores = sorted(enumerate(all_scores), key=lambda x: x[1], reverse=True)
        
        current_rank = next(i for i, (idx, val) in enumerate(sorted_scores) 
                          if idx == len(reference_scores)) + 1
        
        return {
            'current_score': current_score,
            'rank': current_rank,
            'total_datasets': len(all_scores),
            'quality_rating': 'excellent' if current_score > 0.6 else 
                             'good' if current_score > 0.4 else
                             'moderate' if current_score > 0.2 else 'poor'
        }

if __name__ == "__main__":
    # Initialize analyzer
    analyzer = WearableMentalHealthAnalyzer()
    
    # Run Step 1: Data Preprocessing
    processed_data = analyzer.step1_data_preprocessing()
    
    # Run Step 2: W(t) Validation
    wt_results = analyzer.step2_wt_validation()
    
    # Run Step 3: LRI Clustering
    lri_results = analyzer.step3_lri_clustering()
    
    print(f"\nSteps 1-3 completed successfully!")
    print(f"Processed data shape: {processed_data.shape}")
    print(f"W(t) max load: {analyzer.results['wt_analysis'].get('wt_max_load', 'N/A')}")
    print(f"Recovery rate: {analyzer.results['wt_analysis'].get('recovery_rate', 'N/A')}")
    print(f"LRI Silhouette score: {analyzer.results['lri_clustering'].get('best_clustering', 'N/A')}")
    print(f"Results saved to: {analyzer.results_path}")
