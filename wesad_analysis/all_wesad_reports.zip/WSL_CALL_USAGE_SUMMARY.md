# WSL PyTorch Nightly + GPU 远程调用总结

## 核心命令

无论您从哪个目录，都可以使用这个命令调用WSL PyTorch Nightly + GPU：

```powershell
wsl -d Ubuntu-22.04 -e bash -c "cd /mnt/d/WESAD_analysis && python3 run_full_sample_analysis_wsl.py"
```

## 三种使用方法

### 1. 直接命令行调用
```powershell
# 在任何目录中运行
wsl -d Ubuntu-22.04 -e bash -c "cd /mnt/d/WESAD_analysis && python3 run_full_sample_analysis_wsl.py"
```

### 2. 使用批处理文件
```batch
# 双击运行 run_wsl_from_anywhere.bat
# 或从命令行运行
run_wsl_from_anywhere.bat

# 指定脚本
run_wsl_from_anywhere.bat step3_roc_auc_analysis_wsl.py
```

### 3. 使用PowerShell脚本
```powershell
# 运行默认脚本
.\run_wsl_from_anywhere.ps1

# 指定脚本
.\run_wsl_from_anywhere.ps1 -Script step3_roc_auc_analysis_wsl.py

# 查看帮助
.\run_wsl_from_anywhere.ps1 -Help
```

## 常用脚本调用

### 全样本分析
```powershell
wsl -d Ubuntu-22.04 -e bash -c "cd /mnt/d/WESAD_analysis && python3 run_full_sample_analysis_wsl.py"
```

### ROC/AUC分析
```powershell
wsl -d Ubuntu-22.04 -e bash -c "cd /mnt/d/WESAD_analysis && python3 step3_roc_auc_analysis_wsl.py"
```

### 深度学习分析
```powershell
wsl -d Ubuntu-22.04 -e bash -c "cd /mnt/d/WESAD_analysis && bash run_dl_analysis_wsl.sh"
```

## 环境检查命令

### 检查WSL状态
```powershell
wsl --list --verbose
```

### 检查GPU环境
```powershell
wsl -d Ubuntu-22.04 -e bash -c "cd /mnt/d/WESAD_analysis && python3 -c 'import torch; print(f\"PyTorch: {torch.__version__}, CUDA: {torch.cuda.is_available()}\")'"
```

### 检查GPU使用情况
```powershell
wsl -d Ubuntu-22.04 -e bash -c "nvidia-smi"
```

## 文件位置

- **Windows项目路径**: `D:\WESAD_analysis`
- **WSL项目路径**: `/mnt/d/WESAD_analysis`
- **调用脚本**: `run_wsl_from_anywhere.bat` 和 `run_wsl_from_anywhere.ps1`

## 优势

1. **位置无关**: 可以从任何目录调用
2. **GPU加速**: 自动使用RTX 5080 + CUDA 12.8
3. **PyTorch Nightly**: 使用最新功能和性能优化
4. **错误处理**: 包含完整的错误检查和状态报告
5. **参数化**: 支持自定义脚本和发行版

## 快速开始

1. 将 `run_wsl_from_anywhere.bat` 复制到桌面
2. 双击运行
3. 等待分析完成

就这么简单！


