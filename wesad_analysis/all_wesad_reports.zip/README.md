# WESAD 数据分析项目：dW/dt 压力轨迹建模

## 🎯 项目概述

这是一个基于**真实WESAD数据集**的生理信号分析项目，专注于通过心率变异性(HRV)分析实现**dW/dt压力轨迹建模**。项目使用从Kaggle下载的真实WESAD数据集，包含15个被试的完整生理信号数据。

## 🔬 项目具体作用

### 核心功能
1. **真实数据驱动**: 基于Kaggle真实WESAD数据集，包含15个被试的完整生理信号
2. **压力监测系统**: 通过HRV分析实现实时压力状态监测和轨迹建模
3. **多被试比较**: 支持大规模被试数据的批量分析和比较研究
4. **生理信号处理**: 处理Empatica E4设备采集的BVP、ECG等生理信号
5. **压力建模算法**: 实现dW/dt = S(t) - R(t)压力变化模型

### 技术特点
- **BVP信号处理**: 提取和处理血容量脉搏(BVP)信号
- **峰值检测**: 使用scipy.signal.find_peaks进行心跳峰值检测
- **HRV分析**: 计算SDNN(连续RR间期标准差)指标
- **压力建模**: 基于生理学原理的压力变化模型
- **可视化输出**: 生成高质量的压力轨迹图和统计摘要

## 📊 数据来源

- **数据集**: WESAD (Wearable Stress and Affect Detection)
- **来源**: Kaggle - https://www.kaggle.com/datasets/orvile/wesad-wearable-stress-affect-detection-dataset
- **被试数量**: 15个被试 (S2-S17)
- **信号类型**: BVP, ECG, EDA, EMG, TEMP, ACC, Respiration
- **采样率**: 64 Hz (BVP信号)

## 🚀 快速开始

### 方法1: 运行批处理文件 (Windows)
```bash
run_real_analysis.bat
```

### 方法2: 直接运行Python脚本
```bash
# 单被试分析
python wesad_analysis_real.py

# 多被试分析
python wesad_multi_subject_analysis.py

# 综合分析
python comprehensive_wesad_analysis.py
```

### 方法3: 手动安装依赖
```bash
pip install -r requirements.txt
python comprehensive_wesad_analysis.py
```

## 📁 项目结构

```
WESAD_analysis/
├── data/                                    # 真实WESAD数据集
│   └── WESAD/                              # 15个被试数据
│       ├── S2/, S3/, ..., S17/            # 各被试文件夹
│       └── wesad_readme.pdf               # 数据集说明
├── figures/                                # 生成的图表
│   ├── multi_subject_dw_dt_comparison.png  # 多被试比较图
│   ├── statistical_summary.png            # 统计摘要图
│   └── 5/                                 # 详细分析图
├── outputs/                               # 分析结果数据
│   ├── wesad_time_series_data.csv        # 时间序列数据
│   ├── wesad_summary_statistics.csv      # 统计摘要
│   └── 其他分析结果文件
├── wesad_analysis_real.py                # 单被试分析脚本
├── wesad_multi_subject_analysis.py       # 多被试分析脚本
├── comprehensive_wesad_analysis.py       # 综合分析脚本
├── run_real_analysis.bat                 # Windows批处理文件
├── requirements.txt                      # Python依赖包
└── README.md                             # 项目说明
```

## 🔬 分析流程

1. **数据加载**: 从Kaggle下载的真实WESAD数据集中加载生理信号
2. **信号预处理**: 对BVP信号进行带通滤波和标准化
3. **峰值检测**: 使用多种策略检测心跳峰值
4. **RR间期计算**: 基于峰值间隔计算RR间期
5. **HRV分析**: 使用30点滑动窗口计算SDNN指标
6. **压力建模**: 实现dW/dt = S(t) - R(t)模型
7. **可视化输出**: 生成多被试比较图和统计摘要

## 🧮 压力模型详解

基于生理学原理的dW/dt压力变化模型：

- **压力成分 S(t)**: -HRV (HRV下降 = 压力增加)
- **恢复成分 R(t)**: HRV的滑动平均 (10点窗口)
- **净压力变化**: dW/dt = S(t) - R(t)

## 📈 输出结果

### 图表文件
- `multi_subject_dw_dt_comparison.png`: 多被试dW/dt轨迹比较
- `statistical_summary.png`: 统计摘要和相关性分析
- `5/`: 详细分析图表文件夹

### 数据文件
- `wesad_time_series_data.csv`: 完整时间序列数据
- `wesad_summary_statistics.csv`: 各被试统计摘要
- 其他分析结果CSV文件

## ⚙️ 系统要求

- **Python**: 3.11+
- **依赖包**:
  - pandas >= 1.5.0
  - numpy >= 1.21.0
  - matplotlib >= 3.5.0
  - scipy >= 1.9.0

## 🔧 故障排除

1. **模块未找到错误**: 运行 `pip install -r requirements.txt`
2. **数据文件缺失**: 确保已从Kaggle下载WESAD数据集到data/文件夹
3. **内存不足**: 可以调整分析参数或分批处理被试数据

## 📚 引用

如果将此分析用于研究，请引用WESAD数据集：

```
Schmidt, P., Reiss, A., Duerichen, R., Marberger, C., & Van Laerhoven, K. (2018). 
Introducing WESAD, a multimodal dataset for wearable stress and affect detection. 
In Proceedings of the 20th ACM International Conference on Multimodal Interaction (pp. 400-408).
```

## 🎯 项目状态

✅ **已完成功能**:
- 真实WESAD数据集成
- 多被试分析流程
- dW/dt压力轨迹建模
- 高质量可视化输出
- 统计分析功能

🔧 **技术特点**:
- 基于真实生理数据
- 鲁棒的信号处理算法
- 多策略峰值检测
- 完整的分析流水线
- 发表级别的图表质量


