#!/usr/bin/env python3
"""
Step 3 GPU加速科学验证框架
使用RAPIDS cuML真正实现GPU加速
"""

import pandas as pd
import numpy as np
import torch
import json
import warnings
import time
from sklearn.model_selection import train_test_split, RepeatedKFold
from sklearn.preprocessing import StandardScaler, RobustScaler
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from sklearn.impute import SimpleImputer
from scipy import stats
warnings.filterwarnings("ignore")

# GPU检查
print("🔍 GPU检查:")
print(f"  CUDA可用: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print(f"  GPU设备: {torch.cuda.get_device_name(0)}")
    print(f"  GPU内存: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.1f} GB")
    device = torch.device('cuda')
    use_gpu = True
else:
    print("  ⚠️ CUDA不可用，将使用CPU")
    device = torch.device('cpu')
    use_gpu = False

# RAPIDS cuML检查
try:
    import cudf
    import cuml
    from cuml.ensemble import RandomForestRegressor as cuRF
    from cuml.preprocessing import StandardScaler as cuStandardScaler
    from cuml.feature_selection import SelectKBest
    from cuml.feature_selection.f_regression import f_regression as cu_f_regression
    print("  ✅ RAPIDS cuML可用")
    rapids_available = True
except ImportError as e:
    print(f"  ❌ RAPIDS cuML不可用: {e}")
    rapids_available = False

print("=" * 70)
print("Step 3 GPU加速科学验证框架 (RAPIDS cuML)")
print("=" * 70)

# ======= GPU加速函数定义 =======

def safe_impute_gpu(df, verbose=True):
    """
    GPU加速安全imputation函数
    """
    if rapids_available and len(df) > 100000:
        print("  🚀 使用GPU加速imputation...")
        # 转换为cuDF
        df_gpu = cudf.from_pandas(df)
        
        # 检查全NaN列
        nan_cols = df_gpu.columns[df_gpu.isna().all()].tolist()
        if len(nan_cols) > 0:
            if verbose:
                print(f"⚠️ 发现全NaN列，将删除: {nan_cols}")
            df_gpu = df_gpu.drop(columns=nan_cols)
        
        # 数值列筛选
        numeric_cols = df_gpu.select_dtypes(include=[np.number]).columns.tolist()
        if len(numeric_cols) < df_gpu.shape[1]:
            dropped_nonnum = list(set(df_gpu.columns) - set(numeric_cols))
            if verbose:
                print(f"⚠️ 非数值列被排除: {dropped_nonnum}")
            df_gpu = df_gpu[numeric_cols]
        
        # GPU imputation
        df_gpu = df_gpu.fillna(df_gpu.median())
        df_out = df_gpu.to_pandas()
    else:
        print("  💻 使用CPU imputation...")
        df = df.copy()
        original_shape = df.shape
        
        # 检查全NaN列
        nan_cols = df.columns[df.isna().all()].tolist()
        if len(nan_cols) > 0:
            if verbose:
                print(f"⚠️ 发现全NaN列，将删除: {nan_cols}")
            df = df.drop(columns=nan_cols)
        
        # 数值列筛选
        numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        if len(numeric_cols) < df.shape[1]:
            dropped_nonnum = list(set(df.columns) - set(numeric_cols))
            if verbose:
                print(f"⚠️ 非数值列被排除: {dropped_nonnum}")
            df = df[numeric_cols]
        
        # CPU imputation
        imp = SimpleImputer(strategy='median')
        X_imputed = imp.fit_transform(df)
        df_out = pd.DataFrame(X_imputed, columns=df.columns, index=df.index)
    
    if verbose:
        print(f"  Imputation完成: {df_out.shape}")
    
    return df_out

def winsorize_data_gpu(df, lower=0.01, upper=0.99, verbose=True):
    """
    GPU加速Winsorization
    """
    if rapids_available and len(df) > 100000:
        print("  🚀 使用GPU加速Winsorization...")
        df_gpu = cudf.from_pandas(df)
        for col in df_gpu.columns:
            if df_gpu[col].dtype in ['float64', 'int64']:
                lower_bound = df_gpu[col].quantile(lower)
                upper_bound = df_gpu[col].quantile(upper)
                df_gpu[col] = df_gpu[col].clip(lower=lower_bound, upper=upper_bound)
        df_out = df_gpu.to_pandas()
    else:
        print("  💻 使用CPU Winsorization...")
        df_winsorized = df.copy()
        for col in df.columns:
            if df[col].dtype in ['float64', 'int64']:
                lower_bound = df[col].quantile(lower)
                upper_bound = df[col].quantile(upper)
                df_winsorized[col] = df[col].clip(lower=lower_bound, upper=upper_bound)
        df_out = df_winsorized
    
    if verbose:
        print(f"  Winsorization完成: 下界{lower}, 上界{upper}")
    
    return df_out

def feature_selection_gpu(X, y, method='f_test', k=20, verbose=True):
    """
    GPU加速特征选择
    """
    if rapids_available and len(X) > 100000:
        print("  🚀 使用GPU加速特征选择...")
        X_gpu = cudf.from_pandas(X)
        y_gpu = cudf.from_pandas(y)
        
        if method == 'f_test':
            # 使用cuML的F-test
            f_values, p_values = cu_f_regression(X_gpu, y_gpu)
            # 选择前k个特征
            top_k_indices = np.argsort(f_values)[-k:]
            selected_features = X_gpu.columns[top_k_indices]
            X_selected = X_gpu[selected_features].to_pandas()
        else:
            # 默认选择前k个特征
            selected_features = X_gpu.columns[:k].tolist()
            X_selected = X_gpu[selected_features].to_pandas()
    else:
        print("  💻 使用CPU特征选择...")
        if method == 'f_test':
            # 抽样F-test
            if X.shape[0] > 1000000:
                sample_size = min(500000, X.shape[0])
                subset_idx = np.random.choice(X.shape[0], size=sample_size, replace=False)
                X_sub = X.iloc[subset_idx]
                y_sub = y.iloc[subset_idx]
                from sklearn.feature_selection import f_regression
                f_values, p_values = f_regression(X_sub, y_sub)
            else:
                from sklearn.feature_selection import f_regression
                f_values, p_values = f_regression(X, y)
            
            # 选择前k个特征
            top_k_indices = np.argsort(f_values)[-k:]
            selected_features = X.columns[top_k_indices]
            X_selected = X[selected_features]
        else:
            # 默认选择前k个特征
            selected_features = X.columns[:k].tolist()
            X_selected = X[selected_features]
    
    if verbose:
        print(f"  {method}特征选择完成: {X.shape[1]} -> {len(selected_features)} 特征")
    
    return X_selected, selected_features

def train_model_gpu(X_train, X_test, y_train, y_test, verbose=True):
    """
    GPU加速模型训练
    """
    if rapids_available and len(X_train) > 100000:
        print("  🚀 使用GPU加速模型训练...")
        # 转换为cuDF
        X_train_gpu = cudf.from_pandas(X_train)
        X_test_gpu = cudf.from_pandas(X_test)
        y_train_gpu = cudf.from_pandas(y_train)
        y_test_gpu = cudf.from_pandas(y_test)
        
        # 使用cuML RandomForest
        model = cuRF(
            n_estimators=50,
            max_depth=12,
            max_features='sqrt',
            min_samples_leaf=50,
            random_state=42
        )
        
        # 训练
        model.fit(X_train_gpu, y_train_gpu)
        
        # 预测
        y_pred = model.predict(X_test_gpu)
        
        # 计算R²
        r2 = r2_score(y_test_gpu.to_pandas(), y_pred.to_pandas())
        
    else:
        print("  💻 使用CPU模型训练...")
        from sklearn.ensemble import RandomForestRegressor
        
        model = RandomForestRegressor(
            n_estimators=50,
            max_depth=12,
            max_features='sqrt',
            min_samples_leaf=50,
            random_state=42,
            n_jobs=-1
        )
        
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        r2 = r2_score(y_test, y_pred)
    
    if verbose:
        print(f"    模型训练完成: R² = {r2:.4f}")
    
    return r2, y_pred

# ======= Step 1: 数据读取 =======
print("\n📂 Step 1: 数据读取")
start_time = time.time()

print("  📥 正在读取features_base.csv...")
base = pd.read_csv("features_base.csv")
print(f"    ✅ Base特征加载完成: {base.shape}")

print("  📥 正在读取features_extended.csv...")
extended = pd.read_csv("features_extended.csv")
print(f"    ✅ Extended特征加载完成: {extended.shape}")

print("  📥 正在读取labels.csv...")
y = pd.read_csv("labels.csv")["target"]
print(f"    ✅ 标签加载完成: {len(y)} 个样本")

# 样本一致性检查
assert len(base) == len(extended) == len(y), "样本数量不一致"
print(f"  ✅ 数据加载完成: {len(y)} 个样本")
print(f"  ⏱️ 数据加载耗时: {time.time() - start_time:.2f}秒")

# ======= Step 2: 数据预处理 =======
print("\n🔧 Step 2: 数据预处理")
preprocess_start = time.time()

# 2.1 Winsorization
print("  📊 执行Winsorization...")
base_winsorized = winsorize_data_gpu(base)
extended_winsorized = winsorize_data_gpu(extended)

# 2.2 安全Imputation
print("  🔄 执行安全Imputation...")
base_imputed = safe_impute_gpu(base_winsorized)
extended_imputed = safe_impute_gpu(extended_winsorized)

# 2.3 特征选择
print("  🎯 执行特征选择...")
feature_selection_start = time.time()

base_selected, base_selected_features = feature_selection_gpu(
    base_imputed, y, method='f_test', k=min(10, base_imputed.shape[1]))
extended_selected, extended_selected_features = feature_selection_gpu(
    extended_imputed, y, method='f_test', k=min(20, extended_imputed.shape[1]))

print(f"  ⏱️ 特征选择耗时: {time.time() - feature_selection_start:.2f}秒")
print(f"  ⏱️ 预处理总耗时: {time.time() - preprocess_start:.2f}秒")

# ======= Step 3: 交叉验证 =======
print("\n🔄 Step 3: 交叉验证")
cv_start = time.time()

print("  📊 设置交叉验证参数...")
cv = RepeatedKFold(n_splits=5, n_repeats=3, random_state=42)

# 存储结果
cv_results = {
    'base_scores': [],
    'extended_scores': [],
    'fold_info': []
}

print("  🔄 开始交叉验证...")
for fold_idx, (train_idx, test_idx) in enumerate(cv.split(base_selected)):
    fold_start = time.time()
    print(f"    Fold {fold_idx + 1}/15...")
    
    # 数据划分
    try:
        Xb_train, Xb_test = base_selected.iloc[train_idx], base_selected.iloc[test_idx]
        Xe_train, Xe_test = extended_selected.iloc[train_idx], extended_selected.iloc[test_idx]
        y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]
        
        print(f"      📊 数据形状: 训练{Xb_train.shape}, 测试{Xb_test.shape}")
        
    except Exception as e:
        print(f"      ❌ 数据划分失败: {e}")
        continue
    
    # 标准化
    try:
        print(f"      🔄 标准化数据...")
        if rapids_available:
            # GPU标准化
            scaler = cuStandardScaler()
            Xb_train_scaled = scaler.fit_transform(cudf.from_pandas(Xb_train)).to_pandas()
            Xb_test_scaled = scaler.transform(cudf.from_pandas(Xb_test)).to_pandas()
            Xe_train_scaled = scaler.fit_transform(cudf.from_pandas(Xe_train)).to_pandas()
            Xe_test_scaled = scaler.transform(cudf.from_pandas(Xe_test)).to_pandas()
        else:
            # CPU标准化
            scaler = RobustScaler()
            Xb_train_scaled = scaler.fit_transform(Xb_train)
            Xb_test_scaled = scaler.transform(Xb_test)
            Xe_train_scaled = scaler.fit_transform(Xe_train)
            Xe_test_scaled = scaler.transform(Xe_test)
        
        print(f"      ✅ 标准化完成")
    except Exception as e:
        print(f"      ❌ 标准化失败: {e}")
        continue
    
    # 模型训练
    try:
        # Base模型
        print(f"      🎯 训练Base模型...")
        base_score, _ = train_model_gpu(Xb_train_scaled, Xb_test_scaled, y_train, y_test)
        
        # Extended模型
        print(f"      🎯 训练Extended模型...")
        extended_score, _ = train_model_gpu(Xe_train_scaled, Xe_test_scaled, y_train, y_test)
        
    except Exception as e:
        print(f"      ❌ 模型训练失败: {e}")
        continue
    
    cv_results['base_scores'].append(base_score)
    cv_results['extended_scores'].append(extended_score)
    cv_results['fold_info'].append({
        'fold': fold_idx + 1,
        'train_size': len(train_idx),
        'test_size': len(test_idx),
        'fold_time': time.time() - fold_start
    })
    
    print(f"      Base: {base_score:.4f}, Extended: {extended_score:.4f}, 耗时: {time.time() - fold_start:.2f}秒")

print(f"  ⏱️ 交叉验证总耗时: {time.time() - cv_start:.2f}秒")

# ======= Step 4: 统计分析 =======
print("\n📈 Step 4: 统计分析")

# 4.1 基本统计
base_mean = np.mean(cv_results['base_scores'])
extended_mean = np.mean(cv_results['extended_scores'])
base_std = np.std(cv_results['base_scores'])
extended_std = np.std(cv_results['extended_scores'])

# 4.2 配对t检验
t_stat, p_value = stats.ttest_rel(cv_results['extended_scores'], cv_results['base_scores'])

# 4.3 效应量 (Cohen's d)
pooled_std = np.sqrt(((len(cv_results['base_scores']) - 1) * base_std**2 + 
                     (len(cv_results['extended_scores']) - 1) * extended_std**2) / 
                    (len(cv_results['base_scores']) + len(cv_results['extended_scores']) - 2))
cohens_d = (extended_mean - base_mean) / pooled_std

# ======= Step 5: 结果保存 =======
print("\n💾 Step 5: 结果保存")

# 5.1 诊断信息
diagnostics = {
    'gpu_info': {
        'cuda_available': torch.cuda.is_available(),
        'gpu_device': torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
        'gpu_memory_gb': torch.cuda.get_device_properties(0).total_memory / 1024**3 if torch.cuda.is_available() else None,
        'rapids_available': rapids_available
    },
    'performance_info': {
        'total_runtime_seconds': time.time() - start_time,
        'data_loading_time': time.time() - start_time - (time.time() - preprocess_start),
        'preprocessing_time': time.time() - preprocess_start - (time.time() - cv_start),
        'cross_validation_time': time.time() - cv_start
    },
    'data_info': {
        'original_base_shape': base.shape,
        'original_extended_shape': extended.shape,
        'final_base_shape': base_selected.shape,
        'final_extended_shape': extended_selected.shape,
        'samples': len(y)
    },
    'cross_validation_results': {
        'base_mean_r2': float(base_mean),
        'base_std_r2': float(base_std),
        'extended_mean_r2': float(extended_mean),
        'extended_std_r2': float(extended_std),
        'improvement': float(extended_mean - base_mean),
        'improvement_percent': float((extended_mean - base_mean) / abs(base_mean) * 100)
    },
    'statistical_tests': {
        'paired_t_test': {
            't_statistic': float(t_stat),
            'p_value': float(p_value),
            'significant': p_value < 0.05
        },
        'effect_size': {
            'cohens_d': float(cohens_d),
            'interpretation': 'small' if abs(cohens_d) < 0.5 else 'medium' if abs(cohens_d) < 0.8 else 'large'
        }
    },
    'feature_info': {
        'base_selected_features': base_selected_features.tolist(),
        'extended_selected_features': extended_selected_features.tolist()
    }
}

# 5.2 保存结果
print("  💾 保存诊断结果...")
with open("step3_gpu_rapids_diagnostics.json", "w") as f:
    json.dump(diagnostics, f, indent=4)

# ======= Step 6: 结果报告 =======
print("\n📊 Step 6: 结果报告")
print("=" * 70)
print("Step 3 GPU加速科学验证结果 (RAPIDS cuML)")
print("=" * 70)
print(f"🚀 GPU加速状态: {'启用' if rapids_available else '未启用'}")
print(f"⏱️ 性能优化:")
print(f"  总运行时间: {time.time() - start_time:.2f}秒")
print(f"  数据加载: {time.time() - start_time - (time.time() - preprocess_start):.2f}秒")
print(f"  预处理: {time.time() - preprocess_start - (time.time() - cv_start):.2f}秒")
print(f"  交叉验证: {time.time() - cv_start:.2f}秒")
print(f"\n📈 交叉验证结果:")
print(f"  Base模型 R²: {base_mean:.4f} ± {base_std:.4f}")
print(f"  Extended模型 R²: {extended_mean:.4f} ± {extended_std:.4f}")
print(f"  性能提升: {extended_mean - base_mean:.4f} ({((extended_mean - base_mean) / abs(base_mean) * 100):.2f}%)")
print(f"\n🔬 统计检验:")
print(f"  配对t检验: t = {t_stat:.4f}, p = {p_value:.4f}")
print(f"  效应量 (Cohen's d): {cohens_d:.4f} ({'small' if abs(cohens_d) < 0.5 else 'medium' if abs(cohens_d) < 0.8 else 'large'})")
print(f"\n✅ 结果文件:")
print(f"  step3_gpu_rapids_diagnostics.json - GPU加速诊断信息")
print("=" * 70)

print("🎉 Step 3 GPU加速科学验证完成！")
