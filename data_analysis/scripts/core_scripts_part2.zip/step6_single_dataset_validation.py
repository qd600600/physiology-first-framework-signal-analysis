#!/usr/bin/env python3
"""
Step 6: Single Dataset Validation Modeling
单数据集验证建模 - 使用多线程和GPU进行逐个数据集建模
"""

import os
import sys
import logging
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from pathlib import Path
from datetime import datetime
from sklearn.model_selection import train_test_split, cross_val_score, KFold
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.svm import SVR
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from sklearn.preprocessing import StandardScaler
import joblib
from concurrent.futures import ThreadPoolExecutor, as_completed
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('step6_single_dataset_validation.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class PyTorchRegressionModel(nn.Module):
    """PyTorch神经网络回归模型，支持GPU加速."""
    
    def __init__(self, input_size: int, hidden_sizes: list = [64, 32, 16], dropout_rate: float = 0.2):
        super(PyTorchRegressionModel, self).__init__()
        
        layers = []
        prev_size = input_size
        
        for hidden_size in hidden_sizes:
            layers.extend([
                nn.Linear(prev_size, hidden_size),
                nn.ReLU(),
                nn.Dropout(dropout_rate)
            ])
            prev_size = hidden_size
        
        # Output layer
        layers.append(nn.Linear(prev_size, 1))
        
        self.network = nn.Sequential(*layers)
    
    def forward(self, x):
        return self.network(x)

class DatasetValidator:
    """单数据集验证建模器."""
    
    def __init__(self, device: str = 'auto', n_threads: int = 8):
        self.device = self._setup_device(device)
        self.n_threads = n_threads
        
        # 模型定义
        self.models = {
            'RandomForest': RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=1),
            'GradientBoosting': GradientBoostingRegressor(n_estimators=100, random_state=42),
            'LinearRegression': LinearRegression(),
            'Ridge': Ridge(alpha=1.0),
            'Lasso': Lasso(alpha=0.1),
            'SVR': SVR(kernel='rbf', C=1.0, gamma='scale'),
            'PyTorch_NN': None  # Will be initialized per dataset
        }
        
        logger.info(f"Initialized DatasetValidator on {self.device} with {n_threads} threads")
    
    def _setup_device(self, device: str) -> torch.device:
        """Setup computation device."""
        if device == 'auto':
            if torch.cuda.is_available():
                device = 'cuda'
                logger.info(f"CUDA available: {torch.cuda.get_device_name()}")
                logger.info(f"CUDA capability: {torch.cuda.get_device_capability()}")
            else:
                device = 'cpu'
                logger.info("CUDA not available, using CPU")
        
        return torch.device(device)
    
    def load_lri_data(self, dataset_name: str, window_size: str) -> pd.DataFrame:
        """加载LRI数据."""
        try:
            file_path = f"/mnt/d/data_analysis/processed/lri_calculation/lri_{dataset_name}_{window_size}.csv"
            df = pd.read_csv(file_path)
            logger.info(f"Loaded LRI data: {df.shape} from {file_path}")
            return df
        except Exception as e:
            logger.error(f"Error loading LRI data for {dataset_name}_{window_size}: {e}")
            return pd.DataFrame()
    
    def prepare_features_and_target(self, df: pd.DataFrame) -> tuple:
        """准备特征和目标变量."""
        try:
            # 特征列（排除窗口元数据）
            feature_cols = [col for col in df.columns if col not in [
                'window_id', 'window_size_seconds', 'sample_count', 
                'start_time', 'end_time', 'recovery_ratio'
            ]]
            
            # 目标变量：recovery_ratio
            if 'recovery_ratio' not in df.columns:
                logger.warning("No recovery_ratio column found, using wt_mean as target")
                target_col = 'wt_mean'
            else:
                target_col = 'recovery_ratio'
            
            X = df[feature_cols].values
            y = df[target_col].values
            
            logger.info(f"Features shape: {X.shape}, Target shape: {y.shape}")
            logger.info(f"Feature columns: {feature_cols}")
            logger.info(f"Target: {target_col}")
            
            return X, y, feature_cols
            
        except Exception as e:
            logger.error(f"Error preparing features and target: {e}")
            return None, None, None
    
    def train_pytorch_model(self, X_train: np.ndarray, y_train: np.ndarray, 
                           X_val: np.ndarray, y_val: np.ndarray, 
                           feature_cols: list) -> dict:
        """训练PyTorch神经网络模型."""
        try:
            # 数据标准化
            scaler_X = StandardScaler()
            scaler_y = StandardScaler()
            
            X_train_scaled = scaler_X.fit_transform(X_train)
            y_train_scaled = scaler_y.fit_transform(y_train.reshape(-1, 1)).flatten()
            X_val_scaled = scaler_X.transform(X_val)
            y_val_scaled = scaler_y.transform(y_val.reshape(-1, 1)).flatten()
            
            # 转换为PyTorch张量
            X_train_tensor = torch.FloatTensor(X_train_scaled).to(self.device)
            y_train_tensor = torch.FloatTensor(y_train_scaled).to(self.device)
            X_val_tensor = torch.FloatTensor(X_val_scaled).to(self.device)
            y_val_tensor = torch.FloatTensor(y_val_scaled).to(self.device)
            
            # 初始化模型
            model = PyTorchRegressionModel(
                input_size=len(feature_cols),
                hidden_sizes=[64, 32, 16],
                dropout_rate=0.2
            ).to(self.device)
            
            # 损失函数和优化器
            criterion = nn.MSELoss()
            optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
            
            # 训练循环
            model.train()
            train_losses = []
            val_losses = []
            
            for epoch in range(100):  # 100个epoch
                # 训练
                optimizer.zero_grad()
                train_pred = model(X_train_tensor).squeeze()
                train_loss = criterion(train_pred, y_train_tensor)
                train_loss.backward()
                optimizer.step()
                
                # 验证
                model.eval()
                with torch.no_grad():
                    val_pred = model(X_val_tensor).squeeze()
                    val_loss = criterion(val_pred, y_val_tensor)
                
                train_losses.append(train_loss.item())
                val_losses.append(val_loss.item())
                
                if epoch % 20 == 0:
                    logger.info(f"Epoch {epoch}: Train Loss = {train_loss.item():.4f}, Val Loss = {val_loss.item():.4f}")
            
            # 最终预测
            model.eval()
            with torch.no_grad():
                y_pred_scaled = model(X_val_tensor).squeeze().cpu().numpy()
            
            # 反标准化预测结果
            y_pred = scaler_y.inverse_transform(y_pred_scaled.reshape(-1, 1)).flatten()
            
            # 计算指标
            mse = mean_squared_error(y_val, y_pred)
            r2 = r2_score(y_val, y_pred)
            mae = mean_absolute_error(y_val, y_pred)
            
            return {
                'model': model,
                'scaler_X': scaler_X,
                'scaler_y': scaler_y,
                'mse': mse,
                'r2': r2,
                'mae': mae,
                'train_losses': train_losses,
                'val_losses': val_losses,
                'feature_importance': None  # PyTorch模型没有特征重要性
            }
            
        except Exception as e:
            logger.error(f"Error training PyTorch model: {e}")
            return {'error': str(e)}
    
    def train_sklearn_model(self, model_name: str, X_train: np.ndarray, y_train: np.ndarray, 
                           X_val: np.ndarray, y_val: np.ndarray, feature_cols: list) -> dict:
        """训练scikit-learn模型."""
        try:
            model = self.models[model_name]
            
            # 训练模型
            model.fit(X_train, y_train)
            
            # 预测
            y_pred = model.predict(X_val)
            
            # 计算指标
            mse = mean_squared_error(y_val, y_pred)
            r2 = r2_score(y_val, y_pred)
            mae = mean_absolute_error(y_val, y_pred)
            
            # 特征重要性（如果可用）
            feature_importance = None
            if hasattr(model, 'feature_importances_'):
                feature_importance = dict(zip(feature_cols, model.feature_importances_))
            elif hasattr(model, 'coef_'):
                feature_importance = dict(zip(feature_cols, model.coef_))
            
            return {
                'model': model,
                'mse': mse,
                'r2': r2,
                'mae': mae,
                'feature_importance': feature_importance
            }
            
        except Exception as e:
            logger.error(f"Error training {model_name}: {e}")
            return {'error': str(e)}
    
    def cross_validate_model(self, model_name: str, X: np.ndarray, y: np.ndarray, 
                           cv_folds: int = 5) -> dict:
        """交叉验证模型."""
        try:
            if model_name == 'PyTorch_NN':
                # PyTorch模型使用简化的交叉验证
                kf = KFold(n_splits=cv_folds, shuffle=True, random_state=42)
                scores = []
                
                for train_idx, val_idx in kf.split(X):
                    X_train, X_val = X[train_idx], X[val_idx]
                    y_train, y_val = y[train_idx], y[val_idx]
                    
                    result = self.train_pytorch_model(X_train, y_train, X_val, y_val, [])
                    if 'error' not in result:
                        scores.append(result['r2'])
                
                return {
                    'cv_scores': scores,
                    'cv_mean': np.mean(scores) if scores else 0,
                    'cv_std': np.std(scores) if scores else 0
                }
            else:
                # scikit-learn模型使用内置交叉验证
                model = self.models[model_name]
                scores = cross_val_score(model, X, y, cv=cv_folds, scoring='r2')
                
                return {
                    'cv_scores': scores.tolist(),
                    'cv_mean': scores.mean(),
                    'cv_std': scores.std()
                }
                
        except Exception as e:
            logger.error(f"Error in cross validation for {model_name}: {e}")
            return {'error': str(e)}
    
    def validate_dataset(self, dataset_name: str, window_size: str) -> dict:
        """验证单个数据集."""
        try:
            logger.info(f"=== Validating {dataset_name} - {window_size}s windows ===")
            
            # 加载数据
            df = self.load_lri_data(dataset_name, window_size)
            if df.empty:
                return {'error': 'Failed to load data'}
            
            # 准备特征和目标
            X, y, feature_cols = self.prepare_features_and_target(df)
            if X is None:
                return {'error': 'Failed to prepare features'}
            
            # 数据分割
            X_train, X_val, y_train, y_val = train_test_split(
                X, y, test_size=0.2, random_state=42
            )
            
            logger.info(f"Training set: {X_train.shape}, Validation set: {X_val.shape}")
            
            # 训练和评估所有模型
            results = {
                'dataset_name': dataset_name,
                'window_size': window_size,
                'data_shape': X.shape,
                'feature_cols': feature_cols,
                'models': {}
            }
            
            # 使用多线程训练模型
            with ThreadPoolExecutor(max_workers=self.n_threads) as executor:
                # 提交任务
                future_to_model = {}
                
                for model_name in self.models.keys():
                    if model_name == 'PyTorch_NN':
                        future = executor.submit(
                            self.train_pytorch_model, X_train, y_train, X_val, y_val, feature_cols
                        )
                    else:
                        future = executor.submit(
                            self.train_sklearn_model, model_name, X_train, y_train, X_val, y_val, feature_cols
                        )
                    future_to_model[future] = model_name
                
                # 收集结果
                for future in as_completed(future_to_model):
                    model_name = future_to_model[future]
                    try:
                        result = future.result()
                        results['models'][model_name] = result
                        logger.info(f"Completed training {model_name}: R² = {result.get('r2', 0):.3f}")
                    except Exception as e:
                        logger.error(f"Error training {model_name}: {e}")
                        results['models'][model_name] = {'error': str(e)}
            
            # 交叉验证最佳模型
            best_model = max(
                [(name, result.get('r2', 0)) for name, result in results['models'].items() 
                 if 'error' not in result],
                key=lambda x: x[1]
            )
            
            logger.info(f"Best model: {best_model[0]} with R² = {best_model[1]:.3f}")
            
            # 对最佳模型进行交叉验证
            cv_result = self.cross_validate_model(best_model[0], X, y)
            results['best_model'] = {
                'name': best_model[0],
                'r2': best_model[1],
                'cross_validation': cv_result
            }
            
            logger.info(f"=== Completed {dataset_name} - {window_size}s ===")
            return results
            
        except Exception as e:
            logger.error(f"Error validating {dataset_name}_{window_size}: {e}")
            return {'error': str(e)}
    
    def save_results(self, results: dict, output_dir: str):
        """保存验证结果."""
        try:
            output_path = Path(output_dir)
            output_path.mkdir(exist_ok=True)
            
            dataset_name = results['dataset_name']
            window_size = results['window_size']
            
            # 保存模型性能摘要
            summary_file = output_path / f"validation_summary_{dataset_name}_{window_size}.json"
            
            # 准备可序列化的结果
            serializable_results = {
                'dataset_name': dataset_name,
                'window_size': window_size,
                'data_shape': results.get('data_shape'),
                'feature_cols': results.get('feature_cols'),
                'models_performance': {},
                'best_model': results.get('best_model', {})
            }
            
            # 提取模型性能指标
            for model_name, model_result in results.get('models', {}).items():
                if 'error' not in model_result:
                    serializable_results['models_performance'][model_name] = {
                        'mse': model_result.get('mse'),
                        'r2': model_result.get('r2'),
                        'mae': model_result.get('mae'),
                        'feature_importance': model_result.get('feature_importance')
                    }
            
            # 保存JSON结果
            import json
            with open(summary_file, 'w') as f:
                json.dump(serializable_results, f, indent=2, default=str)
            
            logger.info(f"Saved validation results: {summary_file}")
            
            # 保存最佳模型
            best_model_name = results.get('best_model', {}).get('name')
            if best_model_name and best_model_name in results.get('models', {}):
                model_result = results['models'][best_model_name]
                if 'error' not in model_result:
                    model_file = output_path / f"best_model_{dataset_name}_{window_size}.joblib"
                    
                    # 只保存scikit-learn模型
                    if best_model_name != 'PyTorch_NN':
                        joblib.dump(model_result['model'], model_file)
                        logger.info(f"Saved best model: {model_file}")
            
        except Exception as e:
            logger.error(f"Error saving results: {e}")

def main():
    """主函数."""
    try:
        logger.info("Starting Step 6: Single Dataset Validation Modeling")
        
        # 数据集和窗口大小配置
        datasets = ['CRWD', 'SWELL', 'WESAD', 'Nurses', 'MMASH', 
                   'Mental_Health_Pred', 'DRIVE_DB', 'Non_EEG']
        window_sizes = ['60s', '300s', '900s']
        
        output_dir = '/mnt/d/data_analysis/processed/single_dataset_validation'
        
        # 初始化验证器
        validator = DatasetValidator(device='auto', n_threads=8)
        
        # 逐个处理数据集
        all_results = {}
        
        for dataset_name in datasets:
            logger.info(f"\n{'='*50}")
            logger.info(f"Processing Dataset: {dataset_name}")
            logger.info(f"{'='*50}")
            
            dataset_results = {}
            
            for window_size in window_sizes:
                try:
                    result = validator.validate_dataset(dataset_name, window_size)
                    dataset_results[window_size] = result
                    
                    # 保存结果
                    validator.save_results(result, output_dir)
                    
                except Exception as e:
                    logger.error(f"Error processing {dataset_name}_{window_size}: {e}")
                    dataset_results[window_size] = {'error': str(e)}
            
            all_results[dataset_name] = dataset_results
        
        # 保存总体结果摘要
        summary_file = Path(output_dir) / "validation_summary_all_datasets.json"
        import json
        with open(summary_file, 'w') as f:
            json.dump(all_results, f, indent=2, default=str)
        
        logger.info(f"\n{'='*50}")
        logger.info("Step 6 Completed Successfully!")
        logger.info(f"{'='*50}")
        
        # 打印总体摘要
        for dataset_name, dataset_results in all_results.items():
            logger.info(f"\n{dataset_name}:")
            for window_size, result in dataset_results.items():
                if 'error' not in result:
                    best_model = result.get('best_model', {})
                    logger.info(f"  {window_size}: Best model = {best_model.get('name', 'N/A')}, R² = {best_model.get('r2', 0):.3f}")
                else:
                    logger.warning(f"  {window_size}: Error - {result['error']}")
        
    except Exception as e:
        logger.error(f"Error in main execution: {e}")
        raise

if __name__ == "__main__":
    main()



