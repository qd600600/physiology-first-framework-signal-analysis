#!/usr/bin/env python3
"""
Step 3 科学严谨验证框架
严格按照用户要求的科学验证流程执行
包含：winsorization、VIF、robust scaling、permutation testing、cross-validation
输出: step3_diagnostics.json, step3_permutation_null.npy
"""

import pandas as pd
import numpy as np
import json
import warnings
import torch
from sklearn.model_selection import train_test_split, RepeatedKFold
from sklearn.preprocessing import StandardScaler, RobustScaler
from sklearn.feature_selection import f_classif, mutual_info_regression, SelectKBest
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from sklearn.inspection import permutation_importance
from sklearn.impute import SimpleImputer
from scipy import stats
from scipy.stats import pearsonr
import time
warnings.filterwarnings("ignore")

# GPU检查
print("🔍 GPU检查:")
print(f"  CUDA可用: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print(f"  GPU设备: {torch.cuda.get_device_name(0)}")
    print(f"  GPU内存: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.1f} GB")
    device = torch.device('cuda')
else:
    print("  ⚠️ CUDA不可用，将使用CPU")
    device = torch.device('cpu')

print("=" * 70)
print("Step 3 科学严谨验证框架")
print("=" * 70)

# ======= 科学验证函数定义 =======

def safe_impute(df, verbose=True):
    """
    安全imputation函数 - 处理全NaN列和非数值列
    """
    df = df.copy()
    original_shape = df.shape
    
    # 检查全NaN列
    nan_cols = df.columns[df.isna().all()].tolist()
    if len(nan_cols) > 0:
        if verbose:
            print(f"⚠️ 发现全NaN列，将删除: {nan_cols}")
        df = df.drop(columns=nan_cols)
    
    # 数值列筛选
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    if len(numeric_cols) < df.shape[1]:
        dropped_nonnum = list(set(df.columns) - set(numeric_cols))
        if verbose:
            print(f"⚠️ 非数值列被排除: {dropped_nonnum}")
        df = df[numeric_cols]
    
    # Impute
    imp = SimpleImputer(strategy='median')
    X_imputed = imp.fit_transform(df)
    df_out = pd.DataFrame(X_imputed, columns=df.columns, index=df.index)
    
    if verbose:
        print(f"  Imputation完成: {original_shape} -> {df_out.shape}")
    
    return df_out

def winsorize_data(df, lower=0.01, upper=0.99, verbose=True):
    """
    Winsorization - 处理极值
    """
    df_winsorized = df.copy()
    for col in df.columns:
        if df[col].dtype in ['float64', 'int64']:
            lower_bound = df[col].quantile(lower)
            upper_bound = df[col].quantile(upper)
            df_winsorized[col] = df[col].clip(lower=lower_bound, upper=upper_bound)
    
    if verbose:
        print(f"  Winsorization完成: 下界{lower}, 上界{upper}")
    
    return df_winsorized

def remove_high_vif_features(df, threshold=10, verbose=True):
    """
    移除高VIF特征
    """
    from statsmodels.stats.outliers_influence import variance_inflation_factor
    
    # 计算VIF
    vif_data = pd.DataFrame()
    vif_data["Feature"] = df.columns
    vif_data["VIF"] = [variance_inflation_factor(df.values, i) 
                      for i in range(df.shape[1])]
    
    # 移除高VIF特征
    high_vif_features = vif_data[vif_data["VIF"] > threshold]["Feature"].tolist()
    if len(high_vif_features) > 0:
        if verbose:
            print(f"⚠️ 移除高VIF特征: {high_vif_features}")
        df_cleaned = df.drop(columns=high_vif_features)
    else:
        df_cleaned = df.copy()
    
    if verbose:
        print(f"  VIF清理完成: {df.shape[1]} -> {df_cleaned.shape[1]} 特征")
    
    return df_cleaned, vif_data

def robust_feature_selection(X, y, method='f_test', k=20, verbose=True):
    """
    稳健特征选择
    """
    if method == 'f_test':
        selector = SelectKBest(score_func=f_classif, k=min(k, X.shape[1]))
    elif method == 'mutual_info':
        selector = SelectKBest(score_func=mutual_info_regression, k=min(k, X.shape[1]))
    else:
        raise ValueError("method must be 'f_test' or 'mutual_info'")
    
    X_selected = selector.fit_transform(X, y)
    selected_features = X.columns[selector.get_support()]
    
    if verbose:
        print(f"  {method}特征选择完成: {X.shape[1]} -> {len(selected_features)} 特征")
    
    return X_selected, selected_features, selector

def permutation_test(model, X, y, n_permutations=1000, random_state=42, verbose=True):
    """
    置换检验 - 评估模型显著性
    """
    np.random.seed(random_state)
    
    # 真实模型性能
    model.fit(X, y)
    true_score = model.score(X, y)
    
    # 置换检验
    permuted_scores = []
    for i in range(n_permutations):
        if verbose and i % 100 == 0:
            print(f"    置换检验进度: {i}/{n_permutations}")
        
        y_permuted = np.random.permutation(y)
        model.fit(X, y_permuted)
        permuted_scores.append(model.score(X, y_permuted))
    
    # 计算p值
    p_value = np.mean(np.array(permuted_scores) >= true_score)
    
    if verbose:
        print(f"  置换检验完成: p-value = {p_value:.4f}")
    
    return true_score, permuted_scores, p_value

# ======= Step 1: 数据读取 =======
print("\n📂 Step 1: 数据读取")
print("  📥 正在读取features_base.csv...")
base = pd.read_csv("features_base.csv")
print(f"    ✅ Base特征加载完成: {base.shape}")

print("  📥 正在读取features_extended.csv...")
extended = pd.read_csv("features_extended.csv")
print(f"    ✅ Extended特征加载完成: {extended.shape}")

print("  📥 正在读取labels.csv...")
y = pd.read_csv("labels.csv")["target"]
print(f"    ✅ 标签加载完成: {len(y)} 个样本")

# 样本一致性检查
assert len(base) == len(extended) == len(y), "样本数量不一致"
print(f"  ✅ 数据加载完成: {len(y)} 个样本")

# ======= Step 2: 数据预处理 =======
print("\n🔧 Step 2: 数据预处理")

# 2.1 Winsorization
print("  📊 执行Winsorization...")
base_winsorized = winsorize_data(base)
extended_winsorized = winsorize_data(extended)

# 2.2 安全Imputation
print("  🔄 执行安全Imputation...")
base_imputed = safe_impute(base_winsorized)
extended_imputed = safe_impute(extended_winsorized)

# 2.3 VIF清理
print("  🧹 执行VIF清理...")
base_vif_cleaned, base_vif_data = remove_high_vif_features(base_imputed)
extended_vif_cleaned, extended_vif_data = remove_high_vif_features(extended_imputed)

# 2.4 特征选择
print("  🎯 执行特征选择...")
base_selected, base_selected_features, base_selector = robust_feature_selection(
    base_vif_cleaned, y, method='f_test', k=min(10, base_vif_cleaned.shape[1]))
extended_selected, extended_selected_features, extended_selector = robust_feature_selection(
    extended_vif_cleaned, y, method='f_test', k=min(20, extended_vif_cleaned.shape[1]))

# ======= Step 3: 交叉验证 =======
print("\n🔄 Step 3: 交叉验证")
print("  📊 设置交叉验证参数...")
cv = RepeatedKFold(n_splits=5, n_repeats=3, random_state=42)
scaler = RobustScaler()

# 存储结果
cv_results = {
    'base_scores': [],
    'extended_scores': [],
    'fold_info': []
}

print("  🔄 开始交叉验证...")
for fold_idx, (train_idx, test_idx) in enumerate(cv.split(base_selected)):
    print(f"    Fold {fold_idx + 1}/15...")
    
    # 数据划分
    Xb_train, Xb_test = base_selected[train_idx], base_selected[test_idx]
    Xe_train, Xe_test = extended_selected[train_idx], extended_selected[test_idx]
    y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]
    
    # 标准化
    Xb_train_scaled = scaler.fit_transform(Xb_train)
    Xb_test_scaled = scaler.transform(Xb_test)
    Xe_train_scaled = scaler.fit_transform(Xe_train)
    Xe_test_scaled = scaler.transform(Xe_test)
    
    # 模型训练
    model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
    
    # Base模型
    model.fit(Xb_train_scaled, y_train)
    base_score = model.score(Xb_test_scaled, y_test)
    
    # Extended模型
    model.fit(Xe_train_scaled, y_train)
    extended_score = model.score(Xe_test_scaled, y_test)
    
    cv_results['base_scores'].append(base_score)
    cv_results['extended_scores'].append(extended_score)
    cv_results['fold_info'].append({
        'fold': fold_idx + 1,
        'train_size': len(train_idx),
        'test_size': len(test_idx)
    })

# ======= Step 4: 统计分析 =======
print("\n📈 Step 4: 统计分析")

# 4.1 基本统计
base_mean = np.mean(cv_results['base_scores'])
extended_mean = np.mean(cv_results['extended_scores'])
base_std = np.std(cv_results['base_scores'])
extended_std = np.std(cv_results['extended_scores'])

# 4.2 配对t检验
t_stat, p_value = stats.ttest_rel(cv_results['extended_scores'], cv_results['base_scores'])

# 4.3 效应量 (Cohen's d)
pooled_std = np.sqrt(((len(cv_results['base_scores']) - 1) * base_std**2 + 
                     (len(cv_results['extended_scores']) - 1) * extended_std**2) / 
                    (len(cv_results['base_scores']) + len(cv_results['extended_scores']) - 2))
cohens_d = (extended_mean - base_mean) / pooled_std

# 4.4 置换检验
print("  🔬 执行置换检验...")
final_model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
true_score, permuted_scores, perm_p_value = permutation_test(
    final_model, extended_selected, y, n_permutations=1000, verbose=True)

# ======= Step 5: 结果保存 =======
print("\n💾 Step 5: 结果保存")

# 5.1 诊断信息
diagnostics = {
    'data_info': {
        'original_base_shape': base.shape,
        'original_extended_shape': extended.shape,
        'final_base_shape': base_selected.shape,
        'final_extended_shape': extended_selected.shape,
        'samples': len(y)
    },
    'preprocessing_steps': {
        'winsorization_applied': True,
        'imputation_applied': True,
        'vif_cleaning_applied': True,
        'feature_selection_applied': True
    },
    'cross_validation_results': {
        'base_mean_r2': float(base_mean),
        'base_std_r2': float(base_std),
        'extended_mean_r2': float(extended_mean),
        'extended_std_r2': float(extended_std),
        'improvement': float(extended_mean - base_mean),
        'improvement_percent': float((extended_mean - base_mean) / abs(base_mean) * 100)
    },
    'statistical_tests': {
        'paired_t_test': {
            't_statistic': float(t_stat),
            'p_value': float(p_value),
            'significant': p_value < 0.05
        },
        'effect_size': {
            'cohens_d': float(cohens_d),
            'interpretation': 'small' if abs(cohens_d) < 0.5 else 'medium' if abs(cohens_d) < 0.8 else 'large'
        },
        'permutation_test': {
            'true_score': float(true_score),
            'p_value': float(perm_p_value),
            'significant': perm_p_value < 0.05
        }
    },
    'feature_info': {
        'base_selected_features': base_selected_features.tolist(),
        'extended_selected_features': extended_selected_features.tolist(),
        'base_vif_data': base_vif_data.to_dict('records'),
        'extended_vif_data': extended_vif_data.to_dict('records')
    }
}

# 5.2 保存结果
print("  💾 保存诊断结果...")
with open("step3_diagnostics.json", "w") as f:
    json.dump(diagnostics, f, indent=4)

print("  💾 保存置换检验结果...")
np.save("step3_permutation_null.npy", permuted_scores)

# ======= Step 6: 结果报告 =======
print("\n📊 Step 6: 结果报告")
print("=" * 70)
print("Step 3 科学严谨验证结果")
print("=" * 70)
print(f"📈 交叉验证结果:")
print(f"  Base模型 R²: {base_mean:.4f} ± {base_std:.4f}")
print(f"  Extended模型 R²: {extended_mean:.4f} ± {extended_std:.4f}")
print(f"  性能提升: {extended_mean - base_mean:.4f} ({((extended_mean - base_mean) / abs(base_mean) * 100):.2f}%)")
print(f"\n🔬 统计检验:")
print(f"  配对t检验: t = {t_stat:.4f}, p = {p_value:.4f}")
print(f"  效应量 (Cohen's d): {cohens_d:.4f} ({'small' if abs(cohens_d) < 0.5 else 'medium' if abs(cohens_d) < 0.8 else 'large'})")
print(f"  置换检验: p = {perm_p_value:.4f}")
print(f"\n✅ 结果文件:")
print(f"  step3_diagnostics.json - 完整诊断信息")
print(f"  step3_permutation_null.npy - 置换检验结果")
print("=" * 70)

print("🎉 Step 3 科学严谨验证完成！")
