#!/usr/bin/env python3
"""
Step 3: 特征工程增强 - GPU优化版本
使用分块计算、混合精度、异步流等优化策略
目标：Step 4特征选择 < 15分钟，GPU占用75-90%
"""

import pandas as pd
import numpy as np
import torch
import json
import time
import sys
import math
from sklearn.preprocessing import RobustScaler
from sklearn.model_selection import train_test_split, RepeatedKFold
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
import warnings
warnings.filterwarnings("ignore")

def print_progress(message):
    """打印进度信息"""
    print(message)
    sys.stdout.flush()

print("=" * 70)
print("Step 3: 特征工程增强 - GPU优化版本")
print("=" * 70)

# GPU检查
print_progress("🔍 GPU检查:")
print_progress(f"  CUDA可用: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print_progress(f"  GPU设备: {torch.cuda.get_device_name(0)}")
    print_progress(f"  GPU内存: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.1f} GB")
    device = torch.device('cuda')
    use_gpu = True
    torch.backends.cudnn.benchmark = True
    torch.backends.cuda.matmul.allow_tf32 = True
    print_progress("  ✅ 启用CUDA优化 + TF32")
else:
    print_progress("  ⚠️ CUDA不可用，将使用CPU")
    device = torch.device('cpu')
    use_gpu = False

def gpu_feature_engineering_optimized(X, y, verbose=True):
    """GPU优化的特征工程"""
    if verbose:
        print_progress("  🚀 GPU优化特征工程...")
    
    # 转换为GPU张量
    X_tensor = torch.tensor(X.values, device=device, dtype=torch.float32)
    y_tensor = torch.tensor(y.values, device=device, dtype=torch.float32)
    
    n_samples, n_features = X_tensor.shape
    
    if verbose:
        print_progress(f"    📊 GPU数据形状: {X_tensor.shape}")
        print_progress(f"    📊 GPU内存使用: {torch.cuda.memory_allocated() / 1024**3:.2f} GB")
    
    # 使用混合精度进行特征工程
    with torch.autocast(device_type='cuda', dtype=torch.float16):
        # 1. 多尺度变换
        if verbose:
            print_progress("    🔄 GPU多尺度变换（混合精度）...")
        
        X_transformed = X_tensor.clone()
        
        # Log变换
        X_log = torch.log1p(torch.clamp(X_tensor, min=0))
        X_transformed = torch.cat([X_transformed, X_log], dim=1)
        
        # Z-score标准化
        X_mean = X_tensor.mean(dim=0, keepdim=True)
        X_std = X_tensor.std(dim=0, keepdim=True) + 1e-8
        X_zscore = (X_tensor - X_mean) / X_std
        X_transformed = torch.cat([X_transformed, X_zscore], dim=1)
        
        # MinMax标准化
        X_min = X_tensor.min(dim=0, keepdim=True)[0]
        X_max = X_tensor.max(dim=0, keepdim=True)[0]
        X_minmax = (X_tensor - X_min) / (X_max - X_min + 1e-8)
        X_transformed = torch.cat([X_transformed, X_minmax], dim=1)
        
        if verbose:
            print_progress(f"    ✅ 多尺度变换完成: {n_features} -> {X_transformed.shape[1]} 特征")
        
        # 2. 交互特征（限制数量）
        if verbose:
            print_progress("    🔗 GPU交互特征创建（混合精度）...")
        
        # 选择前3个特征进行交互，避免内存爆炸
        X_base = X_tensor[:, :3]
        n_base = X_base.shape[1]
        
        interaction_features = []
        for i in range(n_base):
            for j in range(i+1, n_base):
                # 乘积交互
                product = X_base[:, i] * X_base[:, j]
                interaction_features.append(product.unsqueeze(1))
                
                # 差异交互
                diff = X_base[:, i] - X_base[:, j]
                interaction_features.append(diff.unsqueeze(1))
        
        if interaction_features:
            X_interactions = torch.cat(interaction_features, dim=1)
            X_transformed = torch.cat([X_transformed, X_interactions], dim=1)
        
        if verbose:
            print_progress(f"    ✅ 交互特征完成: {X_transformed.shape[1]} 特征")
    
    # 同步GPU操作
    torch.cuda.synchronize()
    
    if verbose:
        print_progress(f"    📊 GPU内存使用: {torch.cuda.memory_allocated() / 1024**3:.2f} GB")
    
    return X_transformed

def gpu_f_test_batched(X_tensor, y_tensor, batch_size=2000000, verbose=True):
    """分块GPU F-test计算"""
    if verbose:
        print_progress("  🎯 分块GPU F-test计算...")
    
    n_samples, n_features = X_tensor.shape
    num_batches = math.ceil(n_samples / batch_size)
    
    if verbose:
        print_progress(f"    📊 分块处理: {num_batches} 个批次，每批 {batch_size} 样本")
    
    # 使用混合精度
    with torch.autocast(device_type='cuda', dtype=torch.float16):
        f_values_batches = []
        
        for i in range(num_batches):
            start_idx = i * batch_size
            end_idx = min((i + 1) * batch_size, n_samples)
            
            if verbose and (i + 1) % 5 == 0:
                gpu_memory = torch.cuda.memory_allocated() / (1024**3)
                print_progress(f"    处理批次 {i+1}/{num_batches}: {start_idx}-{end_idx}, GPU内存: {gpu_memory:.2f}GB")
            
            # 获取当前批次
            X_batch = X_tensor[start_idx:end_idx]
            y_batch = y_tensor[start_idx:end_idx]
            
            # 计算批次F值
            f_batch = compute_f_test_batch(X_batch, y_batch)
            f_values_batches.append(f_batch.detach().cpu())
        
        # 合并结果
        f_values = torch.cat(f_values_batches, dim=0)
    
    # 同步GPU操作
    torch.cuda.synchronize()
    
    if verbose:
        print_progress(f"    ✅ 分块F-test完成: {f_values.shape}")
        print_progress(f"    📊 F值范围: {f_values.min():.2f} - {f_values.max():.2f}")
    
    return f_values

def compute_f_test_batch(X_batch, y_batch):
    """计算单个批次的F-test"""
    n_samples, n_features = X_batch.shape
    
    # 获取唯一类别
    unique_classes = torch.unique(y_batch)
    n_classes = len(unique_classes)
    
    f_scores = torch.zeros(n_features, device=device, dtype=torch.float16)
    
    # 计算每个类别的统计量
    class_means = torch.zeros(n_classes, n_features, device=device, dtype=torch.float16)
    class_counts = torch.zeros(n_classes, device=device, dtype=torch.float16)
    
    for j, cls in enumerate(unique_classes):
        mask = (y_batch == cls)
        if mask.sum() > 1:
            class_means[j] = X_batch[mask].mean(dim=0)
            class_counts[j] = mask.sum().float()
    
    # 计算总体均值
    overall_mean = X_batch.mean(dim=0)
    
    # 计算F值（向量化）
    for i in range(n_features):
        # 组间方差
        ss_between = torch.sum(class_counts * (class_means[:, i] - overall_mean[i]) ** 2)
        
        # 组内方差
        ss_within = torch.tensor(0.0, device=device, dtype=torch.float16)
        for j, cls in enumerate(unique_classes):
            mask = (y_batch == cls)
            if mask.sum() > 1:
                ss_within += torch.sum((X_batch[mask, i] - class_means[j, i]) ** 2)
        
        # 计算F值
        df_between = n_classes - 1
        df_within = n_samples - n_classes
        
        if ss_within > 1e-8 and df_between > 0 and df_within > 0:
            f_scores[i] = (ss_between / df_between) / (ss_within / df_within)
        else:
            f_scores[i] = 0.0
    
    return f_scores

def gpu_feature_selection_optimized(X_tensor, y_tensor, k=15, verbose=True):
    """GPU优化的特征选择"""
    if verbose:
        print_progress("  🎯 GPU优化特征选择...")
    
    n_samples, n_features = X_tensor.shape
    
    # 1. 分块F-test计算
    f_scores = gpu_f_test_batched(X_tensor, y_tensor, batch_size=2000000, verbose=verbose)
    
    # 2. GPU方差计算（向量化）
    if verbose:
        print_progress("    📊 GPU方差计算...")
    
    with torch.autocast(device_type='cuda', dtype=torch.float16):
        var_scores = X_tensor.var(dim=0)
    
    # 3. GPU相关性计算（向量化）
    if verbose:
        print_progress("    📊 GPU相关性计算...")
    
    with torch.autocast(device_type='cuda', dtype=torch.float16):
        y_mean = y_tensor.mean()
        y_std = y_tensor.std() + 1e-8
        y_norm = (y_tensor - y_mean) / y_std
        
        corr_scores = torch.zeros(n_features, device=device, dtype=torch.float16)
        for i in range(n_features):
            x_norm = (X_tensor[:, i] - X_tensor[:, i].mean()) / (X_tensor[:, i].std() + 1e-8)
            corr_scores[i] = torch.abs(torch.mean(x_norm * y_norm))
    
    # 标准化分数
    def normalize_scores(scores):
        scores = scores.clone()
        if scores.max() - scores.min() > 1e-8:
            return (scores - scores.min()) / (scores.max() - scores.min())
        else:
            return torch.ones_like(scores)
    
    f_scores_norm = normalize_scores(f_scores.float())
    var_scores_norm = normalize_scores(var_scores.float())
    corr_scores_norm = normalize_scores(corr_scores.float())
    
    # 综合评分
    combined_scores = (f_scores_norm + var_scores_norm + corr_scores_norm) / 3
    
    # 选择前k个特征
    top_k_indices = torch.argsort(combined_scores, descending=True)[:k]
    
    # 同步GPU操作
    torch.cuda.synchronize()
    
    if verbose:
        print_progress(f"    ✅ GPU特征选择完成: {n_features} -> {k} 特征")
        print_progress(f"    📊 GPU内存使用: {torch.cuda.memory_allocated() / 1024**3:.2f} GB")
    
    return top_k_indices, combined_scores

def gpu_model_training_optimized(X_train, X_test, y_train, y_test, verbose=True):
    """GPU优化的模型训练"""
    if verbose:
        print_progress("  🤖 GPU优化模型训练...")
    
    # 转换为GPU张量
    X_train_tensor = torch.tensor(X_train, device=device, dtype=torch.float32)
    X_test_tensor = torch.tensor(X_test, device=device, dtype=torch.float32)
    y_train_tensor = torch.tensor(y_train, device=device, dtype=torch.float32)
    y_test_tensor = torch.tensor(y_test, device=device, dtype=torch.float32)
    
    # 使用混合精度进行标准化
    with torch.autocast(device_type='cuda', dtype=torch.float16):
        X_train_mean = X_train_tensor.mean(dim=0, keepdim=True)
        X_train_std = X_train_tensor.std(dim=0, keepdim=True) + 1e-8
        X_train_scaled = (X_train_tensor - X_train_mean) / X_train_std
        X_test_scaled = (X_test_tensor - X_train_mean) / X_train_std
    
    # 转换回CPU进行sklearn训练
    X_train_scaled_cpu = X_train_scaled.cpu().numpy()
    X_test_scaled_cpu = X_test_scaled.cpu().numpy()
    
    # 训练模型
    model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
    model.fit(X_train_scaled_cpu, y_train)
    y_pred = model.predict(X_test_scaled_cpu)
    
    # 计算指标
    r2 = r2_score(y_test, y_pred)
    mae = mean_absolute_error(y_test, y_pred)
    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    
    if verbose:
        print_progress(f"    ✅ 模型训练完成: R² = {r2:.4f}")
    
    return {
        'r2': r2,
        'mae': mae,
        'mse': mse,
        'rmse': rmse,
        'y_pred': y_pred
    }

# ======= Step 1: 数据读取 =======
print_progress("\n📂 Step 1: 数据读取")
start_time = time.time()

print_progress("  📥 正在读取features_base.csv...")
base = pd.read_csv("features_base.csv")
print_progress(f"    ✅ Base特征加载完成: {base.shape}")

print_progress("  📥 正在读取features_extended.csv...")
extended = pd.read_csv("features_extended.csv")
print_progress(f"    ✅ Extended特征加载完成: {extended.shape}")

print_progress("  📥 正在读取labels.csv...")
y = pd.read_csv("labels.csv")["target"]
print_progress(f"    ✅ 标签加载完成: {len(y)} 个样本")

print_progress(f"  ⏱️ 数据加载耗时: {time.time() - start_time:.2f}秒")

# ======= Step 2: 数据预处理 =======
print_progress("\n🔧 Step 2: 数据预处理")
preprocess_start = time.time()

# 移除高缺失值列
print_progress("  🧹 移除高缺失值列...")
missing_ratio = extended.isna().sum() / len(extended)
high_missing_cols = missing_ratio[missing_ratio > 0.5].index.tolist()
extended_clean = extended.drop(columns=high_missing_cols)
extended_imputed = extended_clean.fillna(0)

print_progress(f"    📊 移除列数: {extended.shape[1]} -> {extended_clean.shape[1]}")

print_progress(f"  ⏱️ 预处理耗时: {time.time() - preprocess_start:.2f}秒")

# ======= Step 3: GPU特征工程 =======
print_progress("\n🚀 Step 3: GPU特征工程")
engineering_start = time.time()

# GPU特征工程
X_enhanced_tensor = gpu_feature_engineering_optimized(extended_imputed, y, verbose=True)

print_progress(f"  ⏱️ GPU特征工程耗时: {time.time() - engineering_start:.2f}秒")

# ======= Step 4: GPU特征选择 =======
print_progress("\n🎯 Step 4: GPU特征选择")
selection_start = time.time()

# GPU特征选择
top_k_indices, combined_scores = gpu_feature_selection_optimized(
    X_enhanced_tensor, torch.tensor(y.values, device=device), k=15, verbose=True)

# 选择特征
X_selected_tensor = X_enhanced_tensor[:, top_k_indices]

# 转换回pandas
X_selected = pd.DataFrame(
    X_selected_tensor.cpu().numpy(),
    columns=[f'feature_{i}' for i in range(X_selected_tensor.shape[1])]
)

print_progress(f"  ⏱️ GPU特征选择耗时: {time.time() - selection_start:.2f}秒")

# ======= Step 5: 模型性能评估 =======
print_progress("\n📊 Step 5: 模型性能评估")
evaluation_start = time.time()

# 数据划分
Xb_train, Xb_test, y_train, y_test = train_test_split(
    base, y, test_size=0.3, random_state=42)
Xe_train, Xe_test, _, _ = train_test_split(
    X_selected, y, test_size=0.3, random_state=42)

# Base模型评估
print_progress("  🎯 Base模型评估...")
base_metrics = gpu_model_training_optimized(Xb_train.values, Xb_test.values, y_train, y_test, verbose=True)

# Extended模型评估
print_progress("  🎯 Extended模型评估...")
extended_metrics = gpu_model_training_optimized(Xe_train.values, Xe_test.values, y_train, y_test, verbose=True)

print_progress(f"  ⏱️ 性能评估耗时: {time.time() - evaluation_start:.2f}秒")

# ======= Step 6: 结果保存 =======
print_progress("\n💾 Step 6: 结果保存")

results = {
    "step3_gpu_optimized": {
        "data_info": {
            "samples": len(y),
            "original_features": int(extended.shape[1]),
            "cleaned_features": int(extended_clean.shape[1]),
            "enhanced_features": int(X_enhanced_tensor.shape[1]),
            "selected_features": int(X_selected_tensor.shape[1])
        },
        "model_performance": {
            "base_model": base_metrics,
            "extended_model": extended_metrics,
            "improvement": {
                "r2_improvement": float(extended_metrics['r2'] - base_metrics['r2']),
                "r2_improvement_percent": float((extended_metrics['r2'] - base_metrics['r2']) / abs(base_metrics['r2']) * 100),
                "mae_improvement": float(base_metrics['mae'] - extended_metrics['mae']),
                "rmse_improvement": float(base_metrics['rmse'] - extended_metrics['rmse'])
            }
        },
        "performance_info": {
            "total_runtime_seconds": time.time() - start_time,
            "data_loading_time": time.time() - start_time - (time.time() - preprocess_start),
            "preprocessing_time": time.time() - preprocess_start - (time.time() - engineering_start),
            "engineering_time": time.time() - engineering_start - (time.time() - selection_start),
            "selection_time": time.time() - selection_start - (time.time() - evaluation_start),
            "evaluation_time": time.time() - evaluation_start
        },
        "gpu_info": {
            "cuda_available": torch.cuda.is_available(),
            "gpu_device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
            "gpu_memory_gb": torch.cuda.get_device_properties(0).total_memory / 1024**3 if torch.cuda.is_available() else None,
            "gpu_memory_used_gb": torch.cuda.memory_allocated() / 1024**3 if torch.cuda.is_available() else 0
        }
    }
}

print_progress("  💾 正在保存结果...")
with open("step3_gpu_optimized_results.json", "w") as f:
    json.dump(results, f, indent=4)

# ======= Step 7: 结果报告 =======
print_progress("\n📊 Step 7: 结果报告")
print("=" * 70)
print("Step 3: 特征工程增强结果（GPU优化版本）")
print("=" * 70)
print(f"🔧 特征工程流程:")
print(f"  原始特征数: {extended.shape[1]}")
print(f"  清理后特征数: {extended_clean.shape[1]}")
print(f"  GPU增强后特征数: {X_enhanced_tensor.shape[1]}")
print(f"  最终选择特征数: {X_selected_tensor.shape[1]}")
print(f"\n📈 模型性能对比:")
print(f"  Base模型 R²: {base_metrics['r2']:.4f}")
print(f"  Extended模型 R²: {extended_metrics['r2']:.4f}")
print(f"  性能改善: {extended_metrics['r2'] - base_metrics['r2']:.4f} ({(extended_metrics['r2'] - base_metrics['r2']) / abs(base_metrics['r2']) * 100:.1f}%)")
print(f"  MAE改善: {base_metrics['mae'] - extended_metrics['mae']:.2f}")
print(f"  RMSE改善: {base_metrics['rmse'] - extended_metrics['rmse']:.2f}")
print(f"\n⏱️ 性能信息:")
print(f"  总运行时间: {time.time() - start_time:.2f}秒")
print(f"  GPU特征工程时间: {time.time() - engineering_start - (time.time() - selection_start):.2f}秒")
print(f"  GPU特征选择时间: {time.time() - selection_start - (time.time() - evaluation_start):.2f}秒")
if torch.cuda.is_available():
    print(f"  GPU内存使用: {torch.cuda.memory_allocated() / 1024**3:.2f} GB")
print(f"\n✅ 结果文件:")
print(f"  step3_gpu_optimized_results.json - GPU优化结果")
print("=" * 70)

print("🎉 Step 3: 特征工程增强（GPU优化版本）完成！")
