#!/usr/bin/env python3
"""
Step 3 强化验证脚本
输出: step3_diagnostics.json, step3_permutation_null.npy (null distribution)
说明: 请先准备 CSV:
 - features_base.csv (原始10特征)
 - features_extended.csv (扩展99特征)
 - labels.csv (列名: target)
可按需调整参数（下方 CONFIG）。
"""

import os, json, math, warnings, numpy as np, pandas as pd
from sklearn.model_selection import RepeatedKFold
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.preprocessing import RobustScaler
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from sklearn.feature_selection import f_regression, mutual_info_regression
from sklearn.impute import SimpleImputer
from scipy.stats import trim_mean
warnings.filterwarnings("ignore")

# ===== CONFIG =====
RANDOM_STATE = 42
N_SPLITS = 5
N_REPEATS = 3
MODEL = RandomForestRegressor(n_estimators=200, random_state=RANDOM_STATE)
VAR_THRESHOLD = 1e-8
WINSOR_LO, WINSOR_HI = 0.01, 0.99
VIF_THRESHOLD = 10.0
PERMUTATIONS = 100   # 可按需增大
SAFE_DENOM = 1e-6
# ==================

# ===== utils =====
def winsorize_df(df, low=WINSOR_LO, high=WINSOR_HI):
    lo = df.quantile(low)
    hi = df.quantile(high)
    return df.clip(lo, hi, axis=1)

def safe_replace_inf_nan(df):
    df = df.copy()
    df.replace([np.inf, -np.inf], np.nan, inplace=True)
    # 报告极端值
    extreme_mask = np.abs(df) > 1e12
    if extreme_mask.values.any():
        print("⚠️ 检测到极端值 (>1e12) 的特征/样本，已置为 NaN")
        df[extreme_mask] = np.nan
    return df

def compute_vif(X_df):
    # 使用线性回归近似计算 VIF，避免额外依赖
    from sklearn.linear_model import LinearRegression
    X = X_df.copy()
    cols = X.columns.tolist()
    vifs = {}
    for i, col in enumerate(cols):
        y = X[col].values
        X_other = X.drop(columns=[col]).values
        # 若其它列全部常数则 VIF 无法计算 -> 标记为 inf
        try:
            reg = LinearRegression().fit(X_other, y)
            r2 = reg.score(X_other, y)
            if np.isnan(r2):
                vifs[col] = np.inf
            else:
                denom = max(1 - r2, 1e-12)
                vifs[col] = 1.0 / denom
        except Exception:
            vifs[col] = np.inf
    return pd.Series(vifs)

def safe_f_regression(X, y):
    # 对 X,y 做基础清理后调用 sklearn f_regression
    try:
        F, p = f_regression(X.fillna(0), y)  # f_regression 有时数值不稳定，但用填充避免 NaN
        F = np.nan_to_num(F, nan=0.0, posinf=0.0, neginf=0.0)
    except Exception:
        F = np.zeros(X.shape[1])
        p = np.ones(X.shape[1])
    return pd.Series(F, index=X.columns), pd.Series(p, index=X.columns)

# ===== load data =====
base = pd.read_csv("features_base.csv", index_col=None)
extended = pd.read_csv("features_extended.csv", index_col=None)
y = pd.read_csv("labels.csv")['target']

assert len(base) == len(extended) == len(y), "样本数量不一致，请确认索引/ID 对齐"

# ===== numeric safety =====
extended = safe_replace_inf_nan(extended)
base = safe_replace_inf_nan(base)

# winsorize to control extremes
extended = winsorize_df(extended)
base = winsorize_df(base)

# drop near-constant features
var = extended.var(skipna=True)
keep_cols = var[var > VAR_THRESHOLD].index.tolist()
dropped_const = [c for c in extended.columns if c not in keep_cols]
extended = extended[keep_cols]

# ==== iterative VIF removal (扩展特征) ====
# 标准化临时用于 VIF 计算
imp = SimpleImputer(strategy='median')
Xe_for_vif = pd.DataFrame(imp.fit_transform(extended), columns=extended.columns)
scaler_tmp = RobustScaler().fit(Xe_for_vif)
Xe_vif_scaled = pd.DataFrame(scaler_tmp.transform(Xe_for_vif), columns=extended.columns)
removed_vif = []
while True:
    vifs = compute_vif(Xe_vif_scaled)
    max_vif = vifs.max()
    if max_vif > VIF_THRESHOLD:
        drop_col = vifs.idxmax()
        removed_vif.append((drop_col, max_vif))
        Xe_vif_scaled.drop(columns=[drop_col], inplace=True)
    else:
        break
# keep final extended features after VIF removal
extended = extended[Xe_vif_scaled.columns.tolist()]

# ===== feature scoring (F-test + mutual info) =====
F_scores, p_scores = safe_f_regression(extended, y)
mi_scores = pd.Series(mutual_info_regression(extended.fillna(0), y, random_state=RANDOM_STATE),
                      index=extended.columns)

# 标记潜在异常F值
anomalous_F = F_scores[np.abs(F_scores) > 1e8].to_dict()  # 任意阈值视情况调整

# ===== select features by combined criterion =====
# 方案：互信息与 F 共同筛选（避免单一 F 导致问题）
k_select = min(50, extended.shape[1])
mi_top = mi_scores.sort_values(ascending=False).head(k_select).index
# 联合保留 = MI top ∪ (F p < 0.05)
f_good = p_scores[p_scores < 0.05].index
selected = sorted(set(mi_top).union(set(f_good)))
extended_selected = extended[selected]

# ===== CV evaluation (同一折) =====
rkf = RepeatedKFold(n_splits=N_SPLITS, n_repeats=N_REPEATS, random_state=RANDOM_STATE)
base_scores = []
ext_scores = []
base_train_scores = []
ext_train_scores = []

for train_idx, test_idx in rkf.split(base):
    Xb_tr, Xb_te = base.iloc[train_idx], base.iloc[test_idx]
    Xe_tr, Xe_te = extended_selected.iloc[train_idx], extended_selected.iloc[test_idx]
    y_tr, y_te = y.iloc[train_idx], y.iloc[test_idx]

    # impute + robust scale per fold
    imp = SimpleImputer(strategy='median').fit(Xb_tr)
    Xb_tr = pd.DataFrame(imp.transform(Xb_tr), columns=Xb_tr.columns)
    Xb_te = pd.DataFrame(imp.transform(Xb_te), columns=Xb_te.columns)

    imp2 = SimpleImputer(strategy='median').fit(Xe_tr)
    Xe_tr = pd.DataFrame(imp2.transform(Xe_tr), columns=Xe_tr.columns)
    Xe_te = pd.DataFrame(imp2.transform(Xe_te), columns=Xe_te.columns)

    scaler_b = RobustScaler().fit(Xb_tr)
    Xb_tr_s, Xb_te_s = scaler_b.transform(Xb_tr), scaler_b.transform(Xb_te)
    scaler_e = RobustScaler().fit(Xe_tr)
    Xe_tr_s, Xe_te_s = scaler_e.transform(Xe_tr), scaler_e.transform(Xe_te)

    # train & eval
    MODEL.set_params(random_state=RANDOM_STATE)
    MODEL.fit(Xb_tr_s, y_tr)
    yb_pred_te = MODEL.predict(Xb_te_s)
    yb_pred_tr = MODEL.predict(Xb_tr_s)

    MODEL.fit(Xe_tr_s, y_tr)
    ye_pred_te = MODEL.predict(Xe_te_s)
    ye_pred_tr = MODEL.predict(Xe_tr_s)

    base_scores.append(r2_score(y_te, yb_pred_te))
    ext_scores.append(r2_score(y_te, ye_pred_te))
    base_train_scores.append(r2_score(y_tr, yb_pred_tr))
    ext_train_scores.append(r2_score(y_tr, ye_pred_tr))

# summarize
mean_base = float(np.mean(base_scores))
mean_ext = float(np.mean(ext_scores))
std_base = float(np.std(base_scores))
std_ext = float(np.std(ext_scores))
delta_abs = mean_ext - mean_base
safe_denom = max(abs(mean_base), SAFE_DENOM)
delta_pct = (delta_abs / safe_denom) * 100.0

# overfitting check (train - test gap)
train_gap_base = float(np.mean(base_train_scores) - mean_base)
train_gap_ext = float(np.mean(ext_train_scores) - mean_ext)

# ===== permutation test for extended (null distribution) =====
null_scores = []
for i in range(PERMUTATIONS):
    y_perm = y.sample(frac=1.0, random_state=RANDOM_STATE + i).reset_index(drop=True)
    # we reuse CV splits but compute avg r2 for permuted y using extended_selected
    perm_scores = []
    for train_idx, test_idx in rkf.split(extended_selected):
        Xe_tr = extended_selected.iloc[train_idx]
        Xe_te = extended_selected.iloc[test_idx]
        y_tr = y_perm.iloc[train_idx]
        y_te = y_perm.iloc[test_idx]
        imp2 = SimpleImputer(strategy='median').fit(Xe_tr)
        Xe_tr = pd.DataFrame(imp2.transform(Xe_tr), columns=Xe_tr.columns)
        Xe_te = pd.DataFrame(imp2.transform(Xe_te), columns=Xe_te.columns)
        scaler_e = RobustScaler().fit(Xe_tr)
        Xe_tr_s, Xe_te_s = scaler_e.transform(Xe_tr), scaler_e.transform(Xe_te)
        MODEL.fit(Xe_tr_s, y_tr)
        perm_scores.append(r2_score(y_te, MODEL.predict(Xe_te_s)))
    null_scores.append(np.mean(perm_scores))
null_scores = np.array(null_scores)
p_value_perm = float(np.mean(null_scores >= mean_ext))

# ===== diagnostics & output =====
diagnostics = {
    "n_samples": int(len(y)),
    "n_features_base": int(base.shape[1]),
    "n_features_extended_original": int(pd.read_csv("features_extended.csv").shape[1]),
    "n_features_extended_after_var_vif": int(extended.shape[1]),
    "n_features_extended_selected": int(extended_selected.shape[1]),
    "dropped_const_features": dropped_const,
    "removed_vif": removed_vif,
    "anomalous_F_scores": anomalous_F,
    "mi_top20": mi_scores.sort_values(ascending=False).head(20).to_dict(),
    "cv_mean_r2_base": mean_base,
    "cv_std_r2_base": std_base,
    "cv_mean_r2_extended": mean_ext,
    "cv_std_r2_extended": std_ext,
    "delta_abs_r2": delta_abs,
    "delta_pct_r2_safe": delta_pct,
    "train_gap_base": train_gap_base,
    "train_gap_extended": train_gap_ext,
    "permutation_pvalue_extended": p_value_perm,
    "permutation_null_mean": float(np.mean(null_scores)),
    "permutation_null_std": float(np.std(null_scores)),
    "success_criteria": {
        "delta_abs_r2>0": delta_abs > 0,
        "p_value_perm<0.05": p_value_perm < 0.05,
        "train_gap_extended < 0.1": train_gap_ext < 0.1  # example threshold for overfitting
    }
}

with open("step3_diagnostics.json", "w") as f:
    json.dump(diagnostics, f, indent=2)

np.save("step3_permutation_null.npy", null_scores)
print("✅ Step-3 验证完成，诊断输出: step3_diagnostics.json")
print("主要指标：", {k: diagnostics[k] for k in ["cv_mean_r2_base","cv_mean_r2_extended","delta_abs_r2","delta_pct_r2_safe","permutation_pvalue_extended"]})

