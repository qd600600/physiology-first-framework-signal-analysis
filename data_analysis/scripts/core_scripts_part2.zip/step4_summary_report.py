import json
import numpy as np
from pathlib import Path

def generate_step4_summary():
    """Generate comprehensive summary for Step 4 W(t) generation"""
    
    datasets = ['CRWD', 'SWELL', 'WESAD', 'Nurses', 'MMASH', 'Mental_Health_Pred']
    summary_data = {}

    print('Step 4 W(t) Generation - Comprehensive Summary')
    print('='*60)

    for dataset in datasets:
        stats_file = Path(f'processed/wt_generation/wt_generation_stats_{dataset}.json')
        if stats_file.exists():
            with open(stats_file, 'r') as f:
                stats = json.load(f)
            summary_data[dataset] = stats
            
            print(f'\n{dataset}:')
            print(f'  Generation timestamp: {stats.get("generation_timestamp", "N/A")}')
            
            # Check for NaN values and handle appropriately
            wt_params = stats.get("wt_parameters", {})
            stress_stats = wt_params.get("stress_input_stats", {})
            wt_stats = wt_params.get("wt_stats", {})
            
            # Format stress input stats
            stress_mean = stress_stats.get("mean", np.nan)
            stress_std = stress_stats.get("std", np.nan)
            stress_mean_str = f"{stress_mean:.3f}" if not np.isnan(stress_mean) else "NaN"
            stress_std_str = f"{stress_std:.3f}" if not np.isnan(stress_std) else "NaN"
            
            # Format W(t) stats
            wt_mean = wt_stats.get("mean", np.nan)
            wt_std = wt_stats.get("std", np.nan)
            wt_max = wt_stats.get("max", np.nan)
            wt_mean_str = f"{wt_mean:.3f}" if not np.isnan(wt_mean) else "NaN"
            wt_std_str = f"{wt_std:.3f}" if not np.isnan(wt_std) else "NaN"
            wt_max_str = f"{wt_max:.3f}" if not np.isnan(wt_max) else "NaN"
            
            print(f'  Stress input: mean={stress_mean_str}, std={stress_std_str}')
            print(f'  W(t): mean={wt_mean_str}, std={wt_std_str}, max={wt_max_str}')
            
            # Check sensitivity summary
            sensitivity = stats.get("sensitivity_summary", {})
            if sensitivity:
                print(f'  Best parameters: W_max={sensitivity.get("best_combination", {}).get("W_max", "N/A")}, beta={sensitivity.get("best_combination", {}).get("beta", "N/A")}')
        else:
            print(f'\n{dataset}: ❌ Stats file not found')

    if summary_data:
        # Calculate overall statistics (filter out NaN values)
        wt_means = []
        wt_stds = []
        wt_maxs = []
        
        for data in summary_data.values():
            wt_stats = data.get("wt_parameters", {}).get("wt_stats", {})
            if wt_stats:
                mean_val = wt_stats.get("mean")
                std_val = wt_stats.get("std") 
                max_val = wt_stats.get("max")
                
                if not np.isnan(mean_val):
                    wt_means.append(mean_val)
                if not np.isnan(std_val):
                    wt_stds.append(std_val)
                if not np.isnan(max_val):
                    wt_maxs.append(max_val)

        print(f'\n📊 Overall Statistics:')
        if wt_means:
            print(f'  Average W(t) mean: {np.mean(wt_means):.3f}')
            print(f'  W(t) mean range: [{np.min(wt_means):.3f}, {np.max(wt_means):.3f}]')
        else:
            print(f'  Average W(t) mean: All NaN')
            
        if wt_stds:
            print(f'  Average W(t) std: {np.mean(wt_stds):.3f}')
        else:
            print(f'  Average W(t) std: All NaN')
            
        if wt_maxs:
            print(f'  Average W(t) max: {np.mean(wt_maxs):.3f}')
        else:
            print(f'  Average W(t) max: All NaN')
        
        print(f'\n✅ Step 4 W(t) Generation completed successfully!')
        print(f'📈 Successfully processed {len(summary_data)} out of {len(datasets)} datasets')
        print(f'🎯 Ready for Step 5: LRI Calculation')
        
        return summary_data
    else:
        print(f'\n❌ No W(t) generation data found!')
        return None

if __name__ == "__main__":
    generate_step4_summary()
