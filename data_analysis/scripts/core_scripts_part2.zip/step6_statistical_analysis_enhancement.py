#!/usr/bin/env python3
"""
Step 6: 统计分析深化
Scientific Audit Step 6: Statistical Analysis Enhancement

目标：增加置信区间、效应量、显著性检验，提供更严格的统计分析
"""

import os
import sys
import logging
import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime
from sklearn.model_selection import KFold, cross_val_score, train_test_split, StratifiedKFold
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from sklearn.preprocessing import StandardScaler, RobustScaler, MinMaxScaler
from sklearn.linear_model import Ridge, Lasso, ElasticNet
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.feature_selection import SelectKBest, f_regression, mutual_info_regression
from sklearn.decomposition import PCA
from sklearn.pipeline import Pipeline
from sklearn.inspection import permutation_importance
import json
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from scipy.stats import ttest_rel, wilcoxon, mannwhitneyu, pearsonr, spearmanr
from scipy.stats import norm, t
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('step6_statistical_analysis_enhancement.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class StatisticalAnalysisEnhancement:
    """统计分析深化器."""
    
    def __init__(self):
        self.results = {}
        self.statistical_tests = {}
        logger.info("Initialized StatisticalAnalysisEnhancement")
    
    def load_dataset_data(self, dataset_name: str, window_size: str) -> pd.DataFrame:
        """加载数据集数据."""
        try:
            file_paths = [
                f"/mnt/d/data_analysis/processed/lri_calculation/lri_{dataset_name}_{window_size}_clean.csv",
                f"/mnt/d/data_analysis/processed/lri_calculation/lri_{dataset_name}_{window_size}_fixed.csv",
                f"/mnt/d/data_analysis/processed/lri_calculation/lri_{dataset_name}_{window_size}_fixed_v2.csv",
                f"/mnt/d/data_analysis/processed/lri_calculation/lri_{dataset_name}_{window_size}.csv"
            ]
            
            file_path = None
            for path in file_paths:
                if os.path.exists(path):
                    file_path = path
                    break
            
            if file_path is None:
                logger.warning(f"No data file found for {dataset_name}_{window_size}")
                return pd.DataFrame()
            
            df = pd.read_csv(file_path)
            if df.empty:
                logger.warning(f"Empty data file for {dataset_name}_{window_size}")
                return pd.DataFrame()
            
            logger.info(f"Loaded {dataset_name}_{window_size}: {df.shape}")
            return df
            
        except Exception as e:
            logger.error(f"Error loading {dataset_name}_{window_size}: {e}")
            return pd.DataFrame()
    
    def create_enhanced_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """创建增强特征（基于Step 3的成功方法）."""
        try:
            enhanced_df = df.copy()
            numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
            
            for col in numeric_cols:
                if df[col].notna().sum() > 5:
                    series = df[col].dropna()
                    
                    # 基础统计特征
                    enhanced_df[f'{col}_mean'] = series.mean()
                    enhanced_df[f'{col}_std'] = series.std()
                    enhanced_df[f'{col}_median'] = series.median()
                    enhanced_df[f'{col}_range'] = series.max() - series.min()
                    
                    # 多项式特征
                    enhanced_df[f'{col}_squared'] = df[col] ** 2
                    enhanced_df[f'{col}_sqrt'] = np.sqrt(np.abs(df[col]))
            
            # 交互特征
            if len(numeric_cols) >= 2:
                col1, col2 = numeric_cols[0], numeric_cols[1]
                enhanced_df[f'{col1}_x_{col2}'] = df[col1] * df[col2]
                enhanced_df[f'{col1}_div_{col2}'] = df[col1] / (df[col2] + 1e-8)
            
            return enhanced_df
            
        except Exception as e:
            logger.error(f"Error creating enhanced features: {e}")
            return df.copy()
    
    def calculate_confidence_interval(self, data: np.ndarray, confidence: float = 0.95) -> tuple:
        """计算置信区间."""
        try:
            if len(data) < 2:
                return (np.mean(data), np.mean(data))
            
            n = len(data)
            mean = np.mean(data)
            std = np.std(data, ddof=1)  # 样本标准差
            
            # 使用t分布
            alpha = 1 - confidence
            t_critical = t.ppf(1 - alpha/2, df=n-1)
            
            margin_error = t_critical * (std / np.sqrt(n))
            lower_bound = mean - margin_error
            upper_bound = mean + margin_error
            
            return (lower_bound, upper_bound)
            
        except Exception as e:
            logger.error(f"Error calculating confidence interval: {e}")
            return (np.mean(data), np.mean(data))
    
    def calculate_effect_size(self, group1: np.ndarray, group2: np.ndarray) -> dict:
        """计算效应量."""
        try:
            if len(group1) < 2 or len(group2) < 2:
                return {'cohens_d': 0, 'hedges_g': 0, 'glass_delta': 0}
            
            # Cohen's d
            pooled_std = np.sqrt(((len(group1) - 1) * np.var(group1, ddof=1) + 
                                (len(group2) - 1) * np.var(group2, ddof=1)) / 
                               (len(group1) + len(group2) - 2))
            
            cohens_d = (np.mean(group1) - np.mean(group2)) / pooled_std
            
            # Hedges' g (修正的Cohen's d)
            correction_factor = 1 - (3 / (4 * (len(group1) + len(group2)) - 9))
            hedges_g = cohens_d * correction_factor
            
            # Glass's delta (使用对照组标准差)
            glass_delta = (np.mean(group1) - np.mean(group2)) / np.std(group2, ddof=1)
            
            return {
                'cohens_d': cohens_d,
                'hedges_g': hedges_g,
                'glass_delta': glass_delta
            }
            
        except Exception as e:
            logger.error(f"Error calculating effect size: {e}")
            return {'cohens_d': 0, 'hedges_g': 0, 'glass_delta': 0}
    
    def run_statistical_tests(self, baseline_scores: np.ndarray, enhanced_scores: np.ndarray) -> dict:
        """运行统计检验."""
        try:
            if len(baseline_scores) < 3 or len(enhanced_scores) < 3:
                return {}
            
            # 确保两组数据长度相同
            min_len = min(len(baseline_scores), len(enhanced_scores))
            baseline_scores = baseline_scores[:min_len]
            enhanced_scores = enhanced_scores[:min_len]
            
            test_results = {}
            
            # 1. 配对t检验
            try:
                t_stat, t_pvalue = ttest_rel(enhanced_scores, baseline_scores)
                test_results['paired_ttest'] = {
                    'statistic': t_stat,
                    'pvalue': t_pvalue,
                    'significant': t_pvalue < 0.05
                }
            except Exception as e:
                logger.warning(f"Error in paired t-test: {e}")
                test_results['paired_ttest'] = {'statistic': 0, 'pvalue': 1, 'significant': False}
            
            # 2. Wilcoxon符号秩检验
            try:
                w_stat, w_pvalue = wilcoxon(enhanced_scores, baseline_scores, alternative='greater')
                test_results['wilcoxon'] = {
                    'statistic': w_stat,
                    'pvalue': w_pvalue,
                    'significant': w_pvalue < 0.05
                }
            except Exception as e:
                logger.warning(f"Error in Wilcoxon test: {e}")
                test_results['wilcoxon'] = {'statistic': 0, 'pvalue': 1, 'significant': False}
            
            # 3. Mann-Whitney U检验
            try:
                u_stat, u_pvalue = mannwhitneyu(enhanced_scores, baseline_scores, alternative='greater')
                test_results['mannwhitney'] = {
                    'statistic': u_stat,
                    'pvalue': u_pvalue,
                    'significant': u_pvalue < 0.05
                }
            except Exception as e:
                logger.warning(f"Error in Mann-Whitney test: {e}")
                test_results['mannwhitney'] = {'statistic': 0, 'pvalue': 1, 'significant': False}
            
            # 4. 效应量计算
            effect_sizes = self.calculate_effect_size(enhanced_scores, baseline_scores)
            test_results['effect_sizes'] = effect_sizes
            
            # 5. 置信区间
            diff_scores = enhanced_scores - baseline_scores
            ci_lower, ci_upper = self.calculate_confidence_interval(diff_scores)
            test_results['confidence_interval'] = {
                'lower': ci_lower,
                'upper': ci_upper,
                'mean_difference': np.mean(diff_scores)
            }
            
            # 6. 相关性分析
            try:
                pearson_r, pearson_p = pearsonr(baseline_scores, enhanced_scores)
                spearman_r, spearman_p = spearmanr(baseline_scores, enhanced_scores)
                
                test_results['correlation'] = {
                    'pearson': {'r': pearson_r, 'pvalue': pearson_p},
                    'spearman': {'r': spearman_r, 'pvalue': spearman_p}
                }
            except Exception as e:
                logger.warning(f"Error in correlation analysis: {e}")
                test_results['correlation'] = {
                    'pearson': {'r': 0, 'pvalue': 1},
                    'spearman': {'r': 0, 'pvalue': 1}
                }
            
            return test_results
            
        except Exception as e:
            logger.error(f"Error in statistical tests: {e}")
            return {}
    
    def run_robust_evaluation(self, X: pd.DataFrame, y: pd.Series, dataset_name: str, 
                            window_size: str, n_repeats: int = 20) -> dict:
        """运行稳健评估."""
        try:
            if X.empty or len(X) < 10:
                return {}
            
            # 多种模型
            models = {
                'Ridge': Ridge(alpha=1.0),
                'RandomForest': RandomForestRegressor(n_estimators=50, random_state=42),
                'GradientBoosting': GradientBoostingRegressor(n_estimators=50, random_state=42)
            }
            
            all_results = {}
            
            for model_name, model in models.items():
                baseline_scores = []
                enhanced_scores = []
                
                for repeat in range(n_repeats):
                    try:
                        # 数据分割
                        X_train, X_test, y_train, y_test = train_test_split(
                            X, y, test_size=0.3, random_state=repeat
                        )
                        
                        # 标准化
                        scaler = StandardScaler()
                        X_train_scaled = scaler.fit_transform(X_train)
                        X_test_scaled = scaler.transform(X_test)
                        
                        # 基准模型（原始特征）
                        model_baseline = model.__class__(**model.get_params())
                        model_baseline.fit(X_train_scaled, y_train)
                        y_pred_baseline = model_baseline.predict(X_test_scaled)
                        baseline_r2 = r2_score(y_test, y_pred_baseline)
                        baseline_scores.append(baseline_r2)
                        
                        # 增强模型（使用PCA降维）
                        if X_train_scaled.shape[1] > 5:
                            pca = PCA(n_components=min(10, X_train_scaled.shape[1]//2))
                            X_train_pca = pca.fit_transform(X_train_scaled)
                            X_test_pca = pca.transform(X_test_scaled)
                            
                            model_enhanced = model.__class__(**model.get_params())
                            model_enhanced.fit(X_train_pca, y_train)
                            y_pred_enhanced = model_enhanced.predict(X_test_pca)
                            enhanced_r2 = r2_score(y_test, y_pred_enhanced)
                            enhanced_scores.append(enhanced_r2)
                        else:
                            enhanced_scores.append(baseline_r2)
                        
                    except Exception as e:
                        logger.warning(f"Error in repeat {repeat} for {model_name}: {e}")
                        continue
                
                if baseline_scores and enhanced_scores:
                    # 统计检验
                    statistical_tests = self.run_statistical_tests(
                        np.array(baseline_scores), np.array(enhanced_scores)
                    )
                    
                    all_results[model_name] = {
                        'baseline_scores': baseline_scores,
                        'enhanced_scores': enhanced_scores,
                        'baseline_mean': np.mean(baseline_scores),
                        'enhanced_mean': np.mean(enhanced_scores),
                        'improvement': (np.mean(enhanced_scores) - np.mean(baseline_scores)) / np.mean(baseline_scores) * 100 if np.mean(baseline_scores) != 0 else 0,
                        'statistical_tests': statistical_tests
                    }
            
            return all_results
            
        except Exception as e:
            logger.error(f"Error in robust evaluation: {e}")
            return {}
    
    def run_comprehensive_statistical_analysis(self) -> dict:
        """运行全面的统计分析."""
        try:
            logger.info("Starting comprehensive statistical analysis")
            
            datasets = ['DRIVE_DB', 'CRWD', 'SWELL', 'WESAD']
            window_sizes = ['60s', '300s']
            
            all_analyses = []
            
            for dataset in datasets:
                for window_size in window_sizes:
                    logger.info(f"Analyzing {dataset}_{window_size}")
                    
                    # 加载数据
                    df = self.load_dataset_data(dataset, window_size)
                    if df.empty:
                        continue
                    
                    # 创建增强特征
                    df_enhanced = self.create_enhanced_features(df)
                    
                    # 准备特征
                    numeric_cols = df_enhanced.select_dtypes(include=[np.number]).columns.tolist()
                    if len(numeric_cols) < 2:
                        continue
                    
                    X = df_enhanced[numeric_cols[:-1]].fillna(0)
                    y = df_enhanced[numeric_cols[-1]].fillna(0)
                    
                    if len(X) < 10:
                        continue
                    
                    # 稳健评估
                    evaluation_results = self.run_robust_evaluation(X, y, dataset, window_size)
                    
                    if evaluation_results:
                        analysis = {
                            'dataset': f"{dataset}_{window_size}",
                            'n_samples': len(X),
                            'n_features': X.shape[1],
                            'evaluation_results': evaluation_results
                        }
                        all_analyses.append(analysis)
            
            # 综合分析
            comprehensive_analysis = self._analyze_statistical_results(all_analyses)
            comprehensive_analysis['total_datasets'] = len(all_analyses)
            comprehensive_analysis['all_analyses'] = all_analyses
            
            logger.info(f"Comprehensive statistical analysis completed: {len(all_analyses)} datasets analyzed")
            
            return comprehensive_analysis
            
        except Exception as e:
            logger.error(f"Error in comprehensive statistical analysis: {e}")
            return {}
    
    def _analyze_statistical_results(self, analyses: list) -> dict:
        """分析统计结果."""
        try:
            if not analyses:
                return {}
            
            # 提取所有模型的统计结果
            model_statistics = {}
            
            for analysis in analyses:
                evaluation_results = analysis.get('evaluation_results', {})
                
                for model_name, results in evaluation_results.items():
                    if model_name not in model_statistics:
                        model_statistics[model_name] = {
                            'improvements': [],
                            'pvalues': [],
                            'effect_sizes': [],
                            'significant_tests': 0,
                            'total_tests': 0
                        }
                    
                    # 改善率
                    improvement = results.get('improvement', 0)
                    model_statistics[model_name]['improvements'].append(improvement)
                    
                    # 统计检验结果
                    statistical_tests = results.get('statistical_tests', {})
                    if 'paired_ttest' in statistical_tests:
                        pvalue = statistical_tests['paired_ttest']['pvalue']
                        model_statistics[model_name]['pvalues'].append(pvalue)
                        model_statistics[model_name]['total_tests'] += 1
                        if pvalue < 0.05:
                            model_statistics[model_name]['significant_tests'] += 1
                    
                    # 效应量
                    if 'effect_sizes' in statistical_tests:
                        cohens_d = statistical_tests['effect_sizes'].get('cohens_d', 0)
                        model_statistics[model_name]['effect_sizes'].append(cohens_d)
            
            # 计算汇总统计
            summary_statistics = {}
            for model_name, stats in model_statistics.items():
                summary_statistics[model_name] = {
                    'avg_improvement': np.mean(stats['improvements']),
                    'std_improvement': np.std(stats['improvements']),
                    'median_improvement': np.median(stats['improvements']),
                    'avg_effect_size': np.mean(stats['effect_sizes']),
                    'median_effect_size': np.median(stats['effect_sizes']),
                    'significance_rate': stats['significant_tests'] / stats['total_tests'] * 100 if stats['total_tests'] > 0 else 0,
                    'avg_pvalue': np.mean(stats['pvalues']),
                    'median_pvalue': np.median(stats['pvalues'])
                }
            
            # 整体分析
            overall_analysis = {
                'model_statistics': summary_statistics,
                'best_model': max(summary_statistics.keys(), key=lambda x: summary_statistics[x]['avg_improvement']) if summary_statistics else None,
                'most_significant_model': max(summary_statistics.keys(), key=lambda x: summary_statistics[x]['significance_rate']) if summary_statistics else None,
                'largest_effect_model': max(summary_statistics.keys(), key=lambda x: summary_statistics[x]['avg_effect_size']) if summary_statistics else None,
                'overall_significance_rate': np.mean([stats['significance_rate'] for stats in summary_statistics.values()]) if summary_statistics else 0,
                'overall_avg_improvement': np.mean([stats['avg_improvement'] for stats in summary_statistics.values()]) if summary_statistics else 0,
                'overall_avg_effect_size': np.mean([stats['avg_effect_size'] for stats in summary_statistics.values()]) if summary_statistics else 0
            }
            
            return overall_analysis
            
        except Exception as e:
            logger.error(f"Error analyzing statistical results: {e}")
            return {}
    
    def generate_statistical_analysis_report(self, analysis_results: dict) -> str:
        """生成统计分析报告."""
        try:
            if not analysis_results:
                return "No analysis results available."
            
            total_datasets = analysis_results.get('total_datasets', 0)
            overall_significance_rate = analysis_results.get('overall_significance_rate', 0)
            overall_avg_improvement = analysis_results.get('overall_avg_improvement', 0)
            overall_avg_effect_size = analysis_results.get('overall_avg_effect_size', 0)
            best_model = analysis_results.get('best_model', 'N/A')
            most_significant_model = analysis_results.get('most_significant_model', 'N/A')
            
            if overall_significance_rate > 80 and overall_avg_improvement > 10:
                status = "✅ 统计显著性优秀"
                conclusion = "统计分析显示模型改善具有高度统计显著性，效果显著。"
            elif overall_significance_rate > 60 and overall_avg_improvement > 5:
                status = "⚠️ 统计显著性良好"
                conclusion = "统计分析显示模型改善具有良好的统计显著性。"
            elif overall_significance_rate > 40 and overall_avg_improvement > 0:
                status = "⚠️ 统计显著性一般"
                conclusion = "统计分析显示模型改善具有一定的统计显著性。"
            else:
                status = "❌ 统计显著性不足"
                conclusion = "统计分析显示模型改善缺乏统计显著性。"
            
            report = f"""
# Step 6: 统计分析深化 - 科学审计报告

## 分析目标
增加置信区间、效应量、显著性检验，提供更严格的统计分析，确保结果的科学性和可靠性。

## 统计方法
1. **置信区间计算**: 使用t分布计算95%置信区间
2. **效应量分析**: Cohen's d、Hedges' g、Glass's delta
3. **显著性检验**: 配对t检验、Wilcoxon检验、Mann-Whitney检验
4. **稳健评估**: 20次重复实验，多种模型验证

## 实验结果

### 总体统计
- **测试数据集数**: {total_datasets}
- **整体显著性率**: {overall_significance_rate:.2f}%
- **平均性能改善**: {overall_avg_improvement:.4f}%
- **平均效应量**: {overall_avg_effect_size:.4f}
- **最佳模型**: {best_model}
- **最显著模型**: {most_significant_model}

### 模型统计分析
"""
            
            # 添加模型统计分析
            model_statistics = analysis_results.get('model_statistics', {})
            for model_name, stats in model_statistics.items():
                report += f"""
#### {model_name}
- **平均改善**: {stats.get('avg_improvement', 0):.4f}% ± {stats.get('std_improvement', 0):.4f}%
- **中位数改善**: {stats.get('median_improvement', 0):.4f}%
- **平均效应量**: {stats.get('avg_effect_size', 0):.4f}
- **显著性率**: {stats.get('significance_rate', 0):.2f}%
- **平均p值**: {stats.get('avg_pvalue', 1):.4f}
- **中位数p值**: {stats.get('median_pvalue', 1):.4f}
"""
            
            report += f"""
## 统计检验结果

### 检验方法
1. **配对t检验**: 检验增强模型与基准模型的性能差异
2. **Wilcoxon符号秩检验**: 非参数配对检验
3. **Mann-Whitney U检验**: 非参数独立样本检验
4. **效应量分析**: 量化改善的实际意义

### 关键发现
1. **统计显著性**: {overall_significance_rate:.2f}%的测试显示统计显著改善
2. **平均改善**: 模型平均改善{overall_avg_improvement:.4f}%
3. **效应量**: 平均效应量为{overall_avg_effect_size:.4f}
4. **最佳模型**: {best_model}表现最佳

### 技术亮点
- **多重复验证**: 每个数据集进行20次重复实验
- **多模型比较**: 使用3种不同的机器学习模型
- **严格统计检验**: 配对t检验、非参数检验、效应量分析
- **置信区间**: 提供95%置信区间评估结果可靠性

## 自审结论

### 统计显著性状态
{status}

### 最终评估
{conclusion}

## 文件记录
- **分析结果**: `step6_statistical_analysis_enhancement_results.json`
- **详细报告**: `step6_statistical_analysis_enhancement_report.md`
- **日志文件**: `step6_statistical_analysis_enhancement.log`
- **执行时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""
            
            return report
            
        except Exception as e:
            logger.error(f"Error generating statistical analysis report: {e}")
            return f"Error generating report: {e}"
    
    def save_results(self, analysis_results: dict, report: str):
        """保存结果."""
        try:
            # 创建输出目录
            output_dir = Path("reports/scientific_audit/step6_statistical_analysis_enhancement")
            output_dir.mkdir(parents=True, exist_ok=True)
            
            # 保存JSON结果
            results_file = output_dir / "step6_statistical_analysis_enhancement_results.json"
            with open(results_file, 'w', encoding='utf-8') as f:
                json.dump(analysis_results, f, indent=2, ensure_ascii=False, default=str)
            
            # 保存报告
            report_file = output_dir / "step6_statistical_analysis_enhancement_report.md"
            with open(report_file, 'w', encoding='utf-8') as f:
                f.write(report)
            
            logger.info(f"Statistical analysis results saved to {output_dir}")
            
        except Exception as e:
            logger.error(f"Error saving statistical analysis results: {e}")

def main():
    """主函数."""
    try:
        logger.info("Starting Step 6: Statistical Analysis Enhancement")
        
        # 初始化统计分析深化器
        statistical_analyzer = StatisticalAnalysisEnhancement()
        
        # 运行全面的统计分析
        analysis_results = statistical_analyzer.run_comprehensive_statistical_analysis()
        
        if not analysis_results:
            logger.error("Failed to complete statistical analysis")
            return
        
        # 生成报告
        report = statistical_analyzer.generate_statistical_analysis_report(analysis_results)
        
        # 保存结果
        statistical_analyzer.save_results(analysis_results, report)
        
        # 输出关键结果
        logger.info("=== STATISTICAL ANALYSIS ENHANCEMENT RESULTS ===")
        logger.info(f"Total datasets: {analysis_results.get('total_datasets', 0)}")
        logger.info(f"Overall significance rate: {analysis_results.get('overall_significance_rate', 0):.2f}%")
        logger.info(f"Overall average improvement: {analysis_results.get('overall_avg_improvement', 0):.4f}%")
        logger.info(f"Overall average effect size: {analysis_results.get('overall_avg_effect_size', 0):.4f}")
        logger.info(f"Best model: {analysis_results.get('best_model', 'N/A')}")
        
        logger.info("Step 6: Statistical Analysis Enhancement completed successfully!")
        
    except Exception as e:
        logger.error(f"Error in main execution: {e}")
        raise

if __name__ == "__main__":
    main()

