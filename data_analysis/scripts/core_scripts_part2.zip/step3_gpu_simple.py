#!/usr/bin/env python3
"""
Step 3 GPU简化验证脚本
专门处理数据质量问题，使用GPU加速
"""

import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.model_selection import RepeatedKFold
from sklearn.preprocessing import RobustScaler
from sklearn.metrics import r2_score
from sklearn.impute import SimpleImputer
import warnings
warnings.filterwarnings("ignore")

# GPU配置
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"使用设备: {DEVICE}")

# 简化的GPU神经网络
class SimpleGPURegressor(nn.Module):
    def __init__(self, input_size):
        super(SimpleGPURegressor, self).__init__()
        self.network = nn.Sequential(
            nn.Linear(input_size, 64),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Linear(32, 1)
        )
    
    def forward(self, x):
        return self.network(x).squeeze()

def train_simple_gpu_model(X_train, y_train, X_val, y_val, epochs=20):
    """简化的GPU模型训练"""
    model = SimpleGPURegressor(X_train.shape[1])
    model.to(DEVICE)
    
    # 数据转换
    train_dataset = TensorDataset(torch.FloatTensor(X_train), torch.FloatTensor(y_train))
    val_dataset = TensorDataset(torch.FloatTensor(X_val), torch.FloatTensor(y_val))
    train_loader = DataLoader(train_dataset, batch_size=256, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=256, shuffle=False)
    
    # 训练
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    
    for epoch in range(epochs):
        # 训练
        model.train()
        train_loss = 0.0
        for batch_x, batch_y in train_loader:
            batch_x, batch_y = batch_x.to(DEVICE), batch_y.to(DEVICE)
            optimizer.zero_grad()
            outputs = model(batch_x)
            loss = criterion(outputs, batch_y)
            loss.backward()
            optimizer.step()
            train_loss += loss.item()
        
        # 验证
        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for batch_x, batch_y in val_loader:
                batch_x, batch_y = batch_x.to(DEVICE), batch_y.to(DEVICE)
                outputs = model(batch_x)
                loss = criterion(outputs, batch_y)
                val_loss += loss.item()
    
    # 预测
    model.eval()
    with torch.no_grad():
        val_tensor = torch.FloatTensor(X_val).to(DEVICE)
        predictions = model(val_tensor).cpu().numpy()
    
    return predictions

def clean_data_simple(df):
    """简化的数据清理"""
    # 删除全NaN列
    nan_cols = df.columns[df.isna().all()].tolist()
    if len(nan_cols) > 0:
        df = df.drop(columns=nan_cols)
    
    # 只保留数值列
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    df = df[numeric_cols]
    
    # 简单填充
    df = df.fillna(df.median())
    
    return df

print("=" * 60)
print("Step 3 GPU简化验证")
print("=" * 60)

# 加载数据
print("📂 加载数据...")
base = pd.read_csv("features_base.csv", nrows=10000)  # 使用1万行
extended = pd.read_csv("features_extended.csv", nrows=10000)
y = pd.read_csv("labels.csv", nrows=10000)['target']

print(f"  原始数据: Base{base.shape}, Extended{extended.shape}")

# 数据清理
print("\n🔧 数据清理...")
base_clean = clean_data_simple(base)
extended_clean = clean_data_simple(extended)

print(f"  清理后: Base{base_clean.shape}, Extended{extended_clean.shape}")

# 如果数据为空，退出
if base_clean.empty or extended_clean.empty:
    print("❌ 清理后数据为空，无法继续")
    exit(1)

# 标准化
scaler_base = RobustScaler()
scaler_ext = RobustScaler()

X_base = scaler_base.fit_transform(base_clean)
X_ext = scaler_ext.fit_transform(extended_clean)

print(f"  标准化后: Base{X_base.shape}, Extended{X_ext.shape}")

# 简化的交叉验证
print("\n🔬 GPU交叉验证...")
rkf = RepeatedKFold(n_splits=3, n_repeats=1, random_state=42)

base_scores = []
ext_scores = []

for fold, (train_idx, test_idx) in enumerate(rkf.split(X_base)):
    print(f"  折 {fold+1}/3...")
    
    X_base_train, X_base_test = X_base[train_idx], X_base[test_idx]
    X_ext_train, X_ext_test = X_ext[train_idx], X_ext[test_idx]
    y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]
    
    # GPU模型训练
    base_pred = train_simple_gpu_model(X_base_train, y_train, X_base_test, y_test)
    ext_pred = train_simple_gpu_model(X_ext_train, y_train, X_ext_test, y_test)
    
    # 计算R²
    base_r2 = r2_score(y_test, base_pred)
    ext_r2 = r2_score(y_test, ext_pred)
    
    base_scores.append(base_r2)
    ext_scores.append(ext_r2)
    
    print(f"    Base R²: {base_r2:.4f}, Extended R²: {ext_r2:.4f}")

# 结果分析
mean_base = np.mean(base_scores)
mean_ext = np.mean(ext_scores)
delta = mean_ext - mean_base
improvement = (delta / abs(mean_base + 1e-6)) * 100

print("\n" + "=" * 60)
print("📊 结果总结")
print("=" * 60)
print(f"Base模型平均R²: {mean_base:.4f}")
print(f"Extended模型平均R²: {mean_ext:.4f}")
print(f"绝对改善: {delta:.4f}")
print(f"相对改善: {improvement:.2f}%")
print(f"成功标准 (Δ > 0): {'✅ 通过' if delta > 0 else '❌ 失败'}")

# 保存结果
results = {
    "mean_base_r2": float(mean_base),
    "mean_ext_r2": float(mean_ext),
    "delta_abs": float(delta),
    "delta_pct": float(improvement),
    "success": delta > 0,
    "data_quality": {
        "base_original_cols": int(base.shape[1]),
        "base_clean_cols": int(base_clean.shape[1]),
        "ext_original_cols": int(extended.shape[1]),
        "ext_clean_cols": int(extended_clean.shape[1])
    }
}

import json
with open("step3_gpu_results.json", "w") as f:
    json.dump(results, f, indent=2)

print(f"\n📁 结果已保存到: step3_gpu_results.json")
print("=" * 60)

