#!/usr/bin/env python3
"""
Step 3 GPU详细进度验证脚本
每一步都有详细的时间统计和进度显示
"""

import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.model_selection import RepeatedKFold
from sklearn.preprocessing import RobustScaler
from sklearn.metrics import r2_score
from sklearn.impute import SimpleImputer
import time
import json
import warnings
warnings.filterwarnings("ignore")

# GPU配置
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"🚀 使用设备: {DEVICE}")
if torch.cuda.is_available():
    print(f"📊 GPU型号: {torch.cuda.get_device_name(0)}")
    print(f"💾 GPU内存: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB")

# 简化的GPU神经网络
class SimpleGPURegressor(nn.Module):
    def __init__(self, input_size):
        super(SimpleGPURegressor, self).__init__()
        self.network = nn.Sequential(
            nn.Linear(input_size, 64),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Linear(32, 1)
        )
    
    def forward(self, x):
        return self.network(x).squeeze()

def train_gpu_model_detailed(X_train, y_train, X_val, y_val, epochs=20):
    """详细的GPU模型训练"""
    print(f"    🤖 初始化GPU模型 (输入维度: {X_train.shape[1]})")
    model = SimpleGPURegressor(X_train.shape[1])
    model.to(DEVICE)
    
    # 数据转换
    print(f"    📦 准备数据加载器 (批次大小: 256)")
    train_dataset = TensorDataset(torch.FloatTensor(X_train), torch.FloatTensor(y_train.values))
    val_dataset = TensorDataset(torch.FloatTensor(X_val), torch.FloatTensor(y_val.values))
    train_loader = DataLoader(train_dataset, batch_size=256, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=256, shuffle=False)
    
    # 训练
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    
    print(f"    🔄 开始训练 ({epochs} 轮)")
    for epoch in range(epochs):
        epoch_start = time.time()
        
        # 训练
        model.train()
        train_loss = 0.0
        for batch_x, batch_y in train_loader:
            batch_x, batch_y = batch_x.to(DEVICE), batch_y.to(DEVICE)
            optimizer.zero_grad()
            outputs = model(batch_x)
            loss = criterion(outputs, batch_y)
            loss.backward()
            optimizer.step()
            train_loss += loss.item()
        
        # 验证
        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for batch_x, batch_y in val_loader:
                batch_x, batch_y = batch_x.to(DEVICE), batch_y.to(DEVICE)
                outputs = model(batch_x)
                loss = criterion(outputs, batch_y)
                val_loss += loss.item()
        
        epoch_time = time.time() - epoch_start
        if epoch % 5 == 0:
            print(f"      轮次 {epoch}: 训练损失={train_loss/len(train_loader):.4f}, 验证损失={val_loss/len(val_loader):.4f}, 耗时={epoch_time:.2f}s")
    
    # 预测
    print(f"    🔮 生成预测结果")
    model.eval()
    with torch.no_grad():
        val_tensor = torch.FloatTensor(X_val).to(DEVICE)
        predictions = model(val_tensor).cpu().numpy()
    
    return predictions

def clean_data_detailed(df, name="数据"):
    """详细的数据清理"""
    print(f"    🧹 清理{name} (原始形状: {df.shape})")
    
    # 删除全NaN列
    nan_cols = df.columns[df.isna().all()].tolist()
    if len(nan_cols) > 0:
        print(f"      ❌ 删除全NaN列: {len(nan_cols)}个 {nan_cols[:5]}{'...' if len(nan_cols) > 5 else ''}")
        df = df.drop(columns=nan_cols)
    
    # 只保留数值列
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    if len(numeric_cols) < df.shape[1]:
        dropped = len(df.columns) - len(numeric_cols)
        print(f"      ❌ 删除非数值列: {dropped}个")
        df = df[numeric_cols]
    
    # 简单填充
    print(f"      🔧 填充缺失值 (中位数策略)")
    df = df.fillna(df.median())
    
    print(f"      ✅ 清理完成 (最终形状: {df.shape})")
    return df

print("=" * 80)
print("🔬 Step 3 GPU详细进度验证")
print("=" * 80)

# ===== 数据加载 =====
print("\n📂 步骤1: 数据加载")
start_time = time.time()

print("  📥 读取Base特征...")
base = pd.read_csv("features_base.csv", nrows=50000)  # 使用5万行
base_time = time.time() - start_time
print(f"    ✅ Base加载完成: {base.shape}, 耗时: {base_time:.2f}s")

print("  📥 读取Extended特征...")
ext_start = time.time()
extended = pd.read_csv("features_extended.csv", nrows=50000)
ext_time = time.time() - ext_start
print(f"    ✅ Extended加载完成: {extended.shape}, 耗时: {ext_time:.2f}s")

print("  📥 读取标签...")
label_start = time.time()
y = pd.read_csv("labels.csv", nrows=50000)['target']
label_time = time.time() - label_start
print(f"    ✅ 标签加载完成: {len(y)}个, 耗时: {label_time:.2f}s")

total_load_time = time.time() - start_time
print(f"  🎯 数据加载总耗时: {total_load_time:.2f}s")

# ===== 数据清理 =====
print("\n🔧 步骤2: 数据清理")
clean_start = time.time()

base_clean = clean_data_detailed(base, "Base特征")
extended_clean = clean_data_detailed(extended, "Extended特征")

clean_time = time.time() - clean_start
print(f"  🎯 数据清理总耗时: {clean_time:.2f}s")

# 检查数据是否为空
if base_clean.empty or extended_clean.empty:
    print("❌ 清理后数据为空，无法继续")
    exit(1)

# ===== 标准化 =====
print("\n📊 步骤3: 数据标准化")
scale_start = time.time()

print("  🔄 标准化Base特征...")
scaler_base = RobustScaler()
X_base = scaler_base.fit_transform(base_clean)
print(f"    ✅ Base标准化完成: {X_base.shape}")

print("  🔄 标准化Extended特征...")
scaler_ext = RobustScaler()
X_ext = scaler_ext.fit_transform(extended_clean)
print(f"    ✅ Extended标准化完成: {X_ext.shape}")

scale_time = time.time() - scale_start
print(f"  🎯 标准化总耗时: {scale_time:.2f}s")

# ===== GPU交叉验证 =====
print("\n🔬 步骤4: GPU交叉验证")
cv_start = time.time()

rkf = RepeatedKFold(n_splits=3, n_repeats=1, random_state=42)
base_scores = []
ext_scores = []

for fold, (train_idx, test_idx) in enumerate(rkf.split(X_base)):
    fold_start = time.time()
    print(f"\n  📊 处理折 {fold+1}/3")
    print(f"    训练集: {len(train_idx)}个样本, 测试集: {len(test_idx)}个样本")
    
    # 数据分割
    X_base_train, X_base_test = X_base[train_idx], X_base[test_idx]
    X_ext_train, X_ext_test = X_ext[train_idx], X_ext[test_idx]
    y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]
    
    # Base模型
    print(f"    🎯 训练Base模型...")
    base_model_start = time.time()
    base_pred = train_gpu_model_detailed(X_base_train, y_train, X_base_test, y_test)
    base_model_time = time.time() - base_model_start
    base_r2 = r2_score(y_test, base_pred)
    base_scores.append(base_r2)
    print(f"      ✅ Base模型完成: R²={base_r2:.4f}, 耗时: {base_model_time:.2f}s")
    
    # Extended模型
    print(f"    🎯 训练Extended模型...")
    ext_model_start = time.time()
    ext_pred = train_gpu_model_detailed(X_ext_train, y_train, X_ext_test, y_test)
    ext_model_time = time.time() - ext_model_start
    ext_r2 = r2_score(y_test, ext_pred)
    ext_scores.append(ext_r2)
    print(f"      ✅ Extended模型完成: R²={ext_r2:.4f}, 耗时: {ext_model_time:.2f}s")
    
    fold_time = time.time() - fold_start
    print(f"    🎯 折{fold+1}总耗时: {fold_time:.2f}s")

cv_time = time.time() - cv_start
print(f"  🎯 交叉验证总耗时: {cv_time:.2f}s")

# ===== 结果分析 =====
print("\n📈 步骤5: 结果分析")
analysis_start = time.time()

mean_base = np.mean(base_scores)
mean_ext = np.mean(ext_scores)
delta = mean_ext - mean_base
improvement = (delta / abs(mean_base + 1e-6)) * 100

print(f"  📊 Base模型平均R²: {mean_base:.4f}")
print(f"  📊 Extended模型平均R²: {mean_ext:.4f}")
print(f"  📊 绝对改善: {delta:.4f}")
print(f"  📊 相对改善: {improvement:.2f}%")
print(f"  🎯 成功标准 (Δ > 0): {'✅ 通过' if delta > 0 else '❌ 失败'}")

analysis_time = time.time() - analysis_start

# ===== 保存结果 =====
print("\n💾 步骤6: 保存结果")
save_start = time.time()

results = {
    "mean_base_r2": float(mean_base),
    "mean_ext_r2": float(mean_ext),
    "delta_abs": float(delta),
    "delta_pct": float(improvement),
    "success": delta > 0,
    "timing": {
        "data_loading": float(total_load_time),
        "data_cleaning": float(clean_time),
        "scaling": float(scale_time),
        "cross_validation": float(cv_time),
        "analysis": float(analysis_time)
    },
    "data_quality": {
        "base_original_cols": int(base.shape[1]),
        "base_clean_cols": int(base_clean.shape[1]),
        "ext_original_cols": int(extended.shape[1]),
        "ext_clean_cols": int(extended_clean.shape[1])
    },
    "gpu_config": {
        "device": str(DEVICE),
        "cuda_available": torch.cuda.is_available()
    }
}

with open("step3_gpu_detailed_results.json", "w") as f:
    json.dump(results, f, indent=2)

save_time = time.time() - save_start
total_time = time.time() - start_time

print(f"  ✅ 结果保存完成, 耗时: {save_time:.2f}s")
print(f"  📁 保存到: step3_gpu_detailed_results.json")

print("\n" + "=" * 80)
print("🎉 Step 3 GPU详细验证完成!")
print("=" * 80)
print(f"⏱️  总耗时: {total_time:.2f}s")
print(f"📊 最终结果: {'✅ 成功' if delta > 0 else '❌ 失败'}")
print("=" * 80)
