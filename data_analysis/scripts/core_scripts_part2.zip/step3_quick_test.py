#!/usr/bin/env python3
"""
Step 3 快速测试脚本 - 诊断算法卡死问题
"""

import pandas as pd
import numpy as np
import time
from sklearn.model_selection import RepeatedKFold
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import RobustScaler
from sklearn.metrics import r2_score
from sklearn.impute import SimpleImputer

print("=" * 50)
print("Step 3 快速诊断测试")
print("=" * 50)

# 加载小样本数据
print("📂 加载测试数据...")
base = pd.read_csv("features_base.csv", nrows=1000)
extended = pd.read_csv("features_extended.csv", nrows=1000)
y = pd.read_csv("labels.csv", nrows=1000)['target']

print(f"  数据形状: Base{base.shape}, Extended{extended.shape}, Labels{len(y)}")

# 测试1: safe_impute性能
print("\n🧪 测试1: SafeImpute性能")
def safe_impute(df, strategy='median'):
    df = df.copy()
    nan_cols = df.columns[df.isna().all()].tolist()
    if len(nan_cols) > 0:
        print(f"    删除全NaN列: {len(nan_cols)}个")
        df = df.drop(columns=nan_cols)
    
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    if len(numeric_cols) < df.shape[1]:
        df = df[numeric_cols]
    
    if df.shape[1] == 0:
        return pd.DataFrame()
    
    start_time = time.time()
    imp = SimpleImputer(strategy=strategy)
    X_imputed = imp.fit_transform(df)
    end_time = time.time()
    
    print(f"    SafeImpute耗时: {end_time - start_time:.3f}秒")
    df_out = pd.DataFrame(X_imputed, columns=df.columns, index=df.index)
    return df_out

start_time = time.time()
base_processed = safe_impute(base)
extended_processed = safe_impute(extended)
end_time = time.time()
print(f"  总处理时间: {end_time - start_time:.3f}秒")

# 测试2: 交叉验证性能
print("\n🧪 测试2: 交叉验证性能")
rkf = RepeatedKFold(n_splits=3, n_repeats=1, random_state=42)
fold_count = 0

for train_idx, test_idx in rkf.split(base):
    fold_count += 1
    print(f"  处理折 {fold_count}...")
    
    start_time = time.time()
    
    Xb_tr, Xb_te = base.iloc[train_idx], base.iloc[test_idx]
    y_tr, y_te = y.iloc[train_idx], y.iloc[test_idx]
    
    # SafeImpute
    imp_time = time.time()
    Xb_tr = safe_impute(Xb_tr)
    Xb_te = safe_impute(Xb_te)
    imp_time = time.time() - imp_time
    
    if Xb_tr.empty or Xb_te.empty:
        print(f"    ⚠️ 数据为空，跳过")
        continue
    
    # 标准化
    scaler_time = time.time()
    scaler = RobustScaler().fit(Xb_tr)
    Xb_tr_s = scaler.transform(Xb_tr)
    Xb_te_s = scaler.transform(Xb_te)
    scaler_time = time.time() - scaler_time
    
    # 模型训练
    model_time = time.time()
    model = RandomForestRegressor(n_estimators=50, random_state=42, n_jobs=1)
    model.fit(Xb_tr_s, y_tr)
    y_pred = model.predict(Xb_te_s)
    model_time = time.time() - model_time
    
    total_time = time.time() - start_time
    
    print(f"    耗时: 总计{total_time:.3f}s (Impute{imp_time:.3f}s, Scale{scaler_time:.3f}s, Model{model_time:.3f}s)")
    print(f"    R²: {r2_score(y_te, y_pred):.4f}")

print("\n✅ 快速测试完成")
print("=" * 50)
