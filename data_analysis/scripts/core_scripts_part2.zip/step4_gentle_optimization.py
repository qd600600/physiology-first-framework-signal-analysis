#!/usr/bin/env python3
"""
Step 4: Extended模型温和优化 - 调整筛选策略
目标：Extended模型R²≥0.7，特征数20-25，GPU内存≥3GB
策略：温和的特征筛选 + 更好的特征工程
"""

import pandas as pd
import numpy as np
import torch
import json
import time
import sys
import math
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from sklearn.linear_model import Ridge
import warnings
warnings.filterwarnings("ignore")

# 尝试导入cuML和cupy
try:
    import cuml
    from cuml.linear_model import Ridge as cuRidge
    from cuml.metrics import r2_score as cu_r2_score
    import cupy as cp
    CUML_AVAILABLE = True
    print("✅ cuML + CuPy可用，将使用GPU原生模型")
except ImportError:
    CUML_AVAILABLE = False
    print("⚠️ cuML不可用，将使用PyTorch GPU模型")

def print_progress(message):
    """打印进度信息"""
    print(message)
    sys.stdout.flush()

print("=" * 70)
print("Step 4: Extended模型温和优化 - 调整筛选策略")
print("=" * 70)

# GPU检查
print_progress("🔍 GPU检查:")
print_progress(f"  CUDA可用: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print_progress(f"  GPU设备: {torch.cuda.get_device_name(0)}")
    print_progress(f"  GPU内存: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.1f} GB")
    device = torch.device('cuda')
    use_gpu = True
    torch.backends.cudnn.benchmark = True
    torch.backends.cuda.matmul.allow_tf32 = True
    torch.set_float32_matmul_precision('high')
    print_progress("  ✅ 启用CUDA优化 + TF32 + 高精度")
else:
    print_progress("  ⚠️ CUDA不可用，将使用CPU")
    device = torch.device('cpu')
    use_gpu = False

def stabilize_features_gentle(X_gpu, eps=1e-8, verbose=True):
    """温和的特征稳定化：只移除极端异常特征"""
    if verbose:
        print_progress("    🔧 温和特征稳定化...")
    
    # 计算方差
    variances = cp.var(X_gpu, axis=0)
    
    # 只移除极端异常的特征（更宽松的阈值）
    valid = (variances > eps) & (variances < 1e15)  # 更宽松的上限
    
    if verbose:
        print_progress(f"      📊 方差分布: min={float(cp.min(variances)):.2e}, max={float(cp.max(variances)):.2e}")
        print_progress(f"      📊 保留特征: {int(cp.sum(valid))}/{len(valid)} (删除 {len(valid)-int(cp.sum(valid))} 个)")
    
    # 移除极端异常特征
    X_gpu = X_gpu[:, valid]
    
    # 温和的标准化（使用RobustScaler逻辑）
    X_median = cp.median(X_gpu, axis=0)
    X_mad = cp.median(cp.abs(X_gpu - X_median), axis=0) + eps
    X_gpu = (X_gpu - X_median) / X_mad
    
    if verbose:
        print_progress("      ✅ 温和特征稳定化完成")
    
    return X_gpu, valid

def gentle_feature_selection(X_gpu, y_gpu, target_k=22, verbose=True):
    """温和的特征选择：保留更多特征"""
    if verbose:
        print_progress("  🎯 温和特征选择...")
    
    n_features = X_gpu.shape[1]
    
    # 第一步：只移除最差的20%特征
    if verbose:
        print_progress("    📊 第一步：移除最差20%特征...")
    
    # 计算特征与y的相关性
    corr_scores = cp.zeros(n_features)
    for i in range(n_features):
        xi = X_gpu[:, i]
        corr_scores[i] = cp.abs(cp.corrcoef(xi, y_gpu)[0, 1])
    
    # 保留前80%特征
    keep_ratio = 0.8
    keep_k = max(int(n_features * keep_ratio), target_k)
    corr_indices = cp.argsort(corr_scores)[-keep_k:]
    X_corr = X_gpu[:, corr_indices]
    
    if verbose:
        print_progress(f"    ✅ 相关性筛选: {n_features} -> {keep_k} 特征")
    
    # 第二步：如果特征数仍然太多，使用Ridge重要性
    if X_corr.shape[1] > target_k:
        if verbose:
            print_progress("    📊 第二步：Ridge重要性筛选...")
        
        # 使用Ridge回归计算特征重要性
        ridge = cuRidge(alpha=0.1, solver='svd', fit_intercept=True, normalize=True)  # 更小的正则化
        ridge.fit(X_corr, y_gpu)
        coeff_importance = cp.abs(ridge.coef_)
        
        # 选择最重要的特征
        ridge_indices = cp.argsort(coeff_importance)[-target_k:]
        X_final = X_corr[:, ridge_indices]
        
        if verbose:
            print_progress(f"    ✅ Ridge筛选: {keep_k} -> {target_k} 特征")
    else:
        X_final = X_corr
        if verbose:
            print_progress(f"    ✅ 直接保留: {keep_k} 特征")
    
    return X_final

def enhanced_feature_engineering(X, y, verbose=True):
    """增强的特征工程：生成更多有价值的特征"""
    if verbose:
        print_progress("  🚀 增强特征工程...")
    
    # 转换为GPU张量
    X_tensor = torch.tensor(X.values, device=device, dtype=torch.float32)
    y_tensor = torch.tensor(y.values, device=device, dtype=torch.float32)
    
    n_samples, n_features = X_tensor.shape
    
    if verbose:
        print_progress(f"    📊 GPU数据形状: {X_tensor.shape}")
        print_progress(f"    📊 GPU内存使用: {torch.cuda.memory_allocated() / 1024**3:.2f} GB")
    
    # 使用混合精度进行特征工程
    with torch.autocast(device_type='cuda', dtype=torch.float16):
        # 1. 基础变换
        if verbose:
            print_progress("    🔄 基础变换...")
        
        X_transformed = X_tensor.clone()
        
        # Log变换（更安全）
        X_log = torch.log1p(torch.clamp(X_tensor, min=0))
        X_transformed = torch.cat([X_transformed, X_log], dim=1)
        
        # 平方根变换
        X_sqrt = torch.sqrt(torch.clamp(X_tensor, min=0))
        X_transformed = torch.cat([X_transformed, X_sqrt], dim=1)
        
        # 平方变换
        X_square = X_tensor ** 2
        X_transformed = torch.cat([X_transformed, X_square], dim=1)
        
        if verbose:
            print_progress(f"    ✅ 基础变换完成: {n_features} -> {X_transformed.shape[1]} 特征")
        
        # 2. 统计特征
        if verbose:
            print_progress("    📊 统计特征...")
        
        # 滚动统计（简化版）
        window_size = min(1000, n_samples // 10)
        if window_size > 1:
            # 计算滚动均值
            X_rolling_mean = torch.zeros_like(X_tensor)
            for i in range(n_features):
                for j in range(0, n_samples, window_size):
                    end_idx = min(j + window_size, n_samples)
                    X_rolling_mean[j:end_idx, i] = X_tensor[j:end_idx, i].mean()
            
            X_transformed = torch.cat([X_transformed, X_rolling_mean], dim=1)
        
        if verbose:
            print_progress(f"    ✅ 统计特征完成: {X_transformed.shape[1]} 特征")
        
        # 3. 交互特征（更温和）
        if verbose:
            print_progress("    🔗 温和交互特征...")
        
        # 只选择前2个特征进行交互，减少计算量
        X_base = X_tensor[:, :2]
        n_base = X_base.shape[1]
        
        interaction_features = []
        for i in range(n_base):
            for j in range(i+1, n_base):
                # 乘积交互
                product = X_base[:, i] * X_base[:, j]
                interaction_features.append(product.unsqueeze(1))
        
        if interaction_features:
            X_interactions = torch.cat(interaction_features, dim=1)
            X_transformed = torch.cat([X_transformed, X_interactions], dim=1)
        
        if verbose:
            print_progress(f"    ✅ 交互特征完成: {X_transformed.shape[1]} 特征")
    
    # 同步GPU操作
    torch.cuda.synchronize()
    
    if verbose:
        print_progress(f"    📊 GPU内存使用: {torch.cuda.memory_allocated() / 1024**3:.2f} GB")
    
    return X_transformed

def gpu_model_training_gentle(X_train, X_test, y_train, y_test, alpha=1.0, verbose=True):
    """温和的GPU模型训练"""
    if verbose:
        print_progress("  🤖 GPU温和模型训练...")
    
    if CUML_AVAILABLE:
        # 使用cuML GPU原生模型
        if verbose:
            print_progress("    🚀 使用cuML GPU温和模型...")
        
        # 转换为CuPy数组，处理NaN值
        X_train_clean = np.nan_to_num(X_train, nan=0.0, posinf=0.0, neginf=0.0)
        X_test_clean = np.nan_to_num(X_test, nan=0.0, posinf=0.0, neginf=0.0)
        y_train_clean = np.nan_to_num(y_train, nan=0.0, posinf=0.0, neginf=0.0)
        y_test_clean = np.nan_to_num(y_test, nan=0.0, posinf=0.0, neginf=0.0)
        
        X_train_gpu = cp.asarray(X_train_clean)
        X_test_gpu = cp.asarray(X_test_clean)
        y_train_gpu = cp.asarray(y_train_clean)
        y_test_gpu = cp.asarray(y_test_clean)
        
        # 温和特征稳定化
        X_train_gpu, valid_features = stabilize_features_gentle(X_train_gpu, verbose=verbose)
        X_test_gpu, _ = stabilize_features_gentle(X_test_gpu, verbose=False)
        
        # 训练模型（使用温和正则化）
        model = cuRidge(alpha=alpha, solver='svd', fit_intercept=True, normalize=True)
        model.fit(X_train_gpu, y_train_gpu)
        y_pred_gpu = model.predict(X_test_gpu)
        
        # 计算R²
        ss_res = cp.sum((y_test_gpu - y_pred_gpu) ** 2)
        ss_tot = cp.sum((y_test_gpu - cp.mean(y_test_gpu)) ** 2)
        r2 = 1 - ss_res / ss_tot
        
        # 转换为numpy计算其他指标
        y_pred = cp.asnumpy(y_pred_gpu)
        mae = mean_absolute_error(y_test, y_pred)
        mse = mean_squared_error(y_test, y_pred)
        rmse = np.sqrt(mse)
        
    else:
        # 使用PyTorch GPU模型
        if verbose:
            print_progress("    🚀 使用PyTorch GPU模型...")
        
        # 转换为GPU张量，处理NaN值
        X_train_clean = np.nan_to_num(X_train, nan=0.0, posinf=0.0, neginf=0.0)
        X_test_clean = np.nan_to_num(X_test, nan=0.0, posinf=0.0, neginf=0.0)
        y_train_clean = np.nan_to_num(y_train, nan=0.0, posinf=0.0, neginf=0.0)
        y_test_clean = np.nan_to_num(y_test, nan=0.0, posinf=0.0, neginf=0.0)
        
        X_train_tensor = torch.tensor(X_train_clean, device=device, dtype=torch.float32)
        X_test_tensor = torch.tensor(X_test_clean, device=device, dtype=torch.float32)
        y_train_tensor = torch.tensor(y_train_clean, device=device, dtype=torch.float32)
        y_test_tensor = torch.tensor(y_test_clean, device=device, dtype=torch.float32)
        
        # 使用混合精度进行标准化
        with torch.autocast(device_type='cuda', dtype=torch.float16):
            X_train_mean = X_train_tensor.mean(dim=0, keepdim=True)
            X_train_std = X_train_tensor.std(dim=0, keepdim=True) + 1e-8
            X_train_scaled = (X_train_tensor - X_train_mean) / X_train_std
            X_test_scaled = (X_test_tensor - X_train_mean) / X_train_std
        
        # 转换回CPU进行sklearn训练
        X_train_scaled_cpu = X_train_scaled.cpu().numpy()
        X_test_scaled_cpu = X_test_scaled.cpu().numpy()
        
        # 训练模型
        from sklearn.ensemble import RandomForestRegressor
        model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
        model.fit(X_train_scaled_cpu, y_train_clean)
        y_pred = model.predict(X_test_scaled_cpu)
        
        # 计算指标
        r2 = r2_score(y_test_clean, y_pred)
        mae = mean_absolute_error(y_test_clean, y_pred)
        mse = mean_squared_error(y_test_clean, y_pred)
        rmse = np.sqrt(mse)
    
    if verbose:
        print_progress(f"    ✅ 模型训练完成: R² = {float(r2):.4f} (α={alpha})")
    
    return {
        'r2': float(r2),
        'mae': float(mae),
        'mse': float(mse),
        'rmse': float(rmse),
        'y_pred': y_pred.tolist() if hasattr(y_pred, 'tolist') else y_pred,
        'alpha': alpha
    }

# ======= Step 1: 数据读取 =======
print_progress("\n📂 Step 1: 数据读取")
start_time = time.time()

print_progress("  📥 正在读取features_base.csv...")
base = pd.read_csv("features_base.csv")
print_progress(f"    ✅ Base特征加载完成: {base.shape}")

print_progress("  📥 正在读取features_extended.csv...")
extended = pd.read_csv("features_extended.csv")
print_progress(f"    ✅ Extended特征加载完成: {extended.shape}")

print_progress("  📥 正在读取labels.csv...")
y = pd.read_csv("labels.csv")["target"]
print_progress(f"    ✅ 标签加载完成: {len(y)} 个样本")

print_progress(f"  ⏱️ 数据加载耗时: {time.time() - start_time:.2f}秒")

# ======= Step 2: 数据预处理 =======
print_progress("\n🔧 Step 2: 数据预处理")
preprocess_start = time.time()

# 移除高缺失值列
print_progress("  🧹 移除高缺失值列...")
missing_ratio = extended.isna().sum() / len(extended)
high_missing_cols = missing_ratio[missing_ratio > 0.5].index.tolist()
extended_clean = extended.drop(columns=high_missing_cols)
extended_imputed = extended_clean.fillna(0)

print_progress(f"    📊 移除列数: {extended.shape[1]} -> {extended_clean.shape[1]}")

print_progress(f"  ⏱️ 预处理耗时: {time.time() - preprocess_start:.2f}秒")

# ======= Step 3: 增强特征工程 =======
print_progress("\n🚀 Step 3: 增强特征工程")
engineering_start = time.time()

# 增强特征工程
X_enhanced_tensor = enhanced_feature_engineering(extended_imputed, y, verbose=True)

print_progress(f"  ⏱️ 增强特征工程耗时: {time.time() - engineering_start:.2f}秒")

# ======= Step 4: 温和优化 =======
print_progress("\n🎯 Step 4: 温和优化")
optimization_start = time.time()

# 转换为CuPy进行优化
X_enhanced_gpu = cp.asarray(X_enhanced_tensor.cpu().numpy())
y_gpu = cp.asarray(y.values)

# 温和特征选择
X_optimized_gpu = gentle_feature_selection(X_enhanced_gpu, y_gpu, target_k=22, verbose=True)

# 转换回pandas
X_optimized = pd.DataFrame(
    cp.asnumpy(X_optimized_gpu),
    columns=[f'gentle_feature_{i}' for i in range(X_optimized_gpu.shape[1])]
)

print_progress(f"  ⏱️ 温和优化耗时: {time.time() - optimization_start:.2f}秒")

# ======= Step 5: 温和模型训练 =======
print_progress("\n📊 Step 5: 温和模型训练")
evaluation_start = time.time()

# 数据划分
Xb_train, Xb_test, y_train, y_test = train_test_split(
    base, y, test_size=0.3, random_state=42)
Xe_train, Xe_test, _, _ = train_test_split(
    X_optimized, y, test_size=0.3, random_state=42)

# Base模型评估
print_progress("  🎯 Base模型评估...")
base_metrics = gpu_model_training_gentle(Xb_train.values, Xb_test.values, y_train, y_test, alpha=1.0, verbose=True)

# Extended模型评估（测试不同正则化强度）
print_progress("  🎯 Extended模型评估...")
alphas = [0.1, 0.5, 1.0, 2.0]
extended_results = {}

for alpha in alphas:
    print_progress(f"  🔧 测试正则化强度 α={alpha}...")
    result = gpu_model_training_gentle(Xe_train.values, Xe_test.values, y_train, y_test, alpha=alpha, verbose=False)
    extended_results[f'alpha_{alpha}'] = result

# 选择最佳结果
best_alpha = max(extended_results.keys(), key=lambda k: extended_results[k]['r2'])
extended_metrics = extended_results[best_alpha]

print_progress(f"  ✅ 最佳正则化强度: {best_alpha} (R² = {extended_metrics['r2']:.4f})")

print_progress(f"  ⏱️ 性能评估耗时: {time.time() - evaluation_start:.2f}秒")

# ======= Step 6: 结果保存 =======
print_progress("\n💾 Step 6: 结果保存")

results = {
    "step4_gentle_optimization": {
        "data_info": {
            "samples": len(y),
            "original_features": int(extended.shape[1]),
            "cleaned_features": int(extended_clean.shape[1]),
            "enhanced_features": int(X_enhanced_tensor.shape[1]),
            "optimized_features": int(X_optimized_gpu.shape[1])
        },
        "model_performance": {
            "base_model": base_metrics,
            "extended_model": extended_metrics,
            "all_alpha_results": extended_results,
            "improvement": {
                "r2_improvement": float(extended_metrics['r2'] - base_metrics['r2']),
                "r2_improvement_percent": float((extended_metrics['r2'] - base_metrics['r2']) / abs(base_metrics['r2']) * 100),
                "mae_improvement": float(base_metrics['mae'] - extended_metrics['mae']),
                "rmse_improvement": float(base_metrics['rmse'] - extended_metrics['rmse'])
            }
        },
        "performance_info": {
            "total_runtime_seconds": time.time() - start_time,
            "data_loading_time": time.time() - start_time - (time.time() - preprocess_start),
            "preprocessing_time": time.time() - preprocess_start - (time.time() - engineering_start),
            "engineering_time": time.time() - engineering_start - (time.time() - optimization_start),
            "optimization_time": time.time() - optimization_start - (time.time() - evaluation_start),
            "evaluation_time": time.time() - evaluation_start
        },
        "gpu_info": {
            "cuda_available": torch.cuda.is_available(),
            "cuml_available": CUML_AVAILABLE,
            "gpu_device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
            "gpu_memory_gb": torch.cuda.get_device_properties(0).total_memory / 1024**3 if torch.cuda.is_available() else None,
            "gpu_memory_used_gb": torch.cuda.memory_allocated() / 1024**3 if torch.cuda.is_available() else 0
        }
    }
}

print_progress("  💾 正在保存结果...")
with open("step4_gentle_optimization_results.json", "w") as f:
    json.dump(results, f, indent=4)

# ======= Step 7: 结果报告 =======
print_progress("\n📊 Step 7: 结果报告")
print("=" * 70)
print("Step 4: Extended模型温和优化结果")
print("=" * 70)
print(f"🔧 特征工程流程:")
print(f"  原始特征数: {extended.shape[1]}")
print(f"  清理后特征数: {extended_clean.shape[1]}")
print(f"  增强后特征数: {X_enhanced_tensor.shape[1]}")
print(f"  优化后特征数: {X_optimized_gpu.shape[1]}")
print(f"\n📈 模型性能对比:")
print(f"  Base模型 R²: {base_metrics['r2']:.4f}")
print(f"  Extended模型 R²: {extended_metrics['r2']:.4f} (α={extended_metrics['alpha']})")
print(f"  性能改善: {extended_metrics['r2'] - base_metrics['r2']:.4f} ({(extended_metrics['r2'] - base_metrics['r2']) / abs(base_metrics['r2']) * 100:.1f}%)")
print(f"  MAE改善: {base_metrics['mae'] - extended_metrics['mae']:.2f}")
print(f"  RMSE改善: {base_metrics['rmse'] - extended_metrics['rmse']:.2f}")
print(f"\n🔧 正则化测试结果:")
for alpha_key, result in extended_results.items():
    print(f"  {alpha_key}: R² = {result['r2']:.4f}")
print(f"\n⏱️ 性能信息:")
print(f"  总运行时间: {time.time() - start_time:.2f}秒")
print(f"  增强特征工程时间: {time.time() - engineering_start - (time.time() - optimization_start):.2f}秒")
print(f"  温和优化时间: {time.time() - optimization_start - (time.time() - evaluation_start):.2f}秒")
if torch.cuda.is_available():
    print(f"  GPU内存使用: {torch.cuda.memory_allocated() / 1024**3:.2f} GB")
print(f"\n✅ 结果文件:")
print(f"  step4_gentle_optimization_results.json - 温和优化结果")
print("=" * 70)

# 目标达成检查
target_r2 = 0.7
target_features = 20
target_gpu_memory = 3.0

print(f"\n🎯 目标达成检查:")
print(f"  R² ≥ {target_r2}: {'✅' if extended_metrics['r2'] >= target_r2 else '❌'} ({extended_metrics['r2']:.4f})")
print(f"  特征数 {target_features}-25: {'✅' if target_features <= X_optimized_gpu.shape[1] <= 25 else '❌'} ({X_optimized_gpu.shape[1]})")
print(f"  GPU内存 ≥ {target_gpu_memory}GB: {'✅' if torch.cuda.memory_allocated() / 1024**3 >= target_gpu_memory else '❌'} ({torch.cuda.memory_allocated() / 1024**3:.2f}GB)")

print("🎉 Step 4: Extended模型温和优化完成！")














