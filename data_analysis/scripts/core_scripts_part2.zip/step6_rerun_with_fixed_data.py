#!/usr/bin/env python3
"""
Step 6: 使用修复后的LRI数据重新进行单数据集验证建模
"""

import os
import sys
import logging
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from pathlib import Path
from datetime import datetime
from sklearn.model_selection import train_test_split, cross_val_score, KFold
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.svm import SVR
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from sklearn.preprocessing import StandardScaler
import joblib
from concurrent.futures import ThreadPoolExecutor, as_completed
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('step6_rerun_with_fixed_data.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class PyTorchRegressionModel(nn.Module):
    """PyTorch神经网络回归模型，支持GPU加速."""
    
    def __init__(self, input_size: int, hidden_sizes: list = [64, 32, 16], dropout_rate: float = 0.2):
        super(PyTorchRegressionModel, self).__init__()
        
        layers = []
        prev_size = input_size
        
        for hidden_size in hidden_sizes:
            layers.extend([
                nn.Linear(prev_size, hidden_size),
                nn.ReLU(),
                nn.Dropout(dropout_rate)
            ])
            prev_size = hidden_size
        
        # Output layer
        layers.append(nn.Linear(prev_size, 1))
        
        self.network = nn.Sequential(*layers)
    
    def forward(self, x):
        return self.network(x)

class DatasetValidator:
    """单数据集验证建模器 - 使用修复后的数据."""
    
    def __init__(self, device: str = 'auto', n_threads: int = 8):
        self.device = self._setup_device(device)
        self.n_threads = n_threads
        
        # 模型定义
        self.models = {
            'RandomForest': RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=1),
            'GradientBoosting': GradientBoostingRegressor(n_estimators=100, random_state=42),
            'LinearRegression': LinearRegression(),
            'Ridge': Ridge(alpha=1.0),
            'Lasso': Lasso(alpha=0.1),
            'SVR': SVR(kernel='rbf', C=1.0, gamma='scale'),
            'PyTorch_NN': None  # Will be initialized per dataset
        }
        
        logger.info(f"Initialized DatasetValidator on {self.device} with {n_threads} threads")
    
    def _setup_device(self, device: str) -> torch.device:
        """Setup computation device."""
        if device == 'auto':
            if torch.cuda.is_available():
                device = 'cuda'
                logger.info(f"CUDA available: {torch.cuda.get_device_name()}")
            else:
                device = 'cpu'
                logger.info("CUDA not available, using CPU")
        
        return torch.device(device)
    
    def load_fixed_lri_data(self, dataset_name: str, window_size: str) -> pd.DataFrame:
        """加载修复后的LRI数据."""
        try:
            file_path = f"/mnt/d/data_analysis/processed/lri_calculation/lri_{dataset_name}_{window_size}_fixed.csv"
            df = pd.read_csv(file_path)
            logger.info(f"Loaded fixed LRI data: {df.shape} from {file_path}")
            return df
        except Exception as e:
            logger.error(f"Error loading fixed LRI data for {dataset_name}_{window_size}: {e}")
            return pd.DataFrame()
    
    def prepare_features_and_target(self, df: pd.DataFrame) -> tuple:
        """准备特征和目标变量."""
        try:
            # 特征列（排除窗口元数据）
            exclude_cols = [
                'window_id', 'window_size_seconds', 'sample_count', 
                'start_time', 'end_time'
            ]
            
            # 目标变量选择：优先使用recovery_ratio，如果有变异性的话
            target_col = 'recovery_ratio'
            if target_col not in df.columns or df[target_col].nunique() <= 1:
                target_col = 'stress_intensity'  # 备用目标
                if target_col not in df.columns:
                    target_col = 'wt_mean'  # 最后备用
            
            feature_cols = [col for col in df.columns if col not in exclude_cols + [target_col]]
            
            X = df[feature_cols].values
            y = df[target_col].values
            
            logger.info(f"Features shape: {X.shape}, Target shape: {y.shape}")
            logger.info(f"Feature columns: {feature_cols}")
            logger.info(f"Target: {target_col}")
            logger.info(f"Target range: {y.min():.3f} to {y.max():.3f}, std: {y.std():.3f}")
            
            return X, y, feature_cols, target_col
            
        except Exception as e:
            logger.error(f"Error preparing features and target: {e}")
            return None, None, None, None
    
    def train_sklearn_model(self, model_name: str, X_train: np.ndarray, y_train: np.ndarray, 
                           X_val: np.ndarray, y_val: np.ndarray, feature_cols: list) -> dict:
        """训练scikit-learn模型."""
        try:
            model = self.models[model_name]
            
            # 训练模型
            model.fit(X_train, y_train)
            
            # 预测
            y_pred = model.predict(X_val)
            
            # 计算指标
            mse = mean_squared_error(y_val, y_pred)
            r2 = r2_score(y_val, y_pred)
            mae = mean_absolute_error(y_val, y_pred)
            
            # 特征重要性（如果可用）
            feature_importance = None
            if hasattr(model, 'feature_importances_'):
                feature_importance = dict(zip(feature_cols, model.feature_importances_))
            elif hasattr(model, 'coef_'):
                feature_importance = dict(zip(feature_cols, model.coef_))
            
            return {
                'model': model,
                'mse': mse,
                'r2': r2,
                'mae': mae,
                'feature_importance': feature_importance
            }
            
        except Exception as e:
            logger.error(f"Error training {model_name}: {e}")
            return {'error': str(e)}
    
    def validate_dataset(self, dataset_name: str, window_size: str) -> dict:
        """验证单个数据集."""
        try:
            logger.info(f"=== Validating {dataset_name} - {window_size}s windows (FIXED DATA) ===")
            
            # 加载修复后的数据
            df = self.load_fixed_lri_data(dataset_name, window_size)
            if df.empty:
                return {'error': 'Failed to load fixed data'}
            
            # 准备特征和目标
            X, y, feature_cols, target_col = self.prepare_features_and_target(df)
            if X is None:
                return {'error': 'Failed to prepare features'}
            
            # 数据分割
            X_train, X_val, y_train, y_val = train_test_split(
                X, y, test_size=0.2, random_state=42
            )
            
            logger.info(f"Training set: {X_train.shape}, Validation set: {X_val.shape}")
            
            results = {
                'dataset_name': dataset_name,
                'window_size': window_size,
                'data_shape': X.shape,
                'feature_cols': feature_cols,
                'target_col': target_col,
                'target_stats': {
                    'mean': float(y.mean()),
                    'std': float(y.std()),
                    'min': float(y.min()),
                    'max': float(y.max()),
                    'unique_values': int(len(np.unique(y)))
                },
                'models': {}
            }
            
            # 训练和评估所有模型
            for model_name in self.models.keys():
                if model_name == 'PyTorch_NN':
                    # 跳过PyTorch模型，专注于传统模型
                    continue
                
                logger.info(f"Training {model_name}...")
                
                try:
                    result = self.train_sklearn_model(
                        model_name, X_train, y_train, X_val, y_val, feature_cols
                    )
                    results['models'][model_name] = result
                    
                    if 'error' not in result:
                        logger.info(f"  {model_name}: R² = {result['r2']:.3f}, MSE = {result['mse']:.6f}")
                    else:
                        logger.warning(f"  {model_name}: Error - {result['error']}")
                        
                except Exception as e:
                    logger.error(f"Error training {model_name}: {e}")
                    results['models'][model_name] = {'error': str(e)}
            
            # 选择最佳模型
            valid_models = [(name, result.get('r2', -999)) for name, result in results['models'].items() 
                          if 'error' not in result and not np.isnan(result.get('r2', np.nan))]
            
            if valid_models:
                best_model = max(valid_models, key=lambda x: x[1])
                results['best_model'] = {
                    'name': best_model[0],
                    'r2': best_model[1]
                }
                logger.info(f"Best model: {best_model[0]} with R² = {best_model[1]:.3f}")
            else:
                results['best_model'] = {'name': 'None', 'r2': 0}
                logger.warning("No valid models found")
            
            logger.info(f"=== Completed {dataset_name} - {window_size}s (FIXED) ===")
            return results
            
        except Exception as e:
            logger.error(f"Error validating {dataset_name}_{window_size}: {e}")
            return {'error': str(e)}
    
    def save_results(self, results: dict, output_dir: str):
        """保存验证结果."""
        try:
            output_path = Path(output_dir)
            output_path.mkdir(exist_ok=True)
            
            dataset_name = results['dataset_name']
            window_size = results['window_size']
            
            # 保存模型性能摘要
            summary_file = output_path / f"validation_summary_{dataset_name}_{window_size}_FIXED.json"
            
            # 准备可序列化的结果
            serializable_results = {
                'dataset_name': dataset_name,
                'window_size': window_size,
                'data_shape': results.get('data_shape'),
                'feature_cols': results.get('feature_cols'),
                'target_col': results.get('target_col'),
                'target_stats': results.get('target_stats'),
                'models_performance': {},
                'best_model': results.get('best_model', {})
            }
            
            # 提取模型性能指标
            for model_name, model_result in results.get('models', {}).items():
                if 'error' not in model_result:
                    serializable_results['models_performance'][model_name] = {
                        'mse': model_result.get('mse'),
                        'r2': model_result.get('r2'),
                        'mae': model_result.get('mae'),
                        'feature_importance': model_result.get('feature_importance')
                    }
            
            # 保存JSON结果
            import json
            with open(summary_file, 'w') as f:
                json.dump(serializable_results, f, indent=2, default=str)
            
            logger.info(f"Saved FIXED validation results: {summary_file}")
            
        except Exception as e:
            logger.error(f"Error saving results: {e}")

def main():
    """主函数."""
    try:
        logger.info("Starting Step 6: Single Dataset Validation with FIXED Data")
        
        # 数据集和窗口大小配置
        datasets = ['CRWD', 'SWELL', 'WESAD', 'Nurses', 'MMASH', 
                   'Mental_Health_Pred', 'DRIVE_DB', 'Non_EEG']
        window_sizes = ['60s', '300s', '900s']
        
        output_dir = '/mnt/d/data_analysis/processed/single_dataset_validation_fixed'
        
        # 初始化验证器
        validator = DatasetValidator(device='auto', n_threads=8)
        
        # 逐个处理数据集
        all_results = {}
        
        for dataset_name in datasets:
            logger.info(f"\n{'='*50}")
            logger.info(f"Processing Dataset: {dataset_name} (FIXED)")
            logger.info(f"{'='*50}")
            
            dataset_results = {}
            
            for window_size in window_sizes:
                try:
                    result = validator.validate_dataset(dataset_name, window_size)
                    dataset_results[window_size] = result
                    
                    # 保存结果
                    validator.save_results(result, output_dir)
                    
                except Exception as e:
                    logger.error(f"Error processing {dataset_name}_{window_size}: {e}")
                    dataset_results[window_size] = {'error': str(e)}
            
            all_results[dataset_name] = dataset_results
        
        # 保存总体结果摘要
        summary_file = Path(output_dir) / "validation_summary_all_datasets_FIXED.json"
        import json
        with open(summary_file, 'w') as f:
            json.dump(all_results, f, indent=2, default=str)
        
        logger.info(f"\n{'='*50}")
        logger.info("Step 6 with FIXED Data Completed Successfully!")
        logger.info(f"{'='*50}")
        
        # 打印总体摘要
        for dataset_name, dataset_results in all_results.items():
            logger.info(f"\n{dataset_name} (FIXED):")
            for window_size, result in dataset_results.items():
                if 'error' not in result:
                    best_model = result.get('best_model', {})
                    target_stats = result.get('target_stats', {})
                    logger.info(f"  {window_size}: Best model = {best_model.get('name', 'N/A')}, R² = {best_model.get('r2', 0):.3f}")
                    logger.info(f"    Target: {result.get('target_col', 'N/A')}, Range: {target_stats.get('min', 0):.3f}-{target_stats.get('max', 0):.3f}, Std: {target_stats.get('std', 0):.3f}")
                else:
                    logger.warning(f"  {window_size}: Error - {result['error']}")
        
    except Exception as e:
        logger.error(f"Error in main execution: {e}")
        raise

if __name__ == "__main__":
    main()



