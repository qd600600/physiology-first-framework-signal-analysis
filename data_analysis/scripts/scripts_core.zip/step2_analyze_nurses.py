#!/usr/bin/env python3
"""
Step 2: Analyze Nurses Dataset
"""

import pandas as pd
import numpy as np
from pathlib import Path

def analyze_nurses_dataset():
    """Analyze Nurses dataset files."""
    print("Analyzing Nurses Dataset")
    print("="*60)
    
    # Nurses data path
    nurses_path = Path('processed/Nurses_extracted/nurses_data')
    
    if not nurses_path.exists():
        print(f"❌ Nurses path does not exist: {nurses_path}")
        return None
    
    results = {}
    
    # Find subject directories
    subject_dirs = [d for d in nurses_path.iterdir() if d.is_dir()]
    print(f"Found {len(subject_dirs)} subject directories")
    
    # Analyze first few subjects as sample
    sample_subjects = subject_dirs[:3]  # Analyze first 3 subjects
    
    for subject_dir in sample_subjects:
        subject_id = subject_dir.name
        print(f"\nAnalyzing: {subject_id}")
        print("-" * 40)
        
        subject_results = {}
        
        # Check extracted data
        extracted_path = subject_dir / 'extracted'
        if extracted_path.exists():
            # Find some session directories
            session_dirs = [d for d in extracted_path.iterdir() if d.is_dir()]
            print(f"  Found {len(session_dirs)} session directories")
            
            # Analyze first few sessions
            sample_sessions = session_dirs[:2]  # Analyze first 2 sessions
            
            for session_dir in sample_sessions:
                session_id = session_dir.name
                print(f"  Session: {session_id}")
                
                # Define expected sensor files
                sensor_files = {
                    'ACC.csv': 'acceleration_data',
                    'BVP.csv': 'bvp_data',
                    'EDA.csv': 'eda_data',
                    'HR.csv': 'hr_data',
                    'IBI.csv': 'ibi_data',
                    'TEMP.csv': 'temperature_data',
                    'tags.csv': 'tags_data'
                }
                
                session_results = {}
                
                for filename, file_type in sensor_files.items():
                    file_path = session_dir / filename
                    
                    if file_path.exists():
                        try:
                            # Check if file is empty first
                            if file_path.stat().st_size == 0:
                                print(f"    ⚠️ {filename}: Empty file")
                                session_results[filename] = {'error': 'Empty file'}
                                continue
                            
                            # Try to read with error handling
                            try:
                                df = pd.read_csv(file_path, header=None)
                                if df.empty:
                                    print(f"    ⚠️ {filename}: No data rows")
                                    session_results[filename] = {'error': 'No data rows'}
                                    continue
                            except pd.errors.EmptyDataError:
                                print(f"    ⚠️ {filename}: Empty data file")
                                session_results[filename] = {'error': 'Empty data file'}
                                continue
                            except Exception as read_error:
                                print(f"    ❌ {filename}: Error reading file: {read_error}")
                                session_results[filename] = {'error': f'Read error: {read_error}'}
                                continue
                            
                            print(f"    ✅ {filename}: {df.shape[0]} rows, {df.shape[1]} columns")
                            
                            # Assign column names based on sensor type and actual column count
                            if filename == 'ACC.csv':
                                if df.shape[1] == 3:
                                    df.columns = ['acc_x', 'acc_y', 'acc_z']
                                elif df.shape[1] == 4:
                                    df.columns = ['timestamp', 'acc_x', 'acc_y', 'acc_z']
                                else:
                                    df.columns = [f'col_{i}' for i in range(df.shape[1])]
                            elif filename == 'BVP.csv' and df.shape[1] == 1:
                                df.columns = ['bvp']
                            elif filename == 'EDA.csv' and df.shape[1] == 1:
                                df.columns = ['eda']
                            elif filename == 'HR.csv' and df.shape[1] == 1:
                                df.columns = ['hr']
                            elif filename == 'IBI.csv' and df.shape[1] == 2:
                                df.columns = ['timestamp', 'ibi']
                            elif filename == 'TEMP.csv' and df.shape[1] == 1:
                                df.columns = ['temp']
                            elif filename == 'tags.csv':
                                if df.shape[1] >= 2:
                                    df.columns = ['timestamp', 'tag'] + [f'col_{i}' for i in range(2, df.shape[1])]
                                else:
                                    df.columns = ['timestamp']
                            else:
                                # Generic column naming for unexpected shapes
                                df.columns = [f'col_{i}' for i in range(df.shape[1])]
                            
                            session_results[filename] = {
                                'shape': df.shape,
                                'columns': list(df.columns),
                                'sample_data': dict(df.iloc[0]) if len(df) > 0 else {}
                            }
                            
                        except Exception as e:
                            print(f"    ❌ Error reading {filename}: {e}")
                            session_results[filename] = {'error': str(e)}
                    else:
                        print(f"    ❌ {filename}: File not found")
                        session_results[filename] = {'error': 'File not found'}
                
                subject_results[session_id] = session_results
        else:
            print(f"  ❌ No extracted data found")
            subject_results['error'] = 'No extracted data'
        
        results[subject_id] = subject_results
    
    # Analyze theoretical parameters
    print(f"\n{'='*60}")
    print("THEORETICAL PARAMETER ANALYSIS")
    print(f"{'='*60}")
    
    theoretical_params = {
        'hrv_rmssd': ['rmssd', 'RMSSD', 'hrv_rmssd'],
        'hrv_sdnn': ['sdnn', 'SDNN', 'hrv_sdnn'],
        'hr_mean': ['hr', 'HR', 'heart_rate'],
        'eda': ['eda', 'EDA', 'gsr', 'GSR'],
        'ibi': ['ibi', 'IBI', 'rr_interval'],
        'temperature': ['temp', 'temperature', 'body_temp'],
        'acceleration': ['acc_x', 'acc_y', 'acc_z', 'acceleration'],
        'stress_label': ['stress', 'condition', 'state', 'tag']
    }
    
    # Check for theoretical parameters across all sessions
    found_params = {}
    sessions_analyzed = 0
    
    for subject_id, subject_data in results.items():
        if 'error' in subject_data:
            continue
        
        for session_id, session_data in subject_data.items():
            if 'error' in session_data:
                continue
            
            sessions_analyzed += 1
            
            for filename, file_data in session_data.items():
                if 'error' in file_data or 'columns' not in file_data:
                    continue
                
                # Check for theoretical parameters
                for param_name, aliases in theoretical_params.items():
                    found_columns = []
                    for col in file_data['columns']:
                        col_lower = str(col).lower()
                        for alias in aliases:
                            if alias.lower() in col_lower:
                                found_columns.append(col)
                    if found_columns:
                        if param_name not in found_params:
                            found_params[param_name] = []
                        found_params[param_name].extend(found_columns)
    
    print(f"Analyzed {sessions_analyzed} sessions across {len([k for k, v in results.items() if 'error' not in v])} subjects")
    print(f"Found {len(found_params)} theoretical parameters:")
    
    for param, columns in found_params.items():
        unique_columns = list(set(columns))
        print(f"  ✅ {param}: {unique_columns}")
    
    # Calculate theoretical relevance score
    high_priority_params = ['hrv_rmssd', 'hrv_sdnn', 'hr_mean', 'eda', 'ibi']
    relevance_score = len([p for p in high_priority_params if p in found_params])
    relevance_percentage = (relevance_score / len(high_priority_params)) * 100
    
    print(f"\n⭐ Theoretical relevance: {relevance_percentage:.1f}%")
    print(f"   High-priority parameters found: {[p for p in high_priority_params if p in found_params]}")
    
    # Summary
    print(f"\n{'='*60}")
    print("NURSES ANALYSIS SUMMARY")
    print(f"{'='*60}")
    
    successful_subjects = len([k for k, v in results.items() if 'error' not in v])
    total_sessions = sum(len([k for k, v in subject_data.items() if 'error' not in v]) for subject_data in results.values())
    
    print(f"✅ Analyzed {successful_subjects} subjects")
    print(f"✅ Analyzed {total_sessions} sessions")
    print(f"✅ Found {len(found_params)} theoretical parameters")
    print(f"✅ Theoretical relevance: {relevance_percentage:.1f}%")
    
    results['summary'] = {
        'subjects_analyzed': successful_subjects,
        'sessions_analyzed': total_sessions,
        'theoretical_params_found': found_params,
        'relevance_score': relevance_score,
        'relevance_percentage': relevance_percentage
    }
    
    return results

if __name__ == "__main__":
    results = analyze_nurses_dataset()
    
    if results:
        print(f"\n✅ Nurses analysis completed")
        print(f"Found {len(results['summary']['theoretical_params_found'])} theoretical parameters")
        print(f"Theoretical relevance: {results['summary']['relevance_percentage']:.1f}%")
    else:
        print(f"\n❌ Nurses analysis failed")
