#!/usr/bin/env python3
"""
Step 3 完整科学验证框架
严格按照用户提供的科学验证模板执行
输出: step3_diagnostics.json, step3_permutation_null.npy
"""

import pandas as pd
import numpy as np
import json
import warnings
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.feature_selection import f_classif
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
warnings.filterwarnings("ignore")

print("=" * 70)
print("Step 3 完整科学验证框架")
print("=" * 70)

# ======= Step 1: 数据读取 =======
print("📂 Step 1: 数据读取")
print("  正在读取 features_base.csv...")
base = pd.read_csv("features_base.csv")      # 原始10特征
print(f"  ✅ Base数据加载完成: {base.shape}")

print("  正在读取 features_extended.csv...")
extended = pd.read_csv("features_extended.csv")  # 扩展99特征
print(f"  ✅ Extended数据加载完成: {extended.shape}")

print("  正在读取 labels.csv...")
y = pd.read_csv("labels.csv")["target"]
print(f"  ✅ 标签数据加载完成: {len(y)} 个样本")

# 样本一致性检查
assert len(base) == len(extended) == len(y), "样本数量不一致"
print(f"  ✅ 数据加载完成: {len(y)} 个样本")
print(f"  ✅ Base特征: {base.shape[1]} 个")
print(f"  ✅ Extended特征: {extended.shape[1]} 个")

# ======= Step 2: 数据清理与方差筛选 =======
print("\n🔧 Step 2: 数据清理与方差筛选")

# 删除常数特征
var_threshold = 1e-8
extended = extended.loc[:, extended.var() > var_threshold]
print(f"  ✅ 方差筛选后Extended特征: {extended.shape[1]} 个")

# 检查异常值
if np.any(np.abs(extended.values) > 1e12):
    print("⚠️ 警告: 检测到异常数值，建议检查F-test输入")

# ======= Step 3: 特征选择一致性验证 =======
print("\n🔍 Step 3: 特征选择一致性验证")

# F-test，避免除0
F, p = f_classif(extended.fillna(0), y)
valid_mask = np.isfinite(F) & (F > 0)
selected_features = extended.columns[valid_mask]

extended_valid = extended[selected_features]
print(f"  ✅ 保留 {len(selected_features)} 个有效特征")

# ======= Step 4: 数据划分与标准化 =======
print("\n📊 Step 4: 数据划分与标准化")

Xb_train, Xb_test, y_train, y_test = train_test_split(
    base, y, test_size=0.3, random_state=42)

Xe_train, Xe_test, _, _ = train_test_split(
    extended_valid, y, test_size=0.3, random_state=42)

scaler = StandardScaler()
Xb_train = scaler.fit_transform(Xb_train)
Xb_test = scaler.transform(Xb_test)
Xe_train = scaler.fit_transform(Xe_train)
Xe_test = scaler.transform(Xe_test)

print(f"  ✅ 数据划分完成: 训练集{len(y_train)}个, 测试集{len(y_test)}个")

# ======= Step 5: 模型训练与评估 =======
print("\n🤖 Step 5: 模型训练与评估")

model = RandomForestRegressor(n_estimators=200, random_state=42)

# Base模型
print("  训练Base模型...")
model.fit(Xb_train, y_train)
y_pred_base = model.predict(Xb_test)
r2_base = r2_score(y_test, y_pred_base)

# Extended模型
print("  训练Extended模型...")
model.fit(Xe_train, y_train)
y_pred_ext = model.predict(Xe_test)
r2_ext = r2_score(y_test, y_pred_ext)

print(f"  ✅ Base模型R²: {r2_base:.4f}")
print(f"  ✅ Extended模型R²: {r2_ext:.4f}")

# ======= Step 6: 性能对比 =======
print("\n📈 Step 6: 性能对比")

improvement = (r2_ext - r2_base) / abs(r2_base + 1e-9) * 100
results = {
    "R2_base": r2_base,
    "R2_extended": r2_ext,
    "improvement(%)": improvement,
    "MAE_base": mean_absolute_error(y_test, y_pred_base),
    "MAE_extended": mean_absolute_error(y_test, y_pred_ext),
    "RMSE_base": np.sqrt(mean_squared_error(y_test, y_pred_base)),
    "RMSE_extended": np.sqrt(mean_squared_error(y_test, y_pred_ext))
}

# 保存结果
pd.DataFrame([results]).to_json("step3_verification_result.json", indent=4)
print("✅ 验证完成，结果写入 step3_verification_result.json")
print("\n📊 验证结果:")
for key, value in results.items():
    print(f"  {key}: {value:.4f}")

print("=" * 70)
