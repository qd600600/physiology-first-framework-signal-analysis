#!/usr/bin/env python3
"""
Step 2: 基于Step 4结果的参数选择
在W(t)生成完成后，基于实际数据质量进行参数选择
"""

import pandas as pd
import numpy as np
import json
from pathlib import Path
from datetime import datetime
from sklearn.preprocessing import StandardScaler
from statsmodels.stats.outliers_influence import variance_inflation_factor
import warnings
warnings.filterwarnings('ignore')

def calculate_vif_safe(X):
    """
    安全计算VIF，处理可能的数值问题
    """
    try:
        # 检查是否有足够的非零方差列
        non_zero_var_cols = X.columns[X.var() > 1e-10]
        if len(non_zero_var_cols) < 2:
            return pd.Series([1.0] * len(X.columns), index=X.columns)
        
        X_clean = X[non_zero_var_cols]
        
        # 标准化数据
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X_clean)
        X_scaled_df = pd.DataFrame(X_scaled, columns=X_clean.columns)
        
        # 计算VIF
        vif_data = []
        for i in range(len(X_clean.columns)):
            try:
                vif = variance_inflation_factor(X_scaled_df.values, i)
                vif_data.append(vif if not np.isnan(vif) and not np.isinf(vif) else 5.0)
            except:
                vif_data.append(5.0)
        
        # 创建完整的VIF序列
        full_vif = pd.Series([5.0] * len(X.columns), index=X.columns)
        full_vif[non_zero_var_cols] = vif_data
        
        return full_vif
    except:
        return pd.Series([5.0] * len(X.columns), index=X.columns)

def analyze_dataset_parameters(dataset_name):
    """
    分析单个数据集的参数
    """
    print(f"\n📊 分析数据集: {dataset_name}")
    
    # 查找W(t)数据文件
    wt_files = [
        f'processed/wt_generation/wt_timeseries_{dataset_name}.parquet',
        f'processed/wt_generation/wt_timeseries_{dataset_name}_complete.parquet',
        f'processed/wt_generation/wt_timeseries_{dataset_name}_full_sample.parquet'
    ]
    
    wt_file = None
    for file_path in wt_files:
        if Path(file_path).exists():
            wt_file = file_path
            break
    
    if not wt_file:
        print(f"  ❌ 未找到W(t)数据文件")
        return None
    
    try:
        # 加载W(t)数据
        df = pd.read_parquet(wt_file)
        print(f"  ✅ 加载W(t)数据: {df.shape[0]:,} 行, {df.shape[1]} 列")
        
        # 识别理论相关参数
        theoretical_params = {
            'priority_1_core_physiological': {
                'hrv_rmssd': ['rmssd', 'rmssd_rel_rr', 'sd1'],
                'hrv_sdnn': ['sdnn', 'sdrr', 'sd2'],
                'hr_mean': ['hr', 'heart_rate_bpm', 'hr_mean'],
                'ibi': ['ibi', 'rr', 'ibi_s', 'mean_rr', 'median_rr'],
                'eda': ['eda', 'gsr', 'foot', 'hand']
            },
            'priority_2_regulatory_variables': {
                'temperature': ['temp', 'temperature'],
                'acceleration': ['acc', 'activity', 'steps', 'vector_magnitude', 'ax', 'ay', 'az', 'acceleration'],
                'respiration': ['resp', 'respiration']
            },
            'priority_3_clinical_subjective': {
                'phq_9': ['phq_9', 'phq9', 'mood_rating'],
                'gad_7': ['gad_7', 'gad7'],
                'stress_label': ['condition', 'stress_level', 'mental_health_condition', 'stress_condition']
            }
        }
        
        # 分析每个列
        parameter_analysis = []
        
        for priority_level, params in theoretical_params.items():
            for param_name, aliases in params.items():
                # 查找匹配的列
                matching_cols = []
                for col in df.columns:
                    if any(alias.lower() in col.lower() for alias in aliases):
                        matching_cols.append(col)
                
                for col in matching_cols:
                    if col in ['theta', 'stress_input', 'W_t', 'record_name', 'timestamp', 'sampling_freq', 'subject', 'sensor_type']:
                        continue
                    
                    # 计算数据质量指标
                    nan_count = df[col].isna().sum()
                    nan_percentage = (nan_count / len(df)) * 100
                    
                    # 基本统计
                    if pd.api.types.is_numeric_dtype(df[col]):
                        mean_val = df[col].mean()
                        std_val = df[col].std()
                        min_val = df[col].min()
                        max_val = df[col].max()
                        zero_var = std_val < 1e-10
                    else:
                        mean_val = std_val = min_val = max_val = "N/A"
                        zero_var = False
                    
                    parameter_analysis.append({
                        'parameter_name': param_name,
                        'column_name': col,
                        'priority_level': priority_level,
                        'theoretical_weight': 1.0 if 'priority_1' in priority_level else 0.6 if 'priority_2' in priority_level else 0.3,
                        'data_type': str(df[col].dtype),
                        'nan_count': nan_count,
                        'nan_percentage': round(nan_percentage, 2),
                        'mean_value': mean_val if isinstance(mean_val, (int, float)) else "N/A",
                        'std_value': std_val if isinstance(std_val, (int, float)) else "N/A",
                        'min_value': min_val if isinstance(min_val, (int, float)) else "N/A",
                        'max_value': max_val if isinstance(max_val, (int, float)) else "N/A",
                        'zero_variance': zero_var,
                        'selection_reason': f"理论优先级匹配: {aliases}",
                        'recommended': "是" if nan_percentage < 20 and not zero_var else "否"
                    })
        
        if not parameter_analysis:
            print(f"  ⚠️ 未找到匹配的理论参数")
            return None
        
        # 计算VIF（仅对数值列）
        numeric_cols = [item['column_name'] for item in parameter_analysis 
                       if pd.api.types.is_numeric_dtype(df[item['column_name']]) and item['recommended'] == '是']
        
        if len(numeric_cols) > 1:
            print(f"  🔍 计算VIF for {len(numeric_cols)} 个参数...")
            try:
                X = df[numeric_cols].dropna()
                if len(X) > 0:
                    vif_scores = calculate_vif_safe(X)
                    
                    # 更新VIF信息
                    vif_dict = vif_scores.to_dict()
                    for item in parameter_analysis:
                        if item['column_name'] in vif_dict:
                            item['vif_score'] = round(vif_dict[item['column_name']], 2)
                            if item['vif_score'] >= 5:
                                item['recommended'] = "否 (VIF≥5)"
                        else:
                            item['vif_score'] = "N/A"
                else:
                    for item in parameter_analysis:
                        item['vif_score'] = "N/A"
            except Exception as e:
                print(f"    ⚠️ VIF计算失败: {e}")
                for item in parameter_analysis:
                    item['vif_score'] = "计算失败"
        else:
            for item in parameter_analysis:
                item['vif_score'] = "N/A"
        
        # 创建结果DataFrame
        result_df = pd.DataFrame(parameter_analysis)
        
        # 按理论权重和缺失率排序
        result_df = result_df.sort_values(['theoretical_weight', 'nan_percentage'], ascending=[False, True])
        
        print(f"  📊 分析了 {len(parameter_analysis)} 个参数")
        print(f"  🏆 推荐参数: {len(result_df[result_df['recommended'] == '是'])} 个")
        
        return result_df
        
    except Exception as e:
        print(f"  ❌ 分析失败: {e}")
        return None

def generate_post_step4_parameter_selection():
    """
    基于Step 4结果生成参数选择文件
    """
    print("基于Step 4结果的参数选择")
    print("="*60)
    
    # 数据集列表（基于实际有W(t)数据的）
    datasets = [
        'CRWD_complete',
        'SWELL_complete', 
        'WESAD_full_sample',
        'Nurses_full_sample',
        'MMASH',
        'Mental_Health_Pred',
        'DRIVE_DB_full_sample',
        'Non_EEG_full_sample'
    ]
    
    output_dir = Path('processed/parameter_selection')
    output_dir.mkdir(parents=True, exist_ok=True)
    
    all_results = {}
    
    for dataset_name in datasets:
        result_df = analyze_dataset_parameters(dataset_name)
        if result_df is not None:
            # 保存单个数据集的参数选择
            output_file = output_dir / f'selected_features_{dataset_name}.csv'
            result_df.to_csv(output_file, index=False)
            print(f"  💾 保存: {output_file}")
            
            all_results[dataset_name] = result_df
    
    # 生成汇总报告
    print(f"\n📋 生成汇总报告...")
    summary_data = []
    
    for dataset_name, result_df in all_results.items():
        total_params = len(result_df)
        recommended_params = len(result_df[result_df['recommended'] == '是'])
        
        summary_data.append({
            'dataset': dataset_name,
            'total_parameters': total_params,
            'recommended_parameters': recommended_params,
            'recommendation_rate': round((recommended_params / total_params) * 100, 1) if total_params > 0 else 0,
            'priority_1_params': len(result_df[result_df['priority_level'] == 'priority_1_core_physiological']),
            'priority_2_params': len(result_df[result_df['priority_level'] == 'priority_2_regulatory_variables']),
            'priority_3_params': len(result_df[result_df['priority_level'] == 'priority_3_clinical_subjective'])
        })
    
    summary_df = pd.DataFrame(summary_data)
    summary_file = output_dir / 'parameter_selection_summary.csv'
    summary_df.to_csv(summary_file, index=False)
    print(f"💾 保存汇总报告: {summary_file}")
    
    print(f"\n✅ 基于Step 4的参数选择完成!")
    print(f"📊 处理了 {len(all_results)} 个数据集")
    print(f"📁 输出目录: {output_dir}")

if __name__ == "__main__":
    generate_post_step4_parameter_selection()











