#!/usr/bin/env python3
"""
Step 3 优化科学验证框架
解决F-test在大数据集上的性能问题
使用分块计算和抽样策略
"""

import pandas as pd
import numpy as np
import torch
import json
import warnings
import time
from sklearn.model_selection import train_test_split, RepeatedKFold
from sklearn.preprocessing import StandardScaler, RobustScaler
from sklearn.feature_selection import f_regression, mutual_info_regression, SelectKBest
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from sklearn.inspection import permutation_importance
from sklearn.impute import SimpleImputer
from scipy import stats
warnings.filterwarnings("ignore")

# GPU检查
print("🔍 GPU检查:")
print(f"  CUDA可用: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print(f"  GPU设备: {torch.cuda.get_device_name(0)}")
    print(f"  GPU内存: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.1f} GB")
    device = torch.device('cuda')
    use_gpu = True
else:
    print("  ⚠️ CUDA不可用，将使用CPU")
    device = torch.device('cpu')
    use_gpu = False

print("=" * 70)
print("Step 3 优化科学验证框架")
print("=" * 70)

# ======= 优化函数定义 =======

def safe_impute(df, verbose=True):
    """
    安全imputation函数 - 处理全NaN列和非数值列
    """
    df = df.copy()
    original_shape = df.shape
    
    # 检查全NaN列
    nan_cols = df.columns[df.isna().all()].tolist()
    if len(nan_cols) > 0:
        if verbose:
            print(f"⚠️ 发现全NaN列，将删除: {nan_cols}")
        df = df.drop(columns=nan_cols)
    
    # 数值列筛选
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    if len(numeric_cols) < df.shape[1]:
        dropped_nonnum = list(set(df.columns) - set(numeric_cols))
        if verbose:
            print(f"⚠️ 非数值列被排除: {dropped_nonnum}")
        df = df[numeric_cols]
    
    # Impute
    imp = SimpleImputer(strategy='median')
    X_imputed = imp.fit_transform(df)
    df_out = pd.DataFrame(X_imputed, columns=df.columns, index=df.index)
    
    if verbose:
        print(f"  Imputation完成: {original_shape} -> {df_out.shape}")
    
    return df_out

def winsorize_data(df, lower=0.01, upper=0.99, verbose=True):
    """
    Winsorization - 处理极值
    """
    df_winsorized = df.copy()
    for col in df.columns:
        if df[col].dtype in ['float64', 'int64']:
            lower_bound = df[col].quantile(lower)
            upper_bound = df[col].quantile(upper)
            df_winsorized[col] = df[col].clip(lower=lower_bound, upper=upper_bound)
    
    if verbose:
        print(f"  Winsorization完成: 下界{lower}, 上界{upper}")
    
    return df_winsorized

def batched_f_regression(X, y, batch_size=1000000, verbose=True):
    """
    分块计算F-test - 解决大数据集内存问题
    """
    n_samples = X.shape[0]
    n_features = X.shape[1]
    
    if verbose:
        print(f"  🔄 分块F-test: {n_samples}样本, {n_features}特征, 批次大小{batch_size}")
    
    # 如果样本数小于批次大小，直接计算
    if n_samples <= batch_size:
        if verbose:
            print("  💻 样本数较小，直接计算F-test")
        return f_regression(X, y)
    
    # 分块计算
    f_values = np.zeros(n_features)
    p_values = np.zeros(n_features)
    n_batches = 0
    
    for i in range(0, n_samples, batch_size):
        end_idx = min(i + batch_size, n_samples)
        X_batch = X.iloc[i:end_idx] if isinstance(X, pd.DataFrame) else X[i:end_idx]
        y_batch = y.iloc[i:end_idx] if isinstance(y, pd.Series) else y[i:end_idx]
        
        try:
            f_batch, p_batch = f_regression(X_batch, y_batch)
            f_values += f_batch
            p_values += p_batch
            n_batches += 1
            
            if verbose and n_batches % 5 == 0:
                print(f"    处理批次 {n_batches}: {i}-{end_idx}")
                
        except Exception as e:
            if verbose:
                print(f"    ⚠️ 批次 {i}-{end_idx} 计算失败: {e}")
            continue
    
    # 平均化结果
    if n_batches > 0:
        f_values /= n_batches
        p_values /= n_batches
        if verbose:
            print(f"  ✅ 分块F-test完成: {n_batches}个批次")
    else:
        if verbose:
            print("  ⚠️ 所有批次计算失败，使用默认值")
        f_values = np.ones(n_features)
        p_values = np.ones(n_features)
    
    return f_values, p_values

def sampled_f_regression(X, y, sample_size=1000000, random_state=42, verbose=True):
    """
    抽样F-test - 快速近似计算
    """
    n_samples = X.shape[0]
    
    if n_samples <= sample_size:
        if verbose:
            print("  💻 样本数小于抽样大小，直接计算")
        return f_regression(X, y)
    
    if verbose:
        print(f"  🎯 抽样F-test: 从{n_samples}样本中抽取{sample_size}样本")
    
    # 随机抽样
    np.random.seed(random_state)
    subset_idx = np.random.choice(n_samples, size=sample_size, replace=False)
    
    X_sub = X.iloc[subset_idx] if isinstance(X, pd.DataFrame) else X[subset_idx]
    y_sub = y.iloc[subset_idx] if isinstance(y, pd.Series) else y[subset_idx]
    
    try:
        f_values, p_values = f_regression(X_sub, y_sub)
        if verbose:
            print(f"  ✅ 抽样F-test完成: 抽样比例 {sample_size/n_samples:.2%}")
        return f_values, p_values
    except Exception as e:
        if verbose:
            print(f"  ⚠️ 抽样F-test失败: {e}")
        return np.ones(X.shape[1]), np.ones(X.shape[1])

def robust_feature_selection(X, y, method='f_test', k=20, verbose=True):
    """
    稳健特征选择 - 支持多种方法
    """
    if verbose:
        print(f"  🎯 执行{method}特征选择...")
    
    if method == 'f_test':
        # 根据数据大小选择策略
        if X.shape[0] > 2000000:  # 超过200万样本使用抽样
            f_values, p_values = sampled_f_regression(X, y, sample_size=1000000, verbose=verbose)
        elif X.shape[0] > 500000:  # 超过50万样本使用分块
            f_values, p_values = batched_f_regression(X, y, batch_size=500000, verbose=verbose)
        else:  # 小数据集直接计算
            f_values, p_values = f_regression(X, y)
        
        # 选择前k个特征
        top_k_indices = np.argsort(f_values)[-k:]
        selected_features = X.columns[top_k_indices]
        X_selected = X[selected_features]
        
    elif method == 'mutual_info':
        # 互信息方法，对大数据集更友好
        if X.shape[0] > 1000000:
            # 大数据集抽样
            sample_size = min(500000, X.shape[0])
            subset_idx = np.random.choice(X.shape[0], size=sample_size, replace=False)
            X_sub = X.iloc[subset_idx]
            y_sub = y.iloc[subset_idx]
            mi_scores = mutual_info_regression(X_sub, y_sub, random_state=42)
        else:
            mi_scores = mutual_info_regression(X, y, random_state=42)
        
        # 选择前k个特征
        top_k_indices = np.argsort(mi_scores)[-k:]
        selected_features = X.columns[top_k_indices]
        X_selected = X[selected_features]
        
    else:
        # 默认方差选择
        variances = X.var()
        top_k_indices = np.argsort(variances)[-k:]
        selected_features = X.columns[top_k_indices]
        X_selected = X[selected_features]
    
    if verbose:
        print(f"  ✅ {method}特征选择完成: {X.shape[1]} -> {len(selected_features)} 特征")
    
    return X_selected, selected_features

# ======= Step 1: 数据读取 =======
print("\n📂 Step 1: 数据读取")
start_time = time.time()

print("  📥 正在读取features_base.csv...")
base = pd.read_csv("features_base.csv")
print(f"    ✅ Base特征加载完成: {base.shape}")

print("  📥 正在读取features_extended.csv...")
extended = pd.read_csv("features_extended.csv")
print(f"    ✅ Extended特征加载完成: {extended.shape}")

print("  📥 正在读取labels.csv...")
y = pd.read_csv("labels.csv")["target"]
print(f"    ✅ 标签加载完成: {len(y)} 个样本")

# 样本一致性检查
assert len(base) == len(extended) == len(y), "样本数量不一致"
print(f"  ✅ 数据加载完成: {len(y)} 个样本")
print(f"  ⏱️ 数据加载耗时: {time.time() - start_time:.2f}秒")

# ======= Step 2: 数据预处理 =======
print("\n🔧 Step 2: 数据预处理")
preprocess_start = time.time()

# 2.1 Winsorization
print("  📊 执行Winsorization...")
base_winsorized = winsorize_data(base)
extended_winsorized = winsorize_data(extended)

# 2.2 安全Imputation
print("  🔄 执行安全Imputation...")
base_imputed = safe_impute(base_winsorized)
extended_imputed = safe_impute(extended_winsorized)

# 2.3 特征选择
print("  🎯 执行特征选择...")
feature_selection_start = time.time()

base_selected, base_selected_features = robust_feature_selection(
    base_imputed, y, method='f_test', k=min(10, base_imputed.shape[1]))
extended_selected, extended_selected_features = robust_feature_selection(
    extended_imputed, y, method='f_test', k=min(20, extended_imputed.shape[1]))

print(f"  ⏱️ 特征选择耗时: {time.time() - feature_selection_start:.2f}秒")
print(f"  ⏱️ 预处理总耗时: {time.time() - preprocess_start:.2f}秒")

# ======= Step 3: 交叉验证 =======
print("\n🔄 Step 3: 交叉验证")
cv_start = time.time()

print("  📊 设置交叉验证参数...")
cv = RepeatedKFold(n_splits=5, n_repeats=3, random_state=42)
scaler = RobustScaler()

# 存储结果
cv_results = {
    'base_scores': [],
    'extended_scores': [],
    'fold_info': []
}

print("  🔄 开始交叉验证...")
for fold_idx, (train_idx, test_idx) in enumerate(cv.split(base_selected)):
    fold_start = time.time()
    print(f"    Fold {fold_idx + 1}/15...")
    
    # 数据划分
    try:
        Xb_train, Xb_test = base_selected.iloc[train_idx], base_selected.iloc[test_idx]
        Xe_train, Xe_test = extended_selected.iloc[train_idx], extended_selected.iloc[test_idx]
        y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]
        
        print(f"      📊 数据形状检查:")
        print(f"        Xb_train: {Xb_train.shape}, Xb_test: {Xb_test.shape}")
        print(f"        Xe_train: {Xe_train.shape}, Xe_test: {Xe_test.shape}")
        print(f"        y_train: {y_train.shape}, y_test: {y_test.shape}")
        
    except Exception as e:
        print(f"      ❌ 数据划分失败: {e}")
        continue
    
    # 标准化
    try:
        print(f"      🔄 标准化数据...")
        Xb_train_scaled = scaler.fit_transform(Xb_train)
        Xb_test_scaled = scaler.transform(Xb_test)
        Xe_train_scaled = scaler.fit_transform(Xe_train)
        Xe_test_scaled = scaler.transform(Xe_test)
        print(f"      ✅ 标准化完成")
    except Exception as e:
        print(f"      ❌ 标准化失败: {e}")
        continue
    
    # 模型训练 - 使用内存优化策略
    try:
        print(f"      🤖 训练模型...")
        
        # 方案1: 缩减RandomForest参数 + 子样本训练
        print(f"        📊 原始训练集大小: {Xb_train_scaled.shape[0]} 样本")
        
        # 子样本训练 - 从700万样本中抽取50万代表性样本（更激进的内存优化）
        sample_size = min(500000, Xb_train_scaled.shape[0])
        np.random.seed(42 + fold_idx)  # 每个fold使用不同种子但可复现
        sample_idx = np.random.choice(Xb_train_scaled.shape[0], size=sample_size, replace=False)
        
        Xb_train_sub = Xb_train_scaled[sample_idx]
        Xe_train_sub = Xe_train_scaled[sample_idx]
        y_train_sub = y_train.iloc[sample_idx]
        
        print(f"        🎯 子样本训练: {sample_size} 样本 ({sample_size/Xb_train_scaled.shape[0]*100:.1f}%)")
        
        # 更激进的内存优化RandomForest参数
        model = RandomForestRegressor(
            n_estimators=10,           # 进一步减少到10棵树
            max_depth=8,               # 减少树深度
            max_features='sqrt',       # 降低每次分裂的维度
            min_samples_leaf=100,      # 增加叶子节点最小样本数
            bootstrap=True,
            n_jobs=2,                  # 减少并行线程
            random_state=42,
            verbose=0
        )
        
        # Base模型
        print(f"        🎯 训练Base模型...")
        model.fit(Xb_train_sub, y_train_sub)
        base_score = model.score(Xb_test_scaled, y_test)
        print(f"        ✅ Base模型R²: {base_score:.4f}")
        
        # Extended模型
        print(f"        🎯 训练Extended模型...")
        model.fit(Xe_train_sub, y_train_sub)
        extended_score = model.score(Xe_test_scaled, y_test)
        print(f"        ✅ Extended模型R²: {extended_score:.4f}")
        
    except Exception as e:
        print(f"      ❌ 模型训练失败: {e}")
        # 如果RandomForest失败，尝试更轻量的模型
        try:
            print(f"      🔄 尝试轻量级模型...")
            from sklearn.ensemble import HistGradientBoostingRegressor
            
            # 使用HistGradientBoostingRegressor - 内存效率极高
            model_light = HistGradientBoostingRegressor(
                max_iter=100,
                learning_rate=0.1,
                max_depth=10,
                random_state=42,
                verbose=0
            )
            
            # Base模型
            model_light.fit(Xb_train_scaled, y_train)
            base_score = model_light.score(Xb_test_scaled, y_test)
            
            # Extended模型
            model_light.fit(Xe_train_scaled, y_train)
            extended_score = model_light.score(Xe_test_scaled, y_test)
            
            print(f"        ✅ 轻量级模型完成: Base R²={base_score:.4f}, Extended R²={extended_score:.4f}")
            
        except Exception as e2:
            print(f"      ❌ 轻量级模型也失败: {e2}")
            continue
    
    cv_results['base_scores'].append(base_score)
    cv_results['extended_scores'].append(extended_score)
    cv_results['fold_info'].append({
        'fold': fold_idx + 1,
        'train_size': len(train_idx),
        'test_size': len(test_idx),
        'fold_time': time.time() - fold_start
    })
    
    print(f"      Base: {base_score:.4f}, Extended: {extended_score:.4f}, 耗时: {time.time() - fold_start:.2f}秒")

print(f"  ⏱️ 交叉验证总耗时: {time.time() - cv_start:.2f}秒")

# ======= Step 4: 统计分析 =======
print("\n📈 Step 4: 统计分析")

# 4.1 基本统计
base_mean = np.mean(cv_results['base_scores'])
extended_mean = np.mean(cv_results['extended_scores'])
base_std = np.std(cv_results['base_scores'])
extended_std = np.std(cv_results['extended_scores'])

# 4.2 配对t检验
t_stat, p_value = stats.ttest_rel(cv_results['extended_scores'], cv_results['base_scores'])

# 4.3 效应量 (Cohen's d)
pooled_std = np.sqrt(((len(cv_results['base_scores']) - 1) * base_std**2 + 
                     (len(cv_results['extended_scores']) - 1) * extended_std**2) / 
                    (len(cv_results['base_scores']) + len(cv_results['extended_scores']) - 2))
cohens_d = (extended_mean - base_mean) / pooled_std

# ======= Step 5: 结果保存 =======
print("\n💾 Step 5: 结果保存")

# 5.1 诊断信息
diagnostics = {
    'performance_info': {
        'total_runtime_seconds': time.time() - start_time,
        'data_loading_time': time.time() - start_time - (time.time() - preprocess_start),
        'preprocessing_time': time.time() - preprocess_start - (time.time() - cv_start),
        'cross_validation_time': time.time() - cv_start
    },
    'data_info': {
        'original_base_shape': base.shape,
        'original_extended_shape': extended.shape,
        'final_base_shape': base_selected.shape,
        'final_extended_shape': extended_selected.shape,
        'samples': len(y)
    },
    'optimization_strategy': {
        'f_test_method': 'sampled' if base.shape[0] > 2000000 else 'batched' if base.shape[0] > 500000 else 'direct',
        'sample_size_used': min(1000000, base.shape[0]) if base.shape[0] > 2000000 else None,
        'batch_size_used': 500000 if base.shape[0] > 500000 else None
    },
    'cross_validation_results': {
        'base_mean_r2': float(base_mean),
        'base_std_r2': float(base_std),
        'extended_mean_r2': float(extended_mean),
        'extended_std_r2': float(extended_std),
        'improvement': float(extended_mean - base_mean),
        'improvement_percent': float((extended_mean - base_mean) / abs(base_mean) * 100)
    },
    'statistical_tests': {
        'paired_t_test': {
            't_statistic': float(t_stat),
            'p_value': float(p_value),
            'significant': p_value < 0.05
        },
        'effect_size': {
            'cohens_d': float(cohens_d),
            'interpretation': 'small' if abs(cohens_d) < 0.5 else 'medium' if abs(cohens_d) < 0.8 else 'large'
        }
    },
    'feature_info': {
        'base_selected_features': base_selected_features.tolist(),
        'extended_selected_features': extended_selected_features.tolist()
    }
}

# 5.2 保存结果
print("  💾 保存诊断结果...")
with open("step3_optimized_diagnostics.json", "w") as f:
    json.dump(diagnostics, f, indent=4)

# ======= Step 6: 结果报告 =======
print("\n📊 Step 6: 结果报告")
print("=" * 70)
print("Step 3 优化科学验证结果")
print("=" * 70)
print(f"⏱️ 性能优化:")
print(f"  总运行时间: {time.time() - start_time:.2f}秒")
print(f"  数据加载: {time.time() - start_time - (time.time() - preprocess_start):.2f}秒")
print(f"  预处理: {time.time() - preprocess_start - (time.time() - cv_start):.2f}秒")
print(f"  交叉验证: {time.time() - cv_start:.2f}秒")
print(f"\n📈 交叉验证结果:")
print(f"  Base模型 R²: {base_mean:.4f} ± {base_std:.4f}")
print(f"  Extended模型 R²: {extended_mean:.4f} ± {extended_std:.4f}")
print(f"  性能提升: {extended_mean - base_mean:.4f} ({((extended_mean - base_mean) / abs(base_mean) * 100):.2f}%)")
print(f"\n🔬 统计检验:")
print(f"  配对t检验: t = {t_stat:.4f}, p = {p_value:.4f}")
print(f"  效应量 (Cohen's d): {cohens_d:.4f} ({'small' if abs(cohens_d) < 0.5 else 'medium' if abs(cohens_d) < 0.8 else 'large'})")
print(f"\n✅ 结果文件:")
print(f"  step3_optimized_diagnostics.json - 优化诊断信息")
print("=" * 70)

print("🎉 Step 3 优化科学验证完成！")
