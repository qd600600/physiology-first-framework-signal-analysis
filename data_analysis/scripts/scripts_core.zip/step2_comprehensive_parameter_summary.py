#!/usr/bin/env python3
"""
Step 2: Comprehensive Parameter Selection Summary
汇总所有8个数据集的理论参数分析结果
"""

import json
import pandas as pd
from pathlib import Path
from datetime import datetime

def create_comprehensive_summary():
    """创建所有数据集的综合参数选择报告"""
    print("Creating Comprehensive Parameter Selection Summary")
    print("="*60)
    
    # 理论参数优先级定义
    theoretical_priorities = {
        'priority_1_core_physiological': {
            'description': 'Core physiological markers directly reflecting ANS activity and acute stress.',
            'parameters': {
                'hrv_rmssd': {'aliases': ['rmssd', 'rmssd_rel_rr', 'sd1'], 'description': 'Root Mean Square of Successive Differences, a primary HRV time-domain measure.'},
                'hrv_sdnn': {'aliases': ['sdnn', 'sdrr', 'sd2'], 'description': 'Standard Deviation of NN intervals, reflecting overall HRV.'},
                'hr_mean': {'aliases': ['hr', 'heart_rate_bpm'], 'description': 'Mean Heart Rate.'},
                'ibi': {'aliases': ['ibi', 'rr', 'ibi_s', 'mean_rr', 'median_rr'], 'description': 'Inter-Beat Interval or R-R interval, raw data for HRV calculation.'},
                'eda': {'aliases': ['eda', 'gsr'], 'description': 'Electrodermal Activity / Galvanic Skin Response, indicating sympathetic arousal.'}
            }
        },
        'priority_2_regulatory_variables': {
            'description': 'Physiological and behavioral variables that modulate stress response or provide context.',
            'parameters': {
                'temperature': {'aliases': ['temp', 'temperature'], 'description': 'Skin or body temperature.'},
                'acceleration': {'aliases': ['acc', 'activity', 'steps', 'vector_magnitude'], 'description': 'Activity level, used to differentiate movement-induced physiological changes.'},
                'respiration': {'aliases': ['resp', 'respiration'], 'description': 'Respiration rate or volume (if available).'}
            }
        },
        'priority_3_clinical_subjective': {
            'description': 'Subjective reports and clinical scales for validation and LRI calculation.',
            'parameters': {
                'phq_9': {'aliases': ['phq_9', 'phq9', 'mood_rating'], 'description': 'Patient Health Questionnaire-9 for depression symptoms.'},
                'gad_7': {'aliases': ['gad_7', 'gad7'], 'description': 'Generalized Anxiety Disorder 7-item scale.'},
                'bdi': {'aliases': ['bdi', 'bdi_ii'], 'description': 'Beck Depression Inventory.'},
                'ham_d': {'aliases': ['ham_d', 'hamd'], 'description': 'Hamilton Depression Rating Scale.'},
                'panss': {'aliases': ['panss'], 'description': 'Positive and Negative Syndrome Scale.'},
                'stress_label': {'aliases': ['condition', 'stress_level', 'mental_health_condition'], 'description': 'Categorical or continuous stress/mental health labels.'},
                'sleep': {'aliases': ['sleep_duration_hours', 'total_sleep_time_(tst)', 'sleep_efficiency'], 'description': 'Sleep duration or quality metrics.'}
            }
        }
    }
    
    # 基于分析结果的数据集参数映射
    dataset_parameter_mapping = {
        'CRWD': {
            'found_parameters': ['hrv_rmssd', 'hrv_sdnn', 'hr_mean', 'eda'],
            'relevance_percentage': 80.0,
            'data_quality': 'High',
            'notes': 'Complete HRV parameters and EDA data available'
        },
        'SWELL': {
            'found_parameters': ['hrv_rmssd', 'hrv_sdnn', 'hr_mean', 'stress_label'],
            'relevance_percentage': 80.0,
            'data_quality': 'High',
            'notes': 'HRV parameters with stress condition labels'
        },
        'Mental_Health_Pred': {
            'found_parameters': ['hr_mean', 'eda', 'stress_label'],
            'relevance_percentage': 60.0,
            'data_quality': 'Medium',
            'notes': 'Basic physiological parameters with mental health condition labels'
        },
        'WESAD': {
            'found_parameters': ['hr_mean', 'eda', 'temperature', 'acceleration', 'ibi'],
            'relevance_percentage': 100.0,
            'data_quality': 'High',
            'notes': 'Complete sensor suite with multiple physiological parameters'
        },
        'MMASH': {
            'found_parameters': ['ibi', 'hr_mean', 'acceleration'],
            'relevance_percentage': 60.0,
            'data_quality': 'Medium',
            'notes': 'RR intervals and heart rate data with activity tracking'
        },
        'Nurses': {
            'found_parameters': ['acceleration', 'eda', 'hr_mean', 'ibi', 'temperature'],
            'relevance_percentage': 100.0,
            'data_quality': 'High',
            'notes': 'Complete multi-sensor physiological monitoring data'
        },
        'DRIVE_DB': {
            'found_parameters': ['hr_mean', 'stress_label'],
            'relevance_percentage': 40.0,
            'data_quality': 'Medium',
            'notes': 'ECG/HR data with driving stress conditions (binary format)'
        },
        'Non_EEG': {
            'found_parameters': ['eda', 'stress_label', 'hr_mean'],
            'relevance_percentage': 60.0,
            'data_quality': 'Medium',
            'notes': 'EDA and HR data with neurological status annotations'
        }
    }
    
    # 计算综合统计
    all_parameters = set()
    for dataset, info in dataset_parameter_mapping.items():
        all_parameters.update(info['found_parameters'])
    
    high_priority_params = set(theoretical_priorities['priority_1_core_physiological']['parameters'].keys())
    found_high_priority = all_parameters.intersection(high_priority_params)
    
    # 创建综合报告
    summary_report = {
        'analysis_timestamp': datetime.now().isoformat(),
        'total_datasets': len(dataset_parameter_mapping),
        'theoretical_framework': theoretical_priorities,
        'dataset_analysis': dataset_parameter_mapping,
        'overall_statistics': {
            'total_datasets': len(dataset_parameter_mapping),
            'total_unique_parameters': len(all_parameters),
            'high_priority_parameters_found': len(found_high_priority),
            'parameter_coverage_percentage': (len(found_high_priority) / len(high_priority_params)) * 100,
            'average_dataset_relevance': sum(info['relevance_percentage'] for info in dataset_parameter_mapping.values()) / len(dataset_parameter_mapping)
        },
        'parameter_frequency': {},
        'quality_assessment': {
            'high_quality_datasets': [name for name, info in dataset_parameter_mapping.items() if info['data_quality'] == 'High'],
            'medium_quality_datasets': [name for name, info in dataset_parameter_mapping.items() if info['data_quality'] == 'Medium'],
            'recommended_primary_datasets': ['WESAD', 'Nurses', 'CRWD', 'SWELL'],
            'recommended_secondary_datasets': ['MMASH', 'Mental_Health_Pred', 'Non_EEG'],
            'specialized_datasets': ['DRIVE_DB']
        }
    }
    
    # 计算参数频率
    for dataset, info in dataset_parameter_mapping.items():
        for param in info['found_parameters']:
            if param not in summary_report['parameter_frequency']:
                summary_report['parameter_frequency'][param] = 0
            summary_report['parameter_frequency'][param] += 1
    
    # 打印报告
    print("\n" + "="*60)
    print("COMPREHENSIVE PARAMETER SELECTION REPORT")
    print("="*60)
    
    print(f"\n📊 OVERALL STATISTICS:")
    stats = summary_report['overall_statistics']
    print(f"   Total datasets analyzed: {stats['total_datasets']}")
    print(f"   Unique parameters found: {stats['total_unique_parameters']}")
    print(f"   High-priority parameters: {stats['high_priority_parameters_found']}/{len(high_priority_params)}")
    print(f"   Parameter coverage: {stats['parameter_coverage_percentage']:.1f}%")
    print(f"   Average relevance: {stats['average_dataset_relevance']:.1f}%")
    
    print(f"\n🎯 PARAMETER FREQUENCY ACROSS DATASETS:")
    sorted_params = sorted(summary_report['parameter_frequency'].items(), key=lambda x: x[1], reverse=True)
    for param, count in sorted_params:
        print(f"   {param}: {count}/8 datasets ({count/8*100:.1f}%)")
    
    print(f"\n📈 DATASET QUALITY ASSESSMENT:")
    print(f"   High Quality ({len(summary_report['quality_assessment']['high_quality_datasets'])}): {', '.join(summary_report['quality_assessment']['high_quality_datasets'])}")
    print(f"   Medium Quality ({len(summary_report['quality_assessment']['medium_quality_datasets'])}): {', '.join(summary_report['quality_assessment']['medium_quality_datasets'])}")
    
    print(f"\n🔬 RECOMMENDED ANALYSIS STRATEGY:")
    print(f"   Primary datasets: {', '.join(summary_report['quality_assessment']['recommended_primary_datasets'])}")
    print(f"   Secondary datasets: {', '.join(summary_report['quality_assessment']['recommended_secondary_datasets'])}")
    print(f"   Specialized datasets: {', '.join(summary_report['quality_assessment']['specialized_datasets'])}")
    
    print(f"\n📋 DETAILED DATASET ANALYSIS:")
    for dataset, info in dataset_parameter_mapping.items():
        print(f"\n   {dataset}:")
        print(f"     Parameters: {', '.join(info['found_parameters'])}")
        print(f"     Relevance: {info['relevance_percentage']:.1f}%")
        print(f"     Quality: {info['data_quality']}")
        print(f"     Notes: {info['notes']}")
    
    # 保存报告
    report_file = Path("step2_comprehensive_parameter_summary.json")
    with open(report_file, 'w', encoding='utf-8') as f:
        json.dump(summary_report, f, indent=2, ensure_ascii=False)
    
    print(f"\n✅ Comprehensive summary saved to: {report_file}")
    
    # 创建CSV格式的参数选择表
    csv_data = []
    for dataset, info in dataset_parameter_mapping.items():
        csv_data.append({
            'Dataset': dataset,
            'Parameters_Found': ', '.join(info['found_parameters']),
            'Parameter_Count': len(info['found_parameters']),
            'Relevance_Percentage': info['relevance_percentage'],
            'Data_Quality': info['data_quality'],
            'Notes': info['notes']
        })
    
    df = pd.DataFrame(csv_data)
    csv_file = Path("step2_parameter_selection_table.csv")
    df.to_csv(csv_file, index=False, encoding='utf-8')
    
    print(f"✅ Parameter selection table saved to: {csv_file}")
    
    return summary_report

if __name__ == "__main__":
    report = create_comprehensive_summary()
    print(f"\n🎉 Step 2 Parameter Selection completed successfully!")
    print(f"Ready for Step 3: Data Cleaning")
