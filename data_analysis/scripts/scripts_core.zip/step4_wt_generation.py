#!/usr/bin/env python3
"""
Step 4: W(t) Target Variable Generation
基于理论框架生成累积压力函数W(t)
"""

import pandas as pd
import numpy as np
import json
import os
from pathlib import Path
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

class WtGenerator:
    def __init__(self):
        # W(t)参数配置
        self.wt_parameters = {
            'default': {
                'W_max': 20.0,      # 最大累积压力
                'beta': 0.3,        # 恢复率参数
                'alpha': 1.0,       # 压力输入强度
                'theta_base': 1.0   # 个体敏感性基础值
            },
            'sensitivity_sweep': {
                'W_max': [10, 20, 30],
                'beta': [0.1, 0.3, 0.5]
            }
        }
        
        # 加载Step 2和Step 3的结果
        self.load_previous_results()
        
        # 创建输出目录
        self.output_dir = Path('processed/wt_generation')
        self.output_dir.mkdir(parents=True, exist_ok=True)
    
    def load_previous_results(self):
        """加载之前步骤的结果"""
        try:
            # 加载参数选择结果
            with open('step2_comprehensive_parameter_summary.json', 'r', encoding='utf-8') as f:
                self.param_results = json.load(f)
            
            # 加载清洗结果
            with open('processed/cleaned_data/cleaning_summary.json', 'r', encoding='utf-8') as f:
                self.cleaning_results = json.load(f)
            
            print(f"✅ Loaded parameter selection and cleaning results")
            
        except FileNotFoundError as e:
            print(f"❌ Previous step results not found: {e}")
            raise
    
    def generate_wt_for_dataset(self, dataset_name):
        """为单个数据集生成W(t)"""
        print(f"\n{'='*60}")
        print(f"Generating W(t) for Dataset: {dataset_name}")
        print(f"{'='*60}")
        
        # 检查数据集是否已清洗
        if dataset_name not in self.cleaning_results['dataset_details']:
            print(f"❌ Dataset {dataset_name} not found in cleaning results")
            return None
        
        cleaning_info = self.cleaning_results['dataset_details'][dataset_name]
        if 'data_saving' not in cleaning_info.get('steps_completed', []):
            print(f"❌ Dataset {dataset_name} was not successfully cleaned")
            return None
        
        # 加载清洗后的数据
        cleaned_file = Path('processed/cleaned_data') / f'cleaned_{dataset_name}.parquet'
        if not cleaned_file.exists():
            print(f"❌ Cleaned data file not found: {cleaned_file}")
            return None
        
        try:
            df = pd.read_parquet(cleaned_file)
            print(f"✅ Loaded cleaned data: {df.shape}")
        except Exception as e:
            print(f"❌ Error loading cleaned data: {e}")
            return None
        
        # 生成W(t)时间序列
        wt_results = self.generate_wt_timeseries(df, dataset_name)
        
        # 执行参数敏感性扫描
        sensitivity_results = self.parameter_sensitivity_sweep(df, dataset_name)
        
        # 保存结果
        self.save_wt_results(wt_results, sensitivity_results, dataset_name)
        
        return {
            'dataset_name': dataset_name,
            'wt_timeseries': wt_results,
            'sensitivity_results': sensitivity_results
        }
    
    def generate_wt_timeseries(self, df, dataset_name):
        """生成W(t)时间序列"""
        print(f"🔄 Generating W(t) time series...")
        
        # 提取理论参数
        theoretical_params = self.extract_theoretical_parameters(df, dataset_name)
        
        if not theoretical_params:
            print(f"❌ No theoretical parameters found for {dataset_name}")
            return None
        
        # 计算个体敏感性参数θ
        theta = self.calculate_individual_sensitivity(df, theoretical_params, dataset_name)
        
        # 生成压力输入I(t)
        stress_input = self.calculate_stress_input(df, theoretical_params, dataset_name)
        
        # 生成W(t)序列
        wt_series = self.compute_wt_series(stress_input, theta, dataset_name)
        
        # 创建结果DataFrame
        result_df = df.copy()
        result_df['stress_input'] = stress_input
        result_df['theta'] = theta
        result_df['W_t'] = wt_series
        
        print(f"   Generated W(t) series: {len(wt_series)} points")
        print(f"   W(t) range: [{np.min(wt_series):.2f}, {np.max(wt_series):.2f}]")
        print(f"   Average W(t): {np.mean(wt_series):.2f}")
        
        return {
            'data': result_df,
            'parameters': {
                'theta': theta,
                'stress_input_stats': {
                    'mean': np.mean(stress_input),
                    'std': np.std(stress_input),
                    'min': np.min(stress_input),
                    'max': np.max(stress_input)
                },
                'wt_stats': {
                    'mean': np.mean(wt_series),
                    'std': np.std(wt_series),
                    'min': np.min(wt_series),
                    'max': np.max(wt_series)
                }
            }
        }
    
    def extract_theoretical_parameters(self, df, dataset_name):
        """提取理论相关参数"""
        # 根据数据集类型提取不同的参数
        theoretical_params = {}
        
        if dataset_name == 'CRWD':
            # CRWD包含HRV参数
            hrv_params = ['HR', 'ibi', 'sdnn', 'rmssd']
            for param in hrv_params:
                if param in df.columns:
                    theoretical_params[param] = df[param].values
        
        elif dataset_name == 'SWELL':
            # SWELL包含HRV和压力条件
            hrv_params = ['HR', 'RMSSD', 'SDRR']
            for param in hrv_params:
                if param in df.columns:
                    theoretical_params[param] = df[param].values
            
            if 'condition' in df.columns:
                # 将压力条件转换为数值
                condition_map = {'no stress': 0, 'interruption': 1, 'time pressure': 2}
                theoretical_params['stress_condition'] = df['condition'].map(condition_map).fillna(0).values
        
        elif dataset_name == 'WESAD':
            # WESAD包含多传感器数据
            sensor_params = ['bvp', 'eda', 'hr']
            for param in sensor_params:
                if param in df.columns:
                    theoretical_params[param] = df[param].values
        
        elif dataset_name == 'Nurses':
            # Nurses包含多传感器数据
            sensor_params = ['bvp', 'eda']
            for param in sensor_params:
                if param in df.columns:
                    theoretical_params[param] = df[param].values
        
        elif dataset_name == 'MMASH':
            # MMASH包含IBI数据
            if 'ibi_s' in df.columns:
                theoretical_params['ibi'] = df['ibi_s'].values
        
        elif dataset_name == 'Mental_Health_Pred':
            # Mental Health包含心率和心理健康标签
            if 'Heart_Rate_BPM' in df.columns:
                theoretical_params['hr'] = df['Heart_Rate_BPM'].values
            if 'Mental_Health_Condition' in df.columns:
                theoretical_params['stress_condition'] = df['Mental_Health_Condition'].values
        
        print(f"   Extracted {len(theoretical_params)} theoretical parameters")
        return theoretical_params
    
    def calculate_individual_sensitivity(self, df, theoretical_params, dataset_name):
        """计算个体敏感性参数θ"""
        # 基于HRV计算个体敏感性
        theta = np.ones(len(df))  # 默认值
        
        if 'HR' in theoretical_params:
            hr_data = theoretical_params['HR']
            # 移除NaN值
            valid_hr = hr_data[~np.isnan(hr_data)]
            if len(valid_hr) > 0:
                hr_std = np.std(valid_hr)
                if hr_std > 0:
                    # θ与HRV成反比（HRV高=敏感性低）
                    hr_mean = np.mean(valid_hr)
                    hr_normalized = (hr_data - hr_mean) / hr_std
                    # 处理NaN值
                    hr_normalized = np.nan_to_num(hr_normalized, nan=0.0)
                    theta = 1.0 / (1.0 + np.abs(hr_normalized))
        
        elif 'rmssd' in theoretical_params or 'RMSSD' in theoretical_params:
            # 使用RMSSD计算θ
            rmssd_key = 'rmssd' if 'rmssd' in theoretical_params else 'RMSSD'
            rmssd_data = theoretical_params[rmssd_key]
            valid_rmssd = rmssd_data[~np.isnan(rmssd_data)]
            if len(valid_rmssd) > 0:
                rmssd_std = np.std(valid_rmssd)
                if rmssd_std > 0:
                    rmssd_mean = np.mean(valid_rmssd)
                    rmssd_normalized = (rmssd_data - rmssd_mean) / rmssd_std
                    # 处理NaN值
                    rmssd_normalized = np.nan_to_num(rmssd_normalized, nan=0.0)
                    theta = 1.0 / (1.0 + np.abs(rmssd_normalized))
        
        # 确保θ在合理范围内
        theta = np.clip(theta, 0.1, 2.0)
        
        print(f"   Calculated θ: mean={np.mean(theta):.3f}, std={np.std(theta):.3f}")
        return theta
    
    def calculate_stress_input(self, df, theoretical_params, dataset_name):
        """计算压力输入I(t)"""
        # 组合多个生理指标作为压力输入
        stress_components = []
        
        # 1. 心率相关压力
        if 'HR' in theoretical_params:
            hr_data = theoretical_params['HR']
            valid_hr = hr_data[~np.isnan(hr_data)]
            if len(valid_hr) > 0:
                hr_mean = np.mean(valid_hr)
                hr_std = np.std(valid_hr) + 1e-8
                hr_normalized = (hr_data - hr_mean) / hr_std
                hr_normalized = np.nan_to_num(hr_normalized, nan=0.0)
                stress_components.append(hr_normalized)
        
        # 2. EDA相关压力
        if 'eda' in theoretical_params:
            eda_data = theoretical_params['eda']
            valid_eda = eda_data[~np.isnan(eda_data)]
            if len(valid_eda) > 0:
                eda_mean = np.mean(valid_eda)
                eda_std = np.std(valid_eda) + 1e-8
                eda_normalized = (eda_data - eda_mean) / eda_std
                eda_normalized = np.nan_to_num(eda_normalized, nan=0.0)
                stress_components.append(eda_normalized)
        
        # 3. 压力条件相关
        if 'stress_condition' in theoretical_params:
            stress_cond = theoretical_params['stress_condition']
            stress_cond = np.nan_to_num(stress_cond, nan=0.0)
            stress_components.append(stress_cond)
        
        # 4. HRV相关（反向指标）
        if 'rmssd' in theoretical_params or 'RMSSD' in theoretical_params:
            rmssd_key = 'rmssd' if 'rmssd' in theoretical_params else 'RMSSD'
            rmssd_data = theoretical_params[rmssd_key]
            valid_rmssd = rmssd_data[~np.isnan(rmssd_data)]
            if len(valid_rmssd) > 0:
                rmssd_mean = np.mean(valid_rmssd)
                rmssd_std = np.std(valid_rmssd) + 1e-8
                # HRV低表示高压力
                rmssd_inverted = -(rmssd_data - rmssd_mean) / rmssd_std
                rmssd_inverted = np.nan_to_num(rmssd_inverted, nan=0.0)
                stress_components.append(rmssd_inverted)
        
        # 组合压力输入
        if stress_components:
            stress_input = np.mean(stress_components, axis=0)
        else:
            # 如果没有特定参数，使用随机噪声
            stress_input = np.random.normal(0, 0.1, len(df))
        
        # 处理NaN值
        stress_input = np.nan_to_num(stress_input, nan=0.0)
        
        # 确保压力输入为非负值
        stress_input = np.maximum(stress_input, 0)
        
        print(f"   Calculated stress input: mean={np.mean(stress_input):.3f}, std={np.std(stress_input):.3f}")
        return stress_input
    
    def compute_wt_series(self, stress_input, theta, dataset_name):
        """计算W(t)序列"""
        params = self.wt_parameters['default']
        W_max = params['W_max']
        beta = params['beta']
        alpha = params['alpha']
        
        # 初始化W(t)序列
        n_points = len(stress_input)
        W_t = np.zeros(n_points)
        
        # 添加随机噪声
        epsilon = np.random.normal(0, 0.01, n_points)
        
        # 递推计算W(t)
        for t in range(1, n_points):
            # W[t] = clamp(0, W_max, W[t-1] + θ·(α·I_t) - β·W[t-1] + ε_t)
            W_prev = W_t[t-1]
            I_t = stress_input[t]
            theta_t = theta[t] if hasattr(theta, '__len__') else theta
            
            W_new = W_prev + theta_t * (alpha * I_t) - beta * W_prev + epsilon[t]
            W_t[t] = np.clip(W_new, 0, W_max)
        
        return W_t
    
    def parameter_sensitivity_sweep(self, df, dataset_name):
        """执行参数敏感性扫描"""
        print(f"🔬 Performing parameter sensitivity sweep...")
        
        sweep_params = self.wt_parameters['sensitivity_sweep']
        sensitivity_results = []
        
        # 提取基础参数
        theoretical_params = self.extract_theoretical_parameters(df, dataset_name)
        if not theoretical_params:
            return sensitivity_results
        
        theta = self.calculate_individual_sensitivity(df, theoretical_params, dataset_name)
        stress_input = self.calculate_stress_input(df, theoretical_params, dataset_name)
        
        # 扫描W_max和beta参数
        for W_max in sweep_params['W_max']:
            for beta in sweep_params['beta']:
                # 计算W(t)序列
                n_points = len(stress_input)
                W_t = np.zeros(n_points)
                epsilon = np.random.normal(0, 0.01, n_points)
                
                for t in range(1, n_points):
                    W_prev = W_t[t-1]
                    I_t = stress_input[t]
                    theta_t = theta[t] if hasattr(theta, '__len__') else theta
                    
                    W_new = W_prev + theta_t * (1.0 * I_t) - beta * W_prev + epsilon[t]
                    W_t[t] = np.clip(W_new, 0, W_max)
                
                # 记录结果
                sensitivity_results.append({
                    'W_max': W_max,
                    'beta': beta,
                    'wt_mean': np.mean(W_t),
                    'wt_std': np.std(W_t),
                    'wt_max': np.max(W_t),
                    'wt_min': np.min(W_t),
                    'overflow_rate': np.mean(W_t >= W_max * 0.9)  # 接近最大值的比例
                })
        
        print(f"   Completed sensitivity sweep: {len(sensitivity_results)} parameter combinations")
        return sensitivity_results
    
    def save_wt_results(self, wt_results, sensitivity_results, dataset_name):
        """保存W(t)生成结果"""
        print(f"💾 Saving W(t) results...")
        
        # 保存W(t)时间序列
        if wt_results and 'data' in wt_results:
            wt_file = self.output_dir / f'wt_timeseries_{dataset_name}.parquet'
            wt_results['data'].to_parquet(wt_file, index=False)
            print(f"   Saved W(t) timeseries: {wt_file}")
        
        # 保存参数敏感性结果
        if sensitivity_results:
            sensitivity_df = pd.DataFrame(sensitivity_results)
            sensitivity_file = self.output_dir / f'wt_params_sweep_{dataset_name}.csv'
            sensitivity_df.to_csv(sensitivity_file, index=False)
            print(f"   Saved parameter sweep: {sensitivity_file}")
        
        # 保存生成统计
        stats_file = self.output_dir / f'wt_generation_stats_{dataset_name}.json'
        stats = {
            'dataset_name': dataset_name,
            'generation_timestamp': datetime.now().isoformat(),
            'wt_parameters': wt_results.get('parameters', {}),
            'sensitivity_summary': {
                'total_combinations': len(sensitivity_results),
                'best_combination': max(sensitivity_results, key=lambda x: x['wt_mean']) if sensitivity_results else None
            }
        }
        
        with open(stats_file, 'w', encoding='utf-8') as f:
            json.dump(stats, f, indent=2, ensure_ascii=False, default=str)
        
        print(f"   Saved generation stats: {stats_file}")
    
    def generate_all_wt(self):
        """为所有数据集生成W(t)"""
        print("Starting Step 4: W(t) Target Variable Generation")
        print("="*60)
        
        # 获取成功清洗的数据集
        cleaned_datasets = []
        for dataset_name, details in self.cleaning_results['dataset_details'].items():
            if 'data_saving' in details.get('steps_completed', []):
                cleaned_datasets.append(dataset_name)
        
        print(f"📊 Found {len(cleaned_datasets)} successfully cleaned datasets")
        
        generation_results = {}
        
        for dataset_name in cleaned_datasets:
            try:
                result = self.generate_wt_for_dataset(dataset_name)
                if result:
                    generation_results[dataset_name] = result
            except Exception as e:
                print(f"❌ Error generating W(t) for {dataset_name}: {e}")
        
        # 生成综合报告
        self.generate_wt_summary(generation_results)
        
        return generation_results
    
    def generate_wt_summary(self, generation_results):
        """生成W(t)生成综合报告"""
        print(f"\n{'='*60}")
        print("W(t) GENERATION SUMMARY")
        print(f"{'='*60}")
        
        summary = {
            'generation_timestamp': datetime.now().isoformat(),
            'total_datasets_processed': len(generation_results),
            'successful_generations': len(generation_results),
            'dataset_summaries': {},
            'overall_statistics': {}
        }
        
        # 收集统计信息
        all_wt_means = []
        all_wt_stds = []
        
        for dataset_name, result in generation_results.items():
            wt_params = result.get('wt_timeseries', {}).get('parameters', {})
            wt_stats = wt_params.get('wt_stats', {})
            
            dataset_summary = {
                'wt_mean': wt_stats.get('mean', 0),
                'wt_std': wt_stats.get('std', 0),
                'wt_range': [wt_stats.get('min', 0), wt_stats.get('max', 0)],
                'sensitivity_combinations': len(result.get('sensitivity_results', []))
            }
            
            summary['dataset_summaries'][dataset_name] = dataset_summary
            all_wt_means.append(wt_stats.get('mean', 0))
            all_wt_stds.append(wt_stats.get('std', 0))
        
        # 计算总体统计
        if all_wt_means:
            summary['overall_statistics'] = {
                'average_wt_mean': np.mean(all_wt_means),
                'average_wt_std': np.mean(all_wt_stds),
                'wt_mean_range': [np.min(all_wt_means), np.max(all_wt_means)]
            }
        
        # 打印摘要
        print(f"📊 Overall Statistics:")
        print(f"   Total datasets: {summary['total_datasets_processed']}")
        print(f"   Successful generations: {summary['successful_generations']}")
        
        if 'average_wt_mean' in summary['overall_statistics']:
            stats = summary['overall_statistics']
            print(f"   Average W(t) mean: {stats['average_wt_mean']:.3f}")
            print(f"   Average W(t) std: {stats['average_wt_std']:.3f}")
        
        print(f"\n📋 Dataset Details:")
        for dataset_name, dataset_summary in summary['dataset_summaries'].items():
            print(f"   {dataset_name}:")
            print(f"     W(t) mean: {dataset_summary['wt_mean']:.3f}")
            print(f"     W(t) std: {dataset_summary['wt_std']:.3f}")
            print(f"     Sensitivity combinations: {dataset_summary['sensitivity_combinations']}")
        
        # 保存综合报告
        summary_file = self.output_dir / 'wt_generation_summary.json'
        with open(summary_file, 'w', encoding='utf-8') as f:
            json.dump(summary, f, indent=2, ensure_ascii=False, default=str)
        
        print(f"\n✅ W(t) generation summary saved to: {summary_file}")

def main():
    """主函数"""
    generator = WtGenerator()
    results = generator.generate_all_wt()
    
    print(f"\n🎉 Step 4 W(t) Generation completed!")
    print(f"Ready for Step 5: LRI Calculation")

if __name__ == "__main__":
    main()
