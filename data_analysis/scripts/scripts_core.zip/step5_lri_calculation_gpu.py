#!/usr/bin/env python3
"""
Step 5: LRI Calculation and Time Aggregation (GPU-Accelerated)
================================================================

This script performs LRI (Load Recovery Index) calculation with time aggregation
using GPU acceleration and multi-threading for optimal performance.

Features:
- Multi-threading for parallel processing across datasets
- GPU acceleration for signal processing operations
- Time aggregation with multiple window sizes (60s, 300s, 900s)
- Clustering analysis with stability validation
- Comprehensive output with per-session/per-day LRI metrics

Author: AI Assistant
Date: 2025-01-05
"""

import os
import sys
import json
import time
import logging
import warnings
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Tuple, Optional, Any
from concurrent.futures import ThreadPoolExecutor, as_completed
import multiprocessing as mp

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset
import torch.multiprocessing as torch_mp

from scipy import signal
from scipy.stats import pearsonr
from sklearn.cluster import KMeans
from sklearn.mixture import GaussianMixture
from sklearn.metrics import silhouette_score, calinski_harabasz_score
from sklearn.model_selection import ParameterGrid
from sklearn.preprocessing import StandardScaler
import joblib

# Suppress warnings for cleaner output
warnings.filterwarnings('ignore')
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('step5_lri_calculation.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class LRICalculator:
    """GPU-accelerated LRI calculator with multi-threading support."""
    
    def __init__(self, device: str = 'auto', n_threads: int = None):
        """
        Initialize LRI calculator.
        
        Args:
            device: Device to use ('auto', 'cuda', 'cpu')
            n_threads: Number of threads for parallel processing
        """
        self.device = self._setup_device(device)
        self.n_threads = n_threads or min(mp.cpu_count(), 8)
        
        # Time aggregation windows (in seconds)
        self.window_sizes = [60, 300, 900]  # 1min, 5min, 15min
        
        # Clustering parameters
        self.cluster_range = range(2, 11)  # K from 2 to 10
        self.bootstrap_samples = 100
        
        # Results storage
        self.results = {}
        
        logger.info(f"Initialized LRI Calculator on {self.device} with {self.n_threads} threads")
    
    def _setup_device(self, device: str) -> torch.device:
        """Setup computation device with RTX 5080 compatibility."""
        if device == 'auto':
            if torch.cuda.is_available():
                device = 'cuda'
                logger.info(f"CUDA available: {torch.cuda.get_device_name()}")
                logger.info(f"CUDA capability: {torch.cuda.get_device_capability()}")
                
                # RTX 5080 with PyTorch nightly should be compatible
                capability = torch.cuda.get_device_capability()
                if capability >= (12, 0):  # RTX 5080 has sm_120
                    logger.info(f"RTX 5080 detected (sm_{capability[0]}{capability[1]}) - PyTorch nightly should support this")
                    # Keep using CUDA - PyTorch nightly supports RTX 5080
            else:
                device = 'cpu'
                logger.info("CUDA not available, using CPU")
        
        return torch.device(device)
    
    def load_wt_data(self, file_path: str) -> pd.DataFrame:
        """Load W(t) time series data."""
        try:
            df = pd.read_parquet(file_path)
            logger.info(f"Loaded W(t) data: {df.shape} from {file_path}")
            
            # Ensure we have required columns
            required_cols = ['timestamp', 'W_t']
            missing_cols = [col for col in required_cols if col not in df.columns]
            if missing_cols:
                logger.warning(f"Missing columns: {missing_cols}")
                # Try to infer timestamp column
                if 'timestamp' not in df.columns:
                    if 'time' in df.columns:
                        df['timestamp'] = df['time']
                    elif df.index.name == 'timestamp':
                        df = df.reset_index()
                    else:
                        # Create synthetic timestamp
                        df['timestamp'] = pd.date_range(start='2020-01-01', periods=len(df), freq='1s')
            
            # Convert timestamp to datetime if needed
            if not pd.api.types.is_datetime64_any_dtype(df['timestamp']):
                df['timestamp'] = pd.to_datetime(df['timestamp'])
            
            return df
            
        except Exception as e:
            logger.error(f"Error loading {file_path}: {e}")
            raise
    
    def extract_recovery_features(self, wt_series: torch.Tensor, 
                                 window_size: int = 300) -> Dict[str, float]:
        """
        Extract recovery features from W(t) series using device-optimized processing.
        
        Args:
            wt_series: W(t) time series tensor
            window_size: Window size in seconds
            
        Returns:
            Dictionary of recovery features
        """
        try:
            # Move to device (CPU for RTX 5080 compatibility)
            wt_device = wt_series.to(self.device)
            
            # Calculate recovery ratio (time spent in recovery vs total time)
            threshold = torch.quantile(wt_device, 0.7)  # 70th percentile as threshold
            recovery_mask = wt_device < threshold
            recovery_ratio = recovery_mask.float().mean().item()
            
            # Calculate peak frequency using FFT
            fft = torch.fft.fft(wt_device)
            freqs = torch.fft.fftfreq(len(wt_device))
            power_spectrum = torch.abs(fft) ** 2
            
            # Find dominant frequency
            peak_freq_idx = torch.argmax(power_spectrum[1:len(power_spectrum)//2]) + 1
            peak_frequency = freqs[peak_freq_idx].item()
            
            # Calculate recovery time (time to return to baseline after peaks)
            # Find peaks
            peaks, _ = self._find_peaks_gpu(wt_device)
            
            recovery_times = []
            if len(peaks) > 0:
                for peak_idx in peaks:
                    peak_val = wt_device[peak_idx]
                    baseline = torch.quantile(wt_device, 0.3)
                    
                    # Find recovery point (where W(t) returns to baseline)
                    post_peak = wt_device[peak_idx:]
                    recovery_point = torch.where(post_peak <= baseline)[0]
                    
                    if len(recovery_point) > 0:
                        recovery_time = recovery_point[0].item()
                        recovery_times.append(recovery_time)
            
            avg_recovery_time = np.mean(recovery_times) if recovery_times else 0.0
            
            # Calculate variance in recovery
            recovery_variance = wt_device.var().item()
            
            # Calculate trend (linear slope)
            x = torch.arange(len(wt_device), device=self.device).float()
            # Convert to numpy for polyfit calculation
            x_np = x.cpu().numpy()
            wt_np = wt_device.cpu().numpy()
            slope = np.polyfit(x_np, wt_np, 1)[0]
            
            return {
                'recovery_ratio': recovery_ratio,
                'peak_frequency': abs(peak_frequency),
                'avg_recovery_time': avg_recovery_time,
                'recovery_variance': recovery_variance,
                'trend_slope': slope
            }
            
        except Exception as e:
            logger.error(f"Error extracting recovery features: {e}")
            return {
                'recovery_ratio': 0.0,
                'peak_frequency': 0.0,
                'avg_recovery_time': 0.0,
                'recovery_variance': 0.0,
                'trend_slope': 0.0
            }
    
    def _find_peaks_gpu(self, signal: torch.Tensor, height: float = None) -> Tuple[torch.Tensor, torch.Tensor]:
        """Find peaks in signal using GPU operations."""
        try:
            if height is None:
                height = torch.quantile(signal, 0.8)
            
            # Simple peak detection: local maxima above threshold
            diff = torch.diff(signal)
            sign_changes = torch.diff(torch.sign(diff))
            peaks = torch.where((sign_changes < 0) & (signal[1:-1] > height))[0] + 1
            
            return peaks, torch.tensor([])
            
        except Exception as e:
            logger.warning(f"Error in peak detection: {e}")
            return torch.tensor([]), torch.tensor([])
    
    def time_aggregation(self, df: pd.DataFrame, window_size: int) -> pd.DataFrame:
        """
        Perform time aggregation of W(t) data.
        
        Args:
            df: DataFrame with timestamp and W_t columns
            window_size: Window size in seconds
            
        Returns:
            Aggregated DataFrame with LRI features
        """
        try:
            # Set timestamp as index
            df_indexed = df.set_index('timestamp').copy()
            
            # Resample to window_size seconds and aggregate
            resampled = df_indexed.resample(f'{window_size}s').agg({
                'W_t': ['mean', 'std', 'max', 'min', 'count']
            }).dropna()
            
            # Flatten column names
            resampled.columns = [f'wt_{col[1]}' for col in resampled.columns]
            
            # Calculate additional features for each window
            lri_features = []
            
            for window_start, window_data in df_indexed.resample(f'{window_size}s'):
                if len(window_data) < 10:  # Skip windows with too few points
                    continue
                
                wt_series = torch.tensor(window_data['W_t'].values, dtype=torch.float32)
                features = self.extract_recovery_features(wt_series, window_size)
                
                # Add window metadata
                features.update({
                    'window_start': window_start,
                    'window_size': window_size,
                    'data_points': len(window_data)
                })
                
                lri_features.append(features)
            
            # Create LRI DataFrame
            lri_df = pd.DataFrame(lri_features)
            
            # Merge with resampled data
            if not lri_df.empty and not resampled.empty:
                lri_df = lri_df.set_index('window_start')
                result = pd.concat([resampled, lri_df], axis=1, join='inner')
            else:
                result = lri_df.set_index('window_start') if not lri_df.empty else resampled
            
            logger.info(f"Time aggregation completed: {len(result)} windows of {window_size}s")
            return result
            
        except Exception as e:
            logger.error(f"Error in time aggregation: {e}")
            return pd.DataFrame()
    
    def clustering_analysis(self, features_df: pd.DataFrame, 
                           dataset_name: str) -> Dict[str, Any]:
        """
        Perform clustering analysis with stability validation.
        
        Args:
            features_df: DataFrame with LRI features
            dataset_name: Name of the dataset
            
        Returns:
            Dictionary with clustering results
        """
        try:
            if len(features_df) < 20:  # Need sufficient data for clustering
                logger.warning(f"Insufficient data for clustering: {len(features_df)} samples")
                return {'error': 'Insufficient data for clustering'}
            
            # Select numerical features for clustering
            feature_cols = [col for col in features_df.columns 
                          if col not in ['window_start', 'window_size', 'data_points']]
            
            X = features_df[feature_cols].fillna(0)
            
            # Standardize features
            scaler = StandardScaler()
            X_scaled = scaler.fit_transform(X)
            
            # Bootstrap stability analysis
            stability_scores = {}
            silhouette_scores = {}
            calinski_scores = {}
            
            for k in self.cluster_range:
                if k >= len(X_scaled):
                    continue
                
                k_silhouettes = []
                k_calinskis = []
                
                # Bootstrap sampling for stability
                for _ in range(self.bootstrap_samples):
                    try:
                        # Sample with replacement
                        indices = np.random.choice(len(X_scaled), len(X_scaled), replace=True)
                        X_bootstrap = X_scaled[indices]
                        
                        # KMeans clustering
                        kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
                        labels = kmeans.fit_predict(X_bootstrap)
                        
                        if len(np.unique(labels)) > 1:  # Ensure we have multiple clusters
                            sil_score = silhouette_score(X_bootstrap, labels)
                            cal_score = calinski_harabasz_score(X_bootstrap, labels)
                            
                            k_silhouettes.append(sil_score)
                            k_calinskis.append(cal_score)
                    
                    except Exception as e:
                        logger.debug(f"Bootstrap error for k={k}: {e}")
                        continue
                
                if k_silhouettes:
                    stability_scores[k] = {
                        'silhouette_mean': np.mean(k_silhouettes),
                        'silhouette_std': np.std(k_silhouettes),
                        'calinski_mean': np.mean(k_calinskis),
                        'calinski_std': np.std(k_calinskis),
                        'stability': 1.0 / (1.0 + np.std(k_silhouettes))  # Higher is more stable
                    }
            
            # Select optimal K
            if stability_scores:
                optimal_k = max(stability_scores.keys(), 
                              key=lambda k: stability_scores[k]['stability'])
                
                # Final clustering with optimal K
                final_kmeans = KMeans(n_clusters=optimal_k, random_state=42, n_init=10)
                final_labels = final_kmeans.fit_predict(X_scaled)
                
                # GMM comparison
                gmm = GaussianMixture(n_components=optimal_k, random_state=42)
                gmm_labels = gmm.fit_predict(X_scaled)
                
                results = {
                    'optimal_k': optimal_k,
                    'stability_scores': stability_scores,
                    'kmeans_labels': final_labels.tolist(),
                    'gmm_labels': gmm_labels.tolist(),
                    'kmeans_centers': final_kmeans.cluster_centers_.tolist(),
                    'gmm_means': gmm.means_.tolist(),
                    'gmm_covariances': gmm.covariances_.tolist(),
                    'feature_names': feature_cols,
                    'scaler_params': {
                        'mean': scaler.mean_.tolist(),
                        'scale': scaler.scale_.tolist()
                    }
                }
                
                logger.info(f"Clustering completed for {dataset_name}: optimal K={optimal_k}")
                return results
            
            else:
                logger.warning(f"No stable clustering found for {dataset_name}")
                return {'error': 'No stable clustering found'}
                
        except Exception as e:
            logger.error(f"Error in clustering analysis: {e}")
            return {'error': str(e)}
    
    def process_dataset(self, dataset_name: str, wt_file: str) -> Dict[str, Any]:
        """
        Process a single dataset for LRI calculation.
        
        Args:
            dataset_name: Name of the dataset
            wt_file: Path to W(t) time series file
            
        Returns:
            Dictionary with LRI results for the dataset
        """
        try:
            logger.info(f"Processing dataset: {dataset_name}")
            
            # Load W(t) data
            wt_df = self.load_wt_data(wt_file)
            
            if wt_df.empty:
                logger.warning(f"Empty dataset: {dataset_name}")
                return {'error': 'Empty dataset'}
            
            results = {
                'dataset_name': dataset_name,
                'processing_timestamp': datetime.now().isoformat(),
                'original_data_shape': wt_df.shape,
                'window_results': {},
                'clustering_results': {}
            }
            
            # Process each window size
            for window_size in self.window_sizes:
                logger.info(f"Processing window size: {window_size}s for {dataset_name}")
                
                # Time aggregation
                aggregated_df = self.time_aggregation(wt_df, window_size)
                
                if aggregated_df.empty:
                    logger.warning(f"No data after aggregation for {window_size}s window")
                    continue
                
                # Clustering analysis
                clustering_results = self.clustering_analysis(aggregated_df, 
                                                            f"{dataset_name}_{window_size}s")
                
                # Store results
                results['window_results'][f'{window_size}s'] = {
                    'aggregated_data_shape': aggregated_df.shape,
                    'clustering_results': clustering_results,
                    'aggregated_data': aggregated_df.to_dict('records') if not aggregated_df.empty else []
                }
            
            logger.info(f"Completed processing: {dataset_name}")
            return results
            
        except Exception as e:
            logger.error(f"Error processing {dataset_name}: {e}")
            return {'error': str(e), 'dataset_name': dataset_name}
    
    def save_results(self, results: Dict[str, Any], output_dir: str):
        """Save LRI results to files."""
        try:
            output_path = Path(output_dir)
            output_path.mkdir(parents=True, exist_ok=True)
            
            for dataset_name, dataset_results in results.items():
                if 'error' in dataset_results:
                    continue
                
                # Save LRI CSV files
                for window_name, window_data in dataset_results.get('window_results', {}).items():
                    if window_data.get('aggregated_data'):
                        csv_file = output_path / f"lri_{dataset_name}_{window_name}.csv"
                        lri_df = pd.DataFrame(window_data['aggregated_data'])
                        lri_df.to_csv(csv_file, index=False)
                        logger.info(f"Saved LRI data: {csv_file}")
                
                # Save clustering results
                clustering_file = output_path / f"lri_clusters_{dataset_name}.json"
                clustering_data = {
                    'dataset_name': dataset_name,
                    'timestamp': dataset_results.get('processing_timestamp'),
                    'clustering_results': dataset_results.get('clustering_results', {}),
                    'window_results': {
                        window: data.get('clustering_results', {})
                        for window, data in dataset_results.get('window_results', {}).items()
                    }
                }
                
                with open(clustering_file, 'w') as f:
                    json.dump(clustering_data, f, indent=2)
                logger.info(f"Saved clustering results: {clustering_file}")
            
            # Save summary
            summary_file = output_path / "lri_processing_summary.json"
            summary_data = {
                'processing_timestamp': datetime.now().isoformat(),
                'datasets_processed': len(results),
                'window_sizes': self.window_sizes,
                'cluster_range': list(self.cluster_range),
                'bootstrap_samples': self.bootstrap_samples,
                'device_used': str(self.device),
                'n_threads': self.n_threads,
                'results_summary': {
                    name: {
                        'status': 'success' if 'error' not in data else 'error',
                        'windows_processed': len(data.get('window_results', {})),
                        'error': data.get('error')
                    }
                    for name, data in results.items()
                }
            }
            
            with open(summary_file, 'w') as f:
                json.dump(summary_data, f, indent=2)
            logger.info(f"Saved processing summary: {summary_file}")
            
        except Exception as e:
            logger.error(f"Error saving results: {e}")

def main():
    """Main execution function."""
    try:
        logger.info("Starting Step 5: LRI Calculation and Time Aggregation")
        
        # Setup paths - use absolute path for WSL environment
        processed_dir = Path("/mnt/d/data_analysis/processed")
        wt_dir = processed_dir / "wt_generation"
        output_dir = processed_dir / "lri_calculation"
        
        # Define correct W(t) files based on complete data processing log
        # Priority: use full_sample/complete versions over partial samples
        # NOTE: Nurses dataset has W(t) quality issues (mostly zeros), skipping for now
        wt_file_mapping = {
            'CRWD': 'wt_timeseries_CRWD.parquet',  # 79,639 rows - complete, good quality
            'SWELL': 'wt_timeseries_SWELL_complete.parquet',  # 410,322 rows - complete
            'WESAD': 'wt_timeseries_WESAD_full_sample.parquet',  # 6,844,593 rows - full sample, good quality
            'Nurses': 'wt_timeseries_Nurses_wsl_gpu.parquet',  # 16,864,933 rows - using correct file with good quality
            'MMASH': 'wt_timeseries_MMASH.parquet',  # complete
            'Mental_Health_Pred': 'wt_timeseries_Mental_Health_Pred.parquet',  # complete
            'DRIVE_DB': 'wt_timeseries_DRIVE_DB_full_sample.parquet',  # 1,326,089 rows - full sample
            'Non_EEG': 'wt_timeseries_Non_EEG_full_sample.parquet'  # 415,081 rows - full sample
        }
        
        # Find existing files
        wt_files = []
        for dataset_name, filename in wt_file_mapping.items():
            file_path = wt_dir / filename
            if file_path.exists():
                wt_files.append((dataset_name, str(file_path)))
                logger.info(f"Found {dataset_name}: {filename}")
            else:
                logger.warning(f"Missing {dataset_name}: {filename}")
        
        if not wt_files:
            logger.error("No valid W(t) time series files found!")
            return
        
        logger.info(f"Processing {len(wt_files)} complete W(t) datasets")
        
        # Initialize LRI calculator
        calculator = LRICalculator(device='auto', n_threads=8)
        
        # Process datasets in parallel
        results = {}
        
        with ThreadPoolExecutor(max_workers=calculator.n_threads) as executor:
            # Submit tasks
            future_to_dataset = {}
            for dataset_name, wt_file in wt_files:
                future = executor.submit(calculator.process_dataset, dataset_name, wt_file)
                future_to_dataset[future] = dataset_name
            
            # Collect results
            for future in as_completed(future_to_dataset):
                dataset_name = future_to_dataset[future]
                try:
                    result = future.result()
                    results[dataset_name] = result
                    logger.info(f"Completed: {dataset_name}")
                except Exception as e:
                    logger.error(f"Error processing {dataset_name}: {e}")
                    results[dataset_name] = {'error': str(e), 'dataset_name': dataset_name}
        
        # Save results
        calculator.save_results(results, str(output_dir))
        
        # Print summary
        successful = sum(1 for r in results.values() if 'error' not in r)
        failed = len(results) - successful
        
        logger.info(f"Step 5 completed successfully!")
        logger.info(f"Datasets processed: {successful}/{len(results)}")
        logger.info(f"Successful: {successful}, Failed: {failed}")
        
        if failed > 0:
            logger.warning("Failed datasets:")
            for name, result in results.items():
                if 'error' in result:
                    logger.warning(f"  {name}: {result['error']}")
        
    except Exception as e:
        logger.error(f"Fatal error in main: {e}")
        raise

if __name__ == "__main__":
    main()
