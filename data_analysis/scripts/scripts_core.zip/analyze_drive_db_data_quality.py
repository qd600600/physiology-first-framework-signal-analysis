#!/usr/bin/env python3
"""
数据质量分析：重点分析DRIVE_DB数据集的异常情况
深入分析为什么DRIVE_DB表现相对合理而其他数据集过拟合
"""

import os
import sys
import logging
import pandas as pd
import numpy as np
from pathlib import Path
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('analyze_drive_db_data_quality.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

def compare_datasets_quality():
    """比较所有数据集的数据质量"""
    try:
        logger.info("Comparing data quality across all datasets")
        
        datasets = ['CRWD', 'SWELL', 'DRIVE_DB']
        window_sizes = ['60s', '300s']
        
        comparison_results = {}
        
        for dataset in datasets:
            comparison_results[dataset] = {}
            
            for window_size in window_sizes:
                # 加载清理后的数据
                clean_file = f"/mnt/d/data_analysis/processed/lri_calculation/lri_{dataset}_{window_size}_clean.csv"
                
                if Path(clean_file).exists():
                    df = pd.read_csv(clean_file)
                    
                    # 分析数据质量指标
                    quality_metrics = analyze_dataset_quality(df, dataset, window_size)
                    comparison_results[dataset][window_size] = quality_metrics
                    
                    logger.info(f"{dataset}_{window_size}: {quality_metrics}")
                else:
                    logger.warning(f"Clean file not found: {clean_file}")
        
        return comparison_results
        
    except Exception as e:
        logger.error(f"Error comparing datasets: {e}")
        return None

def analyze_dataset_quality(df: pd.DataFrame, dataset_name: str, window_size: str) -> dict:
    """分析单个数据集的质量指标"""
    try:
        # 排除非特征列
        exclude_cols = ['window_id', 'window_size_seconds', 'sample_count']
        feature_cols = [col for col in df.columns if col not in exclude_cols]
        
        # 找到目标变量
        target_candidates = ['recovery_pattern_score', 'stress_release_efficiency', 'volatility_recovery_index', 'trend_recovery_score']
        target_col = None
        for candidate in target_candidates:
            if candidate in df.columns:
                target_col = candidate
                break
        
        if not target_col:
            logger.error(f"No target variable found in {dataset_name}_{window_size}")
            return {}
        
        feature_cols = [col for col in feature_cols if col != target_col]
        
        # 计算质量指标
        quality_metrics = {
            'dataset_name': dataset_name,
            'window_size': window_size,
            'data_shape': df.shape,
            'target_variable': target_col,
            'feature_count': len(feature_cols),
            'sample_count': len(df),
            'target_stats': {
                'mean': df[target_col].mean(),
                'std': df[target_col].std(),
                'min': df[target_col].min(),
                'max': df[target_col].max(),
                'nunique': df[target_col].nunique()
            },
            'feature_correlations': {},
            'data_complexity': {},
            'noise_level': {}
        }
        
        # 计算特征与目标的相关性
        for feature in feature_cols:
            corr = df[feature].corr(df[target_col])
            quality_metrics['feature_correlations'][feature] = corr
        
        # 计算数据复杂度指标
        quality_metrics['data_complexity'] = {
            'max_feature_correlation': max([abs(corr) for corr in quality_metrics['feature_correlations'].values()]),
            'mean_feature_correlation': np.mean([abs(corr) for corr in quality_metrics['feature_correlations'].values()]),
            'feature_variance': np.mean([df[feature].var() for feature in feature_cols]),
            'target_variance': df[target_col].var()
        }
        
        # 计算噪声水平
        quality_metrics['noise_level'] = {
            'target_std_ratio': df[target_col].std() / df[target_col].mean() if df[target_col].mean() != 0 else 0,
            'feature_std_ratio': np.mean([df[feature].std() / df[feature].mean() for feature in feature_cols if df[feature].mean() != 0]),
            'outlier_ratio': calculate_outlier_ratio(df[target_col])
        }
        
        return quality_metrics
        
    except Exception as e:
        logger.error(f"Error analyzing dataset quality: {e}")
        return {}

def calculate_outlier_ratio(series: pd.Series) -> float:
    """计算异常值比例"""
    try:
        Q1 = series.quantile(0.25)
        Q3 = series.quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        
        outliers = series[(series < lower_bound) | (series > upper_bound)]
        return len(outliers) / len(series)
        
    except Exception as e:
        logger.warning(f"Error calculating outlier ratio: {e}")
        return 0.0

def deep_analyze_drive_db():
    """深度分析DRIVE_DB数据集的特殊性"""
    try:
        logger.info("Deep analysis of DRIVE_DB dataset")
        
        # 加载DRIVE_DB的原始数据
        wt_file = "/mnt/d/data_analysis/processed/wt_generation/wt_timeseries_DRIVE_DB_full_sample.parquet"
        if not Path(wt_file).exists():
            logger.error(f"DRIVE_DB W(t) file not found: {wt_file}")
            return None
        
        df = pd.read_parquet(wt_file)
        logger.info(f"Loaded DRIVE_DB W(t) data: {df.shape}")
        
        # 分析W(t)分布特征
        wt_analysis = {
            'wt_stats': {
                'mean': df['W_t'].mean(),
                'std': df['W_t'].std(),
                'min': df['W_t'].min(),
                'max': df['W_t'].max(),
                'median': df['W_t'].median(),
                'skewness': df['W_t'].skew(),
                'kurtosis': df['W_t'].kurtosis()
            },
            'wt_distribution': {
                'percentiles': {
                    '10th': df['W_t'].quantile(0.1),
                    '25th': df['W_t'].quantile(0.25),
                    '50th': df['W_t'].quantile(0.5),
                    '75th': df['W_t'].quantile(0.75),
                    '90th': df['W_t'].quantile(0.9)
                }
            },
            'temporal_patterns': {},
            'subject_variability': {}
        }
        
        # 分析时间模式（如果有时间信息）
        if 'timestamp' in df.columns:
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            df['hour'] = df['timestamp'].dt.hour
            
            # 按小时分析W(t)变化
            hourly_stats = df.groupby('hour')['W_t'].agg(['mean', 'std', 'count'])
            wt_analysis['temporal_patterns']['hourly_variation'] = {
                'hourly_means': hourly_stats['mean'].to_dict(),
                'hourly_stds': hourly_stats['std'].to_dict(),
                'max_hourly_std': hourly_stats['std'].max(),
                'min_hourly_std': hourly_stats['std'].min()
            }
        
        # 分析受试者变异性（如果有subject信息）
        subject_cols = [col for col in df.columns if 'subject' in col.lower() or 'participant' in col.lower()]
        if subject_cols:
            subject_col = subject_cols[0]
            subject_stats = df.groupby(subject_col)['W_t'].agg(['mean', 'std', 'count'])
            wt_analysis['subject_variability'] = {
                'subject_count': len(subject_stats),
                'mean_subject_std': subject_stats['std'].mean(),
                'max_subject_std': subject_stats['std'].max(),
                'min_subject_std': subject_stats['std'].min(),
                'subject_std_cv': subject_stats['std'].std() / subject_stats['std'].mean()
            }
        
        # 与CRWD和SWELL比较
        logger.info("Comparing DRIVE_DB with other datasets...")
        
        # 加载其他数据集进行对比
        comparison_datasets = ['CRWD', 'SWELL']
        for comp_dataset in comparison_datasets:
            comp_file = f"/mnt/d/data_analysis/processed/wt_generation/wt_timeseries_{comp_dataset}.parquet"
            if Path(comp_file).exists():
                comp_df = pd.read_parquet(comp_file)
                comp_wt_stats = {
                    'mean': comp_df['W_t'].mean(),
                    'std': comp_df['W_t'].std(),
                    'skewness': comp_df['W_t'].skew(),
                    'kurtosis': comp_df['W_t'].kurtosis()
                }
                wt_analysis[f'{comp_dataset}_comparison'] = comp_wt_stats
                
                logger.info(f"{comp_dataset} vs DRIVE_DB:")
                logger.info(f"  Mean: {comp_wt_stats['mean']:.3f} vs {wt_analysis['wt_stats']['mean']:.3f}")
                logger.info(f"  Std: {comp_wt_stats['std']:.3f} vs {wt_analysis['wt_stats']['std']:.3f}")
                logger.info(f"  Skewness: {comp_wt_stats['skewness']:.3f} vs {wt_analysis['wt_stats']['skewness']:.3f}")
        
        return wt_analysis
        
    except Exception as e:
        logger.error(f"Error in deep DRIVE_DB analysis: {e}")
        return None

def create_quality_report(comparison_results: dict, drive_db_analysis: dict):
    """创建数据质量报告"""
    try:
        logger.info("Creating comprehensive data quality report")
        
        report = {
            'analysis_timestamp': pd.Timestamp.now().isoformat(),
            'dataset_comparison': comparison_results,
            'drive_db_deep_analysis': drive_db_analysis,
            'key_findings': [],
            'recommendations': []
        }
        
        # 分析关键发现
        if comparison_results:
            # 找出DRIVE_DB的特殊之处
            drive_db_metrics = {}
            other_metrics = {}
            
            for dataset, windows in comparison_results.items():
                for window_size, metrics in windows.items():
                    if dataset == 'DRIVE_DB':
                        drive_db_metrics[f"{dataset}_{window_size}"] = metrics
                    else:
                        other_metrics[f"{dataset}_{window_size}"] = metrics
            
            # 比较数据复杂度
            if drive_db_metrics and other_metrics:
                drive_db_complexity = np.mean([m['data_complexity']['max_feature_correlation'] for m in drive_db_metrics.values()])
                other_complexity = np.mean([m['data_complexity']['max_feature_correlation'] for m in other_metrics.values()])
                
                report['key_findings'].append({
                    'finding': 'Feature correlation complexity',
                    'drive_db': drive_db_complexity,
                    'others': other_complexity,
                    'difference': drive_db_complexity - other_complexity
                })
                
                logger.info(f"Feature correlation complexity:")
                logger.info(f"  DRIVE_DB: {drive_db_complexity:.3f}")
                logger.info(f"  Others: {other_complexity:.3f}")
                logger.info(f"  Difference: {drive_db_complexity - other_complexity:.3f}")
        
        # 基于DRIVE_DB深度分析的关键发现
        if drive_db_analysis:
            wt_stats = drive_db_analysis['wt_stats']
            
            report['key_findings'].append({
                'finding': 'DRIVE_DB W(t) distribution characteristics',
                'details': {
                    'mean': wt_stats['mean'],
                    'std': wt_stats['std'],
                    'skewness': wt_stats['skewness'],
                    'kurtosis': wt_stats['kurtosis']
                }
            })
            
            # 判断分布特征
            if wt_stats['skewness'] > 1:
                skewness_interpretation = "highly right-skewed (many low values, few high values)"
            elif wt_stats['skewness'] < -1:
                skewness_interpretation = "highly left-skewed (many high values, few low values)"
            else:
                skewness_interpretation = "approximately normal"
            
            report['key_findings'].append({
                'finding': 'Distribution interpretation',
                'skewness_interpretation': skewness_interpretation,
                'implication': 'More natural variation in stress patterns'
            })
            
            logger.info(f"DRIVE_DB distribution interpretation: {skewness_interpretation}")
        
        # 生成建议
        report['recommendations'] = [
            "Use DRIVE_DB as the primary dataset for model validation",
            "Apply similar data preprocessing to other datasets",
            "Focus on datasets with natural variation patterns",
            "Consider the impact of experimental design on data quality"
        ]
        
        # 保存报告
        report_file = "/mnt/d/data_analysis/processed/drive_db_quality_analysis_report.json"
        import json
        with open(report_file, 'w') as f:
            json.dump(report, f, indent=2, default=str)
        
        logger.info(f"Quality analysis report saved: {report_file}")
        
        return report
        
    except Exception as e:
        logger.error(f"Error creating quality report: {e}")
        return None

def main():
    """主函数"""
    try:
        logger.info("Starting DRIVE_DB data quality analysis")
        
        # 1. 比较所有数据集的质量
        logger.info("Step 1: Comparing dataset quality")
        comparison_results = compare_datasets_quality()
        
        # 2. 深度分析DRIVE_DB
        logger.info("Step 2: Deep analysis of DRIVE_DB")
        drive_db_analysis = deep_analyze_drive_db()
        
        # 3. 创建质量报告
        logger.info("Step 3: Creating quality report")
        report = create_quality_report(comparison_results, drive_db_analysis)
        
        logger.info(f"\n{'='*60}")
        logger.info("DRIVE_DB Data Quality Analysis Completed!")
        logger.info(f"{'='*60}")
        
        if report:
            logger.info("Key findings:")
            for finding in report['key_findings']:
                logger.info(f"  • {finding}")
            
            logger.info("\nRecommendations:")
            for rec in report['recommendations']:
                logger.info(f"  • {rec}")
        
    except Exception as e:
        logger.error(f"Error in main execution: {e}")
        raise

if __name__ == "__main__":
    main()



