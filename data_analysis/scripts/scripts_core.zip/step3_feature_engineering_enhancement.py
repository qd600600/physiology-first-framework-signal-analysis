#!/usr/bin/env python3
"""
Step 3: 特征工程增强
目标：在保证数值稳定的前提下恢复模型性能

任务重点：
1. 特征恢复与扩展 - 从原始27特征中重新引入10-15个中等VIF特征
2. 模型过拟合排查与修正 - 检查数据泄露，采用重复KFold评估
3. 筛选策略优化 - 使用多维度指标联合筛选
4. 性能与稳定性评估 - 输出完整性能对比表
5. 报告生成 - 生成完整的Step 3审计报告
"""

import pandas as pd
import numpy as np
import torch
import json
import time
import sys
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import RobustScaler, StandardScaler, MinMaxScaler
from sklearn.model_selection import train_test_split, RepeatedKFold, GridSearchCV
from sklearn.ensemble import RandomForestRegressor, HistGradientBoostingRegressor
from sklearn.linear_model import Ridge, Lasso
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from sklearn.feature_selection import f_classif, mutual_info_regression, SelectKBest
from sklearn.inspection import permutation_importance
from statsmodels.stats.outliers_influence import variance_inflation_factor
import warnings
warnings.filterwarnings("ignore")

def print_progress(message, step=None, total_steps=None):
    """打印进度信息"""
    if step is not None and total_steps is not None:
        progress = (step / total_steps) * 100
        print(f"[{progress:5.1f}%] {message}")
    else:
        print(message)
    sys.stdout.flush()

print("=" * 70)
print("Step 3: 特征工程增强")
print("=" * 70)

# GPU检查
print_progress("🔍 GPU检查:")
print_progress(f"  CUDA可用: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print_progress(f"  GPU设备: {torch.cuda.get_device_name(0)}")
    print_progress(f"  GPU内存: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.1f} GB")
    device = torch.device('cuda')
    use_gpu = True
    torch.backends.cudnn.benchmark = True
    print_progress("  ✅ 启用CUDA优化")
else:
    print_progress("  ⚠️ CUDA不可用，将使用CPU")
    device = torch.device('cpu')
    use_gpu = False

class FeatureEngineeringEnhancer:
    """特征工程增强器"""
    
    def __init__(self, verbose=True):
        self.verbose = verbose
        self.feature_stats = {}
        self.gpu_memory_log = []
    
    def log_gpu_memory(self, step_name):
        """记录GPU内存使用"""
        if torch.cuda.is_available():
            memory_used = torch.cuda.memory_allocated() / (1024**3)
            self.gpu_memory_log.append({
                'step': step_name,
                'memory_gb': memory_used,
                'timestamp': time.time()
            })
            if self.verbose:
                print_progress(f"    📊 GPU内存: {memory_used:.2f} GB")
    
    def calculate_vif(self, X, max_vif=10):
        """计算VIF并筛选中等VIF特征"""
        if self.verbose:
            print_progress("  🔍 计算VIF值...")
        
        # 选择数值型特征
        numeric_cols = X.select_dtypes(include=[np.number]).columns
        X_numeric = X[numeric_cols].fillna(0)
        
        # 计算VIF
        vif_data = []
        for i, col in enumerate(X_numeric.columns):
            try:
                vif = variance_inflation_factor(X_numeric.values, i)
                vif_data.append({'feature': col, 'vif': vif})
            except:
                vif_data.append({'feature': col, 'vif': np.inf})
        
        vif_df = pd.DataFrame(vif_data)
        
        # 筛选中等VIF特征（1.5 < VIF < max_vif）
        medium_vif_features = vif_df[
            (vif_df['vif'] > 1.5) & (vif_df['vif'] < max_vif)
        ]['feature'].tolist()
        
        if self.verbose:
            print_progress(f"    📊 中等VIF特征: {len(medium_vif_features)} 个")
            print_progress(f"    📊 VIF范围: {vif_df['vif'].min():.2f} - {vif_df['vif'].max():.2f}")
        
        return medium_vif_features, vif_df
    
    def apply_multiscale_transforms(self, X, verbose=True):
        """应用多尺度变换"""
        if verbose:
            print_progress("  🔄 应用多尺度变换...")
        
        X_transformed = X.copy()
        numeric_cols = X.select_dtypes(include=[np.number]).columns
            
            for col in numeric_cols:
            if col in X.columns:
                # Log变换（处理正数）
                if (X[col] > 0).all():
                    X_transformed[f'{col}_log'] = np.log1p(X[col])
                
                # Z-score标准化
                X_transformed[f'{col}_zscore'] = (X[col] - X[col].mean()) / (X[col].std() + 1e-8)
                
                # MinMax标准化
                X_transformed[f'{col}_minmax'] = (X[col] - X[col].min()) / (X[col].max() - X[col].min() + 1e-8)
        
        if verbose:
            print_progress(f"    ✅ 多尺度变换完成: {X.shape[1]} -> {X_transformed.shape[1]} 特征")
        
        return X_transformed
    
    def create_interaction_features(self, X, max_interactions=20, verbose=True):
        """创建交互特征"""
        if verbose:
            print_progress("  🔗 创建交互特征...")
        
        X_interaction = X.copy()
        numeric_cols = X.select_dtypes(include=[np.number]).columns
        
        # 限制交互特征数量
        if len(numeric_cols) > 10:
            numeric_cols = numeric_cols[:10]
        
        interaction_count = 0
        for i, col1 in enumerate(numeric_cols):
            for j, col2 in enumerate(numeric_cols[i+1:], i+1):
                if interaction_count >= max_interactions:
                    break
                
                # 乘积交互
                X_interaction[f'{col1}_x_{col2}'] = X[col1] * X[col2]
                
                # 差异交互
                X_interaction[f'{col1}_diff_{col2}'] = X[col1] - X[col2]
                
                # 比值交互（避免除0）
                X_interaction[f'{col1}_div_{col2}'] = X[col1] / (X[col2] + 1e-8)
                
                interaction_count += 3
                
                if interaction_count >= max_interactions:
                    break
            
            if interaction_count >= max_interactions:
                break
        
        if verbose:
            print_progress(f"    ✅ 交互特征创建完成: {X.shape[1]} -> {X_interaction.shape[1]} 特征")
        
        return X_interaction
    
    def multi_criteria_feature_selection(self, X, y, k=15, verbose=True):
        """多维度指标联合筛选"""
        if verbose:
            print_progress("  🎯 执行多维度特征筛选...")
        
        n_features = X.shape[1]
        
        # 1. F-test分数
        try:
            f_scores, _ = f_classif(X.fillna(0), y)
            f_scores = np.nan_to_num(f_scores, nan=0.0, posinf=0.0, neginf=0.0)
        except:
            f_scores = np.ones(n_features)
        
        # 2. 互信息分数
        try:
            mi_scores = mutual_info_regression(X.fillna(0), y, random_state=42)
            mi_scores = np.nan_to_num(mi_scores, nan=0.0, posinf=0.0, neginf=0.0)
        except:
            mi_scores = np.ones(n_features)
        
        # 3. 方差分数
        var_scores = X.var().values
        var_scores = np.nan_to_num(var_scores, nan=0.0, posinf=0.0, neginf=0.0)
        
        # 4. Permutation Importance（使用小样本）
        try:
            if len(X) > 10000:
                sample_idx = np.random.choice(len(X), size=10000, replace=False)
                X_sample = X.iloc[sample_idx]
                y_sample = y.iloc[sample_idx]
            else:
                X_sample = X
                y_sample = y
            
            model = RandomForestRegressor(n_estimators=50, random_state=42, n_jobs=-1)
            model.fit(X_sample.fillna(0), y_sample)
            
            perm_importance = permutation_importance(
                model, X_sample.fillna(0), y_sample, 
                n_repeats=3, random_state=42, n_jobs=-1
            )
            perm_scores = perm_importance.importances_mean
        except:
            perm_scores = np.ones(n_features)
        
        # 标准化各分数
        def normalize_scores(scores):
            scores = np.array(scores)
            if np.max(scores) - np.min(scores) > 1e-8:
                return (scores - np.min(scores)) / (np.max(scores) - np.min(scores))
            else:
                return np.ones_like(scores)
        
        f_scores_norm = normalize_scores(f_scores)
        mi_scores_norm = normalize_scores(mi_scores)
        var_scores_norm = normalize_scores(var_scores)
        perm_scores_norm = normalize_scores(perm_scores)
        
        # 综合评分
        combined_scores = (f_scores_norm + mi_scores_norm + var_scores_norm + perm_scores_norm) / 4
        
        # 选择前k个特征
        top_k_indices = np.argsort(combined_scores)[-k:]
        selected_features = X.columns[top_k_indices]
        X_selected = X[selected_features]
        
        # 创建特征评分表
        feature_scores_df = pd.DataFrame({
            'feature': X.columns,
            'f_test': f_scores_norm,
            'mutual_info': mi_scores_norm,
            'variance': var_scores_norm,
            'permutation': perm_scores_norm,
            'combined': combined_scores
        }).sort_values('combined', ascending=False)
        
        if verbose:
            print_progress(f"    ✅ 多维度筛选完成: {X.shape[1]} -> {X_selected.shape[1]} 特征")
            print_progress(f"    📊 前5个特征: {selected_features[:5].tolist()}")
        
        return X_selected, selected_features, feature_scores_df
    
    def check_data_leakage(self, X_train, X_test, y_train, y_test, verbose=True):
        """检查数据泄露"""
        if verbose:
            print_progress("  🔍 检查数据泄露...")
        
        leakage_indicators = {}
        
        # 1. 检查训练集和测试集的特征分布
        for col in X_train.columns:
            if X_train[col].dtype in ['float64', 'int64']:
                train_mean = X_train[col].mean()
                test_mean = X_test[col].mean()
                mean_diff = abs(train_mean - test_mean) / (abs(train_mean) + 1e-8)
                
                if mean_diff < 0.01:  # 均值差异小于1%
                    leakage_indicators[col] = {
                        'type': 'mean_similarity',
                        'train_mean': train_mean,
                        'test_mean': test_mean,
                        'difference': mean_diff
                    }
        
        # 2. 检查目标变量的分布
        y_train_mean = y_train.mean()
        y_test_mean = y_test.mean()
        y_mean_diff = abs(y_train_mean - y_test_mean) / (abs(y_train_mean) + 1e-8)
        
        if verbose:
            print_progress(f"    📊 目标变量均值差异: {y_mean_diff:.4f}")
            print_progress(f"    📊 可疑特征数量: {len(leakage_indicators)}")
        
        return leakage_indicators, y_mean_diff
    
    def evaluate_model_with_cv(self, X, y, model_type='rf', cv_folds=5, cv_repeats=3, verbose=True):
        """使用交叉验证评估模型"""
        if verbose:
            print_progress(f"  🔄 执行{cv_folds}x{cv_repeats}交叉验证...")
        
        # 准备模型
        if model_type == 'rf':
            model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
        elif model_type == 'gbm':
            model = HistGradientBoostingRegressor(
                max_iter=100, learning_rate=0.1, random_state=42, verbose=0
            )
        else:
            model = Ridge(alpha=1.0, random_state=42)
        
        # 交叉验证
        cv = RepeatedKFold(n_splits=cv_folds, n_repeats=cv_repeats, random_state=42)
        cv_scores = []
        
        for fold_idx, (train_idx, test_idx) in enumerate(cv.split(X)):
            X_train_fold, X_test_fold = X.iloc[train_idx], X.iloc[test_idx]
            y_train_fold, y_test_fold = y.iloc[train_idx], y.iloc[test_idx]
            
            # 标准化
            scaler = RobustScaler()
            X_train_scaled = scaler.fit_transform(X_train_fold.fillna(0))
            X_test_scaled = scaler.transform(X_test_fold.fillna(0))
            
            # 训练和预测
            model.fit(X_train_scaled, y_train_fold)
            y_pred = model.predict(X_test_scaled)
            
            # 计算R²
            r2 = r2_score(y_test_fold, y_pred)
            cv_scores.append(r2)
            
            if verbose and (fold_idx + 1) % 5 == 0:
                print_progress(f"    完成 {fold_idx + 1}/{cv_folds * cv_repeats} 折")
        
        cv_mean = np.mean(cv_scores)
        cv_std = np.std(cv_scores)
        
        if verbose:
            print_progress(f"    ✅ 交叉验证完成: R² = {cv_mean:.4f} ± {cv_std:.4f}")
        
        return cv_mean, cv_std, cv_scores

# ======= Step 1: 数据读取 =======
print_progress("\n📂 Step 1: 数据读取")
start_time = time.time()

print_progress("  📥 正在读取features_base.csv...")
base = pd.read_csv("features_base.csv")
print_progress(f"    ✅ Base特征加载完成: {base.shape}")

print_progress("  📥 正在读取features_extended.csv...")
extended = pd.read_csv("features_extended.csv")
print_progress(f"    ✅ Extended特征加载完成: {extended.shape}")

print_progress("  📥 正在读取labels.csv...")
y = pd.read_csv("labels.csv")["target"]
print_progress(f"    ✅ 标签加载完成: {len(y)} 个样本")

# 样本一致性检查
assert len(base) == len(extended) == len(y), "样本数量不一致"
print_progress(f"  ✅ 数据加载完成: {len(y)} 个样本")
print_progress(f"  ⏱️ 数据加载耗时: {time.time() - start_time:.2f}秒")

# ======= Step 2: 特征工程增强 =======
print_progress("\n🔧 Step 2: 特征工程增强")
enhancement_start = time.time()

enhancer = FeatureEngineeringEnhancer(verbose=True)

# 2.1 数据预处理
print_progress("  🧹 数据预处理...")
missing_ratio = extended.isna().sum() / len(extended)
high_missing_cols = missing_ratio[missing_ratio > 0.5].index.tolist()
extended_clean = extended.drop(columns=high_missing_cols)
extended_imputed = extended_clean.fillna(0)

enhancer.log_gpu_memory("数据预处理")

# 2.2 VIF特征筛选
print_progress("  🔍 VIF特征筛选...")
medium_vif_features, vif_df = enhancer.calculate_vif(extended_imputed, max_vif=10)

# 选择前15个中等VIF特征
if len(medium_vif_features) > 15:
    medium_vif_features = medium_vif_features[:15]

extended_vif = extended_imputed[medium_vif_features]
enhancer.log_gpu_memory("VIF筛选")

# 2.3 多尺度变换
print_progress("  🔄 多尺度变换...")
extended_multiscale = enhancer.apply_multiscale_transforms(extended_vif, verbose=True)
enhancer.log_gpu_memory("多尺度变换")

# 2.4 交互特征
print_progress("  🔗 交互特征创建...")
extended_interaction = enhancer.create_interaction_features(extended_multiscale, max_interactions=20, verbose=True)
enhancer.log_gpu_memory("交互特征")

# 2.5 多维度特征筛选
print_progress("  🎯 多维度特征筛选...")
extended_final, selected_features, feature_scores_df = enhancer.multi_criteria_feature_selection(
    extended_interaction, y, k=15, verbose=True)
enhancer.log_gpu_memory("多维度筛选")

print_progress(f"  ⏱️ 特征工程耗时: {time.time() - enhancement_start:.2f}秒")

# ======= Step 3: 数据泄露检查 =======
print_progress("\n🔍 Step 3: 数据泄露检查")
leakage_start = time.time()

# 数据划分
Xb_train, Xb_test, y_train, y_test = train_test_split(
    base, y, test_size=0.3, random_state=42)
Xe_train, Xe_test, _, _ = train_test_split(
    extended_final, y, test_size=0.3, random_state=42)

# 检查数据泄露
base_leakage, base_y_diff = enhancer.check_data_leakage(Xb_train, Xb_test, y_train, y_test, verbose=True)
extended_leakage, extended_y_diff = enhancer.check_data_leakage(Xe_train, Xe_test, y_train, y_test, verbose=True)

print_progress(f"  ⏱️ 数据泄露检查耗时: {time.time() - leakage_start:.2f}秒")

# ======= Step 4: 模型性能评估 =======
print_progress("\n📊 Step 4: 模型性能评估")
evaluation_start = time.time()

# 4.1 Base模型评估
print_progress("  🎯 Base模型评估...")
base_cv_mean, base_cv_std, base_cv_scores = enhancer.evaluate_model_with_cv(
    base, y, model_type='rf', cv_folds=5, cv_repeats=3, verbose=True)

# 4.2 Extended模型评估
print_progress("  🎯 Extended模型评估...")
extended_cv_mean, extended_cv_std, extended_cv_scores = enhancer.evaluate_model_with_cv(
    extended_final, y, model_type='rf', cv_folds=5, cv_repeats=3, verbose=True)

# 4.3 单次训练评估（用于详细指标）
print_progress("  🎯 单次训练评估...")
scaler = RobustScaler()
Xb_train_scaled = scaler.fit_transform(Xb_train.fillna(0))
Xb_test_scaled = scaler.transform(Xb_test.fillna(0))
Xe_train_scaled = scaler.fit_transform(Xe_train.fillna(0))
Xe_test_scaled = scaler.transform(Xe_test.fillna(0))

# Base模型
base_model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
base_model.fit(Xb_train_scaled, y_train)
y_pred_base = base_model.predict(Xb_test_scaled)

# Extended模型
extended_model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
extended_model.fit(Xe_train_scaled, y_train)
y_pred_extended = extended_model.predict(Xe_test_scaled)

# 计算详细指标
base_metrics = {
    'r2': r2_score(y_test, y_pred_base),
    'mae': mean_absolute_error(y_test, y_pred_base),
    'mse': mean_squared_error(y_test, y_pred_base),
    'rmse': np.sqrt(mean_squared_error(y_test, y_pred_base))
}

extended_metrics = {
    'r2': r2_score(y_test, y_pred_extended),
    'mae': mean_absolute_error(y_test, y_pred_extended),
    'mse': mean_squared_error(y_test, y_pred_extended),
    'rmse': np.sqrt(mean_squared_error(y_test, y_pred_extended))
}

print_progress(f"  ⏱️ 性能评估耗时: {time.time() - evaluation_start:.2f}秒")

# ======= Step 5: 结果保存 =======
print_progress("\n💾 Step 5: 结果保存")

results = {
    "step3_feature_engineering_enhancement": {
        "data_info": {
            "samples": len(y),
            "original_features": int(extended.shape[1]),
            "cleaned_features": int(extended_clean.shape[1]),
            "vif_features": int(len(medium_vif_features)),
            "multiscale_features": int(extended_multiscale.shape[1]),
            "interaction_features": int(extended_interaction.shape[1]),
            "final_features": int(extended_final.shape[1])
        },
        "vif_analysis": {
            "medium_vif_features": medium_vif_features,
            "vif_stats": {
                "min": float(vif_df['vif'].min()),
                "max": float(vif_df['vif'].max()),
                "mean": float(vif_df['vif'].mean()),
                "std": float(vif_df['vif'].std())
            }
        },
        "feature_scores": feature_scores_df.to_dict('records'),
        "data_leakage_check": {
            "base_suspicious_features": len(base_leakage),
            "extended_suspicious_features": len(extended_leakage),
            "base_y_mean_diff": float(base_y_diff),
            "extended_y_mean_diff": float(extended_y_diff)
        },
        "model_performance": {
            "base_model": {
                "cv_mean": float(base_cv_mean),
                "cv_std": float(base_cv_std),
                "single_train": base_metrics
            },
            "extended_model": {
                "cv_mean": float(extended_cv_mean),
                "cv_std": float(extended_cv_std),
                "single_train": extended_metrics
            },
            "improvement": {
                "cv_improvement": float(extended_cv_mean - base_cv_mean),
                "cv_improvement_percent": float((extended_cv_mean - base_cv_mean) / abs(base_cv_mean) * 100),
                "single_train_improvement": float(extended_metrics['r2'] - base_metrics['r2']),
                "single_train_improvement_percent": float((extended_metrics['r2'] - base_metrics['r2']) / abs(base_metrics['r2']) * 100)
            }
        },
        "performance_info": {
            "total_runtime_seconds": time.time() - start_time,
            "data_loading_time": time.time() - start_time - (time.time() - enhancement_start),
            "enhancement_time": time.time() - enhancement_start - (time.time() - leakage_start),
            "leakage_check_time": time.time() - leakage_start - (time.time() - evaluation_start),
            "evaluation_time": time.time() - evaluation_start
        },
        "gpu_memory_log": enhancer.gpu_memory_log,
        "gpu_info": {
            "cuda_available": torch.cuda.is_available(),
            "gpu_device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
            "gpu_memory_gb": torch.cuda.get_device_properties(0).total_memory / 1024**3 if torch.cuda.is_available() else None
        }
    }
}

print_progress("  💾 正在保存结果...")
with open("step3_feature_engineering_enhancement_results.json", "w") as f:
    json.dump(results, f, indent=4)

# 保存特征评分表
feature_scores_df.to_csv("step3_feature_scores.csv", index=False)

print_progress("  💾 正在保存特征评分表...")
with open("step3_feature_scores.csv", "w") as f:
    feature_scores_df.to_csv(f, index=False)

# ======= Step 6: 结果报告 =======
print_progress("\n📊 Step 6: 结果报告")
print("=" * 70)
print("Step 3: 特征工程增强结果")
print("=" * 70)
print(f"🔧 特征工程流程:")
print(f"  原始特征数: {extended.shape[1]}")
print(f"  清理后特征数: {extended_clean.shape[1]}")
print(f"  VIF筛选特征数: {len(medium_vif_features)}")
print(f"  多尺度变换后: {extended_multiscale.shape[1]}")
print(f"  交互特征后: {extended_interaction.shape[1]}")
print(f"  最终特征数: {extended_final.shape[1]}")
print(f"\n🔍 数据泄露检查:")
print(f"  Base模型可疑特征: {len(base_leakage)} 个")
print(f"  Extended模型可疑特征: {len(extended_leakage)} 个")
print(f"  目标变量均值差异: Base {base_y_diff:.4f}, Extended {extended_y_diff:.4f}")
print(f"\n📈 模型性能对比:")
print(f"  Base模型 CV R²: {base_cv_mean:.4f} ± {base_cv_std:.4f}")
print(f"  Extended模型 CV R²: {extended_cv_mean:.4f} ± {extended_cv_std:.4f}")
print(f"  交叉验证改善: {extended_cv_mean - base_cv_mean:.4f} ({(extended_cv_mean - base_cv_mean) / abs(base_cv_mean) * 100:.1f}%)")
print(f"  单次训练改善: {extended_metrics['r2'] - base_metrics['r2']:.4f} ({(extended_metrics['r2'] - base_metrics['r2']) / abs(base_metrics['r2']) * 100:.1f}%)")
print(f"\n⏱️ 性能信息:")
print(f"  总运行时间: {time.time() - start_time:.2f}秒")
print(f"  特征工程时间: {time.time() - enhancement_start - (time.time() - leakage_start):.2f}秒")
print(f"  性能评估时间: {time.time() - evaluation_start:.2f}秒")
print(f"\n✅ 结果文件:")
print(f"  step3_feature_engineering_enhancement_results.json - 完整结果")
print(f"  step3_feature_scores.csv - 特征评分表")
print("=" * 70)

print("🎉 Step 3: 特征工程增强完成！")