#!/usr/bin/env python3
"""
Step 6.1: Add Cross Validation Support
为Step 6添加交叉验证支持 - 解决审计发现的最严重问题
"""

import os
import sys
import logging
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from pathlib import Path
from datetime import datetime
from sklearn.model_selection import (
    train_test_split, cross_val_score, KFold, 
    TimeSeriesSplit, StratifiedKFold
)
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.svm import SVR
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from sklearn.preprocessing import StandardScaler
import joblib
import json
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('step6_1_cross_validation.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class PyTorchRegressionModel(nn.Module):
    """PyTorch神经网络回归模型，支持GPU加速."""
    
    def __init__(self, input_size: int, hidden_sizes: list = [64, 32, 16], dropout_rate: float = 0.2):
        super(PyTorchRegressionModel, self).__init__()
        
        layers = []
        prev_size = input_size
        
        for hidden_size in hidden_sizes:
            layers.extend([
                nn.Linear(prev_size, hidden_size),
                nn.ReLU(),
                nn.Dropout(dropout_rate)
            ])
            prev_size = hidden_size
        
        # Output layer
        layers.append(nn.Linear(prev_size, 1))
        
        self.network = nn.Sequential(*layers)
    
    def forward(self, x):
        return self.network(x)

class CrossValidationValidator:
    """带交叉验证的数据集验证器."""
    
    def __init__(self, device: str = 'auto', cv_folds: int = 5):
        self.device = self._setup_device(device)
        self.cv_folds = cv_folds
        
        # 模型定义
        self.models = {
            'RandomForest': RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=1),
            'GradientBoosting': GradientBoostingRegressor(n_estimators=100, random_state=42),
            'LinearRegression': LinearRegression(),
            'Ridge': Ridge(alpha=1.0),
            'Lasso': Lasso(alpha=0.1),
            'SVR': SVR(kernel='rbf', C=1.0, gamma='scale'),
            'PyTorch_NN': None  # Will be initialized per dataset
        }
        
        logger.info(f"Initialized CrossValidationValidator on {self.device} with {cv_folds}-fold CV")
    
    def _setup_device(self, device: str) -> torch.device:
        """Setup computation device."""
        if device == 'auto':
            if torch.cuda.is_available():
                device = 'cuda'
                logger.info(f"CUDA available: {torch.cuda.get_device_name()}")
                logger.info(f"CUDA capability: {torch.cuda.get_device_capability()}")
            else:
                device = 'cpu'
                logger.info("CUDA not available, using CPU")
        
        return torch.device(device)
    
    def load_fixed_lri_data(self, dataset_name: str, window_size: str) -> pd.DataFrame:
        """加载修复后的LRI数据."""
        try:
            file_path = f"/mnt/d/data_analysis/processed/lri_calculation/lri_{dataset_name}_{window_size}_fixed.csv"
            df = pd.read_csv(file_path)
            logger.info(f"Loaded fixed LRI data: {df.shape} from {file_path}")
            return df
        except Exception as e:
            logger.error(f"Error loading fixed LRI data for {dataset_name}_{window_size}: {e}")
            return pd.DataFrame()
    
    def prepare_features_and_target(self, df: pd.DataFrame) -> tuple:
        """准备特征和目标变量."""
        try:
            # 特征列（排除窗口元数据）
            exclude_cols = [
                'window_id', 'window_size_seconds', 'sample_count', 
                'start_time', 'end_time'
            ]
            
            # 目标变量选择
            target_col = 'recovery_ratio'
            if target_col not in df.columns or df[target_col].nunique() <= 1:
                target_col = 'stress_intensity'
                if target_col not in df.columns:
                    target_col = 'wt_mean'
            
            feature_cols = [col for col in df.columns if col not in exclude_cols + [target_col]]
            
            X = df[feature_cols].values
            y = df[target_col].values
            
            logger.info(f"Features shape: {X.shape}, Target shape: {y.shape}")
            logger.info(f"Target: {target_col}, Range: {y.min():.3f} to {y.max():.3f}")
            
            return X, y, feature_cols, target_col
            
        except Exception as e:
            logger.error(f"Error preparing features and target: {e}")
            return None, None, None, None
    
    def train_pytorch_model_with_cv(self, X: np.ndarray, y: np.ndarray, 
                                   feature_cols: list, cv_strategy: str = 'kfold') -> dict:
        """训练PyTorch模型并进行交叉验证."""
        try:
            # 数据标准化
            scaler_X = StandardScaler()
            scaler_y = StandardScaler()
            
            X_scaled = scaler_X.fit_transform(X)
            y_scaled = scaler_y.fit_transform(y.reshape(-1, 1)).flatten()
            
            # 选择交叉验证策略
            if cv_strategy == 'timeseries':
                cv = TimeSeriesSplit(n_splits=self.cv_folds)
            else:
                cv = KFold(n_splits=self.cv_folds, shuffle=True, random_state=42)
            
            # 交叉验证
            cv_scores = []
            cv_models = []
            
            for fold, (train_idx, val_idx) in enumerate(cv.split(X_scaled)):
                logger.info(f"Training PyTorch model - Fold {fold + 1}/{self.cv_folds}")
                
                X_train_fold = X_scaled[train_idx]
                y_train_fold = y_scaled[train_idx]
                X_val_fold = X_scaled[val_idx]
                y_val_fold = y_scaled[val_idx]
                
                # 转换为PyTorch张量
                X_train_tensor = torch.FloatTensor(X_train_fold).to(self.device)
                y_train_tensor = torch.FloatTensor(y_train_fold).to(self.device)
                X_val_tensor = torch.FloatTensor(X_val_fold).to(self.device)
                y_val_tensor = torch.FloatTensor(y_val_fold).to(self.device)
                
                # 创建模型
                model = PyTorchRegressionModel(
                    input_size=len(feature_cols),
                    hidden_sizes=[64, 32, 16],
                    dropout_rate=0.2
                ).to(self.device)
                
                # 损失函数和优化器
                criterion = nn.MSELoss()
                optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
                
                # 训练循环
                model.train()
                for epoch in range(100):  # 减少epoch数以加快速度
                    optimizer.zero_grad()
                    outputs = model(X_train_tensor).squeeze()
                    loss = criterion(outputs, y_train_tensor)
                    loss.backward()
                    optimizer.step()
                
                # 验证
                model.eval()
                with torch.no_grad():
                    val_pred = model(X_val_tensor).squeeze()
                    val_pred_cpu = val_pred.cpu().numpy()
                    val_true_cpu = y_val_tensor.cpu().numpy()
                    
                    # 反标准化
                    val_pred_original = scaler_y.inverse_transform(val_pred_cpu.reshape(-1, 1)).flatten()
                    val_true_original = scaler_y.inverse_transform(val_true_cpu.reshape(-1, 1)).flatten()
                    
                    r2 = r2_score(val_true_original, val_pred_original)
                    cv_scores.append(r2)
                    cv_models.append(model.state_dict().copy())
                
                logger.info(f"Fold {fold + 1} R²: {r2:.3f}")
            
            # 计算交叉验证统计
            cv_mean = np.mean(cv_scores)
            cv_std = np.std(cv_scores)
            
            logger.info(f"PyTorch NN Cross Validation - Mean R²: {cv_mean:.3f} ± {cv_std:.3f}")
            
            return {
                'cv_scores': cv_scores,
                'cv_mean': cv_mean,
                'cv_std': cv_std,
                'cv_strategy': cv_strategy,
                'models': cv_models,
                'scaler_X': scaler_X,
                'scaler_y': scaler_y
            }
            
        except Exception as e:
            logger.error(f"Error in PyTorch cross validation: {e}")
            return None
    
    def validate_with_cross_validation(self, dataset_name: str, window_size: str) -> dict:
        """带交叉验证的验证."""
        try:
            logger.info(f"=== Cross Validation for {dataset_name} - {window_size}s ===")
            
            # 1. 加载数据
            df = self.load_fixed_lri_data(dataset_name, window_size)
            if df.empty:
                return {'error': 'Failed to load data'}
            
            # 2. 准备特征和目标
            X, y, feature_cols, target_col = self.prepare_features_and_target(df)
            if X is None:
                return {'error': 'Failed to prepare features'}
            
            # 3. 标准模型交叉验证
            logger.info("Performing cross validation for standard models...")
            
            cv_results = {}
            
            # K折交叉验证
            kfold_cv = KFold(n_splits=self.cv_folds, shuffle=True, random_state=42)
            
            for model_name, model in self.models.items():
                if model is None:  # Skip PyTorch model for now
                    continue
                
                logger.info(f"Cross validating {model_name}...")
                
                # 使用sklearn的cross_val_score
                cv_scores = cross_val_score(
                    model, X, y, cv=kfold_cv, scoring='r2', n_jobs=-1
                )
                
                cv_results[model_name] = {
                    'cv_scores': cv_scores.tolist(),
                    'cv_mean': cv_scores.mean(),
                    'cv_std': cv_scores.std(),
                    'cv_strategy': 'KFold'
                }
                
                logger.info(f"{model_name} - CV Mean R²: {cv_scores.mean():.3f} ± {cv_scores.std():.3f}")
            
            # 4. 时间序列交叉验证
            logger.info("Performing time series cross validation...")
            
            timeseries_cv = TimeSeriesSplit(n_splits=self.cv_folds)
            timeseries_results = {}
            
            for model_name, model in self.models.items():
                if model is None:  # Skip PyTorch model for now
                    continue
                
                logger.info(f"Time series cross validating {model_name}...")
                
                cv_scores = cross_val_score(
                    model, X, y, cv=timeseries_cv, scoring='r2', n_jobs=-1
                )
                
                timeseries_results[model_name] = {
                    'cv_scores': cv_scores.tolist(),
                    'cv_mean': cv_scores.mean(),
                    'cv_std': cv_scores.std(),
                    'cv_strategy': 'TimeSeriesSplit'
                }
                
                logger.info(f"{model_name} - TS CV Mean R²: {cv_scores.mean():.3f} ± {cv_scores.std():.3f}")
            
            # 5. PyTorch模型交叉验证
            logger.info("Performing PyTorch neural network cross validation...")
            pytorch_results = self.train_pytorch_model_with_cv(X, y, feature_cols, 'kfold')
            
            # 6. 最终评估（留出法）
            logger.info("Performing holdout evaluation...")
            
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42
            )
            
            holdout_results = {}
            for model_name, model in self.models.items():
                if model is None:  # Skip PyTorch model for now
                    continue
                
                model.fit(X_train, y_train)
                y_pred = model.predict(X_test)
                
                holdout_results[model_name] = {
                    'mse': mean_squared_error(y_test, y_pred),
                    'r2': r2_score(y_test, y_pred),
                    'mae': mean_absolute_error(y_test, y_pred)
                }
                
                logger.info(f"{model_name} Holdout R²: {r2_score(y_test, y_pred):.3f}")
            
            # 7. 选择最佳模型
            best_kfold_model = max(
                cv_results.keys(),
                key=lambda x: cv_results[x]['cv_mean']
            )
            
            best_timeseries_model = max(
                timeseries_results.keys(),
                key=lambda x: timeseries_results[x]['cv_mean']
            )
            
            best_holdout_model = max(
                holdout_results.keys(),
                key=lambda x: holdout_results[x]['r2']
            )
            
            logger.info(f"Best K-fold model: {best_kfold_model} (R² = {cv_results[best_kfold_model]['cv_mean']:.3f})")
            logger.info(f"Best Time Series model: {best_timeseries_model} (R² = {timeseries_results[best_timeseries_model]['cv_mean']:.3f})")
            logger.info(f"Best Holdout model: {best_holdout_model} (R² = {holdout_results[best_holdout_model]['r2']:.3f})")
            
            # 8. 返回结果
            results = {
                'dataset_name': dataset_name,
                'window_size': window_size,
                'target_variable': target_col,
                'data_shape': X.shape,
                'feature_columns': feature_cols,
                'cross_validation_results': {
                    'kfold': cv_results,
                    'timeseries': timeseries_results,
                    'pytorch': pytorch_results
                },
                'holdout_results': holdout_results,
                'best_models': {
                    'kfold': best_kfold_model,
                    'timeseries': best_timeseries_model,
                    'holdout': best_holdout_model
                },
                'validation_timestamp': datetime.now().isoformat()
            }
            
            logger.info(f"=== Completed cross validation for {dataset_name} - {window_size}s ===")
            
            return results
            
        except Exception as e:
            logger.error(f"Error in cross validation for {dataset_name}_{window_size}: {e}")
            return {'error': str(e)}

def main():
    """主函数."""
    try:
        logger.info("Starting Step 6.1: Add Cross Validation Support")
        
        # 数据集配置
        datasets = ['CRWD', 'SWELL', 'WESAD', 'Nurses', 'MMASH', 
                   'Mental_Health_Pred', 'DRIVE_DB', 'Non_EEG']
        window_sizes = ['60s', '300s', '900s']
        
        output_dir = '/mnt/d/data_analysis/processed/step6_cross_validation'
        Path(output_dir).mkdir(exist_ok=True)
        
        # 初始化交叉验证器
        validator = CrossValidationValidator(device='auto', cv_folds=5)
        
        # 逐个处理数据集
        all_results = {}
        
        for dataset_name in datasets:
            logger.info(f"\n{'='*60}")
            logger.info(f"Processing Dataset: {dataset_name} (CROSS VALIDATION)")
            logger.info(f"{'='*60}")
            
            dataset_results = {}
            
            for window_size in window_sizes:
                try:
                    result = validator.validate_with_cross_validation(dataset_name, window_size)
                    dataset_results[window_size] = result
                    
                    # 保存结果
                    if 'error' not in result:
                        output_file = Path(output_dir) / f"cross_validation_{dataset_name}_{window_size}.json"
                        with open(output_file, 'w') as f:
                            json.dump(result, f, indent=2, default=str)
                        logger.info(f"Saved cross validation results: {output_file}")
                    
                except Exception as e:
                    logger.error(f"Error processing {dataset_name}_{window_size}: {e}")
                    dataset_results[window_size] = {'error': str(e)}
            
            all_results[dataset_name] = dataset_results
        
        # 保存总体结果摘要
        summary_file = Path(output_dir) / "cross_validation_summary_all_datasets.json"
        with open(summary_file, 'w') as f:
            json.dump(all_results, f, indent=2, default=str)
        
        logger.info(f"\n{'='*60}")
        logger.info("Step 6.1 Cross Validation Completed Successfully!")
        logger.info(f"{'='*60}")
        
        # 打印交叉验证总结
        logger.info("\nCross Validation Results Summary:")
        for dataset_name, dataset_results in all_results.items():
            logger.info(f"\n{dataset_name}:")
            for window_size, result in dataset_results.items():
                if 'error' not in result:
                    cv_results = result.get('cross_validation_results', {})
                    kfold_results = cv_results.get('kfold', {})
                    
                    if kfold_results:
                        best_kfold = result.get('best_models', {}).get('kfold', 'N/A')
                        best_kfold_score = kfold_results.get(best_kfold, {}).get('cv_mean', 0)
                        logger.info(f"  {window_size}: Best K-fold = {best_kfold} (R² = {best_kfold_score:.3f})")
                        
                        # 显示所有模型的CV结果
                        for model_name, cv_data in kfold_results.items():
                            logger.info(f"    {model_name}: R² = {cv_data.get('cv_mean', 0):.3f} ± {cv_data.get('cv_std', 0):.3f}")
                else:
                    logger.warning(f"  {window_size}: Error - {result['error']}")
        
        logger.info("\n✅ Cross Validation Implementation Completed!")
        logger.info("🔍 Key Improvements:")
        logger.info("  ✓ K-fold cross validation")
        logger.info("  ✓ Time series cross validation") 
        logger.info("  ✓ PyTorch neural network with GPU support")
        logger.info("  ✓ Multiple validation strategies comparison")
        logger.info("  ✓ Comprehensive performance metrics")
        
    except Exception as e:
        logger.error(f"Error in main execution: {e}")
        raise

if __name__ == "__main__":
    main()



