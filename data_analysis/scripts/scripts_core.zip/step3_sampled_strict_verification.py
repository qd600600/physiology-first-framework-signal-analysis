#!/usr/bin/env python3
"""
Step 3 强化验证脚本 - 采样版本
由于数据量太大(8.7M行)，先采样10万行进行快速验证
输出: step3_diagnostics.json, step3_permutation_null.npy
"""

import os, json, math, warnings, numpy as np, pandas as pd
from sklearn.model_selection import RepeatedKFold
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import Ridge, LinearRegression
from sklearn.preprocessing import RobustScaler
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from sklearn.feature_selection import f_regression, mutual_info_regression
from sklearn.impute import SimpleImputer
from scipy.stats import trim_mean
warnings.filterwarnings("ignore")

# ===== CONFIG =====
RANDOM_STATE = 42
N_SPLITS = 5
N_REPEATS = 3
MODEL = RandomForestRegressor(n_estimators=200, random_state=RANDOM_STATE, n_jobs=-1)
VAR_THRESHOLD = 1e-8
WINSOR_LO, WINSOR_HI = 0.01, 0.99
VIF_THRESHOLD = 10.0
PERMUTATIONS = 100
SAFE_DENOM = 1e-6
SAMPLE_SIZE = 100000  # 采样10万行进行验证
# ==================

print("=" * 70)
print("Step 3 强化验证脚本 - 采样版本")
print("=" * 70)
print(f"配置:")
print(f"  - 采样大小: {SAMPLE_SIZE:,} 行")
print(f"  - 交叉验证: {N_SPLITS} 折 × {N_REPEATS} 次重复")
print(f"  - 置换检验: {PERMUTATIONS} 次")
print(f"  - VIF阈值: {VIF_THRESHOLD}")
print("=" * 70)

# ===== utils =====
def winsorize_df(df, low=WINSOR_LO, high=WINSOR_HI):
    lo = df.quantile(low)
    hi = df.quantile(high)
    return df.clip(lo, hi, axis=1)

def safe_replace_inf_nan(df):
    df = df.copy()
    df.replace([np.inf, -np.inf], np.nan, inplace=True)
    extreme_mask = np.abs(df) > 1e12
    if extreme_mask.values.any():
        print("⚠️  检测到极端值 (>1e12)，已置为 NaN")
        df[extreme_mask] = np.nan
    return df

def compute_vif(X_df):
    X = X_df.copy()
    cols = X.columns.tolist()
    vifs = {}
    for i, col in enumerate(cols):
        y = X[col].values
        X_other = X.drop(columns=[col]).values
        try:
            reg = LinearRegression().fit(X_other, y)
            r2 = reg.score(X_other, y)
            if np.isnan(r2):
                vifs[col] = np.inf
            else:
                denom = max(1 - r2, 1e-12)
                vifs[col] = 1.0 / denom
        except Exception:
            vifs[col] = np.inf
    return pd.Series(vifs)

def safe_f_regression(X, y):
    try:
        F, p = f_regression(X.fillna(0), y)
        F = np.nan_to_num(F, nan=0.0, posinf=0.0, neginf=0.0)
    except Exception:
        F = np.zeros(X.shape[1])
        p = np.ones(X.shape[1])
    return pd.Series(F, index=X.columns), pd.Series(p, index=X.columns)

# ===== load data with sampling =====
print("\n📂 加载数据文件...")
print(f"  读取前{SAMPLE_SIZE:,}行进行验证...")

base = pd.read_csv("features_base.csv", index_col=None, nrows=SAMPLE_SIZE)
extended = pd.read_csv("features_extended.csv", index_col=None, nrows=SAMPLE_SIZE)
y = pd.read_csv("labels.csv", nrows=SAMPLE_SIZE)['target']

print(f"  ✅ Base特征: {base.shape}")
print(f"  ✅ Extended特征: {extended.shape}")
print(f"  ✅ 标签: {len(y)} 个")

assert len(base) == len(extended) == len(y), "样本数量不一致"

# ===== numeric safety =====
print("\n🔧 数值清理...")
extended = safe_replace_inf_nan(extended)
base = safe_replace_inf_nan(base)

# winsorize to control extremes
extended = winsorize_df(extended)
base = winsorize_df(base)
print("  ✅ Winsorize完成 (1%-99%)")

# drop near-constant features
var = extended.var(skipna=True)
keep_cols = var[var > VAR_THRESHOLD].index.tolist()
dropped_const = [c for c in extended.columns if c not in keep_cols]
extended = extended[keep_cols]
print(f"  ✅ 删除常数特征: {len(dropped_const)} 个")

# ==== iterative VIF removal ====
print("\n🔍 VIF共线性检测与移除...")
imp = SimpleImputer(strategy='median')
Xe_for_vif = pd.DataFrame(imp.fit_transform(extended), columns=extended.columns)
scaler_tmp = RobustScaler().fit(Xe_for_vif)
Xe_vif_scaled = pd.DataFrame(scaler_tmp.transform(Xe_for_vif), columns=extended.columns)
removed_vif = []
iteration = 0
while True:
    vifs = compute_vif(Xe_vif_scaled)
    max_vif = vifs.max()
    if max_vif > VIF_THRESHOLD:
        drop_col = vifs.idxmax()
        removed_vif.append((drop_col, float(max_vif)))
        Xe_vif_scaled.drop(columns=[drop_col], inplace=True)
        iteration += 1
        if iteration % 5 == 0:
            print(f"  迭代 {iteration}: 移除 {drop_col} (VIF={max_vif:.2f})")
    else:
        break

# 保存VIF处理后的extended特征
extended_vif_processed = extended[Xe_vif_scaled.columns.tolist()]
print(f"  ✅ VIF移除完成: 移除{len(removed_vif)}个特征，保留{extended_vif_processed.shape[1]}个特征")

# ===== feature scoring =====
print("\n📊 特征评分 (F-test + 互信息)...")
F_scores, p_scores = safe_f_regression(extended_vif_processed, y)
mi_scores = pd.Series(mutual_info_regression(extended_vif_processed.fillna(0), y, random_state=RANDOM_STATE),
                      index=extended_vif_processed.columns)

anomalous_F = F_scores[np.abs(F_scores) > 1e8].to_dict()
if anomalous_F:
    print(f"  ⚠️  检测到{len(anomalous_F)}个异常F值特征")

# ===== select features =====
k_select = min(50, extended_vif_processed.shape[1])
mi_top = mi_scores.sort_values(ascending=False).head(k_select).index
f_good = p_scores[p_scores < 0.05].index
selected = sorted(set(mi_top).union(set(f_good)))
extended_selected = extended_vif_processed[selected]
print(f"  ✅ 特征选择完成: {len(selected)} 个特征")

# ===== CV evaluation =====
print("\n🔬 交叉验证评估 (同一折)...")
rkf = RepeatedKFold(n_splits=N_SPLITS, n_repeats=N_REPEATS, random_state=RANDOM_STATE)
base_scores = []
ext_scores = []
base_train_scores = []
ext_train_scores = []

fold_count = 0
total_folds = N_SPLITS * N_REPEATS
for train_idx, test_idx in rkf.split(base):
    fold_count += 1
    if fold_count % 3 == 0:
        print(f"  处理折 {fold_count}/{total_folds}...")
    
    Xb_tr, Xb_te = base.iloc[train_idx], base.iloc[test_idx]
    Xe_tr, Xe_te = extended_selected.iloc[train_idx], extended_selected.iloc[test_idx]
    y_tr, y_te = y.iloc[train_idx], y.iloc[test_idx]

    # impute + robust scale per fold
    imp = SimpleImputer(strategy='median').fit(Xb_tr)
    Xb_tr_imputed = imp.transform(Xb_tr)
    Xb_te_imputed = imp.transform(Xb_te)
    Xb_tr = pd.DataFrame(Xb_tr_imputed, columns=base.columns)
    Xb_te = pd.DataFrame(Xb_te_imputed, columns=base.columns)

    imp2 = SimpleImputer(strategy='median').fit(Xe_tr)
    Xe_tr_imputed = imp2.transform(Xe_tr)
    Xe_te_imputed = imp2.transform(Xe_te)
    Xe_tr = pd.DataFrame(Xe_tr_imputed, columns=extended_selected.columns)
    Xe_te = pd.DataFrame(Xe_te_imputed, columns=extended_selected.columns)

    scaler_b = RobustScaler().fit(Xb_tr)
    Xb_tr_s, Xb_te_s = scaler_b.transform(Xb_tr), scaler_b.transform(Xb_te)
    scaler_e = RobustScaler().fit(Xe_tr)
    Xe_tr_s, Xe_te_s = scaler_e.transform(Xe_tr), scaler_e.transform(Xe_te)

    # train & eval
    MODEL.set_params(random_state=RANDOM_STATE)
    MODEL.fit(Xb_tr_s, y_tr)
    yb_pred_te = MODEL.predict(Xb_te_s)
    yb_pred_tr = MODEL.predict(Xb_tr_s)

    MODEL.fit(Xe_tr_s, y_tr)
    ye_pred_te = MODEL.predict(Xe_te_s)
    ye_pred_tr = MODEL.predict(Xe_tr_s)

    base_scores.append(r2_score(y_te, yb_pred_te))
    ext_scores.append(r2_score(y_te, ye_pred_te))
    base_train_scores.append(r2_score(y_tr, yb_pred_tr))
    ext_train_scores.append(r2_score(y_tr, ye_pred_tr))

# summarize
mean_base = float(np.mean(base_scores))
mean_ext = float(np.mean(ext_scores))
std_base = float(np.std(base_scores))
std_ext = float(np.std(ext_scores))
delta_abs = mean_ext - mean_base
safe_denom = max(abs(mean_base), SAFE_DENOM)
delta_pct = (delta_abs / safe_denom) * 100.0

train_gap_base = float(np.mean(base_train_scores) - mean_base)
train_gap_ext = float(np.mean(ext_train_scores) - mean_ext)

print(f"  ✅ 交叉验证完成")

# ===== permutation test =====
print(f"\n🎲 置换检验 ({PERMUTATIONS}次)...")
null_scores = []
for i in range(PERMUTATIONS):
    if (i + 1) % 20 == 0:
        print(f"  置换 {i+1}/{PERMUTATIONS}...")
    y_perm = y.sample(frac=1.0, random_state=RANDOM_STATE + i).reset_index(drop=True)
    perm_scores = []
    for train_idx, test_idx in rkf.split(extended_selected):
        Xe_tr = extended_selected.iloc[train_idx]
        Xe_te = extended_selected.iloc[test_idx]
        y_tr = y_perm.iloc[train_idx]
        y_te = y_perm.iloc[test_idx]
        imp2 = SimpleImputer(strategy='median').fit(Xe_tr)
        Xe_tr_imputed = imp2.transform(Xe_tr)
        Xe_te_imputed = imp2.transform(Xe_te)
        Xe_tr = pd.DataFrame(Xe_tr_imputed, columns=extended_selected.columns)
        Xe_te = pd.DataFrame(Xe_te_imputed, columns=extended_selected.columns)
        scaler_e = RobustScaler().fit(Xe_tr)
        Xe_tr_s, Xe_te_s = scaler_e.transform(Xe_tr), scaler_e.transform(Xe_te)
        MODEL.fit(Xe_tr_s, y_tr)
        perm_scores.append(r2_score(y_te, MODEL.predict(Xe_te_s)))
    null_scores.append(np.mean(perm_scores))

null_scores = np.array(null_scores)
p_value_perm = float(np.mean(null_scores >= mean_ext))
print(f"  ✅ 置换检验完成, p-value={p_value_perm:.4f}")

# ===== diagnostics & output =====
print("\n📋 生成诊断报告...")
diagnostics = {
    "sample_size": int(len(y)),
    "n_samples_original": 8767260,
    "n_features_base": int(base.shape[1]),
    "n_features_extended_original": int(pd.read_csv("features_extended.csv", nrows=1).shape[1]),
    "n_features_extended_after_var_vif": int(extended_vif_processed.shape[1]),
    "n_features_extended_selected": int(extended_selected.shape[1]),
    "dropped_const_features": dropped_const,
    "removed_vif": removed_vif[:10],  # 只保留前10个
    "anomalous_F_scores": anomalous_F if len(anomalous_F) < 50 else dict(list(anomalous_F.items())[:10]),
    "mi_top20": mi_scores.sort_values(ascending=False).head(20).to_dict(),
    "cv_mean_r2_base": mean_base,
    "cv_std_r2_base": std_base,
    "cv_mean_r2_extended": mean_ext,
    "cv_std_r2_extended": std_ext,
    "delta_abs_r2": delta_abs,
    "delta_pct_r2_safe": delta_pct,
    "train_gap_base": train_gap_base,
    "train_gap_extended": train_gap_ext,
    "permutation_pvalue_extended": p_value_perm,
    "permutation_null_mean": float(np.mean(null_scores)),
    "permutation_null_std": float(np.std(null_scores)),
    "success_criteria": {
        "delta_abs_r2>0": delta_abs > 0,
        "p_value_perm<0.05": p_value_perm < 0.05,
        "train_gap_extended<0.1": train_gap_ext < 0.1
    }
}

with open("step3_diagnostics.json", "w") as f:
    json.dump(diagnostics, f, indent=2)

np.save("step3_permutation_null.npy", null_scores)

# ===== Print Summary =====
print("\n" + "=" * 70)
print("✅ Step-3 验证完成!")
print("=" * 70)
print(f"📊 主要指标:")
print(f"  Base R²      : {mean_base:.4f} ± {std_base:.4f}")
print(f"  Extended R²  : {mean_ext:.4f} ± {std_ext:.4f}")
print(f"  Δ R² (绝对)  : {delta_abs:.4f}")
print(f"  Δ R² (相对)  : {delta_pct:.2f}%")
print(f"  训练差距(Base): {train_gap_base:.4f}")
print(f"  训练差距(Ext) : {train_gap_ext:.4f}")
print(f"  置换p值      : {p_value_perm:.4f}")
print()
print(f"🎯 成功标准:")
print(f"  ✓ Δ R² > 0              : {'✅ 通过' if delta_abs > 0 else '❌ 失败'}")
print(f"  ✓ p-value < 0.05        : {'✅ 通过' if p_value_perm < 0.05 else '❌ 失败'}")
print(f"  ✓ 训练差距 < 0.1        : {'✅ 通过' if train_gap_ext < 0.1 else '❌ 失败'}")
print()
print(f"📁 输出文件:")
print(f"  - step3_diagnostics.json")
print(f"  - step3_permutation_null.npy")
print("=" * 70)
