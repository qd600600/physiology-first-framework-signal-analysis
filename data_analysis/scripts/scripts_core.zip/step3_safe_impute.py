#!/usr/bin/env python3
"""
Step 3 安全Imputation函数
解决SimpleImputer形状变化问题的安全处理函数
"""

import pandas as pd
import numpy as np
from sklearn.impute import SimpleImputer
import warnings
warnings.filterwarnings("ignore")

def safe_impute(df, strategy='median', verbose=True):
    """
    安全的数据填充函数
    
    参数:
    - df: 输入DataFrame
    - strategy: 填充策略 ('median', 'mean', 'most_frequent')
    - verbose: 是否输出详细信息
    
    返回:
    - 处理后的DataFrame，保证形状一致性
    """
    df = df.copy()
    
    if verbose:
        print(f"  🔧 SafeImpute输入: {df.shape}")
    
    # 检查全NaN列
    nan_cols = df.columns[df.isna().all()].tolist()
    if len(nan_cols) > 0:
        if verbose:
            print(f"  ⚠️ 发现全NaN列，将删除: {nan_cols}")
        df = df.drop(columns=nan_cols)
    
    # 数值列筛选
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    if len(numeric_cols) < df.shape[1]:
        dropped_nonnum = list(set(df.columns) - set(numeric_cols))
        if verbose:
            print(f"  ⚠️ 非数值列被排除: {dropped_nonnum}")
        df = df[numeric_cols]
    
    # 如果没有有效列，返回空DataFrame
    if df.shape[1] == 0:
        if verbose:
            print(f"  ❌ 没有有效列，返回空DataFrame")
        return pd.DataFrame()
    
    # Impute
    imp = SimpleImputer(strategy=strategy)
    X_imputed = imp.fit_transform(df)
    
    # 重建DataFrame，使用实际保留的列名
    df_out = pd.DataFrame(X_imputed, columns=df.columns, index=df.index)
    
    if verbose:
        print(f"  ✅ SafeImpute输出: {df_out.shape}")
        print(f"  ✅ 保留的列: {list(df_out.columns)}")
    
    return df_out

def test_safe_impute():
    """
    测试safe_impute函数
    """
    print("=" * 70)
    print("测试SafeImpute函数")
    print("=" * 70)
    
    # 加载数据
    print("📂 加载测试数据...")
    base = pd.read_csv("features_base.csv", index_col=None, nrows=1000)
    print(f"  原始数据: {base.shape}")
    
    # 检查全NaN列
    nan_cols = base.columns[base.isna().all()].tolist()
    print(f"  全NaN列: {nan_cols}")
    
    # 测试safe_impute
    print(f"\n🧪 测试SafeImpute...")
    result = safe_impute(base, verbose=True)
    
    # 验证结果
    print(f"\n✅ 验证结果:")
    print(f"  输出形状: {result.shape}")
    print(f"  列名数量: {len(result.columns)}")
    print(f"  形状一致性: {result.shape[1] == len(result.columns)}")
    print(f"  无缺失值: {not result.isna().any().any()}")
    
    # 测试交叉验证场景
    print(f"\n🔬 测试交叉验证场景...")
    from sklearn.model_selection import train_test_split
    X_train, X_test = train_test_split(base, test_size=0.2, random_state=42)
    
    print(f"  训练集: {X_train.shape}")
    print(f"  测试集: {X_test.shape}")
    
    X_train_imputed = safe_impute(X_train, verbose=False)
    X_test_imputed = safe_impute(X_test, verbose=False)
    
    print(f"  训练集处理后: {X_train_imputed.shape}")
    print(f"  测试集处理后: {X_test_imputed.shape}")
    print(f"  列名一致: {list(X_train_imputed.columns) == list(X_test_imputed.columns)}")
    
    print("=" * 70)
    return result

if __name__ == "__main__":
    test_safe_impute()

