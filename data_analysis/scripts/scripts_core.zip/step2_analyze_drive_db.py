#!/usr/bin/env python3
"""
Step 2: Analyze DRIVE_DB Dataset
"""

import pandas as pd
import numpy as np
from pathlib import Path

def analyze_drive_db():
    """Analyze DRIVE_DB dataset files."""
    print("Analyzing DRIVE_DB Dataset")
    print("="*60)
    
    # DRIVE_DB data path
    drive_path = Path('processed/DRIVE_DB_extracted/stress-recognition-in-automobile-drivers-1.0.0')
    
    if not drive_path.exists():
        print(f"❌ DRIVE_DB path does not exist: {drive_path}")
        return None
    
    results = {}
    
    # Find data files
    dat_files = list(drive_path.glob('*.dat'))
    hea_files = list(drive_path.glob('*.hea'))
    
    print(f"Found {len(dat_files)} .dat files and {len(hea_files)} .hea files")
    
    # Analyze first few files as sample
    sample_files = dat_files[:3]  # Analyze first 3 files
    
    for dat_file in sample_files:
        file_id = dat_file.stem
        print(f"\nAnalyzing: {file_id}")
        print("-" * 40)
        
        # Check corresponding .hea file
        hea_file = dat_file.with_suffix('.hea')
        
        file_results = {
            'dat_file': str(dat_file),
            'hea_file': str(hea_file) if hea_file.exists() else None,
            'file_size_mb': round(dat_file.stat().st_size / (1024 * 1024), 2)
        }
        
        print(f"📁 File size: {file_results['file_size_mb']} MB")
        
        # Try to read .hea file (header file)
        if hea_file.exists():
            try:
                with open(hea_file, 'r') as f:
                    hea_content = f.read()
                
                # Parse header information
                lines = hea_content.split('\n')
                info = {
                    'total_lines': len(lines),
                    'sample_lines': lines[:10]  # First 10 lines
                }
                
                file_results['hea_info'] = info
                print(f"✅ Header file loaded: {len(lines)} lines")
                print(f"📋 Sample header content:")
                for i, line in enumerate(lines[:5]):
                    print(f"   {i+1}: {line}")
                
            except Exception as e:
                print(f"❌ Error reading header file: {e}")
                file_results['hea_error'] = str(e)
        else:
            print(f"❌ No corresponding .hea file found")
        
        # Note: .dat files are binary and require special parsing
        # For now, we'll just record their existence and size
        print(f"📊 Binary data file: {file_id}.dat ({file_results['file_size_mb']} MB)")
        
        results[file_id] = file_results
    
    # Check for RECORDS file
    records_file = drive_path / 'RECORDS'
    if records_file.exists():
        try:
            with open(records_file, 'r') as f:
                records_content = f.read()
            
            records = [line.strip() for line in records_content.split('\n') if line.strip()]
            print(f"\n📋 RECORDS file found: {len(records)} records")
            print(f"   Sample records: {records[:5]}")
            
            results['records'] = records
            
        except Exception as e:
            print(f"❌ Error reading RECORDS file: {e}")
    
    # Theoretical parameter analysis
    print(f"\n{'='*60}")
    print("THEORETICAL PARAMETER ANALYSIS")
    print(f"{'='*60}")
    
    # DRIVE_DB typically contains ECG and other physiological signals
    # We need to infer from file names and header information
    theoretical_params = {
        'hrv_rmssd': ['rmssd', 'RMSSD', 'hrv_rmssd'],
        'hrv_sdnn': ['sdnn', 'SDNN', 'hrv_sdnn'],
        'hr_mean': ['hr', 'HR', 'heart_rate', 'ecg'],
        'stress_label': ['stress', 'condition', 'state', 'drive']
    }
    
    # Analyze header files for parameter information
    found_params = {}
    
    for file_id, file_data in results.items():
        if 'hea_info' in file_data:
            header_lines = file_data['hea_info']['sample_lines']
            for line in header_lines:
                line_lower = line.lower()
                for param_name, aliases in theoretical_params.items():
                    for alias in aliases:
                        if alias.lower() in line_lower:
                            if param_name not in found_params:
                                found_params[param_name] = []
                            found_params[param_name].append(f"{file_id}: {line.strip()}")
    
    print(f"Found {len(found_params)} theoretical parameters:")
    for param, instances in found_params.items():
        print(f"  ✅ {param}: {len(instances)} instances")
        for instance in instances[:2]:  # Show first 2 instances
            print(f"     - {instance}")
    
    # Calculate theoretical relevance score
    high_priority_params = ['hrv_rmssd', 'hrv_sdnn', 'hr_mean', 'stress_label']
    relevance_score = len([p for p in high_priority_params if p in found_params])
    relevance_percentage = (relevance_score / len(high_priority_params)) * 100
    
    print(f"\n⭐ Theoretical relevance: {relevance_percentage:.1f}%")
    print(f"   High-priority parameters found: {[p for p in high_priority_params if p in found_params]}")
    
    # Summary
    print(f"\n{'='*60}")
    print("DRIVE_DB ANALYSIS SUMMARY")
    print(f"{'='*60}")
    
    print(f"✅ Analyzed {len(sample_files)} data files")
    print(f"✅ Found {len(hea_files)} header files")
    print(f"✅ Found {len(found_params)} theoretical parameters")
    print(f"✅ Theoretical relevance: {relevance_percentage:.1f}%")
    total_size = 0
    for file_id, file_data in results.items():
        if isinstance(file_data, dict) and 'file_size_mb' in file_data:
            total_size += file_data['file_size_mb']
    print(f"📊 Total data size: {total_size:.1f} MB")
    
    results['summary'] = {
        'files_analyzed': len(sample_files),
        'total_dat_files': len(dat_files),
        'total_hea_files': len(hea_files),
        'theoretical_params_found': found_params,
        'relevance_score': relevance_score,
        'relevance_percentage': relevance_percentage,
        'total_size_mb': total_size
    }
    
    return results

if __name__ == "__main__":
    results = analyze_drive_db()
    
    if results:
        print(f"\n✅ DRIVE_DB analysis completed")
        print(f"Found {len(results['summary']['theoretical_params_found'])} theoretical parameters")
        print(f"Theoretical relevance: {results['summary']['relevance_percentage']:.1f}%")
    else:
        print(f"\n❌ DRIVE_DB analysis failed")
