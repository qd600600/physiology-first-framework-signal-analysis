#!/usr/bin/env python3
"""
Step 3 诊断脚本 - 检查SimpleImputer形状变化问题
按照科学方法逐步排查数据形状不匹配的根本原因
"""

import pandas as pd
import numpy as np
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import RobustScaler
from sklearn.model_selection import RepeatedKFold

print("=" * 70)
print("Step 3 数据形状诊断")
print("=" * 70)

# 加载数据
print("📂 加载数据...")
base = pd.read_csv("features_base.csv", index_col=None, nrows=100000)
extended = pd.read_csv("features_extended.csv", index_col=None, nrows=100000)
y = pd.read_csv("labels.csv", nrows=100000)['target']

print(f"  ✅ Base特征: {base.shape}")
print(f"  ✅ Extended特征: {extended.shape}")
print(f"  ✅ 标签: {len(y)} 个")

# 检查原始数据状态
print("\n🔍 检查原始数据状态...")
print(f"  Base特征数据类型: {base.dtypes.value_counts().to_dict()}")
print(f"  Extended特征数据类型: {extended.dtypes.value_counts().to_dict()}")

# 检查缺失值
print(f"\n📊 缺失值统计:")
print(f"  Base特征缺失值: {base.isna().sum().sum()} / {base.size}")
print(f"  Extended特征缺失值: {extended.isna().sum().sum()} / {extended.size}")

# 检查全NaN列
print(f"\n⚠️ 检查全NaN列:")
base_nan_cols = base.columns[base.isna().all()].tolist()
ext_nan_cols = extended.columns[extended.isna().all()].tolist()
print(f"  Base特征全NaN列: {base_nan_cols}")
print(f"  Extended特征全NaN列: {ext_nan_cols}")

# 模拟交叉验证的第一步
print(f"\n🔬 模拟交叉验证第一步...")
rkf = RepeatedKFold(n_splits=5, n_repeats=1, random_state=42)
train_idx, test_idx = next(iter(rkf.split(base)))

Xb_tr = base.iloc[train_idx]
Xb_te = base.iloc[test_idx]
print(f"  训练集形状: {Xb_tr.shape}")
print(f"  测试集形状: {Xb_te.shape}")

# Step 1: 检查全NaN列
print(f"\n🔹 Step 1: 检查全NaN列")
nan_cols_tr = Xb_tr.columns[Xb_tr.isna().all()]
print(f"  训练集全NaN列: {nan_cols_tr.tolist()}")

# Step 2: 验证imputer行为
print(f"\n🔹 Step 2: 验证SimpleImputer行为")
imp = SimpleImputer(strategy='median')
print(f"  Before imputation: {Xb_tr.shape}")

# 检查是否有非数值列
non_numeric_cols = Xb_tr.select_dtypes(exclude=[np.number]).columns.tolist()
print(f"  非数值列: {non_numeric_cols}")

# 如果只有数值列，进行imputation
if len(non_numeric_cols) == 0:
    Xb_tr_imputed = imp.fit_transform(Xb_tr)
    print(f"  After imputation: {Xb_tr_imputed.shape}")
    
    # Step 3: 找出被丢掉的列
    print(f"\n🔹 Step 3: 找出被删除的列")
    kept_cols = Xb_tr.columns[~Xb_tr.isna().all()]
    dropped_cols = set(Xb_tr.columns) - set(kept_cols)
    print(f"  被删除的列: {dropped_cols}")
    
    # 尝试重建DataFrame - 这里会出错
    print(f"\n🚨 尝试重建DataFrame (预期会出错):")
    try:
        Xb_tr_rebuilt = pd.DataFrame(Xb_tr_imputed, columns=base.columns)
        print(f"  ✅ 成功重建: {Xb_tr_rebuilt.shape}")
    except ValueError as e:
        print(f"  ❌ 重建失败: {e}")
        print(f"  📊 数据形状分析:")
        print(f"    - Xb_tr_imputed形状: {Xb_tr_imputed.shape}")
        print(f"    - base.columns长度: {len(base.columns)}")
        print(f"    - 差异: {Xb_tr_imputed.shape[1]} vs {len(base.columns)}")
        
        # 找出实际保留的列
        actual_kept_cols = Xb_tr.columns[~Xb_tr.isna().all()].tolist()
        print(f"    - 实际保留的列: {len(actual_kept_cols)}")
        print(f"    - 实际保留的列名: {actual_kept_cols}")
        
        # 正确重建DataFrame
        print(f"\n🔧 正确重建DataFrame:")
        Xb_tr_correct = pd.DataFrame(Xb_tr_imputed, columns=actual_kept_cols)
        print(f"  ✅ 正确重建: {Xb_tr_correct.shape}")
        print(f"  ✅ 列名匹配: {list(Xb_tr_correct.columns) == actual_kept_cols}")
else:
    print(f"  ⚠️ 发现非数值列，需要先处理")

print(f"\n📋 诊断总结:")
print(f"  问题根源: SimpleImputer删除了全NaN列")
print(f"  解决方案: 使用实际保留的列名重建DataFrame")
print(f"  建议: 实现safe_impute函数统一处理")
print("=" * 70)

