#!/usr/bin/env python3
"""
Step 1: F-test 数值稳定性修复 - 修正版本
修复分块处理中的形状不匹配问题
"""

import pandas as pd
import numpy as np
import torch
import json
import time
import sys
from sklearn.feature_selection import f_classif, f_regression, mutual_info_regression, SelectKBest, VarianceThreshold
from sklearn.preprocessing import StandardScaler, RobustScaler
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import HistGradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import Ridge, Lasso
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from sklearn.model_selection import KFold
import warnings
warnings.filterwarnings("ignore")

def print_progress(message, step=None, total_steps=None):
    """打印进度信息"""
    if step is not None and total_steps is not None:
        progress = (step / total_steps) * 100
        print(f"[{progress:5.1f}%] {message}")
    else:
        print(message)
    sys.stdout.flush()

print("=" * 70)
print("Step 1: F-test 数值稳定性修复 - 修正版本")
print("=" * 70)

# GPU检查
print_progress("🔍 GPU检查:")
print_progress(f"  CUDA可用: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print_progress(f"  GPU设备: {torch.cuda.get_device_name(0)}")
    print_progress(f"  GPU内存: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.1f} GB")
    device = torch.device('cuda')
    use_gpu = True
else:
    print_progress("  ⚠️ CUDA不可用，将使用CPU")
    device = torch.device('cpu')
    use_gpu = False

def preprocess_features_globally(X, verbose=True):
    """
    全局预处理特征 - 确保所有块使用相同的特征集合
    """
    if verbose:
        print_progress(f"  🔧 全局预处理特征: {X.shape}")
    
    X_clean = X.copy()
    original_shape = X_clean.shape
    
    # 移除常数特征
    constant_mask = (X_clean.std() > 1e-8)
    X_clean = X_clean.loc[:, constant_mask]
    
    if verbose:
        print_progress(f"    📊 移除常数特征: {original_shape[1]} -> {X_clean.shape[1]} 特征")
    
    # 处理无穷值和NaN
    X_clean = X_clean.replace([np.inf, -np.inf], np.nan)
    
    # 检查每列的NaN比例
    nan_ratio = X_clean.isna().sum() / len(X_clean)
    low_nan_mask = nan_ratio < 0.5  # 保留NaN比例小于50%的列
    X_clean = X_clean.loc[:, low_nan_mask]
    
    if verbose:
        print_progress(f"    📊 移除高NaN列: {original_shape[1]} -> {X_clean.shape[1]} 特征")
    
    # 移除方差极低列
    var_threshold = 1e-8
    variances = X_clean.var()
    low_var_mask = variances > var_threshold
    X_clean = X_clean.loc[:, low_var_mask]
    
    if verbose:
        print_progress(f"    📊 方差筛选: {original_shape[1]} -> {X_clean.shape[1]} 特征")
    
    # 记录有效的特征列
    valid_columns = X_clean.columns.tolist()
    
    if verbose:
        print_progress(f"    ✅ 有效特征列: {len(valid_columns)} 个")
    
    return valid_columns

def safe_f_classif_chunked_fixed(X, y, chunk_size=100000, verbose=True):
    """
    修正的分块F-test实现 - 确保所有块使用相同的特征集合
    """
    if verbose:
        print_progress(f"  🔬 执行修正的分块F-test: {X.shape}, 块大小: {chunk_size}")
    
    n_samples = X.shape[0]
    n_features = X.shape[1]
    
    # 如果数据量小于块大小，直接计算
    if n_samples <= chunk_size:
        if verbose:
            print_progress("  💻 数据量较小，直接计算F-test")
        return safe_f_classif_direct(X, y, verbose=verbose)
    
    # 全局预处理，确定有效特征列
    if verbose:
        print_progress("  🔧 全局预处理确定有效特征...")
    valid_columns = preprocess_features_globally(X, verbose=verbose)
    
    if len(valid_columns) == 0:
        if verbose:
            print_progress("    ⚠️ 没有有效特征，返回默认值")
        return np.ones(n_features), np.ones(n_features)
    
    # 分块计算
    n_chunks = (n_samples + chunk_size - 1) // chunk_size
    f_values = np.zeros(len(valid_columns))
    p_values = np.zeros(len(valid_columns))
    valid_chunks = 0
    
    if verbose:
        print_progress(f"  📊 分块处理: {n_chunks} 个块，使用 {len(valid_columns)} 个有效特征")
    
    for i in range(n_chunks):
        start_idx = i * chunk_size
        end_idx = min((i + 1) * chunk_size, n_samples)
        
        if verbose and (i + 1) % 10 == 0:
            print_progress(f"    处理块 {i+1}/{n_chunks}: {start_idx}-{end_idx}")
        
        try:
            # 获取当前块的数据，只使用有效特征列
            X_chunk = X.iloc[start_idx:end_idx][valid_columns]
            y_chunk = y.iloc[start_idx:end_idx]
            
            # 对当前块执行F-test
            f_chunk, p_chunk = safe_f_classif_direct(X_chunk, y_chunk, verbose=False)
            
            # 累积结果
            f_values += f_chunk
            p_values += p_chunk
            valid_chunks += 1
            
        except Exception as e:
            if verbose:
                print_progress(f"    ⚠️ 块 {i+1} 计算失败: {e}")
            continue
    
    # 平均化结果
    if valid_chunks > 0:
        f_values /= valid_chunks
        p_values /= valid_chunks
    else:
        if verbose:
            print_progress("    ⚠️ 所有块计算失败，返回默认值")
        f_values = np.ones(len(valid_columns))
        p_values = np.ones(len(valid_columns))
    
    # 将结果映射回原始特征维度
    f_values_full = np.ones(n_features)
    p_values_full = np.ones(n_features)
    
    for i, col in enumerate(valid_columns):
        if col in X.columns:
            col_idx = X.columns.get_loc(col)
            f_values_full[col_idx] = f_values[i]
            p_values_full[col_idx] = p_values[i]
    
    if verbose:
        print_progress(f"  ✅ 分块F-test完成: {valid_chunks}/{n_chunks} 个有效块")
        valid_f = f_values_full[np.isfinite(f_values_full) & (f_values_full > 0) & (f_values_full < 1e10)]
        if len(valid_f) > 0:
            print_progress(f"  📊 F值统计: 均值={np.mean(valid_f):.2f}, 标准差={np.std(valid_f):.2f}")
            print_progress(f"  📊 F值范围: {np.min(valid_f):.2f} - {np.max(valid_f):.2f}")
            print_progress(f"  ✅ 有效特征: {len(valid_f)}/{len(f_values_full)}")
    
    return f_values_full, p_values_full

def safe_f_classif_direct(X, y, verbose=True):
    """
    直接F-test实现 - 不使用分块
    """
    # 数据预处理
    X_clean = X.copy()
    
    # 处理无穷值和NaN
    X_clean = X_clean.replace([np.inf, -np.inf], np.nan)
    X_clean = np.nan_to_num(X_clean, nan=0.0, posinf=0.0, neginf=0.0)
    
    # 数据标准化
    scaler = RobustScaler()
    X_scaled = scaler.fit_transform(X_clean)
    
    # 执行F-test
    try:
        F, p = f_classif(X_scaled, y)
        
        # 限制F值范围，避免无穷值
        F = np.clip(F, 0, 1e6)
        
        return F, p
        
    except Exception as e:
        if verbose:
            print_progress(f"    ❌ F-test失败: {e}")
        return np.ones(X.shape[1]), np.ones(X.shape[1])

def multi_method_feature_selection_fixed(X, y, k=20, verbose=True):
    """
    修正的多种方法特征选择
    """
    if verbose:
        print_progress(f"  🎯 执行多种方法特征选择...")
    
    feature_scores = {}
    
    # 方法1: F-test（分块处理）
    if verbose:
        print_progress("    📊 方法1: F-test特征选择（分块）")
    try:
        F, p = safe_f_classif_chunked_fixed(X, y, chunk_size=100000, verbose=verbose)
        feature_scores['f_test'] = F
    except Exception as e:
        if verbose:
            print_progress(f"    ⚠️ F-test失败: {e}")
        feature_scores['f_test'] = np.ones(X.shape[1])
    
    # 方法2: 方差选择
    if verbose:
        print_progress("    📊 方法2: 方差特征选择")
    try:
        var_scores = X.var().values
        feature_scores['variance'] = var_scores
    except:
        feature_scores['variance'] = np.ones(X.shape[1])
    
    # 方法3: 互信息（小样本）
    if verbose:
        print_progress("    📊 方法3: 互信息特征选择")
    try:
        if len(X) > 10000:
            # 大数据集抽样
            sample_idx = np.random.choice(len(X), size=10000, replace=False)
            X_sample = X.iloc[sample_idx]
            y_sample = y.iloc[sample_idx]
        else:
            X_sample = X
            y_sample = y
        
        mi_scores = mutual_info_regression(X_sample, y_sample, random_state=42)
        feature_scores['mutual_info'] = mi_scores
    except Exception as e:
        if verbose:
            print_progress(f"    ⚠️ 互信息失败: {e}")
        feature_scores['mutual_info'] = np.ones(X.shape[1])
    
    # 综合评分
    if verbose:
        print_progress("    📊 计算综合评分")
    
    # 标准化各方法的评分
    combined_scores = np.zeros(X.shape[1])
    for method, scores in feature_scores.items():
        if len(scores) > 0:
            # 标准化到0-1范围
            scores_norm = (scores - np.min(scores)) / (np.max(scores) - np.min(scores) + 1e-8)
            combined_scores += scores_norm
    
    # 选择前k个特征
    top_k_indices = np.argsort(combined_scores)[-k:]
    selected_features = X.columns[top_k_indices]
    X_selected = X[selected_features]
    
    if verbose:
        print_progress(f"    ✅ 多种方法特征选择完成: {X.shape[1]} -> {X_selected.shape[1]} 特征")
    
    return X_selected, selected_features, combined_scores

def train_model_with_regularization(X_train, X_test, y_train, y_test, model_type='regularized', verbose=True):
    """
    使用正则化的模型训练 - 解决过拟合问题
    """
    if verbose:
        print_progress(f"      🤖 训练{model_type}模型...")
    
    if model_type == 'regularized':
        # 使用正则化的线性模型
        model = Ridge(alpha=1.0, random_state=42)
    else:
        # 使用正则化的梯度提升
        model = HistGradientBoostingRegressor(
            max_iter=50,           # 减少迭代次数
            learning_rate=0.05,    # 降低学习率
            max_depth=5,           # 限制树深度
            min_samples_leaf=100,  # 增加叶子节点最小样本数
            l2_regularization=0.1, # 添加L2正则化
            random_state=42,
            verbose=0
        )
    
    # 训练模型
    model.fit(X_train, y_train)
    
    # 预测
    y_pred = model.predict(X_test)
    r2 = r2_score(y_test, y_pred)
    
    if verbose:
        print_progress(f"        ✅ 模型R²: {r2:.4f}")
    
    return r2, y_pred, model

# ======= Step 1: 数据读取 =======
print_progress("\n📂 Step 1: 数据读取")
start_time = time.time()

print_progress("  📥 正在读取features_base.csv...")
base = pd.read_csv("features_base.csv")
print_progress(f"    ✅ Base特征加载完成: {base.shape}")

print_progress("  📥 正在读取features_extended.csv...")
extended = pd.read_csv("features_extended.csv")
print_progress(f"    ✅ Extended特征加载完成: {extended.shape}")

print_progress("  📥 正在读取labels.csv...")
y = pd.read_csv("labels.csv")["target"]
print_progress(f"    ✅ 标签加载完成: {len(y)} 个样本")

# 样本一致性检查
assert len(base) == len(extended) == len(y), "样本数量不一致"
print_progress(f"  ✅ 数据加载完成: {len(y)} 个样本")
print_progress(f"  ⏱️ 数据加载耗时: {time.time() - start_time:.2f}秒")

# ======= Step 2: 多种方法特征选择 =======
print_progress("\n🔧 Step 2: 多种方法特征选择")
selection_start = time.time()

# 2.1 对Extended特征进行多种方法选择
print_progress("  🎯 对Extended特征进行多种方法选择...")
extended_selected, selected_features, combined_scores = multi_method_feature_selection_fixed(
    extended, y, k=20, verbose=True)

print_progress(f"  ⏱️ 特征选择耗时: {time.time() - selection_start:.2f}秒")

# ======= Step 3: 数据划分与标准化 =======
print_progress("\n📊 Step 3: 数据划分与标准化")
preprocess_start = time.time()

print_progress("  🔄 正在划分数据...")
Xb_train, Xb_test, y_train, y_test = train_test_split(
    base, y, test_size=0.3, random_state=42)
Xe_train, Xe_test, _, _ = train_test_split(
    extended_selected, y, test_size=0.3, random_state=42)
print_progress(f"  ✅ 数据划分完成: 训练集{len(y_train)}个, 测试集{len(y_test)}个")

print_progress("  🔄 正在标准化数据...")
# 处理NaN值
Xb_train = Xb_train.fillna(0)
Xb_test = Xb_test.fillna(0)
Xe_train = Xe_train.fillna(0)
Xe_test = Xe_test.fillna(0)

scaler = RobustScaler()
Xb_train_scaled = scaler.fit_transform(Xb_train)
Xb_test_scaled = scaler.transform(Xb_test)
Xe_train_scaled = scaler.fit_transform(Xe_train)
Xe_test_scaled = scaler.transform(Xe_test)
print_progress("  ✅ 数据标准化完成")

print_progress(f"  ⏱️ 预处理耗时: {time.time() - preprocess_start:.2f}秒")

# ======= Step 4: 正则化模型训练与评估 =======
print_progress("\n🤖 Step 4: 正则化模型训练与评估")
model_start = time.time()

# 4.1 Base模型（正则化）
print_progress("  🎯 训练Base模型（正则化）...")
r2_base, y_pred_base, model_base = train_model_with_regularization(
    Xb_train_scaled, Xb_test_scaled, y_train, y_test, 'regularized', verbose=True)

# 4.2 Extended模型（正则化）
print_progress("  🎯 训练Extended模型（正则化）...")
r2_ext, y_pred_ext, model_ext = train_model_with_regularization(
    Xe_train_scaled, Xe_test_scaled, y_train, y_test, 'regularized', verbose=True)

print_progress(f"  ⏱️ 模型训练耗时: {time.time() - model_start:.2f}秒")

# ======= Step 5: 结果保存 =======
print_progress("\n💾 Step 5: 结果保存")

improvement = (r2_ext - r2_base) / abs(r2_base + 1e-9) * 100
results = {
    "step1_f_test_corrected": {
        "feature_selection": {
            "original_features": int(extended.shape[1]),
            "selected_features": int(extended_selected.shape[1]),
            "selected_feature_names": selected_features.tolist(),
            "selection_methods": ["f_test_chunked", "variance", "mutual_info"],
            "combined_scores_mean": float(np.mean(combined_scores)),
            "combined_scores_std": float(np.std(combined_scores))
        },
        "model_performance": {
            "R2_base": float(r2_base),
            "R2_extended": float(r2_ext),
            "improvement_abs": float(r2_ext - r2_base),
            "improvement_percent": float(improvement),
            "MAE_base": float(mean_absolute_error(y_test, y_pred_base)),
            "MAE_extended": float(mean_absolute_error(y_test, y_pred_ext)),
            "RMSE_base": float(np.sqrt(mean_squared_error(y_test, y_pred_base))),
            "RMSE_extended": float(np.sqrt(mean_squared_error(y_test, y_pred_ext)))
        },
        "performance_info": {
            "total_runtime_seconds": time.time() - start_time,
            "data_loading_time": time.time() - start_time - (time.time() - selection_start),
            "feature_selection_time": time.time() - selection_start - (time.time() - preprocess_start),
            "preprocessing_time": time.time() - preprocess_start - (time.time() - model_start),
            "model_training_time": time.time() - model_start
        },
        "gpu_info": {
            "cuda_available": torch.cuda.is_available(),
            "gpu_device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
            "gpu_memory_gb": torch.cuda.get_device_properties(0).total_memory / 1024**3 if torch.cuda.is_available() else None
        }
    }
}

print_progress("  💾 正在保存结果...")
with open("step1_f_test_corrected_results.json", "w") as f:
    json.dump(results, f, indent=4)

# ======= Step 6: 结果报告 =======
print_progress("\n📊 Step 6: 结果报告")
print("=" * 70)
print("Step 1: F-test 数值稳定性修复结果（修正版本）")
print("=" * 70)
print(f"🔧 特征选择效果:")
print(f"  原始特征数: {extended.shape[1]}")
print(f"  选择特征数: {extended_selected.shape[1]}")
print(f"  选择方法: 分块F-test + 方差 + 互信息")
print(f"\n📈 模型性能:")
print(f"  Base模型 R²: {r2_base:.4f}")
print(f"  Extended模型 R²: {r2_ext:.4f}")
print(f"  性能提升: {r2_ext - r2_base:.4f} ({improvement:.2f}%)")
print(f"\n⏱️ 性能信息:")
print(f"  总运行时间: {time.time() - start_time:.2f}秒")
print(f"  特征选择时间: {time.time() - selection_start - (time.time() - preprocess_start):.2f}秒")
print(f"\n✅ 结果文件:")
print(f"  step1_f_test_corrected_results.json - 修正版本结果")
print("=" * 70)

print("🎉 Step 1: F-test 数值稳定性修复（修正版本）完成！")
