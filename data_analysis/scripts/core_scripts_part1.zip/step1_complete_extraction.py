#!/usr/bin/env python3
"""
Step 1: Complete Data Extraction with Validation
Extracts and validates data from 8 datasets with comprehensive checks for completeness.
"""

import os
import zipfile
import json
import hashlib
import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# Set random seed for reproducibility
np.random.seed(42)

class CompleteDataExtractor:
    def __init__(self, data_root="data", output_root="processed"):
        self.data_root = Path(data_root)
        self.output_root = Path(output_root)
        self.output_root.mkdir(exist_ok=True)
        
        # Dataset configurations with expected structure
        self.datasets = {
            'WESAD': {
                'extracted': True, 
                'subjects': ['S2', 'S3', 'S4', 'S5', 'S6', 'S7', 'S8', 'S9', 'S10', 'S11', 'S13', 'S14', 'S15', 'S16', 'S17'],
                'required_files_per_subject': ['ACC.csv', 'BVP.csv', 'EDA.csv', 'HR.csv', 'IBI.csv', 'TEMP.csv', 'tags.csv'],
                'questionnaire_files': ['*_quest.csv']
            },
            'MMASH': {
                'extracted': False, 
                'zip_file': 'MMASH (Multilevel Monitoring of Activity and Sleep in Healthy People).zip',
                'nested_zip': 'MMASH.zip',
                'expected_subjects': 22,
                'required_files': ['*_hr.csv', '*_acc.csv', '*_eda.csv']
            },
            'CRWD': {
                'extracted': False, 
                'zip_file': 'CRWD.zip',
                'required_files': ['sensor_hrv.csv', 'survey.csv']
            },
            'Nurses': {
                'extracted': False, 
                'zip_file': 'nurse.zip',
                'nested_zip': 'Stress_dataset.zip',
                'required_files': ['*_hr.csv', '*_eda.csv', 'SurveyResults.xlsx']
            },
            'DRIVE_DB': {
                'extracted': False, 
                'zip_file': 'stress-recognition-in-automobile-drivers-1.0.0.zip',
                'expected_files': 17,
                'required_pattern': 'drive*.dat'
            },
            'Non_EEG': {
                'extracted': False, 
                'zip_file': 'non-eeg-dataset-for-assessment-of-neurological-status-1.0.0.zip',
                'expected_files': 40,
                'required_pattern': '*.dat'
            },
            'SWELL': {
                'extracted': False, 
                'zip_file': 'swell-knowledge-work-and-stress-dataset.zip',
                'required_files': ['train.csv', 'test.csv'],
                'expected_subjects': 25
            },
            'Mental_Health_Pred': {
                'extracted': False, 
                'zip_file': 'Mental Health Prediction Using Wearable Dataset .zip',
                'required_files': ['mental_health_wearable_data.csv']
            }
        }
        
        # Validation results
        self.validation_results = {}

    def calculate_file_hash(self, file_path):
        """Calculate SHA256 hash of a file."""
        hash_sha256 = hashlib.sha256()
        try:
            with open(file_path, "rb") as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    hash_sha256.update(chunk)
            return hash_sha256.hexdigest()
        except Exception as e:
            print(f"Error calculating hash for {file_path}: {e}")
            return None

    def validate_dataset_completeness(self, dataset_name, extract_dir):
        """Validate that dataset extraction is complete."""
        config = self.datasets[dataset_name]
        validation = {
            'dataset': dataset_name,
            'validation_time': datetime.now().isoformat(),
            'is_complete': True,
            'missing_files': [],
            'extra_files': [],
            'expected_vs_actual': {},
            'data_quality_issues': []
        }
        
        if dataset_name == 'WESAD':
            return self.validate_wesad_completeness(extract_dir, validation)
        elif dataset_name == 'MMASH':
            return self.validate_mmash_completeness(extract_dir, validation)
        elif dataset_name == 'CRWD':
            return self.validate_crwd_completeness(extract_dir, validation)
        elif dataset_name == 'Nurses':
            return self.validate_nurses_completeness(extract_dir, validation)
        elif dataset_name == 'DRIVE_DB':
            return self.validate_drive_db_completeness(extract_dir, validation)
        elif dataset_name == 'Non_EEG':
            return self.validate_non_eeg_completeness(extract_dir, validation)
        elif dataset_name == 'SWELL':
            return self.validate_swell_completeness(extract_dir, validation)
        elif dataset_name == 'Mental_Health_Pred':
            return self.validate_mental_health_completeness(extract_dir, validation)
        
        return validation

    def validate_wesad_completeness(self, extract_dir, validation):
        """Validate WESAD dataset completeness."""
        expected_subjects = self.datasets['WESAD']['subjects']
        found_subjects = []
        
        # Check each expected subject
        for subject in expected_subjects:
            subject_path = extract_dir / subject
            if not subject_path.exists():
                validation['missing_files'].append(f"Subject directory: {subject}")
                validation['is_complete'] = False
                continue
            
            found_subjects.append(subject)
            
            # Check E4 data files
            e4_path = subject_path / f'{subject}_E4_Data'
            if not e4_path.exists():
                validation['missing_files'].append(f"E4 data directory for {subject}")
                validation['is_complete'] = False
                continue
            
            # Check required sensor files
            required_files = self.datasets['WESAD']['required_files_per_subject']
            for file_name in required_files:
                file_path = e4_path / file_name
                if not file_path.exists():
                    validation['missing_files'].append(f"{subject}/{file_name}")
                    validation['is_complete'] = False
            
            # Check questionnaire file
            quest_file = subject_path / f'{subject}_quest.csv'
            if not quest_file.exists():
                validation['missing_files'].append(f"{subject}_quest.csv")
        
        validation['expected_vs_actual']['subjects'] = {
            'expected': len(expected_subjects),
            'found': len(found_subjects),
            'missing': len(expected_subjects) - len(found_subjects)
        }
        
        return validation

    def validate_mmash_completeness(self, extract_dir, validation):
        """Validate MMASH dataset completeness."""
        # Check if nested zip exists and needs extraction
        nested_zip_path = extract_dir / 'multilevel-monitoring-of-activity-and-sleep-in-healthy-people-1.0.0' / 'MMASH.zip'
        
        if nested_zip_path.exists():
            validation['data_quality_issues'].append("Nested zip file found - needs secondary extraction")
            validation['is_complete'] = False
            
            # Try to extract nested zip
            nested_extract_dir = extract_dir / 'MMASH_data'
            nested_extract_dir.mkdir(exist_ok=True)
            
            try:
                with zipfile.ZipFile(nested_zip_path, 'r') as zip_ref:
                    zip_ref.extractall(nested_extract_dir)
                validation['data_quality_issues'].append("Successfully extracted nested zip")
            except Exception as e:
                validation['data_quality_issues'].append(f"Failed to extract nested zip: {e}")
        
        # Count extracted files
        all_files = list(extract_dir.rglob('*'))
        csv_files = [f for f in all_files if f.suffix == '.csv']
        
        validation['expected_vs_actual']['csv_files'] = {
            'found': len(csv_files),
            'expected_min': 22  # Expected at least 22 subjects worth of data
        }
        
        return validation

    def validate_crwd_completeness(self, extract_dir, validation):
        """Validate CRWD dataset completeness."""
        required_files = self.datasets['CRWD']['required_files']
        
        for file_name in required_files:
            file_path = extract_dir / file_name
            if not file_path.exists():
                validation['missing_files'].append(file_name)
                validation['is_complete'] = False
        
        # Check data content
        if (extract_dir / 'sensor_hrv.csv').exists():
            try:
                df = pd.read_csv(extract_dir / 'sensor_hrv.csv', nrows=1000)
                validation['expected_vs_actual']['sensor_data'] = {
                    'columns': len(df.columns),
                    'sample_rows': len(df),
                    'has_hrv': 'rmssd' in df.columns and 'sdnn' in df.columns
                }
            except Exception as e:
                validation['data_quality_issues'].append(f"Error reading sensor data: {e}")
        
        return validation

    def validate_nurses_completeness(self, extract_dir, validation):
        """Validate Nurses dataset completeness."""
        # Check for nested zip
        nested_zip_path = extract_dir / 'Stress_dataset.zip'
        if nested_zip_path.exists():
            validation['data_quality_issues'].append("Nested zip file found - needs secondary extraction")
            validation['is_complete'] = False
            
            # Extract nested zip
            nested_extract_dir = extract_dir / 'nurses_data'
            nested_extract_dir.mkdir(exist_ok=True)
            
            try:
                with zipfile.ZipFile(nested_zip_path, 'r') as zip_ref:
                    zip_ref.extractall(nested_extract_dir)
                validation['data_quality_issues'].append("Successfully extracted nested zip")
            except Exception as e:
                validation['data_quality_issues'].append(f"Failed to extract nested zip: {e}")
        
        # Check required files
        required_files = self.datasets['Nurses']['required_files']
        for file_pattern in required_files:
            matching_files = list(extract_dir.rglob(file_pattern))
            if not matching_files:
                validation['missing_files'].append(file_pattern)
                validation['is_complete'] = False
        
        return validation

    def validate_drive_db_completeness(self, extract_dir, validation):
        """Validate DRIVE_DB dataset completeness."""
        expected_files = self.datasets['DRIVE_DB']['expected_files']
        required_pattern = self.datasets['DRIVE_DB']['required_pattern']
        
        # Count .dat files
        dat_files = list(extract_dir.rglob('*.dat'))
        hea_files = list(extract_dir.rglob('*.hea'))
        
        validation['expected_vs_actual']['files'] = {
            'dat_files': len(dat_files),
            'hea_files': len(hea_files),
            'expected': expected_files
        }
        
        if len(dat_files) < expected_files:
            validation['missing_files'].append(f"Expected {expected_files} .dat files, found {len(dat_files)}")
            validation['is_complete'] = False
        
        return validation

    def validate_non_eeg_completeness(self, extract_dir, validation):
        """Validate Non_EEG dataset completeness."""
        expected_files = self.datasets['Non_EEG']['expected_files']
        required_pattern = self.datasets['Non_EEG']['required_pattern']
        
        # Count files
        dat_files = list(extract_dir.rglob('*.dat'))
        hea_files = list(extract_dir.rglob('*.hea'))
        atr_files = list(extract_dir.rglob('*.atr'))
        
        validation['expected_vs_actual']['files'] = {
            'dat_files': len(dat_files),
            'hea_files': len(hea_files),
            'atr_files': len(atr_files),
            'expected': expected_files
        }
        
        if len(dat_files) < expected_files:
            validation['missing_files'].append(f"Expected {expected_files} .dat files, found {len(dat_files)}")
            validation['is_complete'] = False
        
        return validation

    def validate_swell_completeness(self, extract_dir, validation):
        """Validate SWELL dataset completeness."""
        required_files = self.datasets['SWELL']['required_files']
        expected_subjects = self.datasets['SWELL']['expected_subjects']
        
        # Check for required files
        for file_name in required_files:
            file_path = extract_dir / 'hrv dataset' / 'data' / 'final' / file_name
            if not file_path.exists():
                validation['missing_files'].append(file_name)
                validation['is_complete'] = False
        
        # Check RRI files (individual subject data)
        rri_dir = extract_dir / 'hrv dataset' / 'data' / 'raw' / 'rri'
        if rri_dir.exists():
            rri_files = list(rri_dir.glob('*.txt'))
            validation['expected_vs_actual']['rri_files'] = {
                'found': len(rri_files),
                'expected': expected_subjects
            }
            
            if len(rri_files) < expected_subjects:
                validation['missing_files'].append(f"Expected {expected_subjects} RRI files, found {len(rri_files)}")
                validation['is_complete'] = False
        
        return validation

    def validate_mental_health_completeness(self, extract_dir, validation):
        """Validate Mental_Health_Pred dataset completeness."""
        required_files = self.datasets['Mental_Health_Pred']['required_files']
        
        for file_name in required_files:
            file_path = extract_dir / file_name
            if not file_path.exists():
                validation['missing_files'].append(file_name)
                validation['is_complete'] = False
            else:
                # Check data content
                try:
                    df = pd.read_csv(file_path, nrows=1000)
                    validation['expected_vs_actual']['data_content'] = {
                        'columns': len(df.columns),
                        'sample_rows': len(df),
                        'file_size_mb': file_path.stat().st_size / (1024*1024)
                    }
                except Exception as e:
                    validation['data_quality_issues'].append(f"Error reading {file_name}: {e}")
        
        return validation

    def extract_with_validation(self, dataset_name):
        """Extract dataset with comprehensive validation."""
        config = self.datasets[dataset_name]
        
        if config['extracted']:
            # WESAD is already extracted
            extract_dir = self.data_root / dataset_name / 'raw'
        else:
            # Extract from zip
            zip_path = self.data_root / dataset_name / 'raw' / config['zip_file']
            if not zip_path.exists():
                print(f"Warning: {zip_path} not found")
                return None
            
            extract_dir = self.output_root / f'{dataset_name}_extracted'
            extract_dir.mkdir(exist_ok=True)
            
            # Extract zip file
            try:
                with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                    zip_ref.extractall(extract_dir)
                print(f"Extracted {dataset_name} to {extract_dir}")
            except Exception as e:
                print(f"Error extracting {dataset_name}: {e}")
                return None
        
        # Validate completeness
        validation = self.validate_dataset_completeness(dataset_name, extract_dir)
        
        # Save validation results
        validation_path = self.output_root / f'validation_{dataset_name}.json'
        with open(validation_path, 'w') as f:
            json.dump(validation, f, indent=2)
        
        self.validation_results[dataset_name] = validation
        
        # Print validation summary
        print(f"\n=== {dataset_name} Validation Summary ===")
        print(f"Complete: {validation['is_complete']}")
        if validation['missing_files']:
            print(f"Missing files: {len(validation['missing_files'])}")
            for missing in validation['missing_files'][:5]:  # Show first 5
                print(f"  - {missing}")
        if validation['data_quality_issues']:
            print(f"Quality issues: {len(validation['data_quality_issues'])}")
            for issue in validation['data_quality_issues']:
                print(f"  - {issue}")
        
        return validation

    def run_complete_extraction(self):
        """Run complete extraction with validation for all datasets."""
        print("Starting complete data extraction with validation...")
        
        all_validations = {}
        
        for dataset_name in self.datasets.keys():
            print(f"\nProcessing {dataset_name}...")
            validation = self.extract_with_validation(dataset_name)
            if validation:
                all_validations[dataset_name] = validation
        
        # Create comprehensive summary
        summary = {
            'extraction_summary': {
                'total_datasets': len(self.datasets),
                'successfully_processed': len(all_validations),
                'extraction_time': datetime.now().isoformat(),
                'datasets': list(self.datasets.keys())
            },
            'validation_results': all_validations,
            'completeness_summary': self.create_completeness_summary(all_validations)
        }
        
        # Save comprehensive summary
        summary_path = self.output_root / 'complete_extraction_summary.json'
        with open(summary_path, 'w') as f:
            json.dump(summary, f, indent=2)
        
        # Print final summary
        print(f"\n{'='*50}")
        print("EXTRACTION COMPLETION SUMMARY")
        print(f"{'='*50}")
        print(f"Total datasets: {len(self.datasets)}")
        print(f"Successfully processed: {len(all_validations)}")
        
        complete_datasets = [name for name, val in all_validations.items() if val['is_complete']]
        incomplete_datasets = [name for name, val in all_validations.items() if not val['is_complete']]
        
        print(f"Complete datasets: {len(complete_datasets)} - {complete_datasets}")
        print(f"Incomplete datasets: {len(incomplete_datasets)} - {incomplete_datasets}")
        
        if incomplete_datasets:
            print("\nINCOMPLETE DATASETS REQUIRE ATTENTION:")
            for dataset in incomplete_datasets:
                validation = all_validations[dataset]
                print(f"\n{dataset}:")
                print(f"  Missing files: {len(validation['missing_files'])}")
                print(f"  Quality issues: {len(validation['data_quality_issues'])}")
        
        return summary

    def create_completeness_summary(self, validations):
        """Create summary of dataset completeness."""
        summary = {
            'complete_datasets': [],
            'incomplete_datasets': [],
            'total_missing_files': 0,
            'total_quality_issues': 0,
            'datasets_by_completeness': {}
        }
        
        for dataset_name, validation in validations.items():
            if validation['is_complete']:
                summary['complete_datasets'].append(dataset_name)
            else:
                summary['incomplete_datasets'].append(dataset_name)
            
            summary['total_missing_files'] += len(validation['missing_files'])
            summary['total_quality_issues'] += len(validation['data_quality_issues'])
            
            summary['datasets_by_completeness'][dataset_name] = {
                'complete': validation['is_complete'],
                'missing_files_count': len(validation['missing_files']),
                'quality_issues_count': len(validation['data_quality_issues'])
            }
        
        return summary

def main():
    extractor = CompleteDataExtractor()
    results = extractor.run_complete_extraction()
    return results

if __name__ == "__main__":
    main()











