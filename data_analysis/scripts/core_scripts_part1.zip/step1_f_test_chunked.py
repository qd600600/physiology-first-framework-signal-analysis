#!/usr/bin/env python3
"""
Step 1: F-test 数值稳定性修复 - 分块处理版本
目标：消除 F-test 阶段的极端值与 underflow 异常
使用分块处理大数据集
"""

import pandas as pd
import numpy as np
import torch
import json
import time
import sys
from sklearn.feature_selection import f_classif, f_regression
from sklearn.preprocessing import StandardScaler, RobustScaler
from sklearn.model_selection import train_test_split
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
import warnings
warnings.filterwarnings("ignore")

def print_progress(message, step=None, total_steps=None):
    """打印进度信息"""
    if step is not None and total_steps is not None:
        progress = (step / total_steps) * 100
        print(f"[{progress:5.1f}%] {message}")
    else:
        print(message)
    sys.stdout.flush()

print("=" * 70)
print("Step 1: F-test 数值稳定性修复 - 分块处理版本")
print("=" * 70)

# GPU检查
print_progress("🔍 GPU检查:")
print_progress(f"  CUDA可用: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print_progress(f"  GPU设备: {torch.cuda.get_device_name(0)}")
    print_progress(f"  GPU内存: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.1f} GB")
    device = torch.device('cuda')
    use_gpu = True
else:
    print_progress("  ⚠️ CUDA不可用，将使用CPU")
    device = torch.device('cpu')
    use_gpu = False

def chunked_f_classif(X, y, chunk_size=100000, verbose=True):
    """
    分块F-test实现 - 处理大数据集
    """
    if verbose:
        print_progress(f"  🔬 执行分块F-test: {X.shape}, 块大小: {chunk_size}")
    
    n_samples = X.shape[0]
    n_features = X.shape[1]
    
    # 如果数据量小于块大小，直接计算
    if n_samples <= chunk_size:
        if verbose:
            print_progress("  💻 数据量较小，直接计算F-test")
        return f_classif(X, y)
    
    # 分块计算
    n_chunks = (n_samples + chunk_size - 1) // chunk_size
    f_values = np.zeros(n_features)
    p_values = np.zeros(n_features)
    
    if verbose:
        print_progress(f"  📊 分块处理: {n_chunks} 个块")
    
    for i in range(n_chunks):
        start_idx = i * chunk_size
        end_idx = min((i + 1) * chunk_size, n_samples)
        
        if verbose:
            print_progress(f"    处理块 {i+1}/{n_chunks}: {start_idx}-{end_idx}")
        
        try:
            # 获取当前块的数据
            X_chunk = X.iloc[start_idx:end_idx]
            y_chunk = y.iloc[start_idx:end_idx]
            
            # 数据预处理
            X_chunk_clean = X_chunk.copy()
            
            # 移除常数特征
            constant_mask = (X_chunk_clean.std() > 1e-8)
            X_chunk_clean = X_chunk_clean.loc[:, constant_mask]
            
            # 处理无穷值和NaN
            X_chunk_clean = X_chunk_clean.replace([np.inf, -np.inf], np.nan)
            X_chunk_clean = np.nan_to_num(X_chunk_clean, nan=0.0, posinf=0.0, neginf=0.0)
            
            # 标准化
            scaler = RobustScaler()
            X_chunk_scaled = scaler.fit_transform(X_chunk_clean)
            
            # 执行F-test
            f_chunk, p_chunk = f_classif(X_chunk_scaled, y_chunk)
            
            # 累积结果
            f_values += f_chunk
            p_values += p_chunk
            
        except Exception as e:
            if verbose:
                print_progress(f"    ⚠️ 块 {i+1} 计算失败: {e}")
            continue
    
    # 平均化结果
    f_values /= n_chunks
    p_values /= n_chunks
    
    if verbose:
        print_progress(f"  ✅ 分块F-test完成: {n_chunks} 个块")
        print_progress(f"  📊 F值统计: 均值={np.mean(f_values):.2f}, 标准差={np.std(f_values):.2f}")
        print_progress(f"  📊 F值范围: {np.min(f_values):.2f} - {np.max(f_values):.2f}")
        print_progress(f"  ✅ 有效特征: {np.sum(np.isfinite(f_values) & (f_values > 0))}/{len(f_values)}")
    
    return f_values, p_values

def sample_based_f_classif(X, y, sample_size=500000, verbose=True):
    """
    基于抽样的F-test实现 - 处理超大数据集
    """
    if verbose:
        print_progress(f"  🔬 执行抽样F-test: {X.shape}, 抽样大小: {sample_size}")
    
    n_samples = X.shape[0]
    
    # 如果数据量小于抽样大小，直接计算
    if n_samples <= sample_size:
        if verbose:
            print_progress("  💻 数据量较小，直接计算F-test")
        return f_classif(X, y)
    
    # 随机抽样
    np.random.seed(42)
    sample_indices = np.random.choice(n_samples, size=sample_size, replace=False)
    X_sample = X.iloc[sample_indices]
    y_sample = y.iloc[sample_indices]
    
    if verbose:
        print_progress(f"  📊 抽样处理: {n_samples} -> {sample_size} 样本")
    
    # 数据预处理
    X_sample_clean = X_sample.copy()
    
    # 移除常数特征
    constant_mask = (X_sample_clean.std() > 1e-8)
    X_sample_clean = X_sample_clean.loc[:, constant_mask]
    
    # 处理无穷值和NaN
    X_sample_clean = X_sample_clean.replace([np.inf, -np.inf], np.nan)
    X_sample_clean = np.nan_to_num(X_sample_clean, nan=0.0, posinf=0.0, neginf=0.0)
    
    # 标准化
    scaler = RobustScaler()
    X_sample_scaled = scaler.fit_transform(X_sample_clean)
    
    # 执行F-test
    f_values, p_values = f_classif(X_sample_scaled, y_sample)
    
    if verbose:
        print_progress(f"  ✅ 抽样F-test完成")
        print_progress(f"  📊 F值统计: 均值={np.mean(f_values):.2f}, 标准差={np.std(f_values):.2f}")
        print_progress(f"  📊 F值范围: {np.min(f_values):.2f} - {np.max(f_values):.2f}")
        print_progress(f"  ✅ 有效特征: {np.sum(np.isfinite(f_values) & (f_values > 0))}/{len(f_values)}")
    
    return f_values, p_values

# ======= Step 1: 数据读取 =======
print_progress("\n📂 Step 1: 数据读取")
start_time = time.time()

print_progress("  📥 正在读取features_base.csv...")
base = pd.read_csv("features_base.csv")
print_progress(f"    ✅ Base特征加载完成: {base.shape}")

print_progress("  📥 正在读取features_extended.csv...")
extended = pd.read_csv("features_extended.csv")
print_progress(f"    ✅ Extended特征加载完成: {extended.shape}")

print_progress("  📥 正在读取labels.csv...")
y = pd.read_csv("labels.csv")["target"]
print_progress(f"    ✅ 标签加载完成: {len(y)} 个样本")

# 样本一致性检查
assert len(base) == len(extended) == len(y), "样本数量不一致"
print_progress(f"  ✅ 数据加载完成: {len(y)} 个样本")
print_progress(f"  ⏱️ 数据加载耗时: {time.time() - start_time:.2f}秒")

# ======= Step 2: F-test数值稳定性修复 =======
print_progress("\n🔧 Step 2: F-test数值稳定性修复")
stability_start = time.time()

# 2.1 测试原始F-test（小样本）
print_progress("  🔍 测试原始F-test（小样本）...")
try:
    # 只测试前10000个样本
    F_original, p_original = f_classif(extended.iloc[:10000].fillna(0), y.iloc[:10000])
    print_progress(f"    📊 原始F-test: F值范围 {np.min(F_original):.2f} - {np.max(F_original):.2f}")
    print_progress(f"    📊 有效F值: {np.sum(np.isfinite(F_original) & (F_original > 0))}/{len(F_original)}")
except Exception as e:
    print_progress(f"    ❌ 原始F-test失败: {e}")
    F_original, p_original = np.ones(extended.shape[1]), np.ones(extended.shape[1])

# 2.2 执行修复后的特征选择（分块处理）
print_progress("  🛠️ 执行修复后的特征选择（分块处理）...")
if len(extended) > 1000000:
    # 超大数据集使用抽样
    F_values, p_values = sample_based_f_classif(extended, y, sample_size=500000, verbose=True)
else:
    # 大数据集使用分块
    F_values, p_values = chunked_f_classif(extended, y, chunk_size=100000, verbose=True)

# 选择前20个特征
print_progress("  🎯 选择前20个特征...")
if len(F_values) > 0:
    valid_F = F_values[np.isfinite(F_values) & (F_values > 0)]
    if len(valid_F) > 0:
        top_20_indices = np.argsort(F_values)[-20:]
        selected_features = extended.columns[top_20_indices]
        extended_selected = extended[selected_features]
    else:
        print_progress("    ⚠️ 警告: 无有效F值，使用前20个特征")
        extended_selected = extended.iloc[:, :20]
        selected_features = extended_selected.columns
else:
    print_progress("    ⚠️ 警告: F-test返回空结果，使用前20个特征")
    extended_selected = extended.iloc[:, :20]
    selected_features = extended_selected.columns

print_progress(f"  ✅ 特征选择完成: {extended.shape[1]} -> {extended_selected.shape[1]} 特征")
print_progress(f"  ⏱️ F-test修复耗时: {time.time() - stability_start:.2f}秒")

# ======= Step 3: 数据划分与标准化 =======
print_progress("\n📊 Step 3: 数据划分与标准化")
preprocess_start = time.time()

print_progress("  🔄 正在划分数据...")
Xb_train, Xb_test, y_train, y_test = train_test_split(
    base, y, test_size=0.3, random_state=42)
Xe_train, Xe_test, _, _ = train_test_split(
    extended_selected, y, test_size=0.3, random_state=42)
print_progress(f"  ✅ 数据划分完成: 训练集{len(y_train)}个, 测试集{len(y_test)}个")

print_progress("  🔄 正在标准化数据...")
scaler = RobustScaler()
Xb_train_scaled = scaler.fit_transform(Xb_train)
Xb_test_scaled = scaler.transform(Xb_test)
Xe_train_scaled = scaler.fit_transform(Xe_train)
Xe_test_scaled = scaler.transform(Xe_test)
print_progress("  ✅ 数据标准化完成")

print_progress(f"  ⏱️ 预处理耗时: {time.time() - preprocess_start:.2f}秒")

# ======= Step 4: 模型训练与评估 =======
print_progress("\n🤖 Step 4: 模型训练与评估")
model_start = time.time()

print_progress("  🚀 初始化模型...")
model = HistGradientBoostingRegressor(
    max_iter=100,
    learning_rate=0.1,
    max_depth=10,
    min_samples_leaf=50,
    random_state=42,
    verbose=0
)

# Base模型
print_progress("  🎯 训练Base模型...")
model.fit(Xb_train_scaled, y_train)
y_pred_base = model.predict(Xb_test_scaled)
r2_base = r2_score(y_test, y_pred_base)
print_progress(f"    ✅ Base模型R²: {r2_base:.4f}")

# Extended模型
print_progress("  🎯 训练Extended模型...")
model.fit(Xe_train_scaled, y_train)
y_pred_ext = model.predict(Xe_test_scaled)
r2_ext = r2_score(y_test, y_pred_ext)
print_progress(f"    ✅ Extended模型R²: {r2_ext:.4f}")

print_progress(f"  ⏱️ 模型训练耗时: {time.time() - model_start:.2f}秒")

# ======= Step 5: 结果保存 =======
print_progress("\n💾 Step 5: 结果保存")

improvement = (r2_ext - r2_base) / abs(r2_base + 1e-9) * 100
results = {
    "step1_f_test_stability_chunked": {
        "f_test_comparison": {
            "original_f_range": [float(np.min(F_original)), float(np.max(F_original))],
            "original_f_valid": int(np.sum(np.isfinite(F_original) & (F_original > 0))),
            "fixed_f_range": [float(np.min(F_values)), float(np.max(F_values))],
            "fixed_f_valid": int(np.sum(np.isfinite(F_values) & (F_values > 0)))
        },
        "feature_selection": {
            "original_features": int(extended.shape[1]),
            "selected_features": int(extended_selected.shape[1]),
            "selected_feature_names": selected_features.tolist(),
            "f_values_mean": float(np.mean(F_values)),
            "f_values_std": float(np.std(F_values))
        },
        "model_performance": {
            "R2_base": float(r2_base),
            "R2_extended": float(r2_ext),
            "improvement_abs": float(r2_ext - r2_base),
            "improvement_percent": float(improvement),
            "MAE_base": float(mean_absolute_error(y_test, y_pred_base)),
            "MAE_extended": float(mean_absolute_error(y_test, y_pred_ext)),
            "RMSE_base": float(np.sqrt(mean_squared_error(y_test, y_pred_base))),
            "RMSE_extended": float(np.sqrt(mean_squared_error(y_test, y_pred_ext)))
        },
        "performance_info": {
            "total_runtime_seconds": time.time() - start_time,
            "data_loading_time": time.time() - start_time - (time.time() - stability_start),
            "stability_fix_time": time.time() - stability_start - (time.time() - preprocess_start),
            "preprocessing_time": time.time() - preprocess_start - (time.time() - model_start),
            "model_training_time": time.time() - model_start
        },
        "gpu_info": {
            "cuda_available": torch.cuda.is_available(),
            "gpu_device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
            "gpu_memory_gb": torch.cuda.get_device_properties(0).total_memory / 1024**3 if torch.cuda.is_available() else None
        }
    }
}

print_progress("  💾 正在保存结果...")
with open("step1_f_test_stability_chunked_results.json", "w") as f:
    json.dump(results, f, indent=4)

# ======= Step 6: 结果报告 =======
print_progress("\n📊 Step 6: 结果报告")
print("=" * 70)
print("Step 1: F-test 数值稳定性修复结果（分块处理）")
print("=" * 70)
print(f"🔧 F-test修复效果:")
print(f"  原始F-test有效特征: {np.sum(np.isfinite(F_original) & (F_original > 0))}/{len(F_original)}")
print(f"  修复后F-test有效特征: {np.sum(np.isfinite(F_values) & (F_values > 0))}/{len(F_values)}")
print(f"  特征选择: {extended.shape[1]} -> {extended_selected.shape[1]} 特征")
print(f"\n📈 模型性能:")
print(f"  Base模型 R²: {r2_base:.4f}")
print(f"  Extended模型 R²: {r2_ext:.4f}")
print(f"  性能提升: {r2_ext - r2_base:.4f} ({improvement:.2f}%)")
print(f"\n⏱️ 性能信息:")
print(f"  总运行时间: {time.time() - start_time:.2f}秒")
print(f"  F-test修复时间: {time.time() - stability_start - (time.time() - preprocess_start):.2f}秒")
print(f"\n✅ 结果文件:")
print(f"  step1_f_test_stability_chunked_results.json - F-test稳定性修复结果")
print("=" * 70)

print("🎉 Step 1: F-test 数值稳定性修复完成！")








