#!/usr/bin/env python3
"""
Step 1: F-test 数值稳定性修复 - 带进度显示版本
目标：消除 F-test 阶段的极端值与 underflow 异常
实时显示处理进度
"""

import pandas as pd
import numpy as np
import torch
import json
import time
import sys
from sklearn.feature_selection import f_classif, f_regression
from sklearn.preprocessing import StandardScaler, RobustScaler
from sklearn.model_selection import train_test_split
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
import warnings
warnings.filterwarnings("ignore")

def print_progress(message, step=None, total_steps=None):
    """打印进度信息"""
    if step is not None and total_steps is not None:
        progress = (step / total_steps) * 100
        print(f"[{progress:5.1f}%] {message}")
    else:
        print(message)
    sys.stdout.flush()

print("=" * 70)
print("Step 1: F-test 数值稳定性修复 - 带进度显示版本")
print("=" * 70)

# GPU检查
print_progress("🔍 GPU检查:")
print_progress(f"  CUDA可用: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print_progress(f"  GPU设备: {torch.cuda.get_device_name(0)}")
    print_progress(f"  GPU内存: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.1f} GB")
    device = torch.device('cuda')
    use_gpu = True
else:
    print_progress("  ⚠️ CUDA不可用，将使用CPU")
    device = torch.device('cpu')
    use_gpu = False

def safe_f_classif_with_progress(X, y, verbose=True):
    """
    带进度显示的F-test实现
    """
    if verbose:
        print_progress(f"  🔬 执行修复的F-test: {X.shape}")
    
    # Step 1: 数据预处理
    X_clean = X.copy()
    original_shape = X_clean.shape
    
    print_progress("    🧹 移除常数特征...")
    # 移除常数特征
    constant_mask = (X_clean.std() > 1e-8)
    X_clean = X_clean.loc[:, constant_mask]
    print_progress(f"    📊 常数特征移除: {original_shape[1]} -> {X_clean.shape[1]} 特征")
    
    print_progress("    🧹 处理无穷值和NaN...")
    # 处理无穷值和NaN
    X_clean = X_clean.replace([np.inf, -np.inf], np.nan)
    
    # 检查每列的NaN比例
    nan_ratio = X_clean.isna().sum() / len(X_clean)
    low_nan_mask = nan_ratio < 0.5  # 保留NaN比例小于50%的列
    X_clean = X_clean.loc[:, low_nan_mask]
    print_progress(f"    📊 高NaN列移除: {original_shape[1]} -> {X_clean.shape[1]} 特征")
    
    print_progress("    📊 方差筛选...")
    # 移除方差极低列
    var_threshold = 1e-8
    variances = X_clean.var()
    low_var_mask = variances > var_threshold
    X_clean = X_clean.loc[:, low_var_mask]
    print_progress(f"    📊 方差筛选: {original_shape[1]} -> {X_clean.shape[1]} 特征")
    
    # Step 2: 数值稳定性处理
    print_progress("    🔄 数值稳定性处理...")
    X_clean = np.nan_to_num(X_clean, nan=0.0, posinf=0.0, neginf=0.0)
    
    # Step 3: 检查数据有效性
    if X_clean.shape[1] == 0:
        print_progress("    ⚠️ 警告: 所有特征都被过滤，返回原始数据")
        return np.ones(X.shape[1]), np.ones(X.shape[1])
    
    # Step 4: 数据标准化（提高数值稳定性）
    print_progress("    📊 数据标准化...")
    scaler = RobustScaler()
    X_scaled = scaler.fit_transform(X_clean)
    
    # Step 5: 执行F-test
    print_progress("    🔬 执行F-test计算...")
    try:
        F, p = f_classif(X_scaled, y)
        
        # Step 6: 验证F值有效性
        valid_mask = np.isfinite(F) & (F > 0) & (F < 1e10)
        
        if not np.any(valid_mask):
            print_progress("    ⚠️ 警告: F-test未找到有效特征")
            return np.ones(X.shape[1]), np.ones(X.shape[1])
        
        # Step 7: 记录统计信息
        print_progress(f"    📊 F值统计: 均值={np.mean(F[valid_mask]):.2f}, 标准差={np.std(F[valid_mask]):.2f}")
        print_progress(f"    📊 F值范围: {np.min(F[valid_mask]):.2f} - {np.max(F[valid_mask]):.2f}")
        print_progress(f"    ✅ 有效特征: {np.sum(valid_mask)}/{len(F)}")
        
        return F, p
        
    except Exception as e:
        print_progress(f"    ❌ F-test失败: {e}")
        return np.ones(X.shape[1]), np.ones(X.shape[1])

# ======= Step 1: 数据读取 =======
print_progress("\n📂 Step 1: 数据读取")
start_time = time.time()

print_progress("  📥 正在读取features_base.csv...")
base = pd.read_csv("features_base.csv")
print_progress(f"    ✅ Base特征加载完成: {base.shape}")

print_progress("  📥 正在读取features_extended.csv...")
extended = pd.read_csv("features_extended.csv")
print_progress(f"    ✅ Extended特征加载完成: {extended.shape}")

print_progress("  📥 正在读取labels.csv...")
y = pd.read_csv("labels.csv")["target"]
print_progress(f"    ✅ 标签加载完成: {len(y)} 个样本")

# 样本一致性检查
assert len(base) == len(extended) == len(y), "样本数量不一致"
print_progress(f"  ✅ 数据加载完成: {len(y)} 个样本")
print_progress(f"  ⏱️ 数据加载耗时: {time.time() - start_time:.2f}秒")

# ======= Step 2: F-test数值稳定性修复 =======
print_progress("\n🔧 Step 2: F-test数值稳定性修复")
stability_start = time.time()

# 2.1 测试原始F-test
print_progress("  🔍 测试原始F-test...")
try:
    F_original, p_original = f_classif(extended.fillna(0), y)
    print_progress(f"    📊 原始F-test: F值范围 {np.min(F_original):.2f} - {np.max(F_original):.2f}")
    print_progress(f"    📊 有效F值: {np.sum(np.isfinite(F_original) & (F_original > 0))}/{len(F_original)}")
except Exception as e:
    print_progress(f"    ❌ 原始F-test失败: {e}")
    F_original, p_original = np.ones(extended.shape[1]), np.ones(extended.shape[1])

# 2.2 执行修复后的特征选择
print_progress("  🛠️ 执行修复后的特征选择...")
F_values, p_values = safe_f_classif_with_progress(extended, y)

# 选择前20个特征
print_progress("  🎯 选择前20个特征...")
if len(F_values) > 0:
    valid_F = F_values[np.isfinite(F_values) & (F_values > 0)]
    if len(valid_F) > 0:
        top_20_indices = np.argsort(F_values)[-20:]
        selected_features = extended.columns[top_20_indices]
        extended_selected = extended[selected_features]
    else:
        print_progress("    ⚠️ 警告: 无有效F值，使用前20个特征")
        extended_selected = extended.iloc[:, :20]
        selected_features = extended_selected.columns
else:
    print_progress("    ⚠️ 警告: F-test返回空结果，使用前20个特征")
    extended_selected = extended.iloc[:, :20]
    selected_features = extended_selected.columns

print_progress(f"  ✅ 特征选择完成: {extended.shape[1]} -> {extended_selected.shape[1]} 特征")
print_progress(f"  ⏱️ F-test修复耗时: {time.time() - stability_start:.2f}秒")

# ======= Step 3: 数据划分与标准化 =======
print_progress("\n📊 Step 3: 数据划分与标准化")
preprocess_start = time.time()

print_progress("  🔄 正在划分数据...")
Xb_train, Xb_test, y_train, y_test = train_test_split(
    base, y, test_size=0.3, random_state=42)
Xe_train, Xe_test, _, _ = train_test_split(
    extended_selected, y, test_size=0.3, random_state=42)
print_progress(f"  ✅ 数据划分完成: 训练集{len(y_train)}个, 测试集{len(y_test)}个")

print_progress("  🔄 正在标准化数据...")
scaler = RobustScaler()
Xb_train_scaled = scaler.fit_transform(Xb_train)
Xb_test_scaled = scaler.transform(Xb_test)
Xe_train_scaled = scaler.fit_transform(Xe_train)
Xe_test_scaled = scaler.transform(Xe_test)
print_progress("  ✅ 数据标准化完成")

print_progress(f"  ⏱️ 预处理耗时: {time.time() - preprocess_start:.2f}秒")

# ======= Step 4: 模型训练与评估 =======
print_progress("\n🤖 Step 4: 模型训练与评估")
model_start = time.time()

print_progress("  🚀 初始化模型...")
model = HistGradientBoostingRegressor(
    max_iter=100,
    learning_rate=0.1,
    max_depth=10,
    min_samples_leaf=50,
    random_state=42,
    verbose=0
)

# Base模型
print_progress("  🎯 训练Base模型...")
model.fit(Xb_train_scaled, y_train)
y_pred_base = model.predict(Xb_test_scaled)
r2_base = r2_score(y_test, y_pred_base)
print_progress(f"    ✅ Base模型R²: {r2_base:.4f}")

# Extended模型
print_progress("  🎯 训练Extended模型...")
model.fit(Xe_train_scaled, y_train)
y_pred_ext = model.predict(Xe_test_scaled)
r2_ext = r2_score(y_test, y_pred_ext)
print_progress(f"    ✅ Extended模型R²: {r2_ext:.4f}")

print_progress(f"  ⏱️ 模型训练耗时: {time.time() - model_start:.2f}秒")

# ======= Step 5: 结果保存 =======
print_progress("\n💾 Step 5: 结果保存")

improvement = (r2_ext - r2_base) / abs(r2_base + 1e-9) * 100
results = {
    "step1_f_test_stability_with_progress": {
        "f_test_comparison": {
            "original_f_range": [float(np.min(F_original)), float(np.max(F_original))],
            "original_f_valid": int(np.sum(np.isfinite(F_original) & (F_original > 0))),
            "fixed_f_range": [float(np.min(F_values)), float(np.max(F_values))],
            "fixed_f_valid": int(np.sum(np.isfinite(F_values) & (F_values > 0)))
        },
        "feature_selection": {
            "original_features": int(extended.shape[1]),
            "selected_features": int(extended_selected.shape[1]),
            "selected_feature_names": selected_features.tolist(),
            "f_values_mean": float(np.mean(F_values)),
            "f_values_std": float(np.std(F_values))
        },
        "model_performance": {
            "R2_base": float(r2_base),
            "R2_extended": float(r2_ext),
            "improvement_abs": float(r2_ext - r2_base),
            "improvement_percent": float(improvement),
            "MAE_base": float(mean_absolute_error(y_test, y_pred_base)),
            "MAE_extended": float(mean_absolute_error(y_test, y_pred_ext)),
            "RMSE_base": float(np.sqrt(mean_squared_error(y_test, y_pred_base))),
            "RMSE_extended": float(np.sqrt(mean_squared_error(y_test, y_pred_ext)))
        },
        "performance_info": {
            "total_runtime_seconds": time.time() - start_time,
            "data_loading_time": time.time() - start_time - (time.time() - stability_start),
            "stability_fix_time": time.time() - stability_start - (time.time() - preprocess_start),
            "preprocessing_time": time.time() - preprocess_start - (time.time() - model_start),
            "model_training_time": time.time() - model_start
        },
        "gpu_info": {
            "cuda_available": torch.cuda.is_available(),
            "gpu_device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
            "gpu_memory_gb": torch.cuda.get_device_properties(0).total_memory / 1024**3 if torch.cuda.is_available() else None
        }
    }
}

print_progress("  💾 正在保存结果...")
with open("step1_f_test_stability_progress_results.json", "w") as f:
    json.dump(results, f, indent=4)

# ======= Step 6: 结果报告 =======
print_progress("\n📊 Step 6: 结果报告")
print("=" * 70)
print("Step 1: F-test 数值稳定性修复结果（带进度显示）")
print("=" * 70)
print(f"🔧 F-test修复效果:")
print(f"  原始F-test有效特征: {np.sum(np.isfinite(F_original) & (F_original > 0))}/{len(F_original)}")
print(f"  修复后F-test有效特征: {np.sum(np.isfinite(F_values) & (F_values > 0))}/{len(F_values)}")
print(f"  特征选择: {extended.shape[1]} -> {extended_selected.shape[1]} 特征")
print(f"\n📈 模型性能:")
print(f"  Base模型 R²: {r2_base:.4f}")
print(f"  Extended模型 R²: {r2_ext:.4f}")
print(f"  性能提升: {r2_ext - r2_base:.4f} ({improvement:.2f}%)")
print(f"\n⏱️ 性能信息:")
print(f"  总运行时间: {time.time() - start_time:.2f}秒")
print(f"  F-test修复时间: {time.time() - stability_start - (time.time() - preprocess_start):.2f}秒")
print(f"\n✅ 结果文件:")
print(f"  step1_f_test_stability_progress_results.json - F-test稳定性修复结果")
print("=" * 70)

print("🎉 Step 1: F-test 数值稳定性修复完成！")








