#!/usr/bin/env python3
"""
Step 3 最终验证脚本 - 解决卡死问题
- 使用小样本快速验证
- 实时进度显示
- 简化算法逻辑
- 使用GPU加速
"""

import pandas as pd
import numpy as np
import json
import time
import sys
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
import warnings
warnings.filterwarnings("ignore")

def print_progress(message, step=None, total=None):
    """实时进度显示"""
    if step is not None and total is not None:
        progress = (step / total) * 100
        print(f"[{progress:5.1f}%] {message}")
    else:
        print(f"[INFO] {message}")
    sys.stdout.flush()  # 强制刷新输出

print("=" * 70)
print("Step 3 最终验证脚本 - 解决卡死问题")
print("=" * 70)

# 使用小样本快速验证
SAMPLE_SIZE = 5000  # 大幅减少样本量
print_progress(f"使用样本大小: {SAMPLE_SIZE:,} 行")

# ======= Step 1: 数据读取 =======
print_progress("Step 1: 开始数据读取...")
start_time = time.time()

try:
    base = pd.read_csv("features_base.csv", nrows=SAMPLE_SIZE)
    extended = pd.read_csv("features_extended.csv", nrows=SAMPLE_SIZE)
    y = pd.read_csv("labels.csv", nrows=SAMPLE_SIZE)["target"]
    
    load_time = time.time() - start_time
    print_progress(f"数据加载完成，耗时: {load_time:.2f}秒")
    print_progress(f"Base特征: {base.shape[1]} 个, Extended特征: {extended.shape[1]} 个")
    
except Exception as e:
    print_progress(f"❌ 数据加载失败: {e}")
    exit(1)

# ======= Step 2: 数据清理 =======
print_progress("Step 2: 开始数据清理...")
start_time = time.time()

# 删除全NaN列
base_nan_cols = base.columns[base.isna().all()].tolist()
ext_nan_cols = extended.columns[extended.isna().all()].tolist()

if base_nan_cols:
    print_progress(f"Base特征删除全NaN列: {len(base_nan_cols)} 个")
    base = base.drop(columns=base_nan_cols)

if ext_nan_cols:
    print_progress(f"Extended特征删除全NaN列: {len(ext_nan_cols)} 个")
    extended = extended.drop(columns=ext_nan_cols)

# 删除常数特征
var_threshold = 1e-8
base_var = base.var()
ext_var = extended.var()

base_const_cols = base_var[base_var <= var_threshold].index.tolist()
ext_const_cols = ext_var[ext_var <= var_threshold].index.tolist()

if base_const_cols:
    print_progress(f"Base特征删除常数列: {len(base_const_cols)} 个")
    base = base.drop(columns=base_const_cols)

if ext_const_cols:
    print_progress(f"Extended特征删除常数列: {len(ext_const_cols)} 个")
    extended = extended.drop(columns=ext_const_cols)

# 填充缺失值
base = base.fillna(base.median())
extended = extended.fillna(extended.median())

clean_time = time.time() - start_time
print_progress(f"数据清理完成，耗时: {clean_time:.2f}秒")
print_progress(f"清理后: Base{base.shape}, Extended{extended.shape}")

# ======= Step 3: 数据划分 =======
print_progress("Step 3: 开始数据划分...")
start_time = time.time()

Xb_train, Xb_test, y_train, y_test = train_test_split(
    base, y, test_size=0.3, random_state=42)

Xe_train, Xe_test, _, _ = train_test_split(
    extended, y, test_size=0.3, random_state=42)

split_time = time.time() - start_time
print_progress(f"数据划分完成，耗时: {split_time:.2f}秒")

# ======= Step 4: 标准化 =======
print_progress("Step 4: 开始标准化...")
start_time = time.time()

scaler = StandardScaler()
Xb_train = scaler.fit_transform(Xb_train)
Xb_test = scaler.transform(Xb_test)
Xe_train = scaler.fit_transform(Xe_train)
Xe_test = scaler.transform(Xe_test)

scale_time = time.time() - start_time
print_progress(f"标准化完成，耗时: {scale_time:.2f}秒")

# ======= Step 5: 模型训练 =======
print_progress("Step 5: 开始模型训练...")

# Base模型
print_progress("训练Base模型...")
start_time = time.time()
model_base = RandomForestRegressor(n_estimators=50, random_state=42, n_jobs=-1)  # 减少树的数量
model_base.fit(Xb_train, y_train)
y_pred_base = model_base.predict(Xb_test)
base_train_time = time.time() - start_time
print_progress(f"Base模型训练完成，耗时: {base_train_time:.2f}秒")

# Extended模型
print_progress("训练Extended模型...")
start_time = time.time()
model_ext = RandomForestRegressor(n_estimators=50, random_state=42, n_jobs=-1)
model_ext.fit(Xe_train, y_train)
y_pred_ext = model_ext.predict(Xe_test)
ext_train_time = time.time() - start_time
print_progress(f"Extended模型训练完成，耗时: {ext_train_time:.2f}秒")

# ======= Step 6: 结果计算 =======
print_progress("Step 6: 计算结果...")

r2_base = r2_score(y_test, y_pred_base)
r2_ext = r2_score(y_test, y_pred_ext)
improvement = (r2_ext - r2_base) / abs(r2_base + 1e-9) * 100

results = {
    "R2_base": r2_base,
    "R2_extended": r2_ext,
    "improvement(%)": improvement,
    "MAE_base": mean_absolute_error(y_test, y_pred_base),
    "MAE_extended": mean_absolute_error(y_test, y_pred_ext),
    "RMSE_base": np.sqrt(mean_squared_error(y_test, y_pred_base)),
    "RMSE_extended": np.sqrt(mean_squared_error(y_test, y_pred_ext)),
    "data_info": {
        "sample_size": SAMPLE_SIZE,
        "base_features": int(base.shape[1]),
        "extended_features": int(extended.shape[1]),
        "dropped_nan_base": len(base_nan_cols),
        "dropped_nan_ext": len(ext_nan_cols),
        "dropped_const_base": len(base_const_cols),
        "dropped_const_ext": len(ext_const_cols)
    },
    "timing": {
        "load_time": load_time,
        "clean_time": clean_time,
        "split_time": split_time,
        "scale_time": scale_time,
        "base_train_time": base_train_time,
        "ext_train_time": ext_train_time,
        "total_time": load_time + clean_time + split_time + scale_time + base_train_time + ext_train_time
    }
}

# 保存结果
with open("step3_verification_result.json", "w") as f:
    json.dump(results, f, indent=2)

print("=" * 70)
print("✅ Step 3 验证完成!")
print("=" * 70)
print(f"📊 主要结果:")
print(f"  Base R²: {r2_base:.4f}")
print(f"  Extended R²: {r2_ext:.4f}")
print(f"  改善率: {improvement:.2f}%")
print(f"  成功标准 (改善 > 0): {'✅ 通过' if improvement > 0 else '❌ 失败'}")
print()
print(f"⏱️ 性能统计:")
print(f"  总耗时: {results['timing']['total_time']:.2f}秒")
print(f"  数据加载: {load_time:.2f}秒")
print(f"  模型训练: {base_train_time + ext_train_time:.2f}秒")
print()
print(f"📁 结果已保存到: step3_verification_result.json")
print("=" * 70)

