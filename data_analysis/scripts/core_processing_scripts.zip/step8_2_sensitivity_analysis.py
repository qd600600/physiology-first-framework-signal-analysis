#!/usr/bin/env python3
"""
Step 8.2: 敏感性分析（特征重要性、数据质量影响）
分析特征重要性、数据质量对模型性能的影响
"""

import os
import sys
import logging
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from pathlib import Path
from datetime import datetime
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from sklearn.preprocessing import StandardScaler
from sklearn.inspection import permutation_importance
import json
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('step8_2_sensitivity_analysis.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class PyTorchRegressionModel(nn.Module):
    """PyTorch神经网络回归模型，支持GPU加速."""
    
    def __init__(self, input_size: int, hidden_sizes: list = [64, 32, 16], dropout_rate: float = 0.2):
        super(PyTorchRegressionModel, self).__init__()
        
        layers = []
        prev_size = input_size
        
        for hidden_size in hidden_sizes:
            layers.extend([
                nn.Linear(prev_size, hidden_size),
                nn.ReLU(),
                nn.Dropout(dropout_rate)
            ])
            prev_size = hidden_size
        
        # Output layer
        layers.append(nn.Linear(prev_size, 1))
        
        self.network = nn.Sequential(*layers)
    
    def forward(self, x):
        return self.network(x)

class SensitivityAnalyzer:
    """敏感性分析器."""
    
    def __init__(self, device: str = 'auto', n_trials: int = 10):
        self.device = self._setup_device(device)
        self.n_trials = n_trials
        logger.info(f"Initialized SensitivityAnalyzer on {self.device} with {n_trials} trials")
    
    def _setup_device(self, device: str) -> torch.device:
        """Setup computation device."""
        if device == 'auto':
            if torch.cuda.is_available():
                device = 'cuda'
                logger.info(f"CUDA available: {torch.cuda.get_device_name()}")
                logger.info(f"CUDA capability: {torch.cuda.get_device_capability()}")
                logger.info(f"CUDA memory: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB")
            else:
                device = 'cpu'
                logger.info("CUDA not available, using CPU")
        
        return torch.device(device)
    
    def load_clean_data(self, dataset_name: str, window_size: str) -> pd.DataFrame:
        """加载清理后的数据."""
        try:
            file_path = f"/mnt/d/data_analysis/processed/lri_calculation/lri_{dataset_name}_{window_size}_clean.csv"
            df = pd.read_csv(file_path)
            logger.info(f"Loaded clean data: {df.shape} from {file_path}")
            return df
        except Exception as e:
            logger.error(f"Error loading clean data for {dataset_name}_{window_size}: {e}")
            return pd.DataFrame()
    
    def prepare_features_and_target(self, df: pd.DataFrame) -> tuple:
        """准备特征和目标变量."""
        try:
            # 排除非特征列
            exclude_cols = ['window_id', 'window_size_seconds', 'sample_count']
            feature_cols = [col for col in df.columns if col not in exclude_cols]
            
            # 找到目标变量
            target_candidates = ['recovery_pattern_score', 'stress_release_efficiency', 'volatility_recovery_index', 'trend_recovery_score']
            target_col = None
            for candidate in target_candidates:
                if candidate in df.columns:
                    target_col = candidate
                    break
            
            if not target_col:
                logger.error("No target variable found")
                return None, None, None, None
            
            feature_cols = [col for col in feature_cols if col != target_col]
            
            X = df[feature_cols].values
            y = df[target_col].values
            
            return X, y, feature_cols, target_col
            
        except Exception as e:
            logger.error(f"Error preparing features and target: {e}")
            return None, None, None, None
    
    def train_pytorch_model(self, X_train: np.ndarray, y_train: np.ndarray, 
                           X_test: np.ndarray, y_test: np.ndarray, 
                           feature_cols: list, model_config: dict = None) -> dict:
        """训练PyTorch神经网络模型."""
        try:
            if model_config is None:
                model_config = {
                    'hidden_sizes': [64, 32, 16],
                    'dropout_rate': 0.2,
                    'learning_rate': 0.001,
                    'epochs': 50
                }
            
            # 数据标准化
            scaler_X = StandardScaler()
            scaler_y = StandardScaler()
            
            X_train_scaled = scaler_X.fit_transform(X_train)
            y_train_scaled = scaler_y.fit_transform(y_train.reshape(-1, 1)).flatten()
            X_test_scaled = scaler_X.transform(X_test)
            y_test_scaled = scaler_y.transform(y_test.reshape(-1, 1)).flatten()
            
            # 转换为PyTorch张量
            X_train_tensor = torch.FloatTensor(X_train_scaled).to(self.device)
            y_train_tensor = torch.FloatTensor(y_train_scaled).to(self.device)
            X_test_tensor = torch.FloatTensor(X_test_scaled).to(self.device)
            y_test_tensor = torch.FloatTensor(y_test_scaled).to(self.device)
            
            # 创建模型
            model = PyTorchRegressionModel(
                input_size=len(feature_cols),
                hidden_sizes=model_config['hidden_sizes'],
                dropout_rate=model_config['dropout_rate']
            ).to(self.device)
            
            # 损失函数和优化器
            criterion = nn.MSELoss()
            optimizer = torch.optim.Adam(model.parameters(), lr=model_config['learning_rate'])
            
            # 训练循环
            model.train()
            best_loss = float('inf')
            patience = 10
            patience_counter = 0
            
            for epoch in range(model_config['epochs']):
                optimizer.zero_grad()
                outputs = model(X_train_tensor).squeeze()
                loss = criterion(outputs, y_train_tensor)
                loss.backward()
                optimizer.step()
                
                # 早停机制
                if loss.item() < best_loss:
                    best_loss = loss.item()
                    patience_counter = 0
                else:
                    patience_counter += 1
                
                if patience_counter >= patience:
                    break
            
            # 预测
            model.eval()
            with torch.no_grad():
                y_pred_scaled = model(X_test_tensor).squeeze().cpu().numpy()
            
            # 反标准化
            y_pred = scaler_y.inverse_transform(y_pred_scaled.reshape(-1, 1)).flatten()
            
            # 计算性能指标
            mse = mean_squared_error(y_test, y_pred)
            r2 = r2_score(y_test, y_pred)
            mae = mean_absolute_error(y_test, y_pred)
            
            return {
                'model': model,
                'predictions': y_pred,
                'test_actual': y_test,
                'mse': mse,
                'r2': r2,
                'mae': mae,
                'scaler_X': scaler_X,
                'scaler_y': scaler_y,
                'feature_columns': feature_cols,
                'model_config': model_config
            }
            
        except Exception as e:
            logger.error(f"Error training PyTorch model: {e}")
            return None
    
    def feature_importance_analysis(self, dataset_name: str, window_size: str) -> dict:
        """特征重要性分析."""
        try:
            logger.info(f"Starting feature importance analysis for {dataset_name}_{window_size}")
            
            # 加载数据
            df = self.load_clean_data(dataset_name, window_size)
            if df.empty:
                return {'error': 'Failed to load data'}
            
            X, y, feature_cols, target_col = self.prepare_features_and_target(df)
            if X is None:
                return {'error': 'Failed to prepare features'}
            
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42
            )
            
            # 训练基准模型
            baseline_model = self.train_pytorch_model(X_train, y_train, X_test, y_test, feature_cols)
            if not baseline_model:
                return {'error': 'Failed to train baseline model'}
            
            baseline_r2 = baseline_model['r2']
            logger.info(f"Baseline R²: {baseline_r2:.3f}")
            
            # 1. 单特征移除分析
            logger.info("Performing single feature removal analysis...")
            single_feature_importance = {}
            
            for i, feature_name in enumerate(feature_cols):
                # 移除第i个特征
                X_train_removed = np.delete(X_train, i, axis=1)
                X_test_removed = np.delete(X_test, i, axis=1)
                feature_cols_removed = feature_cols[:i] + feature_cols[i+1:]
                
                # 训练模型
                removed_model = self.train_pytorch_model(
                    X_train_removed, y_train, X_test_removed, y_test, feature_cols_removed
                )
                
                if removed_model:
                    r2_drop = baseline_r2 - removed_model['r2']
                    single_feature_importance[feature_name] = {
                        'r2_without_feature': removed_model['r2'],
                        'r2_drop': r2_drop,
                        'relative_importance': r2_drop / baseline_r2 if baseline_r2 > 0 else 0
                    }
                    logger.info(f"  {feature_name}: R² drop = {r2_drop:.3f}")
            
            # 2. 特征组合分析
            logger.info("Performing feature combination analysis...")
            combination_importance = {}
            
            # 分析两两特征组合的重要性
            for i in range(len(feature_cols)):
                for j in range(i+1, len(feature_cols)):
                    feature_pair = (feature_cols[i], feature_cols[j])
                    
                    # 移除这两个特征
                    remove_indices = [i, j]
                    X_train_pair_removed = np.delete(X_train, remove_indices, axis=1)
                    X_test_pair_removed = np.delete(X_test, remove_indices, axis=1)
                    feature_cols_pair_removed = [col for k, col in enumerate(feature_cols) if k not in remove_indices]
                    
                    # 训练模型
                    pair_removed_model = self.train_pytorch_model(
                        X_train_pair_removed, y_train, X_test_pair_removed, y_test, feature_cols_pair_removed
                    )
                    
                    if pair_removed_model:
                        r2_drop = baseline_r2 - pair_removed_model['r2']
                        combination_importance[f"{feature_cols[i]}+{feature_cols[j]}"] = {
                            'r2_without_pair': pair_removed_model['r2'],
                            'r2_drop': r2_drop,
                            'individual_drops': [
                                single_feature_importance[feature_cols[i]]['r2_drop'],
                                single_feature_importance[feature_cols[j]]['r2_drop']
                            ],
                            'interaction_effect': r2_drop - (single_feature_importance[feature_cols[i]]['r2_drop'] + 
                                                             single_feature_importance[feature_cols[j]]['r2_drop'])
                        }
            
            # 3. 特征排序
            sorted_features = sorted(single_feature_importance.items(), 
                                   key=lambda x: x[1]['r2_drop'], reverse=True)
            
            return {
                'dataset': dataset_name,
                'window_size': window_size,
                'baseline_r2': baseline_r2,
                'feature_columns': feature_cols,
                'single_feature_importance': single_feature_importance,
                'combination_importance': combination_importance,
                'feature_ranking': [item[0] for item in sorted_features],
                'target_variable': target_col
            }
            
        except Exception as e:
            logger.error(f"Error in feature importance analysis: {e}")
            return {'error': str(e)}
    
    def data_quality_sensitivity_analysis(self, dataset_name: str, window_size: str) -> dict:
        """数据质量敏感性分析."""
        try:
            logger.info(f"Starting data quality sensitivity analysis for {dataset_name}_{window_size}")
            
            # 加载数据
            df = self.load_clean_data(dataset_name, window_size)
            if df.empty:
                return {'error': 'Failed to load data'}
            
            X, y, feature_cols, target_col = self.prepare_features_and_target(df)
            if X is None:
                return {'error': 'Failed to prepare features'}
            
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42
            )
            
            # 训练基准模型
            baseline_model = self.train_pytorch_model(X_train, y_train, X_test, y_test, feature_cols)
            if not baseline_model:
                return {'error': 'Failed to train baseline model'}
            
            baseline_r2 = baseline_model['r2']
            
            # 数据质量敏感性测试
            quality_results = {}
            
            # 1. 异常值敏感性
            logger.info("Testing outlier sensitivity...")
            outlier_thresholds = [1.5, 2.0, 2.5, 3.0]  # 标准差倍数
            outlier_results = {}
            
            for threshold in outlier_thresholds:
                r2_scores = []
                
                for trial in range(self.n_trials):
                    # 识别异常值
                    np.random.seed(42 + trial)
                    outlier_mask = np.zeros_like(X_train, dtype=bool)
                    
                    for i in range(X_train.shape[1]):
                        feature_values = X_train[:, i]
                        mean_val = np.mean(feature_values)
                        std_val = np.std(feature_values)
                        
                        # 标记异常值
                        feature_outliers = np.abs(feature_values - mean_val) > threshold * std_val
                        outlier_mask[:, i] = feature_outliers
                    
                    # 移除包含异常值的样本
                    keep_mask = ~np.any(outlier_mask, axis=1)
                    X_train_clean = X_train[keep_mask]
                    y_train_clean = y_train[keep_mask]
                    
                    if len(X_train_clean) > 100:  # 确保有足够的训练数据
                        # 训练模型
                        clean_model = self.train_pytorch_model(
                            X_train_clean, y_train_clean, X_test, y_test, feature_cols
                        )
                        
                        if clean_model:
                            r2_scores.append(clean_model['r2'])
                
                if r2_scores:
                    outlier_results[threshold] = {
                        'mean_r2': np.mean(r2_scores),
                        'std_r2': np.std(r2_scores),
                        'r2_change': np.mean(r2_scores) - baseline_r2,
                        'r2_scores': r2_scores
                    }
            
            quality_results['outlier_sensitivity'] = outlier_results
            
            # 2. 数据完整性敏感性
            logger.info("Testing data completeness sensitivity...")
            completeness_rates = [0.95, 0.90, 0.85, 0.80]  # 数据完整性比例
            completeness_results = {}
            
            for completeness_rate in completeness_rates:
                r2_scores = []
                
                for trial in range(self.n_trials):
                    # 随机移除部分数据
                    np.random.seed(42 + trial)
                    n_samples = int(len(X_train) * completeness_rate)
                    sample_indices = np.random.choice(len(X_train), n_samples, replace=False)
                    
                    X_train_complete = X_train[sample_indices]
                    y_train_complete = y_train[sample_indices]
                    
                    # 训练模型
                    complete_model = self.train_pytorch_model(
                        X_train_complete, y_train_complete, X_test, y_test, feature_cols
                    )
                    
                    if complete_model:
                        r2_scores.append(complete_model['r2'])
                
                if r2_scores:
                    completeness_results[completeness_rate] = {
                        'mean_r2': np.mean(r2_scores),
                        'std_r2': np.std(r2_scores),
                        'r2_change': np.mean(r2_scores) - baseline_r2,
                        'r2_scores': r2_scores
                    }
            
            quality_results['completeness_sensitivity'] = completeness_results
            
            # 3. 数据分布敏感性
            logger.info("Testing data distribution sensitivity...")
            distribution_results = {}
            
            # 测试不同的数据分割比例
            split_ratios = [0.7, 0.8, 0.9]  # 训练集比例
            split_results = {}
            
            for split_ratio in split_ratios:
                r2_scores = []
                
                for trial in range(self.n_trials):
                    # 重新分割数据
                    np.random.seed(42 + trial)
                    X_train_split, X_test_split, y_train_split, y_test_split = train_test_split(
                        X, y, test_size=1-split_ratio, random_state=42+trial
                    )
                    
                    # 训练模型
                    split_model = self.train_pytorch_model(
                        X_train_split, y_train_split, X_test_split, y_test_split, feature_cols
                    )
                    
                    if split_model:
                        r2_scores.append(split_model['r2'])
                
                if r2_scores:
                    split_results[split_ratio] = {
                        'mean_r2': np.mean(r2_scores),
                        'std_r2': np.std(r2_scores),
                        'r2_scores': r2_scores
                    }
            
            distribution_results['split_ratio_sensitivity'] = split_results
            
            quality_results['distribution_sensitivity'] = distribution_results
            
            return {
                'dataset': dataset_name,
                'window_size': window_size,
                'baseline_r2': baseline_r2,
                'quality_results': quality_results,
                'target_variable': target_col
            }
            
        except Exception as e:
            logger.error(f"Error in data quality sensitivity analysis: {e}")
            return {'error': str(e)}
    
    def comprehensive_sensitivity_analysis(self, datasets: list, window_sizes: list) -> dict:
        """综合敏感性分析."""
        try:
            logger.info("Starting comprehensive sensitivity analysis...")
            
            all_results = {}
            
            for dataset in datasets:
                logger.info(f"\n{'='*60}")
                logger.info(f"Analyzing dataset: {dataset}")
                logger.info(f"{'='*60}")
                
                dataset_results = {}
                
                for window_size in window_sizes:
                    logger.info(f"\nWindow size: {window_size}")
                    
                    window_results = {}
                    
                    # 特征重要性分析
                    logger.info("1. Feature importance analysis...")
                    feature_importance_result = self.feature_importance_analysis(dataset, window_size)
                    window_results['feature_importance'] = feature_importance_result
                    
                    # 数据质量敏感性分析
                    logger.info("2. Data quality sensitivity analysis...")
                    quality_sensitivity_result = self.data_quality_sensitivity_analysis(dataset, window_size)
                    window_results['data_quality_sensitivity'] = quality_sensitivity_result
                    
                    dataset_results[window_size] = window_results
                
                all_results[dataset] = dataset_results
            
            return {
                'datasets': datasets,
                'window_sizes': window_sizes,
                'analysis_results': all_results,
                'analysis_timestamp': datetime.now().isoformat(),
                'n_trials': self.n_trials
            }
            
        except Exception as e:
            logger.error(f"Error in comprehensive sensitivity analysis: {e}")
            return {'error': str(e)}

def main():
    """主函数."""
    try:
        logger.info("Starting Step 8.2: Sensitivity Analysis")
        
        # 数据集配置
        datasets = ['DRIVE_DB']  # 先分析一个数据集
        window_sizes = ['60s']   # 先分析一个时间窗口
        
        output_dir = '/mnt/d/data_analysis/processed/step8_sensitivity_analysis'
        Path(output_dir).mkdir(exist_ok=True)
        
        # 初始化敏感性分析器
        analyzer = SensitivityAnalyzer(device='auto', n_trials=5)  # 减少试验次数以加快速度
        
        # 执行综合敏感性分析
        logger.info(f"Executing sensitivity analysis for {datasets} with window sizes {window_sizes}")
        
        sensitivity_results = analyzer.comprehensive_sensitivity_analysis(datasets, window_sizes)
        
        if 'error' in sensitivity_results:
            logger.error(f"Sensitivity analysis failed: {sensitivity_results['error']}")
            return
        
        # 保存结果
        output_file = Path(output_dir) / 'model_sensitivity_analysis_results.json'
        with open(output_file, 'w') as f:
            json.dump(sensitivity_results, f, indent=2, default=str)
        
        logger.info(f"Sensitivity analysis results saved: {output_file}")
        
        # 分析结果
        logger.info(f"\n{'='*60}")
        logger.info("Model Sensitivity Analysis Summary")
        logger.info(f"{'='*60}")
        
        for dataset, dataset_results in sensitivity_results['analysis_results'].items():
            logger.info(f"\nDataset: {dataset}")
            
            for window_size, window_data in dataset_results.items():
                logger.info(f"\nWindow Size: {window_size}")
                
                # 特征重要性
                feature_data = window_data.get('feature_importance', {})
                if 'baseline_r2' in feature_data:
                    logger.info(f"  Baseline R²: {feature_data['baseline_r2']:.3f}")
                    logger.info(f"  Feature Importance Ranking:")
                    
                    feature_ranking = feature_data.get('feature_ranking', [])
                    single_importance = feature_data.get('single_feature_importance', {})
                    
                    for i, feature in enumerate(feature_ranking):
                        importance = single_importance.get(feature, {})
                        r2_drop = importance.get('r2_drop', 0)
                        logger.info(f"    {i+1}. {feature}: R² drop = {r2_drop:.3f}")
                
                # 数据质量敏感性
                quality_data = window_data.get('data_quality_sensitivity', {})
                if 'baseline_r2' in quality_data:
                    logger.info(f"  Data Quality Sensitivity:")
                    
                    outlier_results = quality_data.get('quality_results', {}).get('outlier_sensitivity', {})
                    for threshold, result in outlier_results.items():
                        r2_change = result.get('r2_change', 0)
                        logger.info(f"    Outlier threshold {threshold}: R² change = {r2_change:.3f}")
        
        logger.info(f"\n{'='*60}")
        logger.info("Step 8.2 Sensitivity Analysis Completed Successfully!")
        logger.info(f"{'='*60}")
        
        logger.info("🎉 Key Achievements:")
        logger.info("  ✓ GPU-accelerated PyTorch NN training")
        logger.info("  ✓ Feature importance analysis")
        logger.info("  ✓ Feature combination analysis")
        logger.info("  ✓ Data quality sensitivity analysis")
        logger.info("  ✓ Comprehensive sensitivity evaluation")
        
    except Exception as e:
        logger.error(f"Error in main execution: {e}")
        raise

if __name__ == "__main__":
    main()



