#!/usr/bin/env python3
"""
Step 3: 科学验证框架
Scientific Validation Framework for Step 3

基于客观问题分析的完整验证解决方案
目标：科学、可重现、可追溯的特征工程验证
"""

import os
import sys
import logging
import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.feature_selection import f_classif
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
import json
import hashlib

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class ScientificValidationFramework:
    """科学验证框架."""
    
    def __init__(self):
        self.results = {}
        self.warnings = []
        self.validation_log = []
        
    def log_validation_step(self, step: str, status: str, details: str = ""):
        """记录验证步骤."""
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'step': step,
            'status': status,
            'details': details
        }
        self.validation_log.append(log_entry)
        logger.info(f"Validation Step {step}: {status} - {details}")
    
    def load_dataset_data(self, dataset_name: str, window_size: str) -> pd.DataFrame:
        """加载数据集数据."""
        try:
            file_paths = [
                f"/mnt/d/data_analysis/processed/lri_calculation/lri_{dataset_name}_{window_size}_clean.csv",
                f"/mnt/d/data_analysis/processed/lri_calculation/lri_{dataset_name}_{window_size}_fixed.csv",
                f"/mnt/d/data_analysis/processed/lri_calculation/lri_{dataset_name}_{window_size}_fixed_v2.csv",
                f"/mnt/d/data_analysis/processed/lri_calculation/lri_{dataset_name}_{window_size}.csv"
            ]
            
            for path in file_paths:
                if os.path.exists(path):
                    df = pd.read_csv(path)
                    if not df.empty:
                        logger.info(f"Loaded {dataset_name}_{window_size}: {df.shape}")
                        return df
            
            logger.warning(f"No data file found for {dataset_name}_{window_size}")
            return pd.DataFrame()
            
        except Exception as e:
            logger.error(f"Error loading {dataset_name}_{window_size}: {e}")
            return pd.DataFrame()
    
    def create_base_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """创建基础特征集."""
        try:
            numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
            if len(numeric_cols) < 2:
                return pd.DataFrame()
            
            # 选择前7个数值特征作为基础特征
            base_features = numeric_cols[:7]
            X_base = df[base_features].fillna(0)
            
            self.log_validation_step("BASE_FEATURES", "SUCCESS", f"Created {X_base.shape[1]} base features")
            return X_base
            
        except Exception as e:
            self.log_validation_step("BASE_FEATURES", "ERROR", str(e))
            return pd.DataFrame()
    
    def create_extended_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """创建扩展特征集（科学版本）."""
        try:
            numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
            if len(numeric_cols) < 2:
                return pd.DataFrame()
            
            extended_df = df.copy()
            
            # 1. 基础统计特征
            for col in numeric_cols:
                if df[col].notna().sum() > 5:
                    series = df[col].dropna()
                    
                    extended_df[f'{col}_mean'] = series.mean()
                    extended_df[f'{col}_std'] = series.std()
                    extended_df[f'{col}_median'] = series.median()
                    extended_df[f'{col}_range'] = series.max() - series.min()
                    extended_df[f'{col}_q25'] = series.quantile(0.25)
                    extended_df[f'{col}_q75'] = series.quantile(0.75)
            
            # 2. 多项式特征（只对重要特征）
            important_cols = numeric_cols[:3]
            for col in important_cols:
                if col in df.columns:
                    extended_df[f'{col}_squared'] = df[col] ** 2
                    extended_df[f'{col}_sqrt'] = np.sqrt(np.abs(df[col]) + 1e-8)
            
            # 3. 交互特征（只对重要特征）
            if len(important_cols) >= 2:
                col1, col2 = important_cols[0], important_cols[1]
                if col1 in df.columns and col2 in df.columns:
                    extended_df[f'{col1}_x_{col2}'] = df[col1] * df[col2]
                    extended_df[f'{col1}_div_{col2}'] = df[col1] / (df[col2] + 1e-8)
            
            # 4. 生理学特征（基于现有特征模拟）
            if 'wt_mean' in df.columns and 'wt_std' in df.columns:
                extended_df['hrv_ratio'] = df['wt_std'] / (df['wt_mean'] + 1e-8)
                extended_df['hrv_stability'] = 1 / (df['wt_std'] + 1e-8)
            
            if 'stress_intensity' in df.columns and 'stress_volatility' in df.columns:
                extended_df['stress_ratio'] = df['stress_intensity'] / (df['stress_volatility'] + 1e-8)
                extended_df['stress_normalized'] = (df['stress_intensity'] - df['stress_intensity'].mean()) / (df['stress_intensity'].std() + 1e-8)
            
            # 获取扩展特征
            extended_numeric_cols = extended_df.select_dtypes(include=[np.number]).columns.tolist()
            X_extended = extended_df[extended_numeric_cols].fillna(0)
            
            self.log_validation_step("EXTENDED_FEATURES", "SUCCESS", f"Created {X_extended.shape[1]} extended features")
            return X_extended
            
        except Exception as e:
            self.log_validation_step("EXTENDED_FEATURES", "ERROR", str(e))
            return pd.DataFrame()
    
    def check_data_consistency(self, X_base: pd.DataFrame, X_extended: pd.DataFrame, y: pd.Series) -> bool:
        """检查数据一致性."""
        try:
            # 样本数量一致性
            if len(X_base) != len(X_extended) or len(X_base) != len(y):
                self.warnings.append(f"Sample count mismatch: base={len(X_base)}, extended={len(X_extended)}, y={len(y)}")
                return False
            
            # 样本顺序一致性（通过hash检查）
            base_hash = hashlib.md5(X_base.values.tobytes()).hexdigest()
            extended_base_hash = hashlib.md5(X_extended.iloc[:, :X_base.shape[1]].values.tobytes()).hexdigest()
            
            if base_hash != extended_base_hash:
                self.warnings.append("Sample order mismatch between base and extended features")
                return False
            
            self.log_validation_step("DATA_CONSISTENCY", "SUCCESS", "Sample consistency verified")
            return True
            
        except Exception as e:
            self.log_validation_step("DATA_CONSISTENCY", "ERROR", str(e))
            return False
    
    def clean_features(self, X: pd.DataFrame, var_threshold: float = 1e-8) -> pd.DataFrame:
        """清理特征."""
        try:
            # 删除常数特征
            X_clean = X.loc[:, X.var() > var_threshold]
            
            # 检查异常值
            if np.any(np.abs(X_clean.values) > 1e12):
                self.warnings.append("⚠️ 警告: 检测到异常数值")
            
            # 检查NaN
            if X_clean.isnull().any().any():
                self.warnings.append("⚠️ 警告: 检测到NaN值")
                X_clean = X_clean.fillna(0)
            
            self.log_validation_step("FEATURE_CLEANING", "SUCCESS", f"Cleaned features: {X.shape[1]} -> {X_clean.shape[1]}")
            return X_clean
            
        except Exception as e:
            self.log_validation_step("FEATURE_CLEANING", "ERROR", str(e))
            return X
    
    def scientific_feature_selection(self, X: pd.DataFrame, y: pd.Series, max_features: int = 20) -> pd.DataFrame:
        """科学特征选择."""
        try:
            if X.empty or len(X) < 10:
                return X
            
            # F-test特征选择，避免除0
            try:
                F, p = f_classif(X.fillna(0), y)
                valid_mask = np.isfinite(F) & (F > 0)
                
                if not np.any(valid_mask):
                    self.warnings.append("⚠️ 警告: F-test未找到有效特征")
                    return X.iloc[:, :min(max_features, X.shape[1])]
                
                selected_features = X.columns[valid_mask]
                X_selected = X[selected_features]
                
                # 限制特征数量
                if X_selected.shape[1] > max_features:
                    # 选择F值最大的特征
                    F_values = F[valid_mask]
                    top_indices = np.argsort(F_values)[-max_features:]
                    X_selected = X_selected.iloc[:, top_indices]
                
                self.log_validation_step("FEATURE_SELECTION", "SUCCESS", f"Selected {X_selected.shape[1]} features")
                return X_selected
                
            except Exception as e:
                self.warnings.append(f"⚠️ 警告: F-test失败，使用前{max_features}个特征")
                return X.iloc[:, :min(max_features, X.shape[1])]
                
        except Exception as e:
            self.log_validation_step("FEATURE_SELECTION", "ERROR", str(e))
            return X
    
    def unified_evaluation(self, X_base: pd.DataFrame, X_extended: pd.DataFrame, y: pd.Series) -> dict:
        """统一评估方法."""
        try:
            # 数据分割（固定随机种子）
            Xb_train, Xb_test, y_train, y_test = train_test_split(
                X_base, y, test_size=0.3, random_state=42
            )
            Xe_train, Xe_test, _, _ = train_test_split(
                X_extended, y, test_size=0.3, random_state=42
            )
            
            # 标准化
            scaler = StandardScaler()
            Xb_train_scaled = scaler.fit_transform(Xb_train)
            Xb_test_scaled = scaler.transform(Xb_test)
            Xe_train_scaled = scaler.fit_transform(Xe_train)
            Xe_test_scaled = scaler.transform(Xe_test)
            
            # 模型评估
            models = {
                'RandomForest': RandomForestRegressor(n_estimators=200, random_state=42),
                'Ridge': Ridge(alpha=1.0, random_state=42)
            }
            
            results = {}
            
            for model_name, model in models.items():
                try:
                    # 基础特征模型
                    model_base = model.__class__(**model.get_params())
                    model_base.fit(Xb_train_scaled, y_train)
                    y_pred_base = model_base.predict(Xb_test_scaled)
                    
                    r2_base = r2_score(y_test, y_pred_base)
                    mae_base = mean_absolute_error(y_test, y_pred_base)
                    rmse_base = np.sqrt(mean_squared_error(y_test, y_pred_base))
                    
                    # 扩展特征模型
                    model_ext = model.__class__(**model.get_params())
                    model_ext.fit(Xe_train_scaled, y_train)
                    y_pred_ext = model_ext.predict(Xe_test_scaled)
                    
                    r2_ext = r2_score(y_test, y_pred_ext)
                    mae_ext = mean_absolute_error(y_test, y_pred_ext)
                    rmse_ext = np.sqrt(mean_squared_error(y_test, y_pred_ext))
                    
                    # 计算改善
                    r2_improvement = (r2_ext - r2_base) / abs(r2_base + 1e-9) * 100
                    mae_improvement = (mae_base - mae_ext) / abs(mae_base + 1e-9) * 100
                    rmse_improvement = (rmse_base - rmse_ext) / abs(rmse_base + 1e-9) * 100
                    
                    results[model_name] = {
                        'R2_base': r2_base,
                        'R2_extended': r2_ext,
                        'R2_improvement': r2_improvement,
                        'MAE_base': mae_base,
                        'MAE_extended': mae_ext,
                        'MAE_improvement': mae_improvement,
                        'RMSE_base': rmse_base,
                        'RMSE_extended': rmse_ext,
                        'RMSE_improvement': rmse_improvement,
                        'overall_improvement': (r2_improvement + mae_improvement + rmse_improvement) / 3
                    }
                    
                except Exception as e:
                    self.warnings.append(f"⚠️ 警告: {model_name}评估失败: {str(e)}")
                    continue
            
            self.log_validation_step("UNIFIED_EVALUATION", "SUCCESS", f"Evaluated {len(results)} models")
            return results
            
        except Exception as e:
            self.log_validation_step("UNIFIED_EVALUATION", "ERROR", str(e))
            return {}
    
    def validate_single_dataset(self, dataset_name: str, window_size: str) -> dict:
        """验证单个数据集."""
        try:
            logger.info(f"Validating {dataset_name}_{window_size}")
            
            # 加载数据
            df = self.load_dataset_data(dataset_name, window_size)
            if df.empty:
                return {}
            
            # 准备标签
            numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
            if len(numeric_cols) < 2:
                return {}
            
            y = df[numeric_cols[-1]].fillna(0)
            
            # 创建特征集
            X_base = self.create_base_features(df)
            X_extended = self.create_extended_features(df)
            
            if X_base.empty or X_extended.empty:
                return {}
            
            # 数据一致性检查
            if not self.check_data_consistency(X_base, X_extended, y):
                self.warnings.append(f"Data consistency check failed for {dataset_name}_{window_size}")
            
            # 特征清理
            X_base_clean = self.clean_features(X_base)
            X_extended_clean = self.clean_features(X_extended)
            
            # 特征选择
            X_extended_selected = self.scientific_feature_selection(X_extended_clean, y)
            
            # 统一评估
            evaluation_results = self.unified_evaluation(X_base_clean, X_extended_selected, y)
            
            # 汇总结果
            result = {
                'dataset': f"{dataset_name}_{window_size}",
                'base_features': X_base_clean.shape[1],
                'extended_features': X_extended_selected.shape[1],
                'feature_expansion_ratio': X_extended_selected.shape[1] / X_base_clean.shape[1],
                'evaluation_results': evaluation_results,
                'warnings': [w for w in self.warnings if f"{dataset_name}_{window_size}" in w or "警告" in w]
            }
            
            # 计算平均改善
            if evaluation_results:
                avg_improvements = [r['overall_improvement'] for r in evaluation_results.values()]
                result['average_improvement'] = np.mean(avg_improvements)
                result['significant'] = result['average_improvement'] > 1.0
            else:
                result['average_improvement'] = 0.0
                result['significant'] = False
            
            return result
            
        except Exception as e:
            logger.error(f"Error validating {dataset_name}_{window_size}: {e}")
            return {}
    
    def run_comprehensive_validation(self) -> dict:
        """运行全面验证."""
        try:
            logger.info("Starting Comprehensive Scientific Validation")
            
            datasets = ['DRIVE_DB', 'CRWD', 'SWELL', 'WESAD']
            window_sizes = ['60s', '300s']
            
            all_results = []
            successful_count = 0
            total_count = 0
            
            for dataset in datasets:
                for window_size in window_sizes:
                    result = self.validate_single_dataset(dataset, window_size)
                    
                    if result:
                        all_results.append(result)
                        total_count += 1
                        
                        if result.get('significant', False):
                            successful_count += 1
            
            # 计算总体结果
            success_rate = successful_count / total_count * 100 if total_count > 0 else 0
            avg_improvement = np.mean([r['average_improvement'] for r in all_results]) if all_results else 0
            avg_expansion = np.mean([r['feature_expansion_ratio'] for r in all_results]) if all_results else 0
            
            # 汇总结果
            comprehensive_results = {
                'timestamp': datetime.now().isoformat(),
                'validation_framework': 'Scientific Validation Framework',
                'total_datasets': total_count,
                'successful_datasets': successful_count,
                'success_rate': success_rate,
                'average_improvement': avg_improvement,
                'average_expansion_ratio': avg_expansion,
                'all_results': all_results,
                'validation_log': self.validation_log,
                'warnings': self.warnings
            }
            
            # 保存结果
            output_dir = Path("reports/scientific_audit/step3_scientific_validation_framework")
            output_dir.mkdir(parents=True, exist_ok=True)
            
            results_file = output_dir / "step3_scientific_validation_results.json"
            with open(results_file, 'w', encoding='utf-8') as f:
                json.dump(comprehensive_results, f, indent=2, ensure_ascii=False, default=str)
            
            # 生成验证报告
            self.generate_validation_report(comprehensive_results, results_file)
            
            logger.info("=== SCIENTIFIC VALIDATION FRAMEWORK RESULTS ===")
            logger.info(f"Total datasets: {total_count}")
            logger.info(f"Successful datasets: {successful_count}")
            logger.info(f"Success rate: {success_rate:.2f}%")
            logger.info(f"Average improvement: {avg_improvement:.4f}%")
            logger.info(f"Average expansion ratio: {avg_expansion:.2f}")
            
            # 判断验证结果
            if success_rate > 70 and avg_improvement > 5:
                status = "✅ 科学验证通过"
                conclusion = "Step 3特征工程科学验证通过，效果显著且可重现。"
            elif success_rate > 50 and avg_improvement > 2:
                status = "⚠️ 科学验证部分通过"
                conclusion = "Step 3特征工程科学验证部分通过，有一定效果。"
            elif success_rate > 30 and avg_improvement > 0:
                status = "⚠️ 科学验证勉强通过"
                conclusion = "Step 3特征工程科学验证勉强通过，效果有限。"
            else:
                status = "❌ 科学验证失败"
                conclusion = "Step 3特征工程科学验证失败，效果不明显。"
            
            logger.info(f"Validation Status: {status}")
            logger.info(f"Conclusion: {conclusion}")
            
            return comprehensive_results
            
        except Exception as e:
            logger.error(f"Error in comprehensive validation: {e}")
            return {}
    
    def generate_validation_report(self, results: dict, results_file: Path):
        """生成验证报告."""
        try:
            report = f"""
# Step 3: 科学验证框架报告
## Scientific Validation Framework Report

**验证日期**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
**验证方法**: 科学验证框架
**结果文件**: {results_file}

---

## 验证目标

基于客观问题分析，解决以下关键问题：
1. **评估方法不一致**: 统一训练/验证集划分和指标计算
2. **特征类型单一**: 增加生理学特征和稳定性检查
3. **数值异常**: 修复F-test异常值和数据清理

---

## 验证结果

### 总体统计
- **测试数据集数**: {results.get('total_datasets', 0)}
- **成功数据集数**: {results.get('successful_datasets', 0)}
- **成功率**: {results.get('success_rate', 0):.2f}%
- **平均性能改善**: {results.get('average_improvement', 0):.4f}%
- **平均特征扩展比**: {results.get('average_expansion_ratio', 0):.2f}

### 详细结果
"""
            
            for result in results.get('all_results', []):
                report += f"""
#### {result['dataset']}
- **基础特征数**: {result['base_features']}
- **扩展特征数**: {result['extended_features']}
- **扩展比**: {result['feature_expansion_ratio']:.2f}
- **平均改善**: {result['average_improvement']:.4f}%
- **显著性**: {'是' if result['significant'] else '否'}
"""
                
                if result.get('warnings'):
                    report += f"- **警告**: {', '.join(result['warnings'])}\n"
            
            report += f"""
---

## 验证日志

### 验证步骤
"""
            
            for log_entry in results.get('validation_log', []):
                report += f"- **{log_entry['step']}**: {log_entry['status']} - {log_entry['details']}\n"
            
            report += f"""
---

## 警告信息

"""
            
            for warning in results.get('warnings', []):
                report += f"- {warning}\n"
            
            report += f"""
---

## 科学验证结论

### 验证状态
基于科学验证框架的客观评估结果。

### 关键改进
1. **统一评估标准**: 固定随机种子和数据分割
2. **数据一致性检查**: 确保样本顺序和标签对齐
3. **特征稳定性验证**: 移除异常值和低方差特征
4. **科学特征选择**: 修复F-test异常值问题

### 可重现性
- 固定随机种子 (random_state=42)
- 统一数据分割比例 (7:3)
- 标准化预处理流程
- 详细的验证日志记录

---

**报告生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
**验证框架版本**: Scientific Validation Framework v1.0
"""
            
            # 保存报告
            report_file = results_file.parent / "step3_scientific_validation_report.md"
            with open(report_file, 'w', encoding='utf-8') as f:
                f.write(report)
            
            logger.info(f"Validation report saved to {report_file}")
            
        except Exception as e:
            logger.error(f"Error generating validation report: {e}")

def main():
    """主函数."""
    try:
        logger.info("Starting Step 3 Scientific Validation Framework")
        
        framework = ScientificValidationFramework()
        results = framework.run_comprehensive_validation()
        
        if results:
            logger.info("Scientific validation framework completed successfully!")
        else:
            logger.error("Scientific validation framework failed!")
        
    except Exception as e:
        logger.error(f"Error in main execution: {e}")
        raise

if __name__ == "__main__":
    main()

