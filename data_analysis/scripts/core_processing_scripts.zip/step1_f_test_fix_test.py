#!/usr/bin/env python3
"""
Step 1: F-test 数值稳定性修复 - 测试版本
"""

import pandas as pd
import numpy as np
import torch
import json
import time
from sklearn.feature_selection import f_classif, f_regression
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import r2_score
import warnings
warnings.filterwarnings("ignore")

print("=" * 50)
print("Step 1: F-test 数值稳定性修复 - 测试版本")
print("=" * 50)

# GPU检查
print("🔍 GPU检查:")
print(f"  CUDA可用: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print(f"  GPU设备: {torch.cuda.get_device_name(0)}")
    device = torch.device('cuda')
else:
    print("  ⚠️ CUDA不可用，将使用CPU")
    device = torch.device('cpu')

def safe_f_classif(X, y, verbose=True):
    """安全的F-test实现"""
    if verbose:
        print(f"  🔬 执行安全F-test: {X.shape}")
    
    # Step 1: 数据预处理
    X_clean = X.copy()
    
    # 移除方差极低列
    var_threshold = 1e-8
    variances = X_clean.var()
    low_var_mask = variances > var_threshold
    X_clean = X_clean.loc[:, low_var_mask]
    
    if verbose:
        print(f"    📊 方差筛选: {X.shape[1]} -> {X_clean.shape[1]} 特征")
    
    # 处理无穷值和NaN
    X_clean = X_clean.replace([np.inf, -np.inf], np.nan)
    X_clean = X_clean.dropna(axis=1, how='all')
    
    if verbose:
        print(f"    🧹 清理异常值后: {X_clean.shape[1]} 特征")
    
    # Step 2: 数值稳定性处理
    X_clean = np.nan_to_num(X_clean, nan=0.0, posinf=0.0, neginf=0.0)
    
    # Step 3: 检查数据有效性
    if X_clean.shape[1] == 0:
        if verbose:
            print("    ⚠️ 警告: 所有特征都被过滤，返回原始数据")
        return np.ones(X.shape[1]), np.ones(X.shape[1])
    
    # Step 4: 执行F-test
    try:
        F, p = f_classif(X_clean, y)
        
        # Step 5: 验证F值有效性
        valid_mask = np.isfinite(F) & (F > 0) & (F < 1e10)
        
        if not np.any(valid_mask):
            if verbose:
                print("    ⚠️ 警告: F-test未找到有效特征")
            return np.ones(X.shape[1]), np.ones(X.shape[1])
        
        # Step 6: 记录统计信息
        if verbose:
            print(f"    📊 F值统计: 均值={np.mean(F[valid_mask]):.2f}, 标准差={np.std(F[valid_mask]):.2f}")
            print(f"    📊 F值范围: {np.min(F[valid_mask]):.2f} - {np.max(F[valid_mask]):.2f}")
            print(f"    ✅ 有效特征: {np.sum(valid_mask)}/{len(F)}")
        
        return F, p
        
    except Exception as e:
        if verbose:
            print(f"    ❌ F-test失败: {e}")
        return np.ones(X.shape[1]), np.ones(X.shape[1])

# ======= 数据读取 =======
print("\n📂 数据读取")
start_time = time.time()

print("  📥 正在读取数据...")
try:
    base = pd.read_csv("features_base.csv")
    extended = pd.read_csv("features_extended.csv")
    y = pd.read_csv("labels.csv")["target"]
    
    print(f"    ✅ Base特征: {base.shape}")
    print(f"    ✅ Extended特征: {extended.shape}")
    print(f"    ✅ 标签: {len(y)} 个样本")
    
    # 样本一致性检查
    assert len(base) == len(extended) == len(y), "样本数量不一致"
    print(f"  ✅ 数据加载完成: {len(y)} 个样本")
    
except Exception as e:
    print(f"  ❌ 数据加载失败: {e}")
    exit(1)

print(f"  ⏱️ 数据加载耗时: {time.time() - start_time:.2f}秒")

# ======= F-test修复测试 =======
print("\n🔧 F-test数值稳定性修复测试")
stability_start = time.time()

# 测试原始F-test
print("  🔍 测试原始F-test...")
try:
    F_original, p_original = f_classif(extended.fillna(0), y)
    print(f"    📊 原始F-test: F值范围 {np.min(F_original):.2f} - {np.max(F_original):.2f}")
    print(f"    📊 有效F值: {np.sum(np.isfinite(F_original) & (F_original > 0))}/{len(F_original)}")
except Exception as e:
    print(f"    ❌ 原始F-test失败: {e}")
    F_original, p_original = np.ones(extended.shape[1]), np.ones(extended.shape[1])

# 测试修复后F-test
print("  🛠️ 测试修复后F-test...")
F_fixed, p_fixed = safe_f_classif(extended, y)

print(f"  ⏱️ F-test修复耗时: {time.time() - stability_start:.2f}秒")

# ======= 简单模型测试 =======
print("\n🤖 简单模型测试")
model_start = time.time()

# 数据划分
X_train, X_test, y_train, y_test = train_test_split(
    extended.iloc[:, :10], y, test_size=0.3, random_state=42)

# 标准化
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# 模型训练
model = HistGradientBoostingRegressor(max_iter=50, random_state=42, verbose=0)
model.fit(X_train_scaled, y_train)
y_pred = model.predict(X_test_scaled)
r2 = r2_score(y_test, y_pred)

print(f"    ✅ 模型R²: {r2:.4f}")
print(f"  ⏱️ 模型测试耗时: {time.time() - model_start:.2f}秒")

# ======= 结果保存 =======
print("\n💾 结果保存")
results = {
    "step1_f_test_fix_test": {
        "gpu_info": {
            "cuda_available": torch.cuda.is_available(),
            "gpu_device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None
        },
        "data_info": {
            "samples": len(y),
            "base_features": base.shape[1],
            "extended_features": extended.shape[1]
        },
        "f_test_comparison": {
            "original_f_range": [float(np.min(F_original)), float(np.max(F_original))],
            "original_f_valid": int(np.sum(np.isfinite(F_original) & (F_original > 0))),
            "fixed_f_range": [float(np.min(F_fixed)), float(np.max(F_fixed))],
            "fixed_f_valid": int(np.sum(np.isfinite(F_fixed) & (F_fixed > 0)))
        },
        "model_test": {
            "r2_score": float(r2)
        },
        "performance": {
            "total_runtime": time.time() - start_time
        }
    }
}

with open("step1_f_test_fix_test_results.json", "w") as f:
    json.dump(results, f, indent=4)

print("  ✅ 结果已保存到 step1_f_test_fix_test_results.json")

# ======= 结果报告 =======
print("\n📊 结果报告")
print("=" * 50)
print("Step 1: F-test 数值稳定性修复测试结果")
print("=" * 50)
print(f"🔧 F-test修复测试:")
print(f"  原始F-test有效特征: {np.sum(np.isfinite(F_original) & (F_original > 0))}/{len(F_original)}")
print(f"  修复后F-test有效特征: {np.sum(np.isfinite(F_fixed) & (F_fixed > 0))}/{len(F_fixed)}")
print(f"\n🤖 模型测试:")
print(f"  测试模型R²: {r2:.4f}")
print(f"\n⏱️ 性能:")
print(f"  总运行时间: {time.time() - start_time:.2f}秒")
print("=" * 50)

print("🎉 Step 1: F-test 数值稳定性修复测试完成！")
