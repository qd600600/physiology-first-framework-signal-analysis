#!/usr/bin/env python3
"""
Step 3: 特征工程增强 - GPU最终优化版本
按照专业建议优化：DataLoader + pinned memory + 全向量化F-test + no_grad
目标：Step 4特征选择 < 12分钟，GPU占用85-95%
"""

import pandas as pd
import numpy as np
import torch
import json
import time
import sys
import math
from torch.utils.data import TensorDataset, DataLoader
from sklearn.preprocessing import RobustScaler
from sklearn.model_selection import train_test_split, RepeatedKFold
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
import warnings
warnings.filterwarnings("ignore")

def print_progress(message):
    """打印进度信息"""
    print(message)
    sys.stdout.flush()

print("=" * 70)
print("Step 3: 特征工程增强 - GPU最终优化版本")
print("=" * 70)

# GPU检查
print_progress("🔍 GPU检查:")
print_progress(f"  CUDA可用: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print_progress(f"  GPU设备: {torch.cuda.get_device_name(0)}")
    print_progress(f"  GPU内存: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.1f} GB")
    device = torch.device('cuda')
    use_gpu = True
    torch.backends.cudnn.benchmark = True
    torch.backends.cuda.matmul.allow_tf32 = True
    torch.set_float32_matmul_precision('medium')
    print_progress("  ✅ 启用CUDA优化 + TF32 + 混合精度")
else:
    print_progress("  ⚠️ CUDA不可用，将使用CPU")
    device = torch.device('cpu')
    use_gpu = False

def gpu_feature_engineering_final(X, y, verbose=True):
    """GPU最终优化的特征工程"""
    if verbose:
        print_progress("  🚀 GPU最终优化特征工程...")
    
    # 转换为GPU张量
    X_tensor = torch.tensor(X.values, device=device, dtype=torch.float32)
    y_tensor = torch.tensor(y.values, device=device, dtype=torch.float32)
    
    n_samples, n_features = X_tensor.shape
    
    if verbose:
        print_progress(f"    📊 GPU数据形状: {X_tensor.shape}")
        print_progress(f"    📊 GPU内存使用: {torch.cuda.memory_allocated() / 1024**3:.2f} GB")
    
    # 使用混合精度进行特征工程
    with torch.autocast(device_type='cuda', dtype=torch.float16):
        # 1. 多尺度变换
        if verbose:
            print_progress("    🔄 GPU多尺度变换（混合精度）...")
        
        X_transformed = X_tensor.clone()
        
        # Log变换
        X_log = torch.log1p(torch.clamp(X_tensor, min=0))
        X_transformed = torch.cat([X_transformed, X_log], dim=1)
        
        # Z-score标准化
        X_mean = X_tensor.mean(dim=0, keepdim=True)
        X_std = X_tensor.std(dim=0, keepdim=True) + 1e-8
        X_zscore = (X_tensor - X_mean) / X_std
        X_transformed = torch.cat([X_transformed, X_zscore], dim=1)
        
        # MinMax标准化
        X_min = X_tensor.min(dim=0, keepdim=True)[0]
        X_max = X_tensor.max(dim=0, keepdim=True)[0]
        X_minmax = (X_tensor - X_min) / (X_max - X_min + 1e-8)
        X_transformed = torch.cat([X_transformed, X_minmax], dim=1)
        
        if verbose:
            print_progress(f"    ✅ 多尺度变换完成: {n_features} -> {X_transformed.shape[1]} 特征")
        
        # 2. 交互特征（限制数量）
        if verbose:
            print_progress("    🔗 GPU交互特征创建（混合精度）...")
        
        # 选择前3个特征进行交互
        X_base = X_tensor[:, :3]
        n_base = X_base.shape[1]
        
        interaction_features = []
        for i in range(n_base):
            for j in range(i+1, n_base):
                # 乘积交互
                product = X_base[:, i] * X_base[:, j]
                interaction_features.append(product.unsqueeze(1))
                
                # 差异交互
                diff = X_base[:, i] - X_base[:, j]
                interaction_features.append(diff.unsqueeze(1))
        
        if interaction_features:
            X_interactions = torch.cat(interaction_features, dim=1)
            X_transformed = torch.cat([X_transformed, X_interactions], dim=1)
        
        if verbose:
            print_progress(f"    ✅ 交互特征完成: {X_transformed.shape[1]} 特征")
    
    # 同步GPU操作
    torch.cuda.synchronize()
    
    if verbose:
        print_progress(f"    📊 GPU内存使用: {torch.cuda.memory_allocated() / 1024**3:.2f} GB")
    
    return X_transformed

def gpu_f_test_vectorized(X, y):
    """全向量化GPU F-test - 无循环版本"""
    # 计算相关性作为F-test的近似
    X_mean = X.mean(dim=0)
    y_mean = y.mean()
    
    # 计算协方差
    cov = ((X - X_mean) * (y - y_mean).unsqueeze(1)).mean(dim=0)
    
    # 计算方差
    X_var = X.var(dim=0)
    
    # 计算F值（相关性平方）
    f_values = (cov ** 2) / (X_var + 1e-8)
    
    return f_values

def gpu_feature_selection_final(X_tensor, y_tensor, k=15, verbose=True):
    """GPU最终优化的特征选择"""
    if verbose:
        print_progress("  🎯 GPU最终优化特征选择...")
    
    n_samples, n_features = X_tensor.shape
    batch_size = 2000000
    num_batches = math.ceil(n_samples / batch_size)
    
    if verbose:
        print_progress(f"    📊 分块处理: {num_batches} 个批次，每批 {batch_size} 样本")
    
    # 使用DataLoader进行异步数据传输
    X_np = X_tensor.cpu().numpy()
    y_np = y_tensor.cpu().numpy()
    
    dataset = TensorDataset(torch.from_numpy(X_np), torch.from_numpy(y_np))
    loader = DataLoader(dataset, batch_size=batch_size, pin_memory=True, num_workers=0)
    
    f_values_batches = []
    
    for batch_idx, (X_batch, y_batch) in enumerate(loader):
        if verbose:
            print_progress(f"    ⏳ 批次 {batch_idx+1}/{num_batches} 数据传输...")
            t0 = time.time()
        
        # 异步传输到GPU
        X_gpu = X_batch.to('cuda', non_blocking=True)
        y_gpu = y_batch.to('cuda', non_blocking=True)
        torch.cuda.synchronize()
        
        if verbose:
            transfer_time = time.time() - t0
            print_progress(f"    ✅ 数据传输完成: {transfer_time:.2f}秒")
            print_progress(f"    📊 GPU内存: {torch.cuda.memory_allocated() / 1024**3:.2f} GB")
        
        # 使用no_grad进行F-test计算
        with torch.no_grad():
            with torch.autocast(device_type='cuda', dtype=torch.float16):
                f_batch = gpu_f_test_vectorized(X_gpu, y_gpu)
                f_values_batches.append(f_batch.detach().cpu())
        
        if verbose:
            print_progress(f"    ✅ 批次 {batch_idx+1} F-test完成")
    
    # 合并结果（取平均）
    f_values = torch.stack(f_values_batches, dim=0).mean(dim=0)
    
    # 计算其他特征重要性分数
    if verbose:
        print_progress("    📊 GPU方差和相关性计算...")
    
    with torch.no_grad():
        with torch.autocast(device_type='cuda', dtype=torch.float16):
            # 方差分数
            var_scores = X_tensor.var(dim=0)
            
            # 相关性分数
            X_mean = X_tensor.mean(dim=0)
            y_mean = y_tensor.mean()
            corr_scores = torch.abs(((X_tensor - X_mean) * (y_tensor - y_mean).unsqueeze(1)).mean(dim=0))
    
    # 标准化分数
    def normalize_scores(scores):
        scores = scores.clone()
        if scores.max() - scores.min() > 1e-8:
            return (scores - scores.min()) / (scores.max() - scores.min())
        else:
            return torch.ones_like(scores)
    
    f_scores_norm = normalize_scores(f_values.float().to(device))
    var_scores_norm = normalize_scores(var_scores.float())
    corr_scores_norm = normalize_scores(corr_scores.float())
    
    # 综合评分
    combined_scores = (f_scores_norm + var_scores_norm + corr_scores_norm) / 3
    
    # 选择前k个特征
    top_k_indices = torch.argsort(combined_scores, descending=True)[:k]
    
    # 同步GPU操作
    torch.cuda.synchronize()
    
    if verbose:
        print_progress(f"    ✅ GPU特征选择完成: {n_features} -> {k} 特征")
        print_progress(f"    📊 GPU内存使用: {torch.cuda.memory_allocated() / 1024**3:.2f} GB")
    
    return top_k_indices, combined_scores

def gpu_model_training_final(X_train, X_test, y_train, y_test, verbose=True):
    """GPU最终优化的模型训练"""
    if verbose:
        print_progress("  🤖 GPU最终优化模型训练...")
    
    # 转换为GPU张量
    X_train_tensor = torch.tensor(X_train, device=device, dtype=torch.float32)
    X_test_tensor = torch.tensor(X_test, device=device, dtype=torch.float32)
    y_train_tensor = torch.tensor(y_train.values, device=device, dtype=torch.float32)
    y_test_tensor = torch.tensor(y_test.values, device=device, dtype=torch.float32)
    
    # 使用混合精度进行标准化
    with torch.autocast(device_type='cuda', dtype=torch.float16):
        X_train_mean = X_train_tensor.mean(dim=0, keepdim=True)
        X_train_std = X_train_tensor.std(dim=0, keepdim=True) + 1e-8
        X_train_scaled = (X_train_tensor - X_train_mean) / X_train_std
        X_test_scaled = (X_test_tensor - X_train_mean) / X_train_std
    
    # 转换回CPU进行sklearn训练
    X_train_scaled_cpu = X_train_scaled.cpu().numpy()
    X_test_scaled_cpu = X_test_scaled.cpu().numpy()
    
    # 训练模型
    model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
    model.fit(X_train_scaled_cpu, y_train)
    y_pred = model.predict(X_test_scaled_cpu)
    
    # 计算指标
    r2 = r2_score(y_test, y_pred)
    mae = mean_absolute_error(y_test, y_pred)
    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    
    if verbose:
        print_progress(f"    ✅ 模型训练完成: R² = {r2:.4f}")
    
    return {
        'r2': r2,
        'mae': mae,
        'mse': mse,
        'rmse': rmse,
        'y_pred': y_pred
    }

# ======= Step 1: 数据读取 =======
print_progress("\n📂 Step 1: 数据读取")
start_time = time.time()

print_progress("  📥 正在读取features_base.csv...")
base = pd.read_csv("features_base.csv")
print_progress(f"    ✅ Base特征加载完成: {base.shape}")

print_progress("  📥 正在读取features_extended.csv...")
extended = pd.read_csv("features_extended.csv")
print_progress(f"    ✅ Extended特征加载完成: {extended.shape}")

print_progress("  📥 正在读取labels.csv...")
y = pd.read_csv("labels.csv")["target"]
print_progress(f"    ✅ 标签加载完成: {len(y)} 个样本")

print_progress(f"  ⏱️ 数据加载耗时: {time.time() - start_time:.2f}秒")

# ======= Step 2: 数据预处理 =======
print_progress("\n🔧 Step 2: 数据预处理")
preprocess_start = time.time()

# 移除高缺失值列
print_progress("  🧹 移除高缺失值列...")
missing_ratio = extended.isna().sum() / len(extended)
high_missing_cols = missing_ratio[missing_ratio > 0.5].index.tolist()
extended_clean = extended.drop(columns=high_missing_cols)
extended_imputed = extended_clean.fillna(0)

print_progress(f"    📊 移除列数: {extended.shape[1]} -> {extended_clean.shape[1]}")

print_progress(f"  ⏱️ 预处理耗时: {time.time() - preprocess_start:.2f}秒")

# ======= Step 3: GPU特征工程 =======
print_progress("\n🚀 Step 3: GPU特征工程")
engineering_start = time.time()

# GPU特征工程
X_enhanced_tensor = gpu_feature_engineering_final(extended_imputed, y, verbose=True)

print_progress(f"  ⏱️ GPU特征工程耗时: {time.time() - engineering_start:.2f}秒")

# ======= Step 4: GPU特征选择 =======
print_progress("\n🎯 Step 4: GPU特征选择")
selection_start = time.time()

# GPU特征选择
top_k_indices, combined_scores = gpu_feature_selection_final(
    X_enhanced_tensor, torch.tensor(y.values, device=device), k=15, verbose=True)

# 选择特征
X_selected_tensor = X_enhanced_tensor[:, top_k_indices]

# 转换回pandas
X_selected = pd.DataFrame(
    X_selected_tensor.cpu().numpy(),
    columns=[f'feature_{i}' for i in range(X_selected_tensor.shape[1])]
)

print_progress(f"  ⏱️ GPU特征选择耗时: {time.time() - selection_start:.2f}秒")

# ======= Step 5: 模型性能评估 =======
print_progress("\n📊 Step 5: 模型性能评估")
evaluation_start = time.time()

# 数据划分
Xb_train, Xb_test, y_train, y_test = train_test_split(
    base, y, test_size=0.3, random_state=42)
Xe_train, Xe_test, _, _ = train_test_split(
    X_selected, y, test_size=0.3, random_state=42)

# Base模型评估
print_progress("  🎯 Base模型评估...")
base_metrics = gpu_model_training_final(Xb_train.values, Xb_test.values, y_train, y_test, verbose=True)

# Extended模型评估
print_progress("  🎯 Extended模型评估...")
extended_metrics = gpu_model_training_final(Xe_train.values, Xe_test.values, y_train, y_test, verbose=True)

print_progress(f"  ⏱️ 性能评估耗时: {time.time() - evaluation_start:.2f}秒")

# ======= Step 6: 结果保存 =======
print_progress("\n💾 Step 6: 结果保存")

results = {
    "step3_gpu_final": {
        "data_info": {
            "samples": len(y),
            "original_features": int(extended.shape[1]),
            "cleaned_features": int(extended_clean.shape[1]),
            "enhanced_features": int(X_enhanced_tensor.shape[1]),
            "selected_features": int(X_selected_tensor.shape[1])
        },
        "model_performance": {
            "base_model": base_metrics,
            "extended_model": extended_metrics,
            "improvement": {
                "r2_improvement": float(extended_metrics['r2'] - base_metrics['r2']),
                "r2_improvement_percent": float((extended_metrics['r2'] - base_metrics['r2']) / abs(base_metrics['r2']) * 100),
                "mae_improvement": float(base_metrics['mae'] - extended_metrics['mae']),
                "rmse_improvement": float(base_metrics['rmse'] - extended_metrics['rmse'])
            }
        },
        "performance_info": {
            "total_runtime_seconds": time.time() - start_time,
            "data_loading_time": time.time() - start_time - (time.time() - preprocess_start),
            "preprocessing_time": time.time() - preprocess_start - (time.time() - engineering_start),
            "engineering_time": time.time() - engineering_start - (time.time() - selection_start),
            "selection_time": time.time() - selection_start - (time.time() - evaluation_start),
            "evaluation_time": time.time() - evaluation_start
        },
        "gpu_info": {
            "cuda_available": torch.cuda.is_available(),
            "gpu_device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
            "gpu_memory_gb": torch.cuda.get_device_properties(0).total_memory / 1024**3 if torch.cuda.is_available() else None,
            "gpu_memory_used_gb": torch.cuda.memory_allocated() / 1024**3 if torch.cuda.is_available() else 0
        }
    }
}

print_progress("  💾 正在保存结果...")
with open("step3_gpu_final_results.json", "w") as f:
    json.dump(results, f, indent=4)

# ======= Step 7: 结果报告 =======
print_progress("\n📊 Step 7: 结果报告")
print("=" * 70)
print("Step 3: 特征工程增强结果（GPU最终优化版本）")
print("=" * 70)
print(f"🔧 特征工程流程:")
print(f"  原始特征数: {extended.shape[1]}")
print(f"  清理后特征数: {extended_clean.shape[1]}")
print(f"  GPU增强后特征数: {X_enhanced_tensor.shape[1]}")
print(f"  最终选择特征数: {X_selected_tensor.shape[1]}")
print(f"\n📈 模型性能对比:")
print(f"  Base模型 R²: {base_metrics['r2']:.4f}")
print(f"  Extended模型 R²: {extended_metrics['r2']:.4f}")
print(f"  性能改善: {extended_metrics['r2'] - base_metrics['r2']:.4f} ({(extended_metrics['r2'] - base_metrics['r2']) / abs(base_metrics['r2']) * 100:.1f}%)")
print(f"  MAE改善: {base_metrics['mae'] - extended_metrics['mae']:.2f}")
print(f"  RMSE改善: {base_metrics['rmse'] - extended_metrics['rmse']:.2f}")
print(f"\n⏱️ 性能信息:")
print(f"  总运行时间: {time.time() - start_time:.2f}秒")
print(f"  GPU特征工程时间: {time.time() - engineering_start - (time.time() - selection_start):.2f}秒")
print(f"  GPU特征选择时间: {time.time() - selection_start - (time.time() - evaluation_start):.2f}秒")
if torch.cuda.is_available():
    print(f"  GPU内存使用: {torch.cuda.memory_allocated() / 1024**3:.2f} GB")
print(f"\n✅ 结果文件:")
print(f"  step3_gpu_final_results.json - GPU最终优化结果")
print("=" * 70)

print("🎉 Step 3: 特征工程增强（GPU最终优化版本）完成！")
