#!/usr/bin/env python3
"""
Step 3: 特征工程增强 - 简化版本
目标：在保证数值稳定的前提下恢复模型性能
"""

import pandas as pd
import numpy as np
import torch
import json
import time
import sys
from sklearn.preprocessing import RobustScaler
from sklearn.model_selection import train_test_split, RepeatedKFold
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from sklearn.feature_selection import f_classif, mutual_info_regression
import warnings
warnings.filterwarnings("ignore")

def print_progress(message):
    """打印进度信息"""
    print(message)
    sys.stdout.flush()

print("=" * 70)
print("Step 3: 特征工程增强 - 简化版本")
print("=" * 70)

# GPU检查
print_progress("🔍 GPU检查:")
print_progress(f"  CUDA可用: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print_progress(f"  GPU设备: {torch.cuda.get_device_name(0)}")
    device = torch.device('cuda')
    use_gpu = True
else:
    print_progress("  ⚠️ CUDA不可用，将使用CPU")
    device = torch.device('cpu')
    use_gpu = False

# ======= Step 1: 数据读取 =======
print_progress("\n📂 Step 1: 数据读取")
start_time = time.time()

print_progress("  📥 正在读取features_base.csv...")
base = pd.read_csv("features_base.csv")
print_progress(f"    ✅ Base特征加载完成: {base.shape}")

print_progress("  📥 正在读取features_extended.csv...")
extended = pd.read_csv("features_extended.csv")
print_progress(f"    ✅ Extended特征加载完成: {extended.shape}")

print_progress("  📥 正在读取labels.csv...")
y = pd.read_csv("labels.csv")["target"]
print_progress(f"    ✅ 标签加载完成: {len(y)} 个样本")

print_progress(f"  ⏱️ 数据加载耗时: {time.time() - start_time:.2f}秒")

# ======= Step 2: 特征恢复与扩展 =======
print_progress("\n🔧 Step 2: 特征恢复与扩展")
enhancement_start = time.time()

# 2.1 数据预处理
print_progress("  🧹 数据预处理...")
missing_ratio = extended.isna().sum() / len(extended)
high_missing_cols = missing_ratio[missing_ratio > 0.5].index.tolist()
extended_clean = extended.drop(columns=high_missing_cols)
extended_imputed = extended_clean.fillna(0)

print_progress(f"    📊 移除高缺失值列: {extended.shape[1]} -> {extended_clean.shape[1]}")

# 2.2 特征扩展 - 多尺度变换
print_progress("  🔄 应用多尺度变换...")
extended_multiscale = extended_imputed.copy()
numeric_cols = extended_imputed.select_dtypes(include=[np.number]).columns

for col in numeric_cols:
    if col in extended_imputed.columns:
        # Log变换（处理正数）
        if (extended_imputed[col] > 0).all():
            extended_multiscale[f'{col}_log'] = np.log1p(extended_imputed[col])
        
        # Z-score标准化
        extended_multiscale[f'{col}_zscore'] = (extended_imputed[col] - extended_imputed[col].mean()) / (extended_imputed[col].std() + 1e-8)
        
        # MinMax标准化
        extended_multiscale[f'{col}_minmax'] = (extended_imputed[col] - extended_imputed[col].min()) / (extended_imputed[col].max() - extended_imputed[col].min() + 1e-8)

print_progress(f"    ✅ 多尺度变换完成: {extended_imputed.shape[1]} -> {extended_multiscale.shape[1]} 特征")

# 2.3 交互特征
print_progress("  🔗 创建交互特征...")
extended_interaction = extended_multiscale.copy()
numeric_cols = extended_multiscale.select_dtypes(include=[np.number]).columns

# 限制交互特征数量
if len(numeric_cols) > 5:
    numeric_cols = numeric_cols[:5]

interaction_count = 0
max_interactions = 15
for i, col1 in enumerate(numeric_cols):
    for j, col2 in enumerate(numeric_cols[i+1:], i+1):
        if interaction_count >= max_interactions:
            break
        
        # 乘积交互
        extended_interaction[f'{col1}_x_{col2}'] = extended_multiscale[col1] * extended_multiscale[col2]
        
        # 差异交互
        extended_interaction[f'{col1}_diff_{col2}'] = extended_multiscale[col1] - extended_multiscale[col2]
        
        # 比值交互（避免除0）
        extended_interaction[f'{col1}_div_{col2}'] = extended_multiscale[col1] / (extended_multiscale[col2] + 1e-8)
        
        interaction_count += 3
        
        if interaction_count >= max_interactions:
            break
    
    if interaction_count >= max_interactions:
        break

print_progress(f"    ✅ 交互特征创建完成: {extended_multiscale.shape[1]} -> {extended_interaction.shape[1]} 特征")

print_progress(f"  ⏱️ 特征工程耗时: {time.time() - enhancement_start:.2f}秒")

# ======= Step 3: 多维度特征筛选 =======
print_progress("\n🎯 Step 3: 多维度特征筛选")
selection_start = time.time()

# 3.1 计算多种特征重要性分数
print_progress("  📊 计算特征重要性分数...")

n_features = extended_interaction.shape[1]

# F-test分数
try:
    f_scores, _ = f_classif(extended_interaction.fillna(0), y)
    f_scores = np.nan_to_num(f_scores, nan=0.0, posinf=0.0, neginf=0.0)
except:
    f_scores = np.ones(n_features)

# 互信息分数
try:
    mi_scores = mutual_info_regression(extended_interaction.fillna(0), y, random_state=42)
    mi_scores = np.nan_to_num(mi_scores, nan=0.0, posinf=0.0, neginf=0.0)
except:
    mi_scores = np.ones(n_features)

# 方差分数
var_scores = extended_interaction.var().values
var_scores = np.nan_to_num(var_scores, nan=0.0, posinf=0.0, neginf=0.0)

# 标准化各分数
def normalize_scores(scores):
    scores = np.array(scores)
    if np.max(scores) - np.min(scores) > 1e-8:
        return (scores - np.min(scores)) / (np.max(scores) - np.min(scores))
    else:
        return np.ones_like(scores)

f_scores_norm = normalize_scores(f_scores)
mi_scores_norm = normalize_scores(mi_scores)
var_scores_norm = normalize_scores(var_scores)

# 综合评分
combined_scores = (f_scores_norm + mi_scores_norm + var_scores_norm) / 3

# 选择前15个特征
k = 15
top_k_indices = np.argsort(combined_scores)[-k:]
selected_features = extended_interaction.columns[top_k_indices]
extended_final = extended_interaction[selected_features]

# 创建特征评分表
feature_scores_df = pd.DataFrame({
    'feature': extended_interaction.columns,
    'f_test': f_scores_norm,
    'mutual_info': mi_scores_norm,
    'variance': var_scores_norm,
    'combined': combined_scores
}).sort_values('combined', ascending=False)

print_progress(f"    ✅ 多维度筛选完成: {extended_interaction.shape[1]} -> {extended_final.shape[1]} 特征")
print_progress(f"    📊 前5个特征: {selected_features[:5].tolist()}")

print_progress(f"  ⏱️ 特征筛选耗时: {time.time() - selection_start:.2f}秒")

# ======= Step 4: 模型性能评估 =======
print_progress("\n📊 Step 4: 模型性能评估")
evaluation_start = time.time()

# 4.1 数据划分
print_progress("  🔄 数据划分...")
Xb_train, Xb_test, y_train, y_test = train_test_split(
    base, y, test_size=0.3, random_state=42)
Xe_train, Xe_test, _, _ = train_test_split(
    extended_final, y, test_size=0.3, random_state=42)

# 4.2 交叉验证评估
print_progress("  🔄 执行交叉验证...")
cv = RepeatedKFold(n_splits=5, n_repeats=3, random_state=42)

# Base模型交叉验证
base_cv_scores = []
for train_idx, test_idx in cv.split(base):
    X_train_fold, X_test_fold = base.iloc[train_idx], base.iloc[test_idx]
    y_train_fold, y_test_fold = y.iloc[train_idx], y.iloc[test_idx]
    
    scaler = RobustScaler()
    X_train_scaled = scaler.fit_transform(X_train_fold.fillna(0))
    X_test_scaled = scaler.transform(X_test_fold.fillna(0))
    
    model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
    model.fit(X_train_scaled, y_train_fold)
    y_pred = model.predict(X_test_scaled)
    
    r2 = r2_score(y_test_fold, y_pred)
    base_cv_scores.append(r2)

# Extended模型交叉验证
extended_cv_scores = []
for train_idx, test_idx in cv.split(extended_final):
    X_train_fold, X_test_fold = extended_final.iloc[train_idx], extended_final.iloc[test_idx]
    y_train_fold, y_test_fold = y.iloc[train_idx], y.iloc[test_idx]
    
    scaler = RobustScaler()
    X_train_scaled = scaler.fit_transform(X_train_fold.fillna(0))
    X_test_scaled = scaler.transform(X_test_fold.fillna(0))
    
    model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
    model.fit(X_train_scaled, y_train_fold)
    y_pred = model.predict(X_test_scaled)
    
    r2 = r2_score(y_test_fold, y_pred)
    extended_cv_scores.append(r2)

# 4.3 单次训练评估
print_progress("  🎯 单次训练评估...")
scaler = RobustScaler()
Xb_train_scaled = scaler.fit_transform(Xb_train.fillna(0))
Xb_test_scaled = scaler.transform(Xb_test.fillna(0))
Xe_train_scaled = scaler.fit_transform(Xe_train.fillna(0))
Xe_test_scaled = scaler.transform(Xe_test.fillna(0))

# Base模型
base_model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
base_model.fit(Xb_train_scaled, y_train)
y_pred_base = base_model.predict(Xb_test_scaled)

# Extended模型
extended_model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
extended_model.fit(Xe_train_scaled, y_train)
y_pred_extended = extended_model.predict(Xe_test_scaled)

# 计算指标
base_metrics = {
    'r2': r2_score(y_test, y_pred_base),
    'mae': mean_absolute_error(y_test, y_pred_base),
    'mse': mean_squared_error(y_test, y_pred_base),
    'rmse': np.sqrt(mean_squared_error(y_test, y_pred_base))
}

extended_metrics = {
    'r2': r2_score(y_test, y_pred_extended),
    'mae': mean_absolute_error(y_test, y_pred_extended),
    'mse': mean_squared_error(y_test, y_pred_extended),
    'rmse': np.sqrt(mean_squared_error(y_test, y_pred_extended))
}

print_progress(f"  ⏱️ 性能评估耗时: {time.time() - evaluation_start:.2f}秒")

# ======= Step 5: 结果保存 =======
print_progress("\n💾 Step 5: 结果保存")

results = {
    "step3_feature_engineering_enhancement": {
        "data_info": {
            "samples": len(y),
            "original_features": int(extended.shape[1]),
            "cleaned_features": int(extended_clean.shape[1]),
            "multiscale_features": int(extended_multiscale.shape[1]),
            "interaction_features": int(extended_interaction.shape[1]),
            "final_features": int(extended_final.shape[1])
        },
        "feature_scores": feature_scores_df.to_dict('records'),
        "model_performance": {
            "base_model": {
                "cv_mean": float(np.mean(base_cv_scores)),
                "cv_std": float(np.std(base_cv_scores)),
                "single_train": base_metrics
            },
            "extended_model": {
                "cv_mean": float(np.mean(extended_cv_scores)),
                "cv_std": float(np.std(extended_cv_scores)),
                "single_train": extended_metrics
            },
            "improvement": {
                "cv_improvement": float(np.mean(extended_cv_scores) - np.mean(base_cv_scores)),
                "cv_improvement_percent": float((np.mean(extended_cv_scores) - np.mean(base_cv_scores)) / abs(np.mean(base_cv_scores)) * 100),
                "single_train_improvement": float(extended_metrics['r2'] - base_metrics['r2']),
                "single_train_improvement_percent": float((extended_metrics['r2'] - base_metrics['r2']) / abs(base_metrics['r2']) * 100)
            }
        },
        "performance_info": {
            "total_runtime_seconds": time.time() - start_time,
            "data_loading_time": time.time() - start_time - (time.time() - enhancement_start),
            "enhancement_time": time.time() - enhancement_start - (time.time() - selection_start),
            "selection_time": time.time() - selection_start - (time.time() - evaluation_start),
            "evaluation_time": time.time() - evaluation_start
        },
        "gpu_info": {
            "cuda_available": torch.cuda.is_available(),
            "gpu_device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
            "gpu_memory_gb": torch.cuda.get_device_properties(0).total_memory / 1024**3 if torch.cuda.is_available() else None
        }
    }
}

print_progress("  💾 正在保存结果...")
with open("step3_feature_engineering_enhancement_results.json", "w") as f:
    json.dump(results, f, indent=4)

# 保存特征评分表
feature_scores_df.to_csv("step3_feature_scores.csv", index=False)

# ======= Step 6: 结果报告 =======
print_progress("\n📊 Step 6: 结果报告")
print("=" * 70)
print("Step 3: 特征工程增强结果")
print("=" * 70)
print(f"🔧 特征工程流程:")
print(f"  原始特征数: {extended.shape[1]}")
print(f"  清理后特征数: {extended_clean.shape[1]}")
print(f"  多尺度变换后: {extended_multiscale.shape[1]}")
print(f"  交互特征后: {extended_interaction.shape[1]}")
print(f"  最终特征数: {extended_final.shape[1]}")
print(f"\n📈 模型性能对比:")
print(f"  Base模型 CV R²: {np.mean(base_cv_scores):.4f} ± {np.std(base_cv_scores):.4f}")
print(f"  Extended模型 CV R²: {np.mean(extended_cv_scores):.4f} ± {np.std(extended_cv_scores):.4f}")
print(f"  交叉验证改善: {np.mean(extended_cv_scores) - np.mean(base_cv_scores):.4f} ({(np.mean(extended_cv_scores) - np.mean(base_cv_scores)) / abs(np.mean(base_cv_scores)) * 100:.1f}%)")
print(f"  单次训练改善: {extended_metrics['r2'] - base_metrics['r2']:.4f} ({(extended_metrics['r2'] - base_metrics['r2']) / abs(base_metrics['r2']) * 100:.1f}%)")
print(f"\n⏱️ 性能信息:")
print(f"  总运行时间: {time.time() - start_time:.2f}秒")
print(f"  特征工程时间: {time.time() - enhancement_start - (time.time() - selection_start):.2f}秒")
print(f"  性能评估时间: {time.time() - evaluation_start:.2f}秒")
print(f"\n✅ 结果文件:")
print(f"  step3_feature_engineering_enhancement_results.json - 完整结果")
print(f"  step3_feature_scores.csv - 特征评分表")
print("=" * 70)

print("🎉 Step 3: 特征工程增强完成！")














