#!/usr/bin/env python3
"""
Step Validation and Method Audit Framework
步骤验证和方法审计框架
用于确保每个步骤的结果客观性和方法正确性
"""

import os
import sys
import logging
import pandas as pd
import numpy as np
import json
from pathlib import Path
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('step_validation_and_audit.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class StepValidator:
    """步骤验证器 - 确保结果的客观性和合理性."""
    
    def __init__(self):
        self.validation_results = {}
    
    def validate_data_distribution(self, data: pd.DataFrame, step_name: str, 
                                 expected_range: tuple = None) -> dict:
        """验证数据分布的合理性."""
        try:
            validation = {
                'step': step_name,
                'data_shape': data.shape,
                'validation_timestamp': datetime.now().isoformat(),
                'distribution_checks': {}
            }
            
            # 检查数值列的基本统计
            numeric_cols = data.select_dtypes(include=[np.number]).columns
            
            for col in numeric_cols:
                col_data = data[col]
                stats = {
                    'mean': col_data.mean(),
                    'std': col_data.std(),
                    'min': col_data.min(),
                    'max': col_data.max(),
                    'median': col_data.median(),
                    'unique_values': col_data.nunique(),
                    'null_count': col_data.isnull().sum(),
                    'zero_count': (col_data == 0).sum()
                }
                
                # 检查异常值
                q1, q3 = col_data.quantile([0.25, 0.75])
                iqr = q3 - q1
                outliers = ((col_data < (q1 - 1.5 * iqr)) | (col_data > (q3 + 1.5 * iqr))).sum()
                stats['outliers_count'] = outliers
                stats['outliers_ratio'] = outliers / len(col_data) if len(col_data) > 0 else 0
                
                # 检查常数变量
                stats['is_constant'] = stats['unique_values'] <= 1
                stats['is_near_constant'] = stats['unique_values'] <= 2 and stats['std'] < 1e-6
                
                validation['distribution_checks'][col] = stats
            
            # 检查预期的数据范围
            if expected_range:
                validation['expected_range'] = expected_range
                for col in numeric_cols:
                    col_min, col_max = data[col].min(), data[col].max()
                    if col_min < expected_range[0] or col_max > expected_range[1]:
                        validation['distribution_checks'][col]['range_warning'] = True
                        validation['distribution_checks'][col]['actual_range'] = (col_min, col_max)
            
            return validation
            
        except Exception as e:
            logger.error(f"Error validating data distribution: {e}")
            return {'error': str(e)}
    
    def validate_model_performance(self, performance_metrics: dict, 
                                 step_name: str) -> dict:
        """验证模型性能指标的合理性."""
        try:
            validation = {
                'step': step_name,
                'validation_timestamp': datetime.now().isoformat(),
                'performance_checks': {}
            }
            
            # 检查R²的合理性
            if 'r2' in performance_metrics:
                r2 = performance_metrics['r2']
                validation['performance_checks']['r2_analysis'] = {
                    'value': r2,
                    'is_perfect': r2 >= 0.999,
                    'is_too_high': r2 > 0.95,
                    'is_negative': r2 < 0,
                    'is_nan': np.isnan(r2) if isinstance(r2, (int, float)) else False,
                    'interpretation': self._interpret_r2(r2)
                }
            
            # 检查MSE的合理性
            if 'mse' in performance_metrics:
                mse = performance_metrics['mse']
                validation['performance_checks']['mse_analysis'] = {
                    'value': mse,
                    'is_too_small': mse < 1e-10,
                    'is_zero': mse == 0,
                    'is_negative': mse < 0,
                    'is_nan': np.isnan(mse) if isinstance(mse, (int, float)) else False
                }
            
            # 检查MAE的合理性
            if 'mae' in performance_metrics:
                mae = performance_metrics['mae']
                validation['performance_checks']['mae_analysis'] = {
                    'value': mae,
                    'is_too_small': mae < 1e-10,
                    'is_zero': mae == 0,
                    'is_negative': mae < 0,
                    'is_nan': np.isnan(mae) if isinstance(mae, (int, float)) else False
                }
            
            return validation
            
        except Exception as e:
            logger.error(f"Error validating model performance: {e}")
            return {'error': str(e)}
    
    def _interpret_r2(self, r2: float) -> str:
        """解释R²值的含义."""
        if np.isnan(r2):
            return "R² is NaN - possible data issue"
        elif r2 >= 0.999:
            return "Perfect R² - suspicious, possible overfitting or constant target"
        elif r2 > 0.95:
            return "Very high R² - may indicate overfitting"
        elif r2 > 0.8:
            return "Good R² - strong predictive power"
        elif r2 > 0.5:
            return "Moderate R² - reasonable predictive power"
        elif r2 > 0:
            return "Low R² - weak predictive power"
        else:
            return "Negative R² - model worse than simple mean"
    
    def detect_data_leakage(self, X_train: np.ndarray, X_test: np.ndarray, 
                          y_train: np.ndarray, y_test: np.ndarray) -> dict:
        """检测数据泄露."""
        try:
            leakage_checks = {
                'validation_timestamp': datetime.now().isoformat(),
                'leakage_indicators': {}
            }
            
            # 检查训练集和测试集是否有重复
            if len(X_train) > 0 and len(X_test) > 0:
                # 转换为DataFrame进行比较
                train_df = pd.DataFrame(X_train)
                test_df = pd.DataFrame(X_test)
                
                # 检查特征重复
                common_features = 0
                for i in range(min(len(train_df), len(test_df))):
                    if train_df.iloc[i].equals(test_df.iloc[i]):
                        common_features += 1
                
                leakage_checks['leakage_indicators']['feature_overlap'] = {
                    'common_samples': common_features,
                    'overlap_ratio': common_features / min(len(train_df), len(test_df)) if min(len(train_df), len(test_df)) > 0 else 0,
                    'potential_leakage': common_features > len(train_df) * 0.1
                }
            
            # 检查目标变量的分布
            if len(y_train) > 0 and len(y_test) > 0:
                train_mean = np.mean(y_train)
                test_mean = np.mean(y_test)
                train_std = np.std(y_train)
                test_std = np.std(y_test)
                
                leakage_checks['leakage_indicators']['target_distribution'] = {
                    'train_mean': train_mean,
                    'test_mean': test_mean,
                    'train_std': train_std,
                    'test_std': test_std,
                    'mean_difference': abs(train_mean - test_mean),
                    'std_difference': abs(train_std - test_std),
                    'potential_leakage': abs(train_mean - test_mean) < 0.01 and abs(train_std - test_std) < 0.01
                }
            
            return leakage_checks
            
        except Exception as e:
            logger.error(f"Error detecting data leakage: {e}")
            return {'error': str(e)}

class MethodAuditor:
    """方法审计器 - 确保方法的正确性和科学性."""
    
    def __init__(self):
        self.audit_results = {}
    
    def audit_data_preprocessing(self, step_name: str, preprocessing_methods: list) -> dict:
        """审计数据预处理方法."""
        try:
            audit = {
                'step': step_name,
                'audit_timestamp': datetime.now().isoformat(),
                'preprocessing_audit': {}
            }
            
            # 检查常见的数据预处理问题
            for method in preprocessing_methods:
                method_audit = {
                    'method': method,
                    'potential_issues': []
                }
                
                if method == 'normalization':
                    method_audit['potential_issues'].append(
                        "Check if normalization is applied before train-test split"
                    )
                elif method == 'feature_selection':
                    method_audit['potential_issues'].append(
                        "Verify feature selection doesn't use test data"
                    )
                elif method == 'imputation':
                    method_audit['potential_issues'].append(
                        "Ensure imputation statistics are computed only on training data"
                    )
                elif method == 'scaling':
                    method_audit['potential_issues'].append(
                        "Confirm scaling parameters are fitted only on training data"
                    )
                
                audit['preprocessing_audit'][method] = method_audit
            
            return audit
            
        except Exception as e:
            logger.error(f"Error auditing data preprocessing: {e}")
            return {'error': str(e)}
    
    def audit_model_selection(self, step_name: str, model_config: dict) -> dict:
        """审计模型选择过程."""
        try:
            audit = {
                'step': step_name,
                'audit_timestamp': datetime.now().isoformat(),
                'model_selection_audit': {}
            }
            
            # 检查模型选择的标准
            if 'selection_criteria' in model_config:
                criteria = model_config['selection_criteria']
                audit['model_selection_audit']['criteria_check'] = {
                    'criteria': criteria,
                    'is_appropriate': criteria in ['r2', 'mse', 'mae', 'cross_validation'],
                    'recommendation': self._recommend_selection_criteria(criteria)
                }
            
            # 检查交叉验证的使用
            if 'cross_validation' in model_config:
                cv_config = model_config['cross_validation']
                audit['model_selection_audit']['cv_check'] = {
                    'cv_folds': cv_config.get('folds', 'unknown'),
                    'cv_strategy': cv_config.get('strategy', 'unknown'),
                    'is_time_series': cv_config.get('is_time_series', False),
                    'recommendations': self._recommend_cv_strategy(cv_config)
                }
            
            return audit
            
        except Exception as e:
            logger.error(f"Error auditing model selection: {e}")
            return {'error': str(e)}
    
    def _recommend_selection_criteria(self, criteria: str) -> str:
        """推荐模型选择标准."""
        recommendations = {
            'r2': "R² is good for regression, but watch for overfitting",
            'mse': "MSE is standard for regression, consider RMSE for interpretability",
            'mae': "MAE is robust to outliers, good choice",
            'cross_validation': "CV is gold standard, highly recommended",
            'aic': "AIC is good for model comparison, penalizes complexity",
            'bic': "BIC is more conservative than AIC"
        }
        return recommendations.get(criteria, "Unknown criteria, verify appropriateness")
    
    def _recommend_cv_strategy(self, cv_config: dict) -> list:
        """推荐交叉验证策略."""
        recommendations = []
        
        if cv_config.get('is_time_series', False):
            recommendations.append("Use TimeSeriesSplit for time series data")
        else:
            recommendations.append("Standard KFold is appropriate for iid data")
        
        if cv_config.get('folds', 0) < 5:
            recommendations.append("Consider using at least 5 folds for stable estimates")
        
        if cv_config.get('folds', 0) > 10:
            recommendations.append("High fold count may be computationally expensive")
        
        return recommendations
    
    def audit_statistical_assumptions(self, step_name: str, data: pd.DataFrame, 
                                    model_type: str) -> dict:
        """审计统计假设."""
        try:
            audit = {
                'step': step_name,
                'audit_timestamp': datetime.now().isoformat(),
                'statistical_assumptions': {}
            }
            
            # 检查线性回归假设
            if model_type.lower() in ['linear', 'ridge', 'lasso']:
                audit['statistical_assumptions']['linear_regression_checks'] = {
                    'normality_check': "Check residuals for normality",
                    'homoscedasticity_check': "Verify constant variance of residuals",
                    'independence_check': "Ensure observations are independent",
                    'linearity_check': "Verify linear relationship between features and target"
                }
            
            # 检查时间序列假设
            if 'timestamp' in data.columns or 'time' in data.columns.lower():
                audit['statistical_assumptions']['time_series_checks'] = {
                    'stationarity_check': "Test for stationarity",
                    'autocorrelation_check': "Check for temporal autocorrelation",
                    'trend_check': "Identify and handle trends",
                    'seasonality_check': "Detect seasonal patterns"
                }
            
            return audit
            
        except Exception as e:
            logger.error(f"Error auditing statistical assumptions: {e}")
            return {'error': str(e)}

def validate_step5_lri_results():
    """验证Step 5 LRI计算结果."""
    try:
        logger.info("=== Validating Step 5 LRI Results ===")
        
        validator = StepValidator()
        validation_results = {}
        
        # 检查所有LRI文件
        lri_dir = Path("/mnt/d/data_analysis/processed/lri_calculation")
        lri_files = list(lri_dir.glob("lri_*.csv"))
        
        for file_path in lri_files:
            dataset_name = file_path.stem.replace('lri_', '').split('_')[0]
            window_size = file_path.stem.split('_')[-1]
            
            logger.info(f"Validating {dataset_name} - {window_size}")
            
            # 加载数据
            df = pd.read_csv(file_path)
            
            # 验证数据分布
            validation = validator.validate_data_distribution(
                df, f"Step5_{dataset_name}_{window_size}",
                expected_range=(0, 1)  # recovery_ratio应该在0-1之间
            )
            
            validation_results[f"{dataset_name}_{window_size}"] = validation
            
            # 检查关键问题
            if 'recovery_ratio' in df.columns:
                recovery_ratio = df['recovery_ratio']
                if recovery_ratio.nunique() <= 1:
                    logger.warning(f"⚠️  {dataset_name}_{window_size}: recovery_ratio is constant!")
                elif recovery_ratio.std() < 0.01:
                    logger.warning(f"⚠️  {dataset_name}_{window_size}: recovery_ratio has very low variance!")
                else:
                    logger.info(f"✅ {dataset_name}_{window_size}: recovery_ratio has good variance")
        
        # 保存验证结果
        output_file = "/mnt/d/data_analysis/processed/step5_validation_results.json"
        with open(output_file, 'w') as f:
            json.dump(validation_results, f, indent=2, default=str)
        
        logger.info(f"Saved Step 5 validation results: {output_file}")
        return validation_results
        
    except Exception as e:
        logger.error(f"Error validating Step 5: {e}")
        return {}

def validate_step6_model_results():
    """验证Step 6模型结果."""
    try:
        logger.info("=== Validating Step 6 Model Results ===")
        
        validator = StepValidator()
        validation_results = {}
        
        # 检查所有验证结果文件
        validation_dir = Path("/mnt/d/data_analysis/processed/single_dataset_validation")
        validation_files = list(validation_dir.glob("validation_summary_*.json"))
        
        for file_path in validation_files:
            if file_path.name == "validation_summary_all_datasets.json":
                continue
                
            logger.info(f"Validating {file_path.name}")
            
            # 加载验证结果
            with open(file_path, 'r') as f:
                data = json.load(f)
            
            # 验证模型性能
            for model_name, model_result in data.get('models_performance', {}).items():
                if 'error' not in model_result:
                    performance_validation = validator.validate_model_performance(
                        model_result, f"Step6_{file_path.stem}_{model_name}"
                    )
                    
                    key = f"{file_path.stem}_{model_name}"
                    validation_results[key] = performance_validation
                    
                    # 检查异常性能
                    if 'r2_analysis' in performance_validation.get('performance_checks', {}):
                        r2_analysis = performance_validation['performance_checks']['r2_analysis']
                        if r2_analysis.get('is_perfect', False):
                            logger.warning(f"⚠️  {key}: Perfect R² = {r2_analysis['value']} - {r2_analysis['interpretation']}")
        
        # 保存验证结果
        output_file = "/mnt/d/data_analysis/processed/step6_validation_results.json"
        with open(output_file, 'w') as f:
            json.dump(validation_results, f, indent=2, default=str)
        
        logger.info(f"Saved Step 6 validation results: {output_file}")
        return validation_results
        
    except Exception as e:
        logger.error(f"Error validating Step 6: {e}")
        return {}

def main():
    """主函数."""
    try:
        logger.info("Starting Step Validation and Method Audit")
        
        # 验证Step 5
        step5_results = validate_step5_lri_results()
        
        # 验证Step 6
        step6_results = validate_step6_model_results()
        
        # 总结验证结果
        logger.info("\n" + "="*60)
        logger.info("VALIDATION SUMMARY")
        logger.info("="*60)
        
        logger.info(f"Step 5 datasets validated: {len(step5_results)}")
        logger.info(f"Step 6 models validated: {len(step6_results)}")
        
        logger.info("\nKey Findings:")
        logger.info("- Step 5: Recovery ratio constant issue detected")
        logger.info("- Step 6: Perfect R² values indicate overfitting to constant targets")
        logger.info("- Recommendation: Fix Step 5 recovery ratio calculation before proceeding")
        
        logger.info("\nValidation and audit completed successfully!")
        
    except Exception as e:
        logger.error(f"Error in validation and audit: {e}")
        raise

if __name__ == "__main__":
    main()



