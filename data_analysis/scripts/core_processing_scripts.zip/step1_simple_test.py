#!/usr/bin/env python3
"""
Step 1: 简单测试 - 实时显示进度
"""

import pandas as pd
import numpy as np
import torch
import json
import time
import sys

print("=" * 50)
print("Step 1: 简单测试 - 实时显示进度")
print("=" * 50)

# GPU检查
print("🔍 GPU检查:")
print(f"  CUDA可用: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print(f"  GPU设备: {torch.cuda.get_device_name(0)}")
else:
    print("  ⚠️ CUDA不可用，将使用CPU")

# 数据读取测试
print("\n📂 数据读取测试")
start_time = time.time()

try:
    print("  📥 正在读取features_base.csv（前1000行）...")
    sys.stdout.flush()
    base = pd.read_csv("features_base.csv", nrows=1000)
    print(f"    ✅ Base特征: {base.shape}")
    
    print("  📥 正在读取features_extended.csv（前1000行）...")
    sys.stdout.flush()
    extended = pd.read_csv("features_extended.csv", nrows=1000)
    print(f"    ✅ Extended特征: {extended.shape}")
    
    print("  📥 正在读取labels.csv（前1000行）...")
    sys.stdout.flush()
    y = pd.read_csv("labels.csv", nrows=1000)["target"]
    print(f"    ✅ 标签: {len(y)} 个样本")
    
    print(f"  ✅ 数据加载完成: {len(y)} 个样本")
    print(f"  ⏱️ 数据加载耗时: {time.time() - start_time:.2f}秒")
    
except Exception as e:
    print(f"  ❌ 数据加载失败: {e}")
    exit(1)

# F-test测试
print("\n🔧 F-test测试")
f_test_start = time.time()

try:
    print("  🔬 正在执行F-test...")
    sys.stdout.flush()
    from sklearn.feature_selection import f_classif
    
    # 只测试前5个特征
    X_test = extended.iloc[:, :5]
    F, p = f_classif(X_test, y)
    
    print(f"    📊 F值范围: {np.min(F):.2f} - {np.max(F):.2f}")
    print(f"    📊 有效F值: {np.sum(np.isfinite(F) & (F > 0))}/{len(F)}")
    print(f"  ⏱️ F-test耗时: {time.time() - f_test_start:.2f}秒")
    
except Exception as e:
    print(f"  ❌ F-test失败: {e}")

# 简单模型测试
print("\n🤖 简单模型测试")
model_start = time.time()

try:
    print("  🎯 正在训练简单模型...")
    sys.stdout.flush()
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import StandardScaler
    from sklearn.ensemble import HistGradientBoostingRegressor
    from sklearn.metrics import r2_score
    
    # 数据划分
    X_train, X_test, y_train, y_test = train_test_split(
        extended.iloc[:, :5], y, test_size=0.3, random_state=42)
    
    # 标准化
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # 模型训练
    model = HistGradientBoostingRegressor(max_iter=10, random_state=42, verbose=0)
    model.fit(X_train_scaled, y_train)
    y_pred = model.predict(X_test_scaled)
    r2 = r2_score(y_test, y_pred)
    
    print(f"    ✅ 模型R²: {r2:.4f}")
    print(f"  ⏱️ 模型测试耗时: {time.time() - model_start:.2f}秒")
    
except Exception as e:
    print(f"  ❌ 模型测试失败: {e}")

# 结果保存
print("\n💾 结果保存")
results = {
    "step1_simple_test": {
        "gpu_info": {
            "cuda_available": torch.cuda.is_available(),
            "gpu_device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None
        },
        "data_info": {
            "samples": len(y),
            "base_features": base.shape[1],
            "extended_features": extended.shape[1]
        },
        "performance": {
            "total_runtime": time.time() - start_time
        }
    }
}

with open("step1_simple_test_results.json", "w") as f:
    json.dump(results, f, indent=4)

print("  ✅ 结果已保存到 step1_simple_test_results.json")

# 最终报告
print("\n📊 最终报告")
print("=" * 50)
print("Step 1: 简单测试完成")
print(f"⏱️ 总运行时间: {time.time() - start_time:.2f}秒")
print("=" * 50)

print("🎉 Step 1: 简单测试完成！")







