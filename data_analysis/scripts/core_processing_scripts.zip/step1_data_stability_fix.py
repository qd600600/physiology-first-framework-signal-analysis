#!/usr/bin/env python3
"""
Step 1: 数据稳定性修复
目标：修复数值异常与形状不匹配问题

执行步骤：
1. 检查每个数据集的缺失值比例与全NaN列
2. 移除全NaN列并记录到日志
3. 确保 SimpleImputer 不改变列数量
4. 修复 ValueError: Shape of passed values 类问题
5. 若数据量超过500万行，对F-test阶段使用分批GPU加速
6. 验证输出：打印每个数据集的 imputation_shape_check = True/False
"""

import pandas as pd
import numpy as np
import torch
import json
import time
import sys
from sklearn.preprocessing import StandardScaler, RobustScaler
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from sklearn.feature_selection import f_classif, SelectKBest
import warnings
warnings.filterwarnings("ignore")

# 尝试导入GPU加速库
try:
    import cuml
    import cudf
    CUML_AVAILABLE = True
    print("✅ cuML GPU加速库可用")
except ImportError:
    CUML_AVAILABLE = False
    print("⚠️ cuML不可用，将使用PyTorch GPU加速")

def print_progress(message, step=None, total_steps=None):
    """打印进度信息"""
    if step is not None and total_steps is not None:
        progress = (step / total_steps) * 100
        print(f"[{progress:5.1f}%] {message}")
    else:
        print(message)
    sys.stdout.flush()

print("=" * 70)
print("Step 1: 数据稳定性修复")
print("=" * 70)

# GPU检查
print_progress("🔍 GPU检查:")
print_progress(f"  CUDA可用: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print_progress(f"  GPU设备: {torch.cuda.get_device_name(0)}")
    print_progress(f"  GPU内存: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.1f} GB")
    device = torch.device('cuda')
    use_gpu = True
else:
    print_progress("  ⚠️ CUDA不可用，将使用CPU")
    device = torch.device('cpu')
    use_gpu = False

def check_missing_values(df, dataset_name, verbose=True):
    """
    检查数据集的缺失值比例与全NaN列
    """
    if verbose:
        print_progress(f"  🔍 检查{dataset_name}缺失值...")
    
    # 检查全NaN列
    all_nan_cols = df.columns[df.isna().all()].tolist()
    
    # 检查每列的缺失值比例
    missing_ratio = df.isna().sum() / len(df)
    high_missing_cols = missing_ratio[missing_ratio > 0.5].index.tolist()
    
    if verbose:
        print_progress(f"    📊 全NaN列: {len(all_nan_cols)} 个")
        print_progress(f"    📊 高缺失值列(>50%): {len(high_missing_cols)} 个")
        print_progress(f"    📊 总缺失值比例: {df.isna().sum().sum() / (df.shape[0] * df.shape[1]):.4f}")
    
    return {
        'all_nan_cols': all_nan_cols,
        'high_missing_cols': high_missing_cols,
        'missing_ratio': missing_ratio.to_dict(),
        'total_missing_ratio': df.isna().sum().sum() / (df.shape[0] * df.shape[1])
    }

def remove_problematic_columns(df, missing_info, verbose=True):
    """
    移除全NaN列和高缺失值列
    """
    if verbose:
        print_progress("  🗑️ 移除问题列...")
    
    original_shape = df.shape
    
    # 移除全NaN列
    df_clean = df.drop(columns=missing_info['all_nan_cols'])
    
    # 移除高缺失值列
    df_clean = df_clean.drop(columns=missing_info['high_missing_cols'])
    
    if verbose:
        print_progress(f"    📊 移除列数: {original_shape[1]} -> {df_clean.shape[1]}")
        print_progress(f"    📊 移除的列: {missing_info['all_nan_cols'] + missing_info['high_missing_cols']}")
    
    return df_clean

def safe_imputation(df, dataset_name, verbose=True):
    """
    安全的Imputation，确保不改变列数量
    """
    if verbose:
        print_progress(f"  🔄 执行{dataset_name}安全Imputation...")
    
    original_shape = df.shape
    
    # 检查是否还有NaN值
    if df.isna().sum().sum() == 0:
        if verbose:
            print_progress("    ✅ 无缺失值，跳过Imputation")
        return df, True
    
    # 使用SimpleImputer
    imputer = SimpleImputer(strategy='median')
    
    try:
        # 执行Imputation
        X_imputed = imputer.fit_transform(df)
        
        # 创建新的DataFrame，保持原始列名和索引
        df_imputed = pd.DataFrame(X_imputed, columns=df.columns, index=df.index)
        
        # 验证形状是否一致
        shape_check = df_imputed.shape[1] == df.shape[1]
        
        if verbose:
            print_progress(f"    📊 Imputation前形状: {original_shape}")
            print_progress(f"    📊 Imputation后形状: {df_imputed.shape}")
            print_progress(f"    ✅ 形状检查: {shape_check}")
        
        return df_imputed, shape_check
        
    except Exception as e:
        if verbose:
            print_progress(f"    ❌ Imputation失败: {e}")
        return df, False

def gpu_accelerated_f_test(X, y, verbose=True):
    """
    GPU加速的F-test - 使用PyTorch
    """
    if verbose:
        print_progress("  🚀 使用PyTorch GPU加速F-test...")
    
    try:
        # 转换为PyTorch张量
        X_tensor = torch.from_numpy(X.values).float().to(device)
        y_tensor = torch.from_numpy(y.values).float().to(device)
        
        if verbose:
            print_progress(f"    📊 GPU数据形状: {X_tensor.shape}")
        
        # 计算F-test统计量
        n_samples = X_tensor.shape[0]
        n_features = X_tensor.shape[1]
        
        # 计算组间和组内方差
        unique_classes = torch.unique(y_tensor)
        n_classes = len(unique_classes)
        
        f_scores = torch.zeros(n_features, device=device)
        
        for i in range(n_features):
            feature = X_tensor[:, i]
            
            # 计算组间方差
            group_means = torch.zeros(n_classes, device=device)
            group_counts = torch.zeros(n_classes, device=device)
            
            for j, cls in enumerate(unique_classes):
                mask = (y_tensor == cls)
                group_means[j] = feature[mask].mean()
                group_counts[j] = mask.sum()
            
            overall_mean = feature.mean()
            ss_between = torch.sum(group_counts * (group_means - overall_mean) ** 2)
            
            # 计算组内方差
            ss_within = torch.zeros(1, device=device)
            for j, cls in enumerate(unique_classes):
                mask = (y_tensor == cls)
                if mask.sum() > 0:
                    ss_within += torch.sum((feature[mask] - group_means[j]) ** 2)
            
            # 计算F值
            if ss_within > 1e-8:
                f_scores[i] = (ss_between / (n_classes - 1)) / (ss_within / (n_samples - n_classes))
            else:
                f_scores[i] = 0.0
        
        # 转换回numpy
        f_scores_np = f_scores.cpu().numpy()
        
        if verbose:
            print_progress("    ✅ PyTorch GPU F-test完成")
            print_progress(f"    📊 F值范围: {f_scores_np.min():.2f} - {f_scores_np.max():.2f}")
        
        return f_scores_np, True
        
    except Exception as e:
        if verbose:
            print_progress(f"    ⚠️ GPU F-test失败，回退到CPU: {e}")
        return cpu_f_test(X, y, verbose)

def cpu_f_test(X, y, verbose=True):
    """
    CPU版本的F-test
    """
    if verbose:
        print_progress("  💻 使用CPU F-test...")
    
    try:
        # 处理NaN值
        X_clean = X.fillna(0)
        
        # 执行F-test
        F, p = f_classif(X_clean, y)
        
        if verbose:
            print_progress("    ✅ CPU F-test完成")
        
        return F, True
        
    except Exception as e:
        if verbose:
            print_progress(f"    ❌ CPU F-test失败: {e}")
        return np.ones(X.shape[1]), False

def feature_selection_with_stability(X, y, k=20, verbose=True):
    """
    稳定的特征选择
    """
    if verbose:
        print_progress("  🎯 执行稳定特征选择...")
    
    # 执行F-test
    f_scores, f_success = gpu_accelerated_f_test(X, y, verbose=verbose)
    
    if f_success:
        # 选择前k个特征
        top_k_indices = np.argsort(f_scores)[-k:]
        selected_features = X.columns[top_k_indices]
        X_selected = X[selected_features]
        
        if verbose:
            print_progress(f"    ✅ 特征选择完成: {X.shape[1]} -> {X_selected.shape[1]} 特征")
        
        return X_selected, selected_features, f_scores
    else:
        # 如果F-test失败，使用前k个特征
        if verbose:
            print_progress("    ⚠️ F-test失败，使用前k个特征")
        
        X_selected = X.iloc[:, :k]
        selected_features = X_selected.columns
        f_scores = np.ones(X.shape[1])
        
        return X_selected, selected_features, f_scores

# ======= Step 1: 数据读取 =======
print_progress("\n📂 Step 1: 数据读取")
start_time = time.time()

print_progress("  📥 正在读取features_base.csv...")
base = pd.read_csv("features_base.csv")
print_progress(f"    ✅ Base特征加载完成: {base.shape}")

print_progress("  📥 正在读取features_extended.csv...")
extended = pd.read_csv("features_extended.csv")
print_progress(f"    ✅ Extended特征加载完成: {extended.shape}")

print_progress("  📥 正在读取labels.csv...")
y = pd.read_csv("labels.csv")["target"]
print_progress(f"    ✅ 标签加载完成: {len(y)} 个样本")

# 样本一致性检查
assert len(base) == len(extended) == len(y), "样本数量不一致"
print_progress(f"  ✅ 数据加载完成: {len(y)} 个样本")
print_progress(f"  ⏱️ 数据加载耗时: {time.time() - start_time:.2f}秒")

# ======= Step 2: 缺失值检查 =======
print_progress("\n🔍 Step 2: 缺失值检查")
missing_check_start = time.time()

# 2.1 检查Base数据集
base_missing_info = check_missing_values(base, "Base", verbose=True)

# 2.2 检查Extended数据集
extended_missing_info = check_missing_values(extended, "Extended", verbose=True)

print_progress(f"  ⏱️ 缺失值检查耗时: {time.time() - missing_check_start:.2f}秒")

# ======= Step 3: 移除问题列 =======
print_progress("\n🗑️ Step 3: 移除问题列")
cleanup_start = time.time()

# 3.1 清理Base数据集
base_clean = remove_problematic_columns(base, base_missing_info, verbose=True)

# 3.2 清理Extended数据集
extended_clean = remove_problematic_columns(extended, extended_missing_info, verbose=True)

print_progress(f"  ⏱️ 问题列移除耗时: {time.time() - cleanup_start:.2f}秒")

# ======= Step 4: 安全Imputation =======
print_progress("\n🔄 Step 4: 安全Imputation")
imputation_start = time.time()

# 4.1 Base数据集Imputation
base_imputed, base_imputation_shape_check = safe_imputation(base_clean, "Base", verbose=True)

# 4.2 Extended数据集Imputation
extended_imputed, extended_imputation_shape_check = safe_imputation(extended_clean, "Extended", verbose=True)

print_progress(f"  ⏱️ Imputation耗时: {time.time() - imputation_start:.2f}秒")

# ======= Step 5: 特征选择 =======
print_progress("\n🎯 Step 5: 特征选择")
selection_start = time.time()

# 5.1 Extended特征选择
extended_selected, selected_features, f_scores = feature_selection_with_stability(
    extended_imputed, y, k=20, verbose=True)

print_progress(f"  ⏱️ 特征选择耗时: {time.time() - selection_start:.2f}秒")

# ======= Step 6: 数据划分与标准化 =======
print_progress("\n📊 Step 6: 数据划分与标准化")
preprocess_start = time.time()

print_progress("  🔄 正在划分数据...")
Xb_train, Xb_test, y_train, y_test = train_test_split(
    base_imputed, y, test_size=0.3, random_state=42)
Xe_train, Xe_test, _, _ = train_test_split(
    extended_selected, y, test_size=0.3, random_state=42)
print_progress(f"  ✅ 数据划分完成: 训练集{len(y_train)}个, 测试集{len(y_test)}个")

print_progress("  🔄 正在标准化数据...")
scaler = RobustScaler()
Xb_train_scaled = scaler.fit_transform(Xb_train)
Xb_test_scaled = scaler.transform(Xb_test)
Xe_train_scaled = scaler.fit_transform(Xe_train)
Xe_test_scaled = scaler.transform(Xe_test)
print_progress("  ✅ 数据标准化完成")

print_progress(f"  ⏱️ 预处理耗时: {time.time() - preprocess_start:.2f}秒")

# ======= Step 7: 模型训练与评估 =======
print_progress("\n🤖 Step 7: 模型训练与评估")
model_start = time.time()

print_progress("  🚀 初始化模型...")
model = HistGradientBoostingRegressor(
    max_iter=100,
    learning_rate=0.1,
    max_depth=10,
    min_samples_leaf=50,
    random_state=42,
    verbose=0
)

# Base模型
print_progress("  🎯 训练Base模型...")
model.fit(Xb_train_scaled, y_train)
y_pred_base = model.predict(Xb_test_scaled)
r2_base = r2_score(y_test, y_pred_base)
print_progress(f"    ✅ Base模型R²: {r2_base:.4f}")

# Extended模型
print_progress("  🎯 训练Extended模型...")
model.fit(Xe_train_scaled, y_train)
y_pred_ext = model.predict(Xe_test_scaled)
r2_ext = r2_score(y_test, y_pred_ext)
print_progress(f"    ✅ Extended模型R²: {r2_ext:.4f}")

print_progress(f"  ⏱️ 模型训练耗时: {time.time() - model_start:.2f}秒")

# ======= Step 8: 结果保存 =======
print_progress("\n💾 Step 8: 结果保存")

improvement = (r2_ext - r2_base) / abs(r2_base + 1e-9) * 100
results = {
    "step1_data_stability_fix": {
        "missing_value_analysis": {
            "base_all_nan_cols": base_missing_info['all_nan_cols'],
            "base_high_missing_cols": base_missing_info['high_missing_cols'],
            "base_total_missing_ratio": float(base_missing_info['total_missing_ratio']),
            "extended_all_nan_cols": extended_missing_info['all_nan_cols'],
            "extended_high_missing_cols": extended_missing_info['high_missing_cols'],
            "extended_total_missing_ratio": float(extended_missing_info['total_missing_ratio'])
        },
        "imputation_shape_check": {
            "base_imputation_shape_check": base_imputation_shape_check,
            "extended_imputation_shape_check": extended_imputation_shape_check
        },
        "feature_selection": {
            "original_features": int(extended.shape[1]),
            "selected_features": int(extended_selected.shape[1]),
            "selected_feature_names": selected_features.tolist(),
            "f_scores_mean": float(np.mean(f_scores)),
            "f_scores_std": float(np.std(f_scores))
        },
        "model_performance": {
            "R2_base": float(r2_base),
            "R2_extended": float(r2_ext),
            "improvement_abs": float(r2_ext - r2_base),
            "improvement_percent": float(improvement),
            "MAE_base": float(mean_absolute_error(y_test, y_pred_base)),
            "MAE_extended": float(mean_absolute_error(y_test, y_pred_ext)),
            "RMSE_base": float(np.sqrt(mean_squared_error(y_test, y_pred_base))),
            "RMSE_extended": float(np.sqrt(mean_squared_error(y_test, y_pred_ext)))
        },
        "performance_info": {
            "total_runtime_seconds": time.time() - start_time,
            "data_loading_time": time.time() - start_time - (time.time() - missing_check_start),
            "missing_check_time": time.time() - missing_check_start - (time.time() - cleanup_start),
            "cleanup_time": time.time() - cleanup_start - (time.time() - imputation_start),
            "imputation_time": time.time() - imputation_start - (time.time() - selection_start),
            "selection_time": time.time() - selection_start - (time.time() - preprocess_start),
            "preprocessing_time": time.time() - preprocess_start - (time.time() - model_start),
            "model_training_time": time.time() - model_start
        },
        "gpu_info": {
            "cuda_available": torch.cuda.is_available(),
            "cuml_available": CUML_AVAILABLE,
            "gpu_device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
            "gpu_memory_gb": torch.cuda.get_device_properties(0).total_memory / 1024**3 if torch.cuda.is_available() else None
        }
    }
}

print_progress("  💾 正在保存结果...")
with open("step1_data_stability_fix_results.json", "w") as f:
    json.dump(results, f, indent=4)

# ======= Step 9: 结果报告 =======
print_progress("\n📊 Step 9: 结果报告")
print("=" * 70)
print("Step 1: 数据稳定性修复结果")
print("=" * 70)
print(f"🔍 缺失值分析:")
print(f"  Base全NaN列: {len(base_missing_info['all_nan_cols'])} 个")
print(f"  Base高缺失值列: {len(base_missing_info['high_missing_cols'])} 个")
print(f"  Extended全NaN列: {len(extended_missing_info['all_nan_cols'])} 个")
print(f"  Extended高缺失值列: {len(extended_missing_info['high_missing_cols'])} 个")
print(f"\n🔄 Imputation形状检查:")
print(f"  Base imputation_shape_check: {base_imputation_shape_check}")
print(f"  Extended imputation_shape_check: {extended_imputation_shape_check}")
print(f"\n🎯 特征选择:")
print(f"  原始特征数: {extended.shape[1]}")
print(f"  选择特征数: {extended_selected.shape[1]}")
print(f"\n📈 模型性能:")
print(f"  Base模型 R²: {r2_base:.4f}")
print(f"  Extended模型 R²: {r2_ext:.4f}")
print(f"  性能提升: {r2_ext - r2_base:.4f} ({improvement:.2f}%)")
print(f"\n⏱️ 性能信息:")
print(f"  总运行时间: {time.time() - start_time:.2f}秒")
print(f"\n✅ 结果文件:")
print(f"  step1_data_stability_fix_results.json - 数据稳定性修复结果")
print("=" * 70)

print("🎉 Step 1: 数据稳定性修复完成！")
