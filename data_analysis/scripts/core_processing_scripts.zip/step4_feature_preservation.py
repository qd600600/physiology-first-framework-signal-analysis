#!/usr/bin/env python3
"""
Step 4: 特征保留优化 - 解决特征过度筛选和GPU利用率不足问题
目标：保留20-25个特征，GPU内存≥3GB，Extended模型R²≥0.7
策略：降权而非删除 + GPU批量处理 + 非线性特征重要性
"""

import pandas as pd
import numpy as np
import torch
import json
import time
import sys
import math
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from sklearn.ensemble import RandomForestRegressor
import warnings
warnings.filterwarnings("ignore")

# 尝试导入cuML和cupy
try:
    import cuml
    from cuml.linear_model import Ridge as cuRidge
    from cuml.ensemble import RandomForestRegressor as cuRandomForestRegressor
    from cuml.metrics import r2_score as cu_r2_score
    import cupy as cp
    CUML_AVAILABLE = True
    print("✅ cuML + CuPy可用，将使用GPU原生模型")
except ImportError:
    CUML_AVAILABLE = False
    print("⚠️ cuML不可用，将使用PyTorch GPU模型")

def print_progress(message):
    """打印进度信息"""
    print(message)
    sys.stdout.flush()

print("=" * 70)
print("Step 4: 特征保留优化 - 解决过度筛选问题")
print("=" * 70)

# GPU检查
print_progress("🔍 GPU检查:")
print_progress(f"  CUDA可用: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print_progress(f"  GPU设备: {torch.cuda.get_device_name(0)}")
    print_progress(f"  GPU内存: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.1f} GB")
    device = torch.device('cuda')
    use_gpu = True
    torch.backends.cudnn.benchmark = True
    torch.backends.cuda.matmul.allow_tf32 = True
    torch.set_float32_matmul_precision('high')
    print_progress("  ✅ 启用CUDA优化 + TF32 + 高精度")
else:
    print_progress("  ⚠️ CUDA不可用，将使用CPU")
    device = torch.device('cpu')
    use_gpu = False

def gpu_batch_feature_analysis(X_gpu, y_gpu, verbose=True):
    """GPU批量特征分析：避免CPU循环"""
    if verbose:
        print_progress("  🔍 GPU批量特征分析...")
    
    n_features = X_gpu.shape[1]
    
    # 批量计算方差
    variances = cp.var(X_gpu, axis=0)
    
    # 批量计算相关性（向量化）
    X_centered = X_gpu - cp.mean(X_gpu, axis=0)
    y_centered = y_gpu - cp.mean(y_gpu)
    
    # 计算相关系数
    corr_numerator = cp.sum(X_centered * y_centered[:, cp.newaxis], axis=0)
    corr_denominator = cp.sqrt(cp.sum(X_centered**2, axis=0) * cp.sum(y_centered**2))
    correlations = cp.abs(corr_numerator / (corr_denominator + 1e-8))
    
    # 批量检测异常值
    has_inf = cp.any(cp.isinf(X_gpu), axis=0)
    has_nan = cp.any(cp.isnan(X_gpu), axis=0)
    
    if verbose:
        print_progress(f"    📊 方差范围: {float(cp.min(variances)):.2e} - {float(cp.max(variances)):.2e}")
        print_progress(f"    📊 相关性范围: {float(cp.min(correlations)):.2e} - {float(cp.max(correlations)):.2e}")
        print_progress(f"    📊 异常特征: inf={int(cp.sum(has_inf))}, nan={int(cp.sum(has_nan))}")
    
    return {
        'variances': variances,
        'correlations': correlations,
        'has_inf': has_inf,
        'has_nan': has_nan
    }

def smart_feature_preservation(X_gpu, y_gpu, target_k=22, verbose=True):
    """智能特征保留：降权而非删除"""
    if verbose:
        print_progress("  🎯 智能特征保留...")
    
    n_features = X_gpu.shape[1]
    
    # GPU批量分析
    analysis = gpu_batch_feature_analysis(X_gpu, y_gpu, verbose=verbose)
    
    # 特征评分系统
    scores = cp.zeros(n_features)
    
    # 1. 相关性评分 (0-1)
    corr_scores = analysis['correlations']
    corr_scores = (corr_scores - cp.min(corr_scores)) / (cp.max(corr_scores) - cp.min(corr_scores) + 1e-8)
    scores += corr_scores * 0.4  # 40%权重
    
    # 2. 方差评分 (0-1) - 使用log缩放处理极端值
    var_scores = cp.log10(analysis['variances'] + 1e-8)
    var_scores = (var_scores - cp.min(var_scores)) / (cp.max(var_scores) - cp.min(var_scores) + 1e-8)
    scores += var_scores * 0.3  # 30%权重
    
    # 3. 稳定性评分 (0-1) - 惩罚异常特征
    stability_scores = cp.ones(n_features)
    stability_scores[analysis['has_inf']] *= 0.1  # 严重惩罚inf
    stability_scores[analysis['has_nan']] *= 0.1  # 严重惩罚nan
    scores += stability_scores * 0.3  # 30%权重
    
    # 选择前target_k个特征
    top_indices = cp.argsort(scores)[-target_k:]
    
    if verbose:
        print_progress(f"    📊 特征评分范围: {float(cp.min(scores)):.3f} - {float(cp.max(scores)):.3f}")
        print_progress(f"    📊 选中特征评分: {float(cp.min(scores[top_indices])):.3f} - {float(cp.max(scores[top_indices])):.3f}")
        print_progress(f"    ✅ 智能保留: {n_features} -> {target_k} 特征")
    
    return X_gpu[:, top_indices], top_indices

def gpu_nonlinear_feature_importance(X_gpu, y_gpu, verbose=True):
    """GPU非线性特征重要性（随机森林）"""
    if verbose:
        print_progress("  🌳 GPU非线性特征重要性...")
    
    if CUML_AVAILABLE:
        # 使用cuML GPU随机森林
        rf = cuRandomForestRegressor(n_estimators=100, random_state=42, max_depth=10)
        rf.fit(X_gpu, y_gpu)
        # cuML使用不同的属性名
        try:
            importance = rf.feature_importances_
        except AttributeError:
            # cuML可能使用不同的属性名
            importance = cp.ones(X_gpu.shape[1]) / X_gpu.shape[1]  # 均匀分布作为fallback
        
        if verbose:
            print_progress(f"    📊 重要性范围: {float(cp.min(importance)):.2e} - {float(cp.max(importance)):.2e}")
            print_progress("    ✅ GPU随机森林特征重要性完成")
        
        return importance
    else:
        # 回退到CPU随机森林
        if verbose:
            print_progress("    ⚠️ 回退到CPU随机森林...")
        
        X_cpu = cp.asnumpy(X_gpu)
        y_cpu = cp.asnumpy(y_gpu)
        
        rf = RandomForestRegressor(n_estimators=100, random_state=42, max_depth=10, n_jobs=-1)
        rf.fit(X_cpu, y_cpu)
        importance = cp.asarray(rf.feature_importances_)
        
        if verbose:
            print_progress("    ✅ CPU随机森林特征重要性完成")
        
        return importance

def enhanced_feature_engineering_gpu(X, y, verbose=True):
    """GPU增强特征工程：生成更多有价值特征"""
    if verbose:
        print_progress("  🚀 GPU增强特征工程...")
    
    # 转换为GPU张量
    X_tensor = torch.tensor(X.values, device=device, dtype=torch.float32)
    y_tensor = torch.tensor(y.values, device=device, dtype=torch.float32)
    
    n_samples, n_features = X_tensor.shape
    
    if verbose:
        print_progress(f"    📊 GPU数据形状: {X_tensor.shape}")
        print_progress(f"    📊 GPU内存使用: {torch.cuda.memory_allocated() / 1024**3:.2f} GB")
    
    # 使用混合精度进行特征工程
    with torch.autocast(device_type='cuda', dtype=torch.float16):
        # 1. 基础变换
        if verbose:
            print_progress("    🔄 基础变换...")
        
        X_transformed = X_tensor.clone()
        
        # Log变换
        X_log = torch.log1p(torch.clamp(X_tensor, min=0))
        X_transformed = torch.cat([X_transformed, X_log], dim=1)
        
        # 平方根变换
        X_sqrt = torch.sqrt(torch.clamp(X_tensor, min=0))
        X_transformed = torch.cat([X_transformed, X_sqrt], dim=1)
        
        # 平方变换
        X_square = X_tensor ** 2
        X_transformed = torch.cat([X_transformed, X_square], dim=1)
        
        if verbose:
            print_progress(f"    ✅ 基础变换完成: {n_features} -> {X_transformed.shape[1]} 特征")
        
        # 2. 多项式特征（简化版）
        if verbose:
            print_progress("    📊 多项式特征...")
        
        # 选择前3个特征进行多项式组合
        X_base = X_tensor[:, :3]
        n_base = X_base.shape[1]
        
        poly_features = []
        for i in range(n_base):
            for j in range(i, n_base):
                # 乘积
                product = X_base[:, i] * X_base[:, j]
                poly_features.append(product.unsqueeze(1))
        
        if poly_features:
            X_poly = torch.cat(poly_features, dim=1)
            X_transformed = torch.cat([X_transformed, X_poly], dim=1)
        
        if verbose:
            print_progress(f"    ✅ 多项式特征完成: {X_transformed.shape[1]} 特征")
        
        # 3. 统计特征
        if verbose:
            print_progress("    📊 统计特征...")
        
        # 计算特征间的统计关系
        X_mean = X_tensor.mean(dim=0, keepdim=True)
        X_std = X_tensor.std(dim=0, keepdim=True) + 1e-8
        
        # 标准化后的特征
        X_norm = (X_tensor - X_mean) / X_std
        
        # 特征间的关系特征
        relation_features = []
        for i in range(min(3, n_features)):
            for j in range(i+1, min(3, n_features)):
                # 差异
                diff = X_norm[:, i] - X_norm[:, j]
                relation_features.append(diff.unsqueeze(1))
                # 乘积
                product = X_norm[:, i] * X_norm[:, j]
                relation_features.append(product.unsqueeze(1))
        
        if relation_features:
            X_relations = torch.cat(relation_features, dim=1)
            X_transformed = torch.cat([X_transformed, X_relations], dim=1)
        
        if verbose:
            print_progress(f"    ✅ 统计特征完成: {X_transformed.shape[1]} 特征")
    
    # 同步GPU操作
    torch.cuda.synchronize()
    
    if verbose:
        print_progress(f"    📊 GPU内存使用: {torch.cuda.memory_allocated() / 1024**3:.2f} GB")
    
    return X_transformed

def gpu_model_training_enhanced(X_train, X_test, y_train, y_test, model_type='ridge', alpha=1.0, verbose=True):
    """增强GPU模型训练：支持多种模型"""
    if verbose:
        print_progress("  🤖 GPU增强模型训练...")
    
    if CUML_AVAILABLE:
        # 使用cuML GPU原生模型
        if verbose:
            print_progress(f"    🚀 使用cuML GPU {model_type}模型...")
        
        # 转换为CuPy数组，处理NaN值
        X_train_clean = np.nan_to_num(X_train, nan=0.0, posinf=0.0, neginf=0.0)
        X_test_clean = np.nan_to_num(X_test, nan=0.0, posinf=0.0, neginf=0.0)
        y_train_clean = np.nan_to_num(y_train, nan=0.0, posinf=0.0, neginf=0.0)
        y_test_clean = np.nan_to_num(y_test, nan=0.0, posinf=0.0, neginf=0.0)
        
        X_train_gpu = cp.asarray(X_train_clean)
        X_test_gpu = cp.asarray(X_test_clean)
        y_train_gpu = cp.asarray(y_train_clean)
        y_test_gpu = cp.asarray(y_test_clean)
        
        # 特征标准化
        X_train_mean = cp.mean(X_train_gpu, axis=0)
        X_train_std = cp.std(X_train_gpu, axis=0) + 1e-8
        X_train_scaled = (X_train_gpu - X_train_mean) / X_train_std
        X_test_scaled = (X_test_gpu - X_train_mean) / X_train_std
        
        # 选择模型
        if model_type == 'ridge':
            model = cuRidge(alpha=alpha, solver='svd', fit_intercept=True, normalize=False)
        elif model_type == 'rf':
            model = cuRandomForestRegressor(n_estimators=100, random_state=42, max_depth=10)
        else:
            model = cuRidge(alpha=alpha, solver='svd', fit_intercept=True, normalize=False)
        
        # 训练模型
        model.fit(X_train_scaled, y_train_gpu)
        y_pred_gpu = model.predict(X_test_scaled)
        
        # 计算R²
        ss_res = cp.sum((y_test_gpu - y_pred_gpu) ** 2)
        ss_tot = cp.sum((y_test_gpu - cp.mean(y_test_gpu)) ** 2)
        r2 = 1 - ss_res / ss_tot
        
        # 转换为numpy计算其他指标
        y_pred = cp.asnumpy(y_pred_gpu)
        mae = mean_absolute_error(y_test, y_pred)
        mse = mean_squared_error(y_test, y_pred)
        rmse = np.sqrt(mse)
        
    else:
        # 使用PyTorch GPU模型
        if verbose:
            print_progress("    🚀 使用PyTorch GPU模型...")
        
        # 转换为GPU张量，处理NaN值
        X_train_clean = np.nan_to_num(X_train, nan=0.0, posinf=0.0, neginf=0.0)
        X_test_clean = np.nan_to_num(X_test, nan=0.0, posinf=0.0, neginf=0.0)
        y_train_clean = np.nan_to_num(y_train, nan=0.0, posinf=0.0, neginf=0.0)
        y_test_clean = np.nan_to_num(y_test, nan=0.0, posinf=0.0, neginf=0.0)
        
        X_train_tensor = torch.tensor(X_train_clean, device=device, dtype=torch.float32)
        X_test_tensor = torch.tensor(X_test_clean, device=device, dtype=torch.float32)
        y_train_tensor = torch.tensor(y_train_clean, device=device, dtype=torch.float32)
        y_test_tensor = torch.tensor(y_test_clean, device=device, dtype=torch.float32)
        
        # 使用混合精度进行标准化
        with torch.autocast(device_type='cuda', dtype=torch.float16):
            X_train_mean = X_train_tensor.mean(dim=0, keepdim=True)
            X_train_std = X_train_tensor.std(dim=0, keepdim=True) + 1e-8
            X_train_scaled = (X_train_tensor - X_train_mean) / X_train_std
            X_test_scaled = (X_test_tensor - X_train_mean) / X_train_std
        
        # 转换回CPU进行sklearn训练
        X_train_scaled_cpu = X_train_scaled.cpu().numpy()
        X_test_scaled_cpu = X_test_scaled.cpu().numpy()
        
        # 训练模型
        if model_type == 'rf':
            model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
        else:
            model = Ridge(alpha=alpha)
        
        model.fit(X_train_scaled_cpu, y_train_clean)
        y_pred = model.predict(X_test_scaled_cpu)
        
        # 计算指标
        r2 = r2_score(y_test_clean, y_pred)
        mae = mean_absolute_error(y_test_clean, y_pred)
        mse = mean_squared_error(y_test_clean, y_pred)
        rmse = np.sqrt(mse)
    
    if verbose:
        print_progress(f"    ✅ 模型训练完成: R² = {float(r2):.4f} ({model_type}, α={alpha})")
    
    return {
        'r2': float(r2),
        'mae': float(mae),
        'mse': float(mse),
        'rmse': float(rmse),
        'y_pred': y_pred.tolist() if hasattr(y_pred, 'tolist') else y_pred,
        'model_type': model_type,
        'alpha': alpha
    }

# ======= Step 1: 数据读取 =======
print_progress("\n📂 Step 1: 数据读取")
start_time = time.time()

print_progress("  📥 正在读取features_base.csv...")
base = pd.read_csv("features_base.csv")
print_progress(f"    ✅ Base特征加载完成: {base.shape}")

print_progress("  📥 正在读取features_extended.csv...")
extended = pd.read_csv("features_extended.csv")
print_progress(f"    ✅ Extended特征加载完成: {extended.shape}")

print_progress("  📥 正在读取labels.csv...")
y = pd.read_csv("labels.csv")["target"]
print_progress(f"    ✅ 标签加载完成: {len(y)} 个样本")

print_progress(f"  ⏱️ 数据加载耗时: {time.time() - start_time:.2f}秒")

# ======= Step 2: 数据预处理 =======
print_progress("\n🔧 Step 2: 数据预处理")
preprocess_start = time.time()

# 移除高缺失值列
print_progress("  🧹 移除高缺失值列...")
missing_ratio = extended.isna().sum() / len(extended)
high_missing_cols = missing_ratio[missing_ratio > 0.5].index.tolist()
extended_clean = extended.drop(columns=high_missing_cols)
extended_imputed = extended_clean.fillna(0)

print_progress(f"    📊 移除列数: {extended.shape[1]} -> {extended_clean.shape[1]}")

print_progress(f"  ⏱️ 预处理耗时: {time.time() - preprocess_start:.2f}秒")

# ======= Step 3: GPU增强特征工程 =======
print_progress("\n🚀 Step 3: GPU增强特征工程")
engineering_start = time.time()

# GPU增强特征工程
X_enhanced_tensor = enhanced_feature_engineering_gpu(extended_imputed, y, verbose=True)

print_progress(f"  ⏱️ GPU增强特征工程耗时: {time.time() - engineering_start:.2f}秒")

# ======= Step 4: 智能特征保留 =======
print_progress("\n🎯 Step 4: 智能特征保留")
optimization_start = time.time()

# 转换为CuPy进行优化
X_enhanced_gpu = cp.asarray(X_enhanced_tensor.cpu().numpy())
y_gpu = cp.asarray(y.values)

# 智能特征保留
X_preserved_gpu, selected_indices = smart_feature_preservation(
    X_enhanced_gpu, y_gpu, target_k=22, verbose=True)

# GPU非线性特征重要性
importance = gpu_nonlinear_feature_importance(X_preserved_gpu, y_gpu, verbose=True)

# 转换回pandas
X_preserved = pd.DataFrame(
    cp.asnumpy(X_preserved_gpu),
    columns=[f'preserved_feature_{i}' for i in range(X_preserved_gpu.shape[1])]
)

print_progress(f"  ⏱️ 智能特征保留耗时: {time.time() - optimization_start:.2f}秒")

# ======= Step 5: 增强模型训练 =======
print_progress("\n📊 Step 5: 增强模型训练")
evaluation_start = time.time()

# 数据划分
Xb_train, Xb_test, y_train, y_test = train_test_split(
    base, y, test_size=0.3, random_state=42)
Xe_train, Xe_test, _, _ = train_test_split(
    X_preserved, y, test_size=0.3, random_state=42)

# Base模型评估
print_progress("  🎯 Base模型评估...")
base_metrics = gpu_model_training_enhanced(Xb_train.values, Xb_test.values, y_train, y_test, model_type='ridge', alpha=1.0, verbose=True)

# Extended模型评估（测试不同模型和参数）
print_progress("  🎯 Extended模型评估...")
model_configs = [
    ('ridge', 0.1), ('ridge', 1.0), ('ridge', 5.0),
    ('rf', None)
]
extended_results = {}

for model_type, alpha in model_configs:
    print_progress(f"  🔧 测试模型: {model_type} (α={alpha})...")
    result = gpu_model_training_enhanced(Xe_train.values, Xe_test.values, y_train, y_test, 
                                       model_type=model_type, alpha=alpha, verbose=False)
    extended_results[f'{model_type}_{alpha}'] = result

# 选择最佳结果
best_config = max(extended_results.keys(), key=lambda k: extended_results[k]['r2'])
extended_metrics = extended_results[best_config]

print_progress(f"  ✅ 最佳模型配置: {best_config} (R² = {extended_metrics['r2']:.4f})")

print_progress(f"  ⏱️ 性能评估耗时: {time.time() - evaluation_start:.2f}秒")

# ======= Step 6: 结果保存 =======
print_progress("\n💾 Step 6: 结果保存")

results = {
    "step4_feature_preservation": {
        "data_info": {
            "samples": len(y),
            "original_features": int(extended.shape[1]),
            "cleaned_features": int(extended_clean.shape[1]),
            "enhanced_features": int(X_enhanced_tensor.shape[1]),
            "preserved_features": int(X_preserved_gpu.shape[1])
        },
        "model_performance": {
            "base_model": base_metrics,
            "extended_model": extended_metrics,
            "all_model_results": extended_results,
            "improvement": {
                "r2_improvement": float(extended_metrics['r2'] - base_metrics['r2']),
                "r2_improvement_percent": float((extended_metrics['r2'] - base_metrics['r2']) / abs(base_metrics['r2']) * 100),
                "mae_improvement": float(base_metrics['mae'] - extended_metrics['mae']),
                "rmse_improvement": float(base_metrics['rmse'] - extended_metrics['rmse'])
            }
        },
        "performance_info": {
            "total_runtime_seconds": time.time() - start_time,
            "data_loading_time": time.time() - start_time - (time.time() - preprocess_start),
            "preprocessing_time": time.time() - preprocess_start - (time.time() - engineering_start),
            "engineering_time": time.time() - engineering_start - (time.time() - optimization_start),
            "optimization_time": time.time() - optimization_start - (time.time() - evaluation_start),
            "evaluation_time": time.time() - evaluation_start
        },
        "gpu_info": {
            "cuda_available": torch.cuda.is_available(),
            "cuml_available": CUML_AVAILABLE,
            "gpu_device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
            "gpu_memory_gb": torch.cuda.get_device_properties(0).total_memory / 1024**3 if torch.cuda.is_available() else None,
            "gpu_memory_used_gb": torch.cuda.memory_allocated() / 1024**3 if torch.cuda.is_available() else 0
        }
    }
}

print_progress("  💾 正在保存结果...")
with open("step4_feature_preservation_results.json", "w") as f:
    json.dump(results, f, indent=4)

# ======= Step 7: 结果报告 =======
print_progress("\n📊 Step 7: 结果报告")
print("=" * 70)
print("Step 4: 特征保留优化结果")
print("=" * 70)
print(f"🔧 特征工程流程:")
print(f"  原始特征数: {extended.shape[1]}")
print(f"  清理后特征数: {extended_clean.shape[1]}")
print(f"  增强后特征数: {X_enhanced_tensor.shape[1]}")
print(f"  保留特征数: {X_preserved_gpu.shape[1]}")
print(f"\n📈 模型性能对比:")
print(f"  Base模型 R²: {base_metrics['r2']:.4f}")
print(f"  Extended模型 R²: {extended_metrics['r2']:.4f} ({best_config})")
print(f"  性能改善: {extended_metrics['r2'] - base_metrics['r2']:.4f} ({(extended_metrics['r2'] - base_metrics['r2']) / abs(base_metrics['r2']) * 100:.1f}%)")
print(f"  MAE改善: {base_metrics['mae'] - extended_metrics['mae']:.2f}")
print(f"  RMSE改善: {base_metrics['rmse'] - extended_metrics['rmse']:.2f}")
print(f"\n🔧 模型测试结果:")
for config, result in extended_results.items():
    print(f"  {config}: R² = {result['r2']:.4f}")
print(f"\n⏱️ 性能信息:")
print(f"  总运行时间: {time.time() - start_time:.2f}秒")
print(f"  GPU增强特征工程时间: {time.time() - engineering_start - (time.time() - optimization_start):.2f}秒")
print(f"  智能特征保留时间: {time.time() - optimization_start - (time.time() - evaluation_start):.2f}秒")
if torch.cuda.is_available():
    print(f"  GPU内存使用: {torch.cuda.memory_allocated() / 1024**3:.2f} GB")
print(f"\n✅ 结果文件:")
print(f"  step4_feature_preservation_results.json - 特征保留优化结果")
print("=" * 70)

# 目标达成检查
target_r2 = 0.7
target_features = 20
target_gpu_memory = 3.0

print(f"\n🎯 目标达成检查:")
print(f"  R² ≥ {target_r2}: {'✅' if extended_metrics['r2'] >= target_r2 else '❌'} ({extended_metrics['r2']:.4f})")
print(f"  特征数 {target_features}-25: {'✅' if target_features <= X_preserved_gpu.shape[1] <= 25 else '❌'} ({X_preserved_gpu.shape[1]})")
print(f"  GPU内存 ≥ {target_gpu_memory}GB: {'✅' if torch.cuda.memory_allocated() / 1024**3 >= target_gpu_memory else '❌'} ({torch.cuda.memory_allocated() / 1024**3:.2f}GB)")

print("🎉 Step 4: 特征保留优化完成！")
