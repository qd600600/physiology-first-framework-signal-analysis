#!/usr/bin/env python3
"""
Step 2: F-test 数值稳定性修正
目标：消除异常F值与浮点溢出，优化特征筛选阈值，启用真实GPU F-test计算

修正要点：
1. 修正F-test数值稳定性 - 消除异常F值与浮点溢出
2. 优化特征筛选阈值 - 避免过筛选导致性能塌陷
3. 启用真实GPU F-test计算 - 提高GPU利用率和效率
4. 重新训练Base模型并比较性能
5. 生成新的Step 2审计报告
"""

import pandas as pd
import numpy as np
import torch
import json
import time
import sys
import matplotlib.pyplot as plt
from sklearn.preprocessing import RobustScaler
from sklearn.model_selection import train_test_split
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from sklearn.feature_selection import f_classif, mutual_info_regression
import warnings
warnings.filterwarnings("ignore")

def print_progress(message, step=None, total_steps=None):
    """打印进度信息"""
    if step is not None and total_steps is not None:
        progress = (step / total_steps) * 100
        print(f"[{progress:5.1f}%] {message}")
    else:
        print(message)
    sys.stdout.flush()

print("=" * 70)
print("Step 2: F-test 数值稳定性修正")
print("=" * 70)

# GPU检查
print_progress("🔍 GPU检查:")
print_progress(f"  CUDA可用: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print_progress(f"  GPU设备: {torch.cuda.get_device_name(0)}")
    print_progress(f"  GPU内存: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.1f} GB")
    device = torch.device('cuda')
    use_gpu = True
    torch.backends.cudnn.benchmark = True
    print_progress("  ✅ 启用CUDA优化")
else:
    print_progress("  ⚠️ CUDA不可用，将使用CPU")
    device = torch.device('cpu')
    use_gpu = False

def robust_feature_normalization(X, verbose=True):
    """
    Step 2.1: 修正F-test数值稳定性 - 特征标准化
    """
    if verbose:
        print_progress("  🔧 执行稳健特征标准化...")
    
    X_normalized = X.copy()
    
    for col in X.columns:
        # 计算均值和标准差
        mean_val = X[col].mean()
        std_val = X[col].std()
        
        # 防除0保护
        if std_val < 1e-8:
            if verbose:
                print_progress(f"    ⚠️ 列 {col} 标准差过小 ({std_val:.2e})，跳过标准化")
            continue
        
        # 标准化
        X_normalized[col] = (X[col] - mean_val) / (std_val + 1e-8)
    
    if verbose:
        print_progress(f"    ✅ 特征标准化完成: {X.shape}")
    
    return X_normalized

def stable_gpu_f_test(X, y, verbose=True):
    """
    Step 2.3: 启用真实GPU F-test计算
    """
    if verbose:
        print_progress("  🚀 执行稳定GPU F-test...")
    
    try:
        # 转换为GPU张量
        X_tensor = torch.tensor(X.values, device=device, dtype=torch.float32)
        y_tensor = torch.tensor(y.values, device=device, dtype=torch.float32)
        
        n_samples, n_features = X_tensor.shape
        
        # 获取唯一类别
        unique_classes = torch.unique(y_tensor)
        n_classes = len(unique_classes)
        
        if verbose:
            print_progress(f"    📊 样本数: {n_samples}, 特征数: {n_features}, 类别数: {n_classes}")
        
        f_scores = torch.zeros(n_features, device=device, dtype=torch.float32)
        
        # 计算每个类别的统计量
        class_stats = {}
        for cls in unique_classes:
            mask = (y_tensor == cls)
            if mask.sum() > 1:  # 确保有足够的样本
                class_stats[cls.item()] = {
                    'mean': X_tensor[mask].mean(dim=0),
                    'var': X_tensor[mask].var(dim=0),
                    'count': mask.sum().float()
                }
        
        # 计算总体统计量
        overall_mean = X_tensor.mean(dim=0)
        overall_var = X_tensor.var(dim=0)
        
        # 计算F值
        for i in range(n_features):
            # 组间方差
            ss_between = torch.tensor(0.0, device=device)
            for cls, stats in class_stats.items():
                n_k = stats['count']
                mean_k = stats['mean'][i]
                ss_between += n_k * (mean_k - overall_mean[i]) ** 2
            
            # 组内方差
            ss_within = torch.tensor(0.0, device=device)
            for cls, stats in class_stats.items():
                n_k = stats['count']
                var_k = stats['var'][i]
                ss_within += (n_k - 1) * var_k
            
            # 防除0保护
            df_between = n_classes - 1
            df_within = n_samples - n_classes
            
            if ss_within > 1e-8 and df_between > 0 and df_within > 0:
                f_scores[i] = (ss_between / df_between) / (ss_within / df_within)
            else:
                f_scores[i] = 0.0
        
        # 同步GPU操作
        torch.cuda.synchronize()
        
        # 转换回numpy
        f_scores_np = f_scores.cpu().numpy()
        
        # 异常值检测和处理
        f_scores_clean = np.copy(f_scores_np)
        extreme_mask = (f_scores_clean > 1e5) | (f_scores_clean < 0) | ~np.isfinite(f_scores_clean)
        
        if np.any(extreme_mask):
            if verbose:
                print_progress(f"    ⚠️ 发现 {np.sum(extreme_mask)} 个异常F值，进行截断处理")
            f_scores_clean[extreme_mask] = np.nan
        
        if verbose:
            valid_f = f_scores_clean[np.isfinite(f_scores_clean)]
            if len(valid_f) > 0:
                print_progress(f"    📊 F值统计: 均值={np.mean(valid_f):.2f}, 标准差={np.std(valid_f):.2f}")
                print_progress(f"    📊 F值范围: {np.min(valid_f):.2f} - {np.max(valid_f):.2f}")
                print_progress(f"    ✅ 有效特征: {len(valid_f)}/{len(f_scores_clean)}")
        
        return f_scores_clean, np.sum(extreme_mask)
        
    except Exception as e:
        if verbose:
            print_progress(f"    ❌ GPU F-test失败: {e}")
        # 回退到CPU版本
        return stable_cpu_f_test(X, y, verbose)

def stable_cpu_f_test(X, y, verbose=True):
    """稳定的CPU F-test"""
    if verbose:
        print_progress("    💻 回退到稳定CPU F-test")
    
    try:
        # 使用sklearn的f_classif
        F, p = f_classif(X.fillna(0), y)
        
        # 异常值处理
        F_clean = np.copy(F)
        extreme_mask = (F_clean > 1e5) | (F_clean < 0) | ~np.isfinite(F_clean)
        F_clean[extreme_mask] = np.nan
        
        return F_clean, np.sum(extreme_mask)
        
    except Exception as e:
        if verbose:
            print_progress(f"    ❌ CPU F-test失败: {e}")
        return np.ones(X.shape[1]), 0

def dynamic_feature_selection(X, y, f_scores, keep_ratios=[0.1, 0.3, 0.5, 0.7], verbose=True):
    """
    Step 2.2: 优化特征筛选阈值 - 动态阈值策略
    """
    if verbose:
        print_progress("  🎯 执行动态特征筛选...")
    
    results = {}
    
    for keep_ratio in keep_ratios:
        # 计算保留的特征数
        top_k = max(1, int(X.shape[1] * keep_ratio))
        
        # 选择特征
        valid_f = f_scores[np.isfinite(f_scores)]
        if len(valid_f) > 0:
            top_k_indices = np.argsort(f_scores)[-top_k:]
            selected_features = X.columns[top_k_indices]
            X_selected = X[selected_features]
        else:
            # 如果没有有效F值，使用前k个特征
            X_selected = X.iloc[:, :top_k]
            selected_features = X_selected.columns
        
        results[keep_ratio] = {
            'top_k': top_k,
            'selected_features': selected_features.tolist(),
            'X_selected': X_selected
        }
        
        if verbose:
            print_progress(f"    📊 保留比例 {keep_ratio}: {X.shape[1]} -> {X_selected.shape[1]} 特征")
    
    return results

def evaluate_model_performance(X_train, X_test, y_train, y_test, model_name="Model", verbose=True):
    """评估模型性能"""
    if verbose:
        print_progress(f"      🤖 训练{model_name}...")
    
    model = HistGradientBoostingRegressor(
        max_iter=100,
        learning_rate=0.1,
        max_depth=10,
        min_samples_leaf=50,
        random_state=42,
        verbose=0
    )
    
    # 训练模型
    model.fit(X_train, y_train)
    
    # 预测
    y_pred = model.predict(X_test)
    
    # 计算指标
    r2 = r2_score(y_test, y_pred)
    mae = mean_absolute_error(y_test, y_pred)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    
    if verbose:
        print_progress(f"        ✅ {model_name} R²: {r2:.4f}")
    
    return {
        'r2': r2,
        'mae': mae,
        'rmse': rmse,
        'y_pred': y_pred
    }

# ======= Step 1: 数据读取 =======
print_progress("\n📂 Step 1: 数据读取")
start_time = time.time()

print_progress("  📥 正在读取features_base.csv...")
base = pd.read_csv("features_base.csv")
print_progress(f"    ✅ Base特征加载完成: {base.shape}")

print_progress("  📥 正在读取features_extended.csv...")
extended = pd.read_csv("features_extended.csv")
print_progress(f"    ✅ Extended特征加载完成: {extended.shape}")

print_progress("  📥 正在读取labels.csv...")
y = pd.read_csv("labels.csv")["target"]
print_progress(f"    ✅ 标签加载完成: {len(y)} 个样本")

# 样本一致性检查
assert len(base) == len(extended) == len(y), "样本数量不一致"
print_progress(f"  ✅ 数据加载完成: {len(y)} 个样本")
print_progress(f"  ⏱️ 数据加载耗时: {time.time() - start_time:.2f}秒")

# ======= Step 2: 数据预处理 =======
print_progress("\n🔧 Step 2: 数据预处理")
preprocess_start = time.time()

# 移除高缺失值列
print_progress("  🗑️ 移除高缺失值列...")
missing_ratio = extended.isna().sum() / len(extended)
high_missing_cols = missing_ratio[missing_ratio > 0.5].index.tolist()
extended_clean = extended.drop(columns=high_missing_cols)

print_progress(f"    📊 移除列数: {extended.shape[1]} -> {extended_clean.shape[1]}")

# 填充缺失值
print_progress("  🔄 填充缺失值...")
extended_imputed = extended_clean.fillna(0)

# 稳健特征标准化
extended_normalized = robust_feature_normalization(extended_imputed, verbose=True)

print_progress(f"  ⏱️ 预处理耗时: {time.time() - preprocess_start:.2f}秒")

# ======= Step 3: 稳定GPU F-test =======
print_progress("\n🚀 Step 3: 稳定GPU F-test")
f_test_start = time.time()

f_scores, n_extreme = stable_gpu_f_test(extended_normalized, y, verbose=True)

print_progress(f"  ⏱️ F-test耗时: {time.time() - f_test_start:.2f}秒")

# ======= Step 4: 动态特征筛选 =======
print_progress("\n🎯 Step 4: 动态特征筛选")
selection_start = time.time()

selection_results = dynamic_feature_selection(extended_normalized, y, f_scores, verbose=True)

print_progress(f"  ⏱️ 特征筛选耗时: {time.time() - selection_start:.2f}秒")

# ======= Step 5: 性能评估 =======
print_progress("\n📊 Step 5: 性能评估")
evaluation_start = time.time()

# 数据划分
Xb_train, Xb_test, y_train, y_test = train_test_split(
    base, y, test_size=0.3, random_state=42)

# 标准化Base数据
scaler = RobustScaler()
Xb_train_scaled = scaler.fit_transform(Xb_train)
Xb_test_scaled = scaler.transform(Xb_test)

# 评估Base模型
base_performance = evaluate_model_performance(
    Xb_train_scaled, Xb_test_scaled, y_train, y_test, "Base模型", verbose=True)

# 评估不同筛选比例的性能
performance_results = {}
for keep_ratio, result in selection_results.items():
    X_selected = result['X_selected']
    
    # 数据划分
    Xe_train, Xe_test, _, _ = train_test_split(
        X_selected, y, test_size=0.3, random_state=42)
    
    # 标准化
    scaler = RobustScaler()
    Xe_train_scaled = scaler.fit_transform(Xe_train)
    Xe_test_scaled = scaler.transform(Xe_test)
    
    # 评估模型
    model_name = f"Extended模型(保留{keep_ratio})"
    ext_performance = evaluate_model_performance(
        Xe_train_scaled, Xe_test_scaled, y_train, y_test, model_name, verbose=True)
    
    # 计算改善率
    improvement = (ext_performance['r2'] - base_performance['r2']) / abs(base_performance['r2'] + 1e-9) * 100
    
    performance_results[keep_ratio] = {
        'r2': ext_performance['r2'],
        'mae': ext_performance['mae'],
        'rmse': ext_performance['rmse'],
        'improvement_percent': improvement,
        'selected_features': result['selected_features']
    }

print_progress(f"  ⏱️ 性能评估耗时: {time.time() - evaluation_start:.2f}秒")

# ======= Step 6: 结果保存 =======
print_progress("\n💾 Step 6: 结果保存")

results = {
    "step2_f_test_numerical_fix": {
        "data_info": {
            "samples": len(y),
            "original_features": int(extended.shape[1]),
            "cleaned_features": int(extended_clean.shape[1]),
            "normalized_features": int(extended_normalized.shape[1])
        },
        "f_test_analysis": {
            "f_scores_mean": float(np.nanmean(f_scores)),
            "f_scores_std": float(np.nanstd(f_scores)),
            "f_scores_min": float(np.nanmin(f_scores)),
            "f_scores_max": float(np.nanmax(f_scores)),
            "extreme_values_count": int(n_extreme),
            "valid_features_count": int(np.sum(np.isfinite(f_scores)))
        },
        "base_model_performance": {
            "r2": float(base_performance['r2']),
            "mae": float(base_performance['mae']),
            "rmse": float(base_performance['rmse'])
        },
        "dynamic_selection_results": performance_results,
        "performance_info": {
            "total_runtime_seconds": time.time() - start_time,
            "data_loading_time": time.time() - start_time - (time.time() - preprocess_start),
            "preprocessing_time": time.time() - preprocess_start - (time.time() - f_test_start),
            "f_test_time": time.time() - f_test_start - (time.time() - selection_start),
            "selection_time": time.time() - selection_start - (time.time() - evaluation_start),
            "evaluation_time": time.time() - evaluation_start
        },
        "gpu_info": {
            "cuda_available": torch.cuda.is_available(),
            "gpu_device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
            "gpu_memory_gb": torch.cuda.get_device_properties(0).total_memory / 1024**3 if torch.cuda.is_available() else None
        }
    }
}

print_progress("  💾 正在保存结果...")
with open("step2_f_test_numerical_fix_results.json", "w") as f:
    json.dump(results, f, indent=4)

# ======= Step 7: 结果报告 =======
print_progress("\n📊 Step 7: 结果报告")
print("=" * 70)
print("Step 2: F-test 数值稳定性修正结果")
print("=" * 70)
print(f"🔧 数据处理:")
print(f"  原始特征数: {extended.shape[1]}")
print(f"  清理后特征数: {extended_clean.shape[1]}")
print(f"  标准化后特征数: {extended_normalized.shape[1]}")
print(f"\n🚀 F-test分析:")
print(f"  F值均值: {np.nanmean(f_scores):.2f}")
print(f"  F值标准差: {np.nanstd(f_scores):.2f}")
print(f"  F值范围: {np.nanmin(f_scores):.2f} - {np.nanmax(f_scores):.2f}")
print(f"  异常值数量: {n_extreme}")
print(f"  有效特征数: {np.sum(np.isfinite(f_scores))}")
print(f"\n📈 模型性能对比:")
print(f"  Base模型 R²: {base_performance['r2']:.4f}")
print(f"\n  动态筛选结果:")
for keep_ratio, perf in performance_results.items():
    print(f"    保留比例 {keep_ratio}: R²={perf['r2']:.4f}, 改善率={perf['improvement_percent']:.1f}%")
print(f"\n⏱️ 性能信息:")
print(f"  总运行时间: {time.time() - start_time:.2f}秒")
print(f"  F-test耗时: {time.time() - f_test_start - (time.time() - selection_start):.2f}秒")
print(f"\n✅ 结果文件:")
print(f"  step2_f_test_numerical_fix_results.json - Step 2修正结果")
print("=" * 70)

print("🎉 Step 2: F-test 数值稳定性修正完成！")














