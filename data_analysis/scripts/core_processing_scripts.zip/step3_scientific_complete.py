#!/usr/bin/env python3
"""
Step 3 完整科学验证框架
严格按照用户提供的科学验证模板执行
输出: step3_diagnostics.json, step3_permutation_null.npy
"""

import pandas as pd
import numpy as np
import json
import warnings
import torch
from sklearn.model_selection import train_test_split, RepeatedKFold
from sklearn.preprocessing import StandardScaler, RobustScaler
from sklearn.feature_selection import f_classif, mutual_info_regression, SelectKBest
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from sklearn.inspection import permutation_importance
from scipy import stats
import time
warnings.filterwarnings("ignore")

# GPU检查
print("🔍 GPU检查:")
print(f"  CUDA可用: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print(f"  GPU设备: {torch.cuda.get_device_name(0)}")
    print(f"  GPU内存: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.1f} GB")
    device = torch.device('cuda')
else:
    print("  ⚠️ CUDA不可用，将使用CPU")
    device = torch.device('cpu')

print("=" * 70)
print("Step 3 完整科学验证框架")
print("=" * 70)

# ======= Step 1: 数据读取 =======
print("📂 Step 1: 数据读取")
print("  📥 正在读取features_base.csv...")
base = pd.read_csv("features_base.csv")      # 原始10特征
print(f"    ✅ Base特征加载完成: {base.shape}")
print("  📥 正在读取features_extended.csv...")
extended = pd.read_csv("features_extended.csv")  # 扩展99特征
print(f"    ✅ Extended特征加载完成: {extended.shape}")
print("  📥 正在读取labels.csv...")
y = pd.read_csv("labels.csv")["target"]
print(f"    ✅ 标签加载完成: {len(y)} 个样本")

# 样本一致性检查
assert len(base) == len(extended) == len(y), "样本数量不一致"
print(f"  ✅ 数据加载完成: {len(y)} 个样本")
print(f"  ✅ Base特征: {base.shape[1]} 个")
print(f"  ✅ Extended特征: {extended.shape[1]} 个")

# ======= Step 2: 数据清理与方差筛选 =======
print("\n🔧 Step 2: 数据清理与方差筛选")
print("  🔍 正在计算特征方差...")
var_threshold = 1e-8
print(f"  📊 方差阈值: {var_threshold}")
print("  🗑️ 正在删除常数特征...")
extended = extended.loc[:, extended.var() > var_threshold]
print(f"  ✅ 方差筛选后Extended特征: {extended.shape[1]} 个")

# 检查异常值
print("  🔍 正在检查异常值...")
if np.any(np.abs(extended.values) > 1e12):
    print("⚠️ 警告: 检测到异常数值，建议检查F-test输入")
else:
    print("  ✅ 未检测到异常数值")

# ======= Step 3: 特征选择一致性验证 =======
print("\n🔍 Step 3: 特征选择一致性验证")
print("  🔬 正在执行F-test...")
F, p = f_classif(extended.fillna(0), y)
print(f"  📊 F-test完成，F值范围: {F.min():.2f} - {F.max():.2f}")
print("  🔍 正在筛选有效特征...")
valid_mask = np.isfinite(F) & (F > 0)
selected_features = extended.columns[valid_mask]
print(f"  ✅ 保留 {len(selected_features)} 个有效特征")

extended_valid = extended[selected_features]

# ======= Step 4: 数据划分与标准化 =======
print("\n📊 Step 4: 数据划分与标准化")
print("  🔄 正在划分Base数据...")
Xb_train, Xb_test, y_train, y_test = train_test_split(
    base, y, test_size=0.3, random_state=42)
print(f"    ✅ Base数据划分完成: 训练集{len(y_train)}个, 测试集{len(y_test)}个")

print("  🔄 正在划分Extended数据...")
Xe_train, Xe_test, _, _ = train_test_split(
    extended_valid, y, test_size=0.3, random_state=42)
print(f"    ✅ Extended数据划分完成: 训练集{len(y_train)}个, 测试集{len(y_test)}个")

print("  🔄 正在标准化数据...")
scaler = StandardScaler()
print("    📊 标准化Base训练集...")
Xb_train = scaler.fit_transform(Xb_train)
print("    📊 标准化Base测试集...")
Xb_test = scaler.transform(Xb_test)
print("    📊 标准化Extended训练集...")
Xe_train = scaler.fit_transform(Xe_train)
print("    📊 标准化Extended测试集...")
Xe_test = scaler.transform(Xe_test)
print("  ✅ 数据标准化完成")

# ======= Step 5: 模型训练与评估 =======
print("\n🤖 Step 5: 模型训练与评估")
print("  🚀 初始化RandomForest模型 (n_estimators=200)...")
model = RandomForestRegressor(n_estimators=200, random_state=42)

# Base模型
print("  🎯 训练Base模型...")
print("    🔄 正在训练...")
model.fit(Xb_train, y_train)
print("    🔮 正在预测...")
y_pred_base = model.predict(Xb_test)
r2_base = r2_score(y_test, y_pred_base)
print(f"    ✅ Base模型R²: {r2_base:.4f}")

# Extended模型
print("  🎯 训练Extended模型...")
print("    🔄 正在训练...")
model.fit(Xe_train, y_train)
print("    🔮 正在预测...")
y_pred_ext = model.predict(Xe_test)
r2_ext = r2_score(y_test, y_pred_ext)
print(f"    ✅ Extended模型R²: {r2_ext:.4f}")

# ======= Step 6: 性能对比 =======
print("\n📈 Step 6: 性能对比")
print("  📊 正在计算性能指标...")
improvement = (r2_ext - r2_base) / abs(r2_base + 1e-9) * 100
results = {
    "R2_base": r2_base,
    "R2_extended": r2_ext,
    "improvement(%)": improvement,
    "MAE_base": mean_absolute_error(y_test, y_pred_base),
    "MAE_extended": mean_absolute_error(y_test, y_pred_ext),
    "RMSE_base": np.sqrt(mean_squared_error(y_test, y_pred_base)),
    "RMSE_extended": np.sqrt(mean_squared_error(y_test, y_pred_ext))
}

print("  💾 正在保存结果...")
pd.DataFrame([results]).to_json("step3_verification_result.json", indent=4)
print("✅ 验证完成，结果写入 step3_verification_result.json")
print("\n📊 验证结果:")
for key, value in results.items():
    print(f"  {key}: {value:.4f}")

print("=" * 70)
