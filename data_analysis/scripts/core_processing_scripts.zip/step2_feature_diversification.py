#!/usr/bin/env python3
"""
Step 2: 特征类型多样化
目标：改善"特征类型单一"（仅非线性特征）的问题
具体方法：
1. 生理学特征再构造：添加如 HRV（心率变异性）、时域/频域指标模拟特征
2. 对连续变量计算：rolling_mean, fft_power等
3. 非线性组合增强：使用多项式扩展
"""

import pandas as pd
import numpy as np
import torch
import json
import time
import sys
from sklearn.preprocessing import StandardScaler, RobustScaler, PolynomialFeatures
from sklearn.model_selection import train_test_split
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from sklearn.feature_selection import f_classif
import warnings
warnings.filterwarnings("ignore")

def print_progress(message, step=None, total_steps=None):
    """打印进度信息"""
    if step is not None and total_steps is not None:
        progress = (step / total_steps) * 100
        print(f"[{progress:5.1f}%] {message}")
    else:
        print(message)
    sys.stdout.flush()

print("=" * 70)
print("Step 2: 特征类型多样化")
print("=" * 70)

# GPU检查
print_progress("🔍 GPU检查:")
print_progress(f"  CUDA可用: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print_progress(f"  GPU设备: {torch.cuda.get_device_name(0)}")
    print_progress(f"  GPU内存: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.1f} GB")
    device = torch.device('cuda')
    use_gpu = True
else:
    print_progress("  ⚠️ CUDA不可用，将使用CPU")
    device = torch.device('cpu')
    use_gpu = False

def create_hrv_features(df, verbose=True):
    """
    创建HRV（心率变异性）特征
    """
    if verbose:
        print_progress("  💓 创建HRV特征...")
    
    df_hrv = df.copy()
    
    # 查找心率相关列
    hr_cols = [col for col in df.columns if any(keyword in col.lower() for keyword in ['hr', 'heart', 'ibi', 'bpm'])]
    
    if not hr_cols:
        if verbose:
            print_progress("    ⚠️ 未找到心率相关列")
        return df_hrv
    
    if verbose:
        print_progress(f"    📊 找到心率相关列: {hr_cols}")
    
    for col in hr_cols:
        if col in df.columns:
            # 时域特征
            df_hrv[f'{col}_mean'] = df[col].rolling(window=5, min_periods=1).mean()
            df_hrv[f'{col}_std'] = df[col].rolling(window=5, min_periods=1).std()
            df_hrv[f'{col}_var'] = df[col].rolling(window=5, min_periods=1).var()
            df_hrv[f'{col}_min'] = df[col].rolling(window=5, min_periods=1).min()
            df_hrv[f'{col}_max'] = df[col].rolling(window=5, min_periods=1).max()
            df_hrv[f'{col}_range'] = df_hrv[f'{col}_max'] - df_hrv[f'{col}_min']
            
            # 频域特征（简化版）
            df_hrv[f'{col}_fft_power'] = np.abs(np.fft.fft(df[col].fillna(0)))[:len(df)]
            df_hrv[f'{col}_fft_power'] = df_hrv[f'{col}_fft_power'].fillna(0)
    
    if verbose:
        print_progress(f"    ✅ HRV特征创建完成: {df.shape[1]} -> {df_hrv.shape[1]} 特征")
    
    return df_hrv

def create_temporal_features(df, verbose=True):
    """
    创建时域特征
    """
    if verbose:
        print_progress("  ⏰ 创建时域特征...")
    
    df_temporal = df.copy()
    
    # 对数值列创建时域特征
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    
    for col in numeric_cols[:10]:  # 限制列数避免内存问题
        if col in df.columns:
            # 滚动统计特征
            df_temporal[f'{col}_rolling_mean_5'] = df[col].rolling(window=5, min_periods=1).mean()
            df_temporal[f'{col}_rolling_std_5'] = df[col].rolling(window=5, min_periods=1).std()
            df_temporal[f'{col}_rolling_mean_10'] = df[col].rolling(window=10, min_periods=1).mean()
            df_temporal[f'{col}_rolling_std_10'] = df[col].rolling(window=10, min_periods=1).std()
            
            # 差分特征
            df_temporal[f'{col}_diff'] = df[col].diff()
            df_temporal[f'{col}_diff2'] = df[col].diff().diff()
            
            # 百分比变化
            df_temporal[f'{col}_pct_change'] = df[col].pct_change()
    
    if verbose:
        print_progress(f"    ✅ 时域特征创建完成: {df.shape[1]} -> {df_temporal.shape[1]} 特征")
    
    return df_temporal

def create_frequency_features(df, verbose=True):
    """
    创建频域特征
    """
    if verbose:
        print_progress("  📡 创建频域特征...")
    
    df_freq = df.copy()
    
    # 对数值列创建频域特征
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    
    for col in numeric_cols[:5]:  # 限制列数避免内存问题
        if col in df.columns:
            # FFT功率谱特征
            try:
                fft_values = np.fft.fft(df[col].fillna(0))
                df_freq[f'{col}_fft_power'] = np.abs(fft_values)[:len(df)]
                df_freq[f'{col}_fft_real'] = np.real(fft_values)[:len(df)]
                df_freq[f'{col}_fft_imag'] = np.imag(fft_values)[:len(df)]
            except:
                df_freq[f'{col}_fft_power'] = 0
                df_freq[f'{col}_fft_real'] = 0
                df_freq[f'{col}_fft_imag'] = 0
    
    if verbose:
        print_progress(f"    ✅ 频域特征创建完成: {df.shape[1]} -> {df_freq.shape[1]} 特征")
    
    return df_freq

def create_polynomial_features(df, degree=2, interaction_only=True, verbose=True):
    """
    创建多项式特征
    """
    if verbose:
        print_progress("  🔢 创建多项式特征...")
    
    # 选择数值列
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    
    if len(numeric_cols) > 10:
        # 如果列太多，只选择前10列
        numeric_cols = numeric_cols[:10]
        if verbose:
            print_progress(f"    📊 选择前10个数值列: {list(numeric_cols)}")
    
    # 准备数据
    X_numeric = df[numeric_cols].fillna(0)
    
    # 创建多项式特征
    poly = PolynomialFeatures(degree=degree, interaction_only=interaction_only, include_bias=False)
    
    try:
        X_poly = poly.fit_transform(X_numeric)
        
        # 创建特征名称
        feature_names = poly.get_feature_names_out(numeric_cols)
        
        # 创建DataFrame
        df_poly = pd.DataFrame(X_poly, columns=feature_names, index=df.index)
        
        # 合并原始数据
        df_combined = pd.concat([df, df_poly], axis=1)
        
        if verbose:
            print_progress(f"    ✅ 多项式特征创建完成: {df.shape[1]} -> {df_combined.shape[1]} 特征")
        
        return df_combined
        
    except Exception as e:
        if verbose:
            print_progress(f"    ⚠️ 多项式特征创建失败: {e}")
        return df

def create_interaction_features(df, verbose=True):
    """
    创建交互特征
    """
    if verbose:
        print_progress("  🔗 创建交互特征...")
    
    df_interaction = df.copy()
    
    # 选择数值列
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    
    if len(numeric_cols) > 5:
        # 如果列太多，只选择前5列
        numeric_cols = numeric_cols[:5]
    
    # 创建两两交互特征
    for i, col1 in enumerate(numeric_cols):
        for j, col2 in enumerate(numeric_cols[i+1:], i+1):
            if col1 != col2:
                df_interaction[f'{col1}_x_{col2}'] = df[col1] * df[col2]
                df_interaction[f'{col1}_div_{col2}'] = df[col1] / (df[col2] + 1e-8)
    
    if verbose:
        print_progress(f"    ✅ 交互特征创建完成: {df.shape[1]} -> {df_interaction.shape[1]} 特征")
    
    return df_interaction

def diversify_features(df, verbose=True):
    """
    特征多样化主函数
    """
    if verbose:
        print_progress("🎨 开始特征多样化...")
    
    original_shape = df.shape
    
    # Step 1: 创建HRV特征
    df = create_hrv_features(df, verbose=verbose)
    
    # Step 2: 创建时域特征
    df = create_temporal_features(df, verbose=verbose)
    
    # Step 3: 创建频域特征
    df = create_frequency_features(df, verbose=verbose)
    
    # Step 4: 创建交互特征
    df = create_interaction_features(df, verbose=verbose)
    
    # Step 5: 创建多项式特征
    df = create_polynomial_features(df, degree=2, interaction_only=True, verbose=verbose)
    
    if verbose:
        print_progress(f"🎉 特征多样化完成: {original_shape[1]} -> {df.shape[1]} 特征")
        print_progress(f"📊 特征扩展比例: {df.shape[1]/original_shape[1]:.1f}x")
    
    return df

# ======= Step 1: 数据读取 =======
print_progress("\n📂 Step 1: 数据读取")
start_time = time.time()

print_progress("  📥 正在读取features_base.csv...")
base = pd.read_csv("features_base.csv")
print_progress(f"    ✅ Base特征加载完成: {base.shape}")

print_progress("  📥 正在读取features_extended.csv...")
extended = pd.read_csv("features_extended.csv")
print_progress(f"    ✅ Extended特征加载完成: {extended.shape}")

print_progress("  📥 正在读取labels.csv...")
y = pd.read_csv("labels.csv")["target"]
print_progress(f"    ✅ 标签加载完成: {len(y)} 个样本")

# 样本一致性检查
assert len(base) == len(extended) == len(y), "样本数量不一致"
print_progress(f"  ✅ 数据加载完成: {len(y)} 个样本")
print_progress(f"  ⏱️ 数据加载耗时: {time.time() - start_time:.2f}秒")

# ======= Step 2: 特征多样化 =======
print_progress("\n🎨 Step 2: 特征多样化")
diversification_start = time.time()

# 2.1 对Base特征进行多样化
print_progress("  🎯 对Base特征进行多样化...")
base_diversified = diversify_features(base, verbose=True)

# 2.2 对Extended特征进行多样化
print_progress("  🎯 对Extended特征进行多样化...")
extended_diversified = diversify_features(extended, verbose=True)

print_progress(f"  ⏱️ 特征多样化耗时: {time.time() - diversification_start:.2f}秒")

# ======= Step 3: 特征选择 =======
print_progress("\n🔍 Step 3: 特征选择")
selection_start = time.time()

# 3.1 选择Base特征（前20个）
print_progress("  🎯 选择Base特征...")
base_selected = base_diversified.iloc[:, :min(20, base_diversified.shape[1])]

# 3.2 选择Extended特征（前30个）
print_progress("  🎯 选择Extended特征...")
extended_selected = extended_diversified.iloc[:, :min(30, extended_diversified.shape[1])]

print_progress(f"  ✅ 特征选择完成: Base {base_selected.shape[1]} 特征, Extended {extended_selected.shape[1]} 特征")
print_progress(f"  ⏱️ 特征选择耗时: {time.time() - selection_start:.2f}秒")

# ======= Step 4: 数据划分与标准化 =======
print_progress("\n📊 Step 4: 数据划分与标准化")
preprocess_start = time.time()

print_progress("  🔄 正在划分数据...")
Xb_train, Xb_test, y_train, y_test = train_test_split(
    base_selected, y, test_size=0.3, random_state=42)
Xe_train, Xe_test, _, _ = train_test_split(
    extended_selected, y, test_size=0.3, random_state=42)
print_progress(f"  ✅ 数据划分完成: 训练集{len(y_train)}个, 测试集{len(y_test)}个")

print_progress("  🔄 正在标准化数据...")
scaler = RobustScaler()
Xb_train_scaled = scaler.fit_transform(Xb_train)
Xb_test_scaled = scaler.transform(Xb_test)
Xe_train_scaled = scaler.fit_transform(Xe_train)
Xe_test_scaled = scaler.transform(Xe_test)
print_progress("  ✅ 数据标准化完成")

print_progress(f"  ⏱️ 预处理耗时: {time.time() - preprocess_start:.2f}秒")

# ======= Step 5: 模型训练与评估 =======
print_progress("\n🤖 Step 5: 模型训练与评估")
model_start = time.time()

print_progress("  🚀 初始化模型...")
model = HistGradientBoostingRegressor(
    max_iter=100,
    learning_rate=0.1,
    max_depth=10,
    min_samples_leaf=50,
    random_state=42,
    verbose=0
)

# Base模型
print_progress("  🎯 训练Base模型...")
model.fit(Xb_train_scaled, y_train)
y_pred_base = model.predict(Xb_test_scaled)
r2_base = r2_score(y_test, y_pred_base)
print_progress(f"    ✅ Base模型R²: {r2_base:.4f}")

# Extended模型
print_progress("  🎯 训练Extended模型...")
model.fit(Xe_train_scaled, y_train)
y_pred_ext = model.predict(Xe_test_scaled)
r2_ext = r2_score(y_test, y_pred_ext)
print_progress(f"    ✅ Extended模型R²: {r2_ext:.4f}")

print_progress(f"  ⏱️ 模型训练耗时: {time.time() - model_start:.2f}秒")

# ======= Step 6: 结果保存 =======
print_progress("\n💾 Step 6: 结果保存")

improvement = (r2_ext - r2_base) / abs(r2_base + 1e-9) * 100
results = {
    "step2_feature_diversification": {
        "feature_diversification": {
            "original_base_features": int(base.shape[1]),
            "diversified_base_features": int(base_diversified.shape[1]),
            "base_expansion_ratio": float(base_diversified.shape[1] / base.shape[1]),
            "original_extended_features": int(extended.shape[1]),
            "diversified_extended_features": int(extended_diversified.shape[1]),
            "extended_expansion_ratio": float(extended_diversified.shape[1] / extended.shape[1]),
            "final_base_features": int(base_selected.shape[1]),
            "final_extended_features": int(extended_selected.shape[1])
        },
        "model_performance": {
            "R2_base": float(r2_base),
            "R2_extended": float(r2_ext),
            "improvement_abs": float(r2_ext - r2_base),
            "improvement_percent": float(improvement),
            "MAE_base": float(mean_absolute_error(y_test, y_pred_base)),
            "MAE_extended": float(mean_absolute_error(y_test, y_pred_ext)),
            "RMSE_base": float(np.sqrt(mean_squared_error(y_test, y_pred_base))),
            "RMSE_extended": float(np.sqrt(mean_squared_error(y_test, y_pred_ext)))
        },
        "performance_info": {
            "total_runtime_seconds": time.time() - start_time,
            "data_loading_time": time.time() - start_time - (time.time() - diversification_start),
            "diversification_time": time.time() - diversification_start - (time.time() - selection_start),
            "selection_time": time.time() - selection_start - (time.time() - preprocess_start),
            "preprocessing_time": time.time() - preprocess_start - (time.time() - model_start),
            "model_training_time": time.time() - model_start
        },
        "gpu_info": {
            "cuda_available": torch.cuda.is_available(),
            "gpu_device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
            "gpu_memory_gb": torch.cuda.get_device_properties(0).total_memory / 1024**3 if torch.cuda.is_available() else None
        }
    }
}

print_progress("  💾 正在保存结果...")
with open("step2_feature_diversification_results.json", "w") as f:
    json.dump(results, f, indent=4)

# ======= Step 7: 结果报告 =======
print_progress("\n📊 Step 7: 结果报告")
print("=" * 70)
print("Step 2: 特征类型多样化结果")
print("=" * 70)
print(f"🎨 特征多样化效果:")
print(f"  Base特征扩展: {base.shape[1]} -> {base_diversified.shape[1]} ({base_diversified.shape[1]/base.shape[1]:.1f}x)")
print(f"  Extended特征扩展: {extended.shape[1]} -> {extended_diversified.shape[1]} ({extended_diversified.shape[1]/extended.shape[1]:.1f}x)")
print(f"  最终特征数: Base {base_selected.shape[1]}, Extended {extended_selected.shape[1]}")
print(f"\n📈 模型性能:")
print(f"  Base模型 R²: {r2_base:.4f}")
print(f"  Extended模型 R²: {r2_ext:.4f}")
print(f"  性能提升: {r2_ext - r2_base:.4f} ({improvement:.2f}%)")
print(f"\n⏱️ 性能信息:")
print(f"  总运行时间: {time.time() - start_time:.2f}秒")
print(f"  特征多样化时间: {time.time() - diversification_start - (time.time() - selection_start):.2f}秒")
print(f"\n✅ 结果文件:")
print(f"  step2_feature_diversification_results.json - 特征多样化结果")
print("=" * 70)

print("🎉 Step 2: 特征类型多样化完成！")








