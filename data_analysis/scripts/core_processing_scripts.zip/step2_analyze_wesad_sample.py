#!/usr/bin/env python3
"""
Step 2: Analyze WESAD Dataset Sample Files
"""

import pandas as pd
import numpy as np
from pathlib import Path

def analyze_wesad_files():
    """Analyze WESAD sample files."""
    print("Analyzing WESAD Dataset Sample Files")
    print("="*60)
    
    # Sample subject path
    sample_subject = 'S2'
    sample_path = Path(f'data/WESAD/raw/{sample_subject}/{sample_subject}_E4_Data')
    
    if not sample_path.exists():
        print(f"❌ Sample path does not exist: {sample_path}")
        return None
    
    results = {}
    
    # Define sensor files to analyze
    sensor_files = {
        'ACC.csv': ['timestamp', 'acc_x', 'acc_y', 'acc_z'],
        'BVP.csv': ['bvp'],
        'EDA.csv': ['eda'],
        'HR.csv': ['hr'],
        'IBI.csv': ['timestamp', 'ibi'],
        'TEMP.csv': ['temp']
    }
    
    for sensor_file, expected_columns in sensor_files.items():
        file_path = sample_path / sensor_file
        
        print(f"\nAnalyzing: {sensor_file}")
        print("-" * 40)
        
        if not file_path.exists():
            print(f"❌ File does not exist: {file_path}")
            continue
        
        try:
            # Read the file
            df = pd.read_csv(file_path, header=None)
            print(f"✅ Successfully read file")
            print(f"📊 Shape: {df.shape[0]} rows, {df.shape[1]} columns")
            print(f"📋 Actual columns: {df.shape[1]}, Expected: {len(expected_columns)}")
            
            # Assign column names
            if df.shape[1] == len(expected_columns):
                df.columns = expected_columns
                print(f"✅ Column names assigned: {list(df.columns)}")
            else:
                print(f"⚠️ Column count mismatch - using generic names")
                df.columns = [f'col_{i}' for i in range(df.shape[1])]
            
            # Show data types
            print(f"🔍 Data types:")
            for col, dtype in df.dtypes.items():
                print(f"   - {col}: {dtype}")
            
            # Show first few rows
            print(f"📄 First 3 rows:")
            for i, row in df.head(3).iterrows():
                print(f"   Row {i}: {dict(row)}")
            
            # Check for missing data
            missing = df.isnull().sum()
            missing_found = False
            for col, count in missing.items():
                if count > 0:
                    missing_found = True
                    pct = (count / len(df)) * 100
                    print(f"⚠️ {col}: {count} missing ({pct:.1f}%)")
            if not missing_found:
                print("   ✅ No missing data")
            
            # Basic statistics for numeric columns
            numeric_cols = df.select_dtypes(include=[np.number]).columns
            if len(numeric_cols) > 0:
                print(f"📈 Numeric statistics:")
                stats = df[numeric_cols].describe()
                print(f"   Mean values: {dict(stats.loc['mean'])}")
                print(f"   Std values: {dict(stats.loc['std'])}")
            
            # Store results
            results[sensor_file] = {
                'shape': df.shape,
                'columns': list(df.columns),
                'dtypes': dict(df.dtypes),
                'missing_data': dict(missing),
                'numeric_stats': dict(stats.loc['mean']) if len(numeric_cols) > 0 else {},
                'sample_data': df.head(3).to_dict('records')
            }
            
        except Exception as e:
            print(f"❌ Error reading {sensor_file}: {e}")
            results[sensor_file] = {'error': str(e)}
    
    # Analyze questionnaire file
    quest_file = Path(f'data/WESAD/raw/{sample_subject}/{sample_subject}_quest.csv')
    print(f"\nAnalyzing: {sample_subject}_quest.csv")
    print("-" * 40)
    
    if quest_file.exists():
        try:
            quest_df = pd.read_csv(quest_file)
            print(f"✅ Questionnaire data loaded")
            print(f"📊 Shape: {quest_df.shape[0]} rows, {quest_df.shape[1]} columns")
            print(f"📋 Columns: {list(quest_df.columns)}")
            print(f"📄 First 3 rows:")
            print(quest_df.head(3).to_string())
            
            results[f'{sample_subject}_quest.csv'] = {
                'shape': quest_df.shape,
                'columns': list(quest_df.columns),
                'sample_data': quest_df.head(3).to_dict('records')
            }
        except Exception as e:
            print(f"❌ Error reading questionnaire: {e}")
            results[f'{sample_subject}_quest.csv'] = {'error': str(e)}
    else:
        print(f"❌ Questionnaire file not found")
    
    # Summary
    print(f"\n{'='*60}")
    print("WESAD SAMPLE ANALYSIS SUMMARY")
    print(f"{'='*60}")
    
    successful_files = [k for k, v in results.items() if 'error' not in v]
    failed_files = [k for k, v in results.items() if 'error' in v]
    
    print(f"✅ Successfully analyzed: {len(successful_files)} files")
    for file in successful_files:
        if 'shape' in results[file]:
            print(f"   - {file}: {results[file]['shape']}")
    
    if failed_files:
        print(f"❌ Failed to analyze: {len(failed_files)} files")
        for file in failed_files:
            print(f"   - {file}: {results[file]['error']}")
    
    return results

if __name__ == "__main__":
    results = analyze_wesad_files()
    
    if results:
        print(f"\n✅ WESAD sample analysis completed")
        print(f"Analyzed {len([k for k, v in results.items() if 'error' not in v])} files successfully")
    else:
        print(f"\n❌ WESAD analysis failed")











