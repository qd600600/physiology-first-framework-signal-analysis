#!/usr/bin/env python3
"""
Step 3: 科学验证版本
Scientific Verification for Step 3

目标：基于客观数据，进行科学严谨的特征工程验证
"""

import os
import sys
import logging
import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor
from sklearn.feature_selection import SelectKBest, f_regression
import json

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def load_dataset_data(dataset_name: str, window_size: str) -> pd.DataFrame:
    """加载数据集数据."""
    try:
        file_paths = [
            f"/mnt/d/data_analysis/processed/lri_calculation/lri_{dataset_name}_{window_size}_clean.csv",
            f"/mnt/d/data_analysis/processed/lri_calculation/lri_{dataset_name}_{window_size}_fixed.csv",
            f"/mnt/d/data_analysis/processed/lri_calculation/lri_{dataset_name}_{window_size}_fixed_v2.csv",
            f"/mnt/d/data_analysis/processed/lri_calculation/lri_{dataset_name}_{window_size}.csv"
        ]
        
        for path in file_paths:
            if os.path.exists(path):
                df = pd.read_csv(path)
                if not df.empty:
                    logger.info(f"Loaded {dataset_name}_{window_size}: {df.shape}")
                    return df
        
        logger.warning(f"No data file found for {dataset_name}_{window_size}")
        return pd.DataFrame()
        
    except Exception as e:
        logger.error(f"Error loading {dataset_name}_{window_size}: {e}")
        return pd.DataFrame()

def create_scientific_features(df: pd.DataFrame) -> pd.DataFrame:
    """创建科学的特征工程."""
    try:
        enhanced_df = df.copy()
        numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        
        if len(numeric_cols) < 2:
            return df.copy()
        
        # 1. 基础统计特征
        for col in numeric_cols:
            if df[col].notna().sum() > 5:
                series = df[col].dropna()
                
                enhanced_df[f'{col}_mean'] = series.mean()
                enhanced_df[f'{col}_std'] = series.std()
                enhanced_df[f'{col}_median'] = series.median()
                enhanced_df[f'{col}_range'] = series.max() - series.min()
                enhanced_df[f'{col}_q25'] = series.quantile(0.25)
                enhanced_df[f'{col}_q75'] = series.quantile(0.75)
        
        # 2. 多项式特征（只对重要特征）
        important_cols = numeric_cols[:3]  # 只选择前3个重要特征
        for col in important_cols:
            if col in df.columns:
                enhanced_df[f'{col}_squared'] = df[col] ** 2
                enhanced_df[f'{col}_sqrt'] = np.sqrt(np.abs(df[col]) + 1e-8)
        
        # 3. 交互特征（只对重要特征）
        if len(important_cols) >= 2:
            col1, col2 = important_cols[0], important_cols[1]
            if col1 in df.columns and col2 in df.columns:
                enhanced_df[f'{col1}_x_{col2}'] = df[col1] * df[col2]
                enhanced_df[f'{col1}_div_{col2}'] = df[col1] / (df[col2] + 1e-8)
        
        # 4. 生理学特征（基于现有特征模拟）
        if 'wt_mean' in df.columns and 'wt_std' in df.columns:
            # 心率变异性特征
            enhanced_df['hrv_ratio'] = df['wt_std'] / (df['wt_mean'] + 1e-8)
            enhanced_df['hrv_stability'] = 1 / (df['wt_std'] + 1e-8)
        
        if 'stress_intensity' in df.columns and 'stress_volatility' in df.columns:
            # 压力特征
            enhanced_df['stress_ratio'] = df['stress_intensity'] / (df['stress_volatility'] + 1e-8)
            enhanced_df['stress_normalized'] = (df['stress_intensity'] - df['stress_intensity'].mean()) / (df['stress_intensity'].std() + 1e-8)
        
        return enhanced_df
        
    except Exception as e:
        logger.error(f"Error creating features: {e}")
        return df.copy()

def scientific_feature_selection(X: pd.DataFrame, y: pd.Series, max_features: int = 20) -> pd.DataFrame:
    """科学的特征选择."""
    try:
        if X.empty or len(X) < 10:
            return X
        
        # 1. 移除常数列
        X_clean = X.loc[:, (X != X.iloc[0]).any()]
        
        if X_clean.empty:
            return X
        
        # 2. 移除高相关性特征
        corr_matrix = X_clean.corr().abs()
        upper_tri = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))
        high_corr_features = [column for column in upper_tri.columns if any(upper_tri[column] > 0.95)]
        X_low_corr = X_clean.drop(columns=high_corr_features)
        
        # 3. 基于F-test的特征选择
        if X_low_corr.shape[1] > max_features:
            selector = SelectKBest(score_func=f_regression, k=max_features)
            X_selected = pd.DataFrame(
                selector.fit_transform(X_low_corr, y),
                columns=X_low_corr.columns[selector.get_support()],
                index=X_low_corr.index
            )
        else:
            X_selected = X_low_corr
        
        logger.info(f"Feature selection: {X_clean.shape[1]} -> {X_selected.shape[1]} features")
        return X_selected
        
    except Exception as e:
        logger.error(f"Error in feature selection: {e}")
        return X

def evaluate_model_performance(X_original: pd.DataFrame, X_enhanced: pd.DataFrame, y: pd.Series) -> dict:
    """评估模型性能."""
    try:
        if X_original.empty or X_enhanced.empty or len(X_original) < 10:
            return {'improvement': 0.0, 'significant': False}
        
        # 确保数据一致性
        min_samples = min(len(X_original), len(X_enhanced), len(y))
        X_original = X_original.iloc[:min_samples]
        X_enhanced = X_enhanced.iloc[:min_samples]
        y = y.iloc[:min_samples]
        
        # 数据分割
        test_size = min(0.3, max(0.2, 20/len(X_original)))
        X_orig_train, X_orig_test, y_train, y_test = train_test_split(
            X_original, y, test_size=test_size, random_state=42
        )
        X_enh_train, X_enh_test, _, _ = train_test_split(
            X_enhanced, y, test_size=test_size, random_state=42
        )
        
        # 标准化
        scaler_orig = StandardScaler()
        scaler_enh = StandardScaler()
        
        X_orig_train_scaled = scaler_orig.fit_transform(X_orig_train)
        X_orig_test_scaled = scaler_orig.transform(X_orig_test)
        X_enh_train_scaled = scaler_enh.fit_transform(X_enh_train)
        X_enh_test_scaled = scaler_enh.transform(X_enh_test)
        
        # 模型评估
        models = {
            'Ridge': Ridge(alpha=1.0, random_state=42),
            'RandomForest': RandomForestRegressor(n_estimators=50, random_state=42)
        }
        
        results = {}
        
        for model_name, model in models.items():
            try:
                # 原始特征
                model_orig = model.__class__(**model.get_params())
                model_orig.fit(X_orig_train_scaled, y_train)
                y_pred_orig = model_orig.predict(X_orig_test_scaled)
                orig_r2 = r2_score(y_test, y_pred_orig)
                orig_rmse = np.sqrt(mean_squared_error(y_test, y_pred_orig))
                
                # 增强特征
                model_enh = model.__class__(**model.get_params())
                model_enh.fit(X_enh_train_scaled, y_train)
                y_pred_enh = model_enh.predict(X_enh_test_scaled)
                enh_r2 = r2_score(y_test, y_pred_enh)
                enh_rmse = np.sqrt(mean_squared_error(y_test, y_pred_enh))
                
                # 计算改善
                r2_improvement = (enh_r2 - orig_r2) / orig_r2 * 100 if orig_r2 != 0 else 0
                rmse_improvement = (orig_rmse - enh_rmse) / orig_rmse * 100 if orig_rmse != 0 else 0
                
                results[model_name] = {
                    'original_r2': orig_r2,
                    'enhanced_r2': enh_r2,
                    'r2_improvement': r2_improvement,
                    'original_rmse': orig_rmse,
                    'enhanced_rmse': enh_rmse,
                    'rmse_improvement': rmse_improvement,
                    'overall_improvement': (r2_improvement + rmse_improvement) / 2
                }
                
            except Exception as e:
                logger.warning(f"Error with {model_name}: {e}")
                continue
        
        # 计算平均改善
        if results:
            avg_improvement = np.mean([r['overall_improvement'] for r in results.values()])
            significant = avg_improvement > 1.0  # 改善超过1%认为显著
            
            return {
                'improvement': avg_improvement,
                'significant': significant,
                'results': results,
                'n_tests': len(results)
            }
        else:
            return {'improvement': 0.0, 'significant': False}
            
    except Exception as e:
        logger.error(f"Error evaluating performance: {e}")
        return {'improvement': 0.0, 'significant': False}

def run_step3_scientific_verification():
    """运行Step 3科学验证."""
    try:
        logger.info("Starting Step 3 Scientific Verification")
        
        datasets = ['DRIVE_DB', 'CRWD', 'SWELL', 'WESAD']
        window_sizes = ['60s', '300s']
        
        all_results = []
        successful_count = 0
        total_count = 0
        
        for dataset in datasets:
            for window_size in window_sizes:
                logger.info(f"Verifying {dataset}_{window_size}")
                
                # 加载数据
                df = load_dataset_data(dataset, window_size)
                if df.empty:
                    continue
                
                # 准备原始特征
                numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
                if len(numeric_cols) < 2:
                    continue
                
                X_original = df[numeric_cols[:-1]].fillna(0)
                y = df[numeric_cols[-1]].fillna(0)
                
                if len(X_original) < 10:
                    continue
                
                # 创建增强特征
                df_enhanced = create_scientific_features(df)
                enhanced_numeric_cols = df_enhanced.select_dtypes(include=[np.number]).columns.tolist()
                X_enhanced = df_enhanced[enhanced_numeric_cols[:-1]].fillna(0)
                
                # 特征选择
                X_enhanced_selected = scientific_feature_selection(X_enhanced, y)
                
                # 评估性能
                evaluation_result = evaluate_model_performance(X_original, X_enhanced_selected, y)
                
                # 记录结果
                result = {
                    'dataset': f"{dataset}_{window_size}",
                    'original_features': X_original.shape[1],
                    'enhanced_features': X_enhanced_selected.shape[1],
                    'feature_expansion_ratio': X_enhanced_selected.shape[1] / X_original.shape[1],
                    'improvement': evaluation_result.get('improvement', 0),
                    'significant': evaluation_result.get('significant', False),
                    'n_tests': evaluation_result.get('n_tests', 0)
                }
                
                all_results.append(result)
                total_count += 1
                
                if evaluation_result.get('significant', False):
                    successful_count += 1
                
                logger.info(f"{dataset}_{window_size}: {X_original.shape[1]} -> {X_enhanced_selected.shape[1]} features, "
                          f"Improvement: {evaluation_result.get('improvement', 0):.4f}%, "
                          f"Significant: {evaluation_result.get('significant', False)}")
        
        # 计算总体结果
        success_rate = successful_count / total_count * 100 if total_count > 0 else 0
        avg_improvement = np.mean([r['improvement'] for r in all_results]) if all_results else 0
        avg_expansion = np.mean([r['feature_expansion_ratio'] for r in all_results]) if all_results else 0
        
        # 保存结果
        results = {
            'timestamp': datetime.now().isoformat(),
            'verification_method': 'Scientific Verification',
            'total_datasets': total_count,
            'successful_datasets': successful_count,
            'success_rate': success_rate,
            'average_improvement': avg_improvement,
            'average_expansion_ratio': avg_expansion,
            'all_results': all_results
        }
        
        output_dir = Path("reports/scientific_audit/step3_scientific_verification")
        output_dir.mkdir(parents=True, exist_ok=True)
        
        results_file = output_dir / "step3_scientific_verification_results.json"
        with open(results_file, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False, default=str)
        
        logger.info("=== STEP 3 SCIENTIFIC VERIFICATION RESULTS ===")
        logger.info(f"Total datasets: {total_count}")
        logger.info(f"Successful datasets: {successful_count}")
        logger.info(f"Success rate: {success_rate:.2f}%")
        logger.info(f"Average improvement: {avg_improvement:.4f}%")
        logger.info(f"Average expansion ratio: {avg_expansion:.2f}")
        
        # 判断验证结果
        if success_rate > 70 and avg_improvement > 5:
            status = "✅ 验证通过"
            conclusion = "Step 3特征工程科学验证通过，效果显著。"
        elif success_rate > 50 and avg_improvement > 2:
            status = "⚠️ 部分通过"
            conclusion = "Step 3特征工程科学验证部分通过，有一定效果。"
        elif success_rate > 30 and avg_improvement > 0:
            status = "⚠️ 勉强通过"
            conclusion = "Step 3特征工程科学验证勉强通过，效果有限。"
        else:
            status = "❌ 验证失败"
            conclusion = "Step 3特征工程科学验证失败，效果不明显。"
        
        logger.info(f"Verification Status: {status}")
        logger.info(f"Conclusion: {conclusion}")
        
        return results
        
    except Exception as e:
        logger.error(f"Error in scientific verification: {e}")
        return {}

if __name__ == "__main__":
    run_step3_scientific_verification()

