#!/usr/bin/env python3
"""
Step 3 GPU加速简化验证
使用GPU加速处理大数据集
"""

import pandas as pd
import numpy as np
import torch
import cudf
import cuml
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
import json
import warnings
warnings.filterwarnings("ignore")

print("=" * 70)
print("Step 3 GPU加速简化验证")
print("=" * 70)

# GPU检查
print("🔍 GPU检查:")
print(f"  CUDA可用: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print(f"  GPU设备: {torch.cuda.get_device_name(0)}")
    print(f"  GPU内存: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.1f} GB")
    device = torch.device('cuda')
else:
    print("  ⚠️ CUDA不可用，将使用CPU")
    device = torch.device('cpu')

# ======= Step 1: 数据读取 =======
print("\n📂 Step 1: 数据读取")
print("  📥 正在读取features_base.csv...")
base = pd.read_csv("features_base.csv")
print(f"    ✅ Base特征加载完成: {base.shape}")

print("  📥 正在读取features_extended.csv...")
extended = pd.read_csv("features_extended.csv")
print(f"    ✅ Extended特征加载完成: {extended.shape}")

print("  📥 正在读取labels.csv...")
y = pd.read_csv("labels.csv")["target"]
print(f"    ✅ 标签加载完成: {len(y)} 个样本")

# 样本一致性检查
assert len(base) == len(extended) == len(y), "样本数量不一致"
print(f"  ✅ 数据加载完成: {len(y)} 个样本")

# ======= Step 2: 数据清理 =======
print("\n🔧 Step 2: 数据清理")
print("  🗑️ 正在删除常数特征...")
var_threshold = 1e-8
extended = extended.loc[:, extended.var() > var_threshold]
print(f"  ✅ 方差筛选后Extended特征: {extended.shape[1]} 个")

# ======= Step 3: 数据划分 =======
print("\n📊 Step 3: 数据划分")
print("  🔄 正在划分数据...")
Xb_train, Xb_test, y_train, y_test = train_test_split(
    base, y, test_size=0.3, random_state=42)
Xe_train, Xe_test, _, _ = train_test_split(
    extended, y, test_size=0.3, random_state=42)
print(f"  ✅ 数据划分完成: 训练集{len(y_train)}个, 测试集{len(y_test)}个")

# ======= Step 4: 标准化 =======
print("\n📊 Step 4: 数据标准化")
print("  🔄 正在标准化数据...")
scaler = StandardScaler()
Xb_train = scaler.fit_transform(Xb_train)
Xb_test = scaler.transform(Xb_test)
Xe_train = scaler.fit_transform(Xe_train)
Xe_test = scaler.transform(Xe_test)
print("  ✅ 数据标准化完成")

# ======= Step 5: 模型训练 =======
print("\n🤖 Step 5: 模型训练与评估")
print("  🚀 初始化RandomForest模型...")
model = RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)

# Base模型
print("  🎯 训练Base模型...")
model.fit(Xb_train, y_train)
y_pred_base = model.predict(Xb_test)
r2_base = r2_score(y_test, y_pred_base)
print(f"    ✅ Base模型R²: {r2_base:.4f}")

# Extended模型
print("  🎯 训练Extended模型...")
model.fit(Xe_train, y_train)
y_pred_ext = model.predict(Xe_test)
r2_ext = r2_score(y_test, y_pred_ext)
print(f"    ✅ Extended模型R²: {r2_ext:.4f}")

# ======= Step 6: 结果保存 =======
print("\n📈 Step 6: 结果保存")
improvement = (r2_ext - r2_base) / abs(r2_base + 1e-9) * 100
results = {
    "R2_base": float(r2_base),
    "R2_extended": float(r2_ext),
    "improvement(%)": float(improvement),
    "MAE_base": float(mean_absolute_error(y_test, y_pred_base)),
    "MAE_extended": float(mean_absolute_error(y_test, y_pred_ext)),
    "RMSE_base": float(np.sqrt(mean_squared_error(y_test, y_pred_base))),
    "RMSE_extended": float(np.sqrt(mean_squared_error(y_test, y_pred_ext))),
    "base_features": int(base.shape[1]),
    "extended_features": int(extended.shape[1]),
    "samples": int(len(y))
}

print("  💾 正在保存结果...")
with open("step3_gpu_verification_result.json", "w") as f:
    json.dump(results, f, indent=4)

print("✅ 验证完成，结果写入 step3_gpu_verification_result.json")
print("\n📊 验证结果:")
for key, value in results.items():
    if isinstance(value, float):
        print(f"  {key}: {value:.4f}")
    else:
        print(f"  {key}: {value}")

print("=" * 70)
