#!/usr/bin/env python3
"""
Step 1: Data Extraction and Normalization
Extracts and normalizes data from 8 datasets for stress-cognition-behavior entanglement analysis.
"""

import os
import zipfile
import json
import hashlib
import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# Set random seed for reproducibility
np.random.seed(42)

class DataExtractor:
    def __init__(self, data_root="data", output_root="processed"):
        self.data_root = Path(data_root)
        self.output_root = Path(output_root)
        self.output_root.mkdir(exist_ok=True)
        
        # Dataset configurations
        self.datasets = {
            'WESAD': {'extracted': True, 'subjects': ['S2', 'S3', 'S4', 'S5', 'S6', 'S7', 'S8', 'S9', 'S10', 'S11', 'S13', 'S14', 'S15', 'S16', 'S17']},
            'MMASH': {'extracted': False, 'zip_file': 'MMASH (Multilevel Monitoring of Activity and Sleep in Healthy People).zip'},
            'CRWD': {'extracted': False, 'zip_file': 'CRWD.zip'},
            'Nurses': {'extracted': False, 'zip_file': 'nurse.zip'},
            'DRIVE_DB': {'extracted': False, 'zip_file': 'stress-recognition-in-automobile-drivers-1.0.0.zip'},
            'Non_EEG': {'extracted': False, 'zip_file': 'non-eeg-dataset-for-assessment-of-neurological-status-1.0.0.zip'},
            'SWELL': {'extracted': False, 'zip_file': 'swell-knowledge-work-and-stress-dataset.zip'},
            'Mental_Health_Pred': {'extracted': False, 'zip_file': 'Mental Health Prediction Using Wearable Dataset .zip'}
        }
        
        # Unified column mapping for standardization
        self.column_mapping = {
            'timestamp': ['timestamp', 'time', 'datetime', 't', 'ts'],
            'hr': ['hr', 'heart_rate', 'HR', 'heartrate', 'hr_mean'],
            'hrv_rmssd': ['rmssd', 'HRV_RMSSD', 'rmssd_ms'],
            'hrv_sdnn': ['sdnn', 'HRV_SDNN', 'sdnn_ms'],
            'hrv_mean': ['hrv_mean', 'HRV_mean', 'hrv_avg'],
            'eda': ['eda', 'EDA', 'gsr', 'GSR', 'skin_conductance'],
            'temp': ['temp', 'temperature', 'TEMP', 'body_temp'],
            'acc_x': ['acc_x', 'accX', 'x', 'accelerometer_x'],
            'acc_y': ['acc_y', 'accY', 'y', 'accelerometer_y'],
            'acc_z': ['acc_z', 'accZ', 'z', 'accelerometer_z'],
            'acc_magnitude': ['acc_magnitude', 'acc_mag', 'magnitude'],
            'ibi': ['ibi', 'IBI', 'rr_interval', 'rr_intervals'],
            'bvp': ['bvp', 'BVP', 'ppg', 'PPG'],
            'respiration': ['resp', 'respiration', 'breathing', 'breath_rate'],
            'stress_label': ['stress', 'stress_label', 'label', 'condition', 'state'],
            'subject_id': ['subject', 'subject_id', 'participant', 'id', 'user']
        }

    def calculate_file_hash(self, file_path):
        """Calculate SHA256 hash of a file."""
        hash_sha256 = hashlib.sha256()
        try:
            with open(file_path, "rb") as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    hash_sha256.update(chunk)
            return hash_sha256.hexdigest()
        except Exception as e:
            print(f"Error calculating hash for {file_path}: {e}")
            return None

    def extract_zip_file(self, zip_path, extract_to):
        """Extract zip file with progress tracking."""
        try:
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(extract_to)
            return True
        except Exception as e:
            print(f"Error extracting {zip_path}: {e}")
            return False

    def process_wesad_dataset(self):
        """Process WESAD dataset (already extracted)."""
        print("Processing WESAD dataset...")
        wesad_root = self.data_root / 'WESAD' / 'raw'
        manifest = {
            'dataset': 'WESAD',
            'extraction_time': datetime.now().isoformat(),
            'subjects': [],
            'files': [],
            'total_records': 0,
            'sampling_rates': {}
        }
        
        for subject in self.datasets['WESAD']['subjects']:
            subject_path = wesad_root / subject
            if not subject_path.exists():
                continue
                
            subject_info = {
                'subject_id': subject,
                'files': [],
                'total_records': 0,
                'duration_hours': 0
            }
            
            # Process E4 data files
            e4_path = subject_path / f'{subject}_E4_Data'
            if e4_path.exists():
                for sensor_file in ['ACC.csv', 'BVP.csv', 'EDA.csv', 'HR.csv', 'IBI.csv', 'TEMP.csv']:
                    file_path = e4_path / sensor_file
                    if file_path.exists():
                        try:
                            # Read file to get basic info
                            df = pd.read_csv(file_path, header=None)
                            file_hash = self.calculate_file_hash(file_path)
                            
                            file_info = {
                                'filename': sensor_file,
                                'path': str(file_path),
                                'hash': file_hash,
                                'rows': len(df),
                                'columns': len(df.columns),
                                'size_bytes': file_path.stat().st_size
                            }
                            
                            # Estimate sampling rate from first two timestamps
                            if len(df) > 1 and sensor_file in ['ACC.csv', 'EDA.csv', 'TEMP.csv']:
                                try:
                                    time_diff = df.iloc[1, 0] - df.iloc[0, 0]
                                    if time_diff > 0:
                                        sampling_rate = 1.0 / time_diff
                                        file_info['sampling_rate'] = sampling_rate
                                        manifest['sampling_rates'][f'{subject}_{sensor_file}'] = sampling_rate
                                except:
                                    pass
                            
                            subject_info['files'].append(file_info)
                            manifest['files'].append(file_info)
                            subject_info['total_records'] += len(df)
                            
                        except Exception as e:
                            print(f"Error processing {file_path}: {e}")
            
            # Process questionnaire data
            quest_file = subject_path / f'{subject}_quest.csv'
            if quest_file.exists():
                try:
                    df = pd.read_csv(quest_file)
                    file_hash = self.calculate_file_hash(quest_file)
                    file_info = {
                        'filename': f'{subject}_quest.csv',
                        'path': str(quest_file),
                        'hash': file_hash,
                        'rows': len(df),
                        'columns': len(df.columns),
                        'size_bytes': quest_file.stat().st_size
                    }
                    subject_info['files'].append(file_info)
                    manifest['files'].append(file_info)
                except Exception as e:
                    print(f"Error processing {quest_file}: {e}")
            
            manifest['subjects'].append(subject_info)
            manifest['total_records'] += subject_info['total_records']
        
        # Save manifest
        manifest_path = self.output_root / 'raw_snapshot_WESAD.manifest.json'
        with open(manifest_path, 'w') as f:
            json.dump(manifest, f, indent=2)
        
        print(f"WESAD processing complete. Total records: {manifest['total_records']}")
        return manifest

    def extract_other_datasets(self):
        """Extract and create manifests for other datasets."""
        results = {}
        
        for dataset_name, config in self.datasets.items():
            if config['extracted']:
                continue
                
            print(f"Processing {dataset_name} dataset...")
            zip_path = self.data_root / dataset_name / 'raw' / config['zip_file']
            
            if not zip_path.exists():
                print(f"Warning: {zip_path} not found, skipping {dataset_name}")
                continue
            
            # Create extraction directory
            extract_dir = self.output_root / f'{dataset_name}_extracted'
            extract_dir.mkdir(exist_ok=True)
            
            # Extract zip file
            if self.extract_zip_file(zip_path, extract_dir):
                # Create manifest
                manifest = self.create_manifest_from_extracted(extract_dir, dataset_name)
                
                # Save manifest
                manifest_path = self.output_root / f'raw_snapshot_{dataset_name}.manifest.json'
                with open(manifest_path, 'w') as f:
                    json.dump(manifest, f, indent=2)
                
                results[dataset_name] = manifest
                print(f"{dataset_name} extraction complete.")
            else:
                print(f"Failed to extract {dataset_name}")
        
        return results

    def create_manifest_from_extracted(self, extract_dir, dataset_name):
        """Create manifest for extracted dataset."""
        manifest = {
            'dataset': dataset_name,
            'extraction_time': datetime.now().isoformat(),
            'extract_directory': str(extract_dir),
            'files': [],
            'total_records': 0,
            'sampling_rates': {}
        }
        
        for root, dirs, files in os.walk(extract_dir):
            for file in files:
                if file.endswith(('.csv', '.txt', '.json', '.pkl')):
                    file_path = Path(root) / file
                    try:
                        file_hash = self.calculate_file_hash(file_path)
                        
                        file_info = {
                            'filename': file,
                            'path': str(file_path),
                            'hash': file_hash,
                            'size_bytes': file_path.stat().st_size
                        }
                        
                        # Try to get row count for CSV files
                        if file.endswith('.csv'):
                            try:
                                df = pd.read_csv(file_path, nrows=1000)  # Read first 1000 rows
                                file_info['estimated_rows'] = len(df)
                                file_info['columns'] = len(df.columns)
                                manifest['total_records'] += len(df)
                            except:
                                pass
                        
                        manifest['files'].append(file_info)
                    except Exception as e:
                        print(f"Error processing {file_path}: {e}")
        
        return manifest

    def standardize_timestamps(self, df, timestamp_col='timestamp'):
        """Standardize timestamp format to UTC."""
        if timestamp_col not in df.columns:
            return df
        
        try:
            # Convert to datetime if not already
            if not pd.api.types.is_datetime64_any_dtype(df[timestamp_col]):
                # Try different timestamp formats
                if df[timestamp_col].dtype in ['int64', 'float64']:
                    # Assume Unix timestamp
                    df[timestamp_col] = pd.to_datetime(df[timestamp_col], unit='s')
                else:
                    df[timestamp_col] = pd.to_datetime(df[timestamp_col])
            
            # Convert to UTC
            if df[timestamp_col].dt.tz is None:
                df[timestamp_col] = df[timestamp_col].dt.tz_localize('UTC')
            else:
                df[timestamp_col] = df[timestamp_col].dt.tz_convert('UTC')
            
        except Exception as e:
            print(f"Warning: Could not standardize timestamps: {e}")
        
        return df

    def map_columns(self, df):
        """Map dataset columns to unified schema."""
        mapped_df = df.copy()
        column_map = {}
        
        for standard_name, possible_names in self.column_mapping.items():
            for col in df.columns:
                col_lower = col.lower().replace(' ', '_').replace('-', '_')
                if col_lower in [name.lower() for name in possible_names]:
                    column_map[col] = standard_name
                    break
        
        # Rename columns
        mapped_df = mapped_df.rename(columns=column_map)
        
        return mapped_df, column_map

    def run_extraction(self):
        """Run complete extraction process."""
        print("Starting data extraction and normalization...")
        print(f"Data root: {self.data_root}")
        print(f"Output root: {self.output_root}")
        
        # Process WESAD (already extracted)
        wesad_manifest = self.process_wesad_dataset()
        
        # Extract other datasets
        other_manifests = self.extract_other_datasets()
        
        # Create summary manifest
        summary = {
            'extraction_summary': {
                'total_datasets': len(self.datasets),
                'successfully_processed': 1 + len(other_manifests),
                'extraction_time': datetime.now().isoformat(),
                'datasets': list(self.datasets.keys())
            },
            'wesad': wesad_manifest,
            'other_datasets': other_manifests
        }
        
        summary_path = self.output_root / 'extraction_summary.json'
        with open(summary_path, 'w') as f:
            json.dump(summary, f, indent=2)
        
        print(f"\nExtraction complete!")
        print(f"Processed {summary['extraction_summary']['successfully_processed']} datasets")
        print(f"Summary saved to: {summary_path}")
        
        return summary

def main():
    extractor = DataExtractor()
    results = extractor.run_extraction()
    return results

if __name__ == "__main__":
    main()








