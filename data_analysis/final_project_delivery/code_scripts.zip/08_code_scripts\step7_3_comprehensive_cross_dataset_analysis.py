#!/usr/bin/env python3
"""
Step 7.3: 全面的跨数据集迁移分析和总结
分析Step 7.1和7.2的结果，生成综合报告
"""

import os
import sys
import logging
import pandas as pd
import numpy as np
import json
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('step7_3_comprehensive_cross_dataset_analysis.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class ComprehensiveCrossDatasetAnalyzer:
    """全面的跨数据集迁移分析器."""
    
    def __init__(self):
        self.results_dir = '/mnt/d/data_analysis/processed/step7_cross_dataset_transfer'
        self.output_dir = '/mnt/d/data_analysis/processed/step7_cross_dataset_transfer'
        Path(self.output_dir).mkdir(exist_ok=True)
        
        logger.info("Initialized ComprehensiveCrossDatasetAnalyzer")
    
    def load_transfer_results(self) -> dict:
        """加载所有跨数据集迁移结果."""
        try:
            results = {}
            
            # 加载Step 7.1结果
            step7_1_file = Path(self.results_dir) / "cross_dataset_transfer_DRIVE_DB_baseline.json"
            if step7_1_file.exists():
                with open(step7_1_file, 'r') as f:
                    results['step7_1'] = json.load(f)
                logger.info(f"Loaded Step 7.1 results from {step7_1_file}")
            
            # 加载Step 7.2结果
            step7_2_file = Path(self.results_dir) / "extended_cross_dataset_transfer_DRIVE_DB_pytorch_only.json"
            if step7_2_file.exists():
                with open(step7_2_file, 'r') as f:
                    results['step7_2'] = json.load(f)
                logger.info(f"Loaded Step 7.2 results from {step7_2_file}")
            
            return results
            
        except Exception as e:
            logger.error(f"Error loading transfer results: {e}")
            return {}
    
    def analyze_model_performance_patterns(self, results: dict) -> dict:
        """分析模型性能模式."""
        try:
            logger.info("Analyzing model performance patterns...")
            
            analysis = {
                'model_comparison': {},
                'window_size_impact': {},
                'dataset_similarity': {},
                'data_leakage_detection': {}
            }
            
            # 分析Step 7.1结果（多种模型）
            if 'step7_1' in results:
                step7_1_data = results['step7_1']
                
                for window_size, window_data in step7_1_data.get('transfer_results', {}).items():
                    if window_size not in analysis['model_comparison']:
                        analysis['model_comparison'][window_size] = {}
                    
                    # 源数据集性能
                    source_perf = window_data.get('source_training', {}).get('trained_models', {})
                    for model_name, perf in source_perf.items():
                        if model_name not in analysis['model_comparison'][window_size]:
                            analysis['model_comparison'][window_size][model_name] = {
                                'source_r2': [], 'transfer_r2': [], 'r2_drop': []
                            }
                        
                        source_r2 = perf.get('r2', 0)
                        analysis['model_comparison'][window_size][model_name]['source_r2'].append(source_r2)
                        
                        # 迁移性能
                        target_perf = window_data.get('target_testing', {})
                        for target_dataset, target_data in target_perf.items():
                            transfer_perf = target_data.get('transfer_results', {}).get(model_name, {})
                            if transfer_perf and 'r2' in transfer_perf:
                                transfer_r2 = transfer_perf['r2']
                                r2_drop = source_r2 - transfer_r2
                                
                                analysis['model_comparison'][window_size][model_name]['transfer_r2'].append(transfer_r2)
                                analysis['model_comparison'][window_size][model_name]['r2_drop'].append(r2_drop)
            
            # 分析Step 7.2结果（PyTorch NN详细分析）
            if 'step7_2' in results:
                step7_2_data = results['step7_2']
                
                for window_size, window_data in step7_2_data.get('transfer_results', {}).items():
                    if window_size not in analysis['window_size_impact']:
                        analysis['window_size_impact'][window_size] = {}
                    
                    source_perf = window_data.get('source_performance', {})
                    source_r2 = source_perf.get('r2', 0)
                    
                    analysis['window_size_impact'][window_size]['source_r2'] = source_r2
                    analysis['window_size_impact'][window_size]['transfers'] = {}
                    
                    target_perf = window_data.get('target_performance', {})
                    for target_dataset, target_data in target_perf.items():
                        perf = target_data.get('performance', {})
                        transfer_r2 = perf.get('r2', 0)
                        r2_drop = source_r2 - transfer_r2
                        
                        analysis['window_size_impact'][window_size]['transfers'][target_dataset] = {
                            'transfer_r2': transfer_r2,
                            'r2_drop': r2_drop,
                            'data_shape': target_data.get('data_shape', [0, 0])
                        }
            
            # 检测数据泄露
            analysis['data_leakage_detection'] = self._detect_data_leakage(analysis)
            
            # 分析数据集相似性
            analysis['dataset_similarity'] = self._analyze_dataset_similarity(analysis)
            
            return analysis
            
        except Exception as e:
            logger.error(f"Error analyzing model performance patterns: {e}")
            return {}
    
    def _detect_data_leakage(self, analysis: dict) -> dict:
        """检测数据泄露."""
        leakage_detection = {
            'suspicious_models': [],
            'normal_models': [],
            'leakage_indicators': {}
        }
        
        for window_size, models in analysis.get('model_comparison', {}).items():
            for model_name, perf_data in models.items():
                source_r2s = perf_data.get('source_r2', [])
                transfer_r2s = perf_data.get('transfer_r2', [])
                r2_drops = perf_data.get('r2_drop', [])
                
                if source_r2s and transfer_r2s:
                    avg_source_r2 = np.mean(source_r2s)
                    avg_transfer_r2 = np.mean(transfer_r2s)
                    avg_r2_drop = np.mean(r2_drops)
                    
                    # 检测异常高的R²值
                    if avg_source_r2 > 0.99 and avg_transfer_r2 > 0.99:
                        leakage_detection['suspicious_models'].append({
                            'model': model_name,
                            'window_size': window_size,
                            'source_r2': avg_source_r2,
                            'transfer_r2': avg_transfer_r2,
                            'r2_drop': avg_r2_drop,
                            'indicator': 'R²接近1.0，可能存在数据泄露'
                        })
                    elif avg_r2_drop < 0.1:
                        leakage_detection['suspicious_models'].append({
                            'model': model_name,
                            'window_size': window_size,
                            'source_r2': avg_source_r2,
                            'transfer_r2': avg_transfer_r2,
                            'r2_drop': avg_r2_drop,
                            'indicator': '迁移性能下降过小，可能存在数据泄露'
                        })
                    else:
                        leakage_detection['normal_models'].append({
                            'model': model_name,
                            'window_size': window_size,
                            'source_r2': avg_source_r2,
                            'transfer_r2': avg_transfer_r2,
                            'r2_drop': avg_r2_drop
                        })
        
        return leakage_detection
    
    def _analyze_dataset_similarity(self, analysis: dict) -> dict:
        """分析数据集相似性."""
        similarity_analysis = {
            'window_size_impact': {},
            'transfer_performance_by_dataset': {}
        }
        
        # 分析时间窗口对迁移性能的影响
        for window_size, window_data in analysis.get('window_size_impact', {}).items():
            transfers = window_data.get('transfers', {})
            r2_drops = [t['r2_drop'] for t in transfers.values()]
            
            similarity_analysis['window_size_impact'][window_size] = {
                'avg_r2_drop': np.mean(r2_drops) if r2_drops else 0,
                'min_r2_drop': np.min(r2_drops) if r2_drops else 0,
                'max_r2_drop': np.max(r2_drops) if r2_drops else 0,
                'std_r2_drop': np.std(r2_drops) if r2_drops else 0
            }
            
            # 分析每个数据集的迁移性能
            for target_dataset, transfer_data in transfers.items():
                if target_dataset not in similarity_analysis['transfer_performance_by_dataset']:
                    similarity_analysis['transfer_performance_by_dataset'][target_dataset] = []
                
                similarity_analysis['transfer_performance_by_dataset'][target_dataset].append({
                    'window_size': window_size,
                    'r2_drop': transfer_data['r2_drop'],
                    'transfer_r2': transfer_data['transfer_r2']
                })
        
        return similarity_analysis
    
    def generate_visualizations(self, analysis: dict) -> dict:
        """生成可视化图表."""
        try:
            logger.info("Generating visualizations...")
            
            # 设置中文字体
            plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
            plt.rcParams['axes.unicode_minus'] = False
            
            viz_files = {}
            
            # 1. 模型性能对比图
            if 'model_comparison' in analysis:
                self._create_model_comparison_plot(analysis['model_comparison'], viz_files)
            
            # 2. 时间窗口影响分析图
            if 'window_size_impact' in analysis:
                self._create_window_size_impact_plot(analysis['window_size_impact'], viz_files)
            
            # 3. 数据泄露检测图
            if 'data_leakage_detection' in analysis:
                self._create_data_leakage_plot(analysis['data_leakage_detection'], viz_files)
            
            return viz_files
            
        except Exception as e:
            logger.error(f"Error generating visualizations: {e}")
            return {}
    
    def _create_model_comparison_plot(self, model_comparison: dict, viz_files: dict):
        """创建模型性能对比图."""
        try:
            fig, axes = plt.subplots(2, 2, figsize=(15, 12))
            fig.suptitle('Model Performance Comparison Across Datasets', fontsize=16)
            
            window_sizes = list(model_comparison.keys())
            models = set()
            for window_data in model_comparison.values():
                models.update(window_data.keys())
            models = list(models)
            
            # 为每个时间窗口创建子图
            for i, window_size in enumerate(window_sizes):
                ax = axes[i // 2, i % 2]
                
                window_data = model_comparison[window_size]
                
                model_names = []
                source_r2s = []
                transfer_r2s = []
                r2_drops = []
                
                for model_name in models:
                    if model_name in window_data:
                        model_data = window_data[model_name]
                        if model_data['source_r2'] and model_data['transfer_r2']:
                            model_names.append(model_name)
                            source_r2s.append(np.mean(model_data['source_r2']))
                            transfer_r2s.append(np.mean(model_data['transfer_r2']))
                            r2_drops.append(np.mean(model_data['r2_drop']))
                
                x = np.arange(len(model_names))
                width = 0.25
                
                ax.bar(x - width, source_r2s, width, label='Source R²', alpha=0.8)
                ax.bar(x, transfer_r2s, width, label='Transfer R²', alpha=0.8)
                ax.bar(x + width, r2_drops, width, label='R² Drop', alpha=0.8)
                
                ax.set_xlabel('Models')
                ax.set_ylabel('R² Score')
                ax.set_title(f'Window Size: {window_size}')
                ax.set_xticks(x)
                ax.set_xticklabels(model_names, rotation=45)
                ax.legend()
                ax.grid(True, alpha=0.3)
            
            plt.tight_layout()
            plot_file = Path(self.output_dir) / 'model_comparison_plot.png'
            plt.savefig(plot_file, dpi=300, bbox_inches='tight')
            plt.close()
            
            viz_files['model_comparison'] = str(plot_file)
            logger.info(f"Created model comparison plot: {plot_file}")
            
        except Exception as e:
            logger.error(f"Error creating model comparison plot: {e}")
    
    def _create_window_size_impact_plot(self, window_size_impact: dict, viz_files: dict):
        """创建时间窗口影响分析图."""
        try:
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
            fig.suptitle('Window Size Impact on Transfer Performance', fontsize=16)
            
            window_sizes = list(window_size_impact.keys())
            avg_drops = []
            std_drops = []
            
            for window_size in window_sizes:
                window_data = window_size_impact[window_size]
                avg_drops.append(window_data.get('avg_r2_drop', 0))
                std_drops.append(window_data.get('std_r2_drop', 0))
            
            # R² drop by window size
            ax1.bar(window_sizes, avg_drops, yerr=std_drops, capsize=5, alpha=0.7)
            ax1.set_xlabel('Window Size')
            ax1.set_ylabel('Average R² Drop')
            ax1.set_title('Performance Drop by Window Size')
            ax1.grid(True, alpha=0.3)
            
            # Transfer performance by dataset and window size
            datasets = set()
            for window_data in window_size_impact.values():
                datasets.update(window_data.get('transfers', {}).keys())
            datasets = list(datasets)
            
            x = np.arange(len(datasets))
            width = 0.35
            
            for i, window_size in enumerate(window_sizes):
                window_data = window_size_impact[window_size]
                transfers = window_data.get('transfers', {})
                
                transfer_r2s = []
                for dataset in datasets:
                    if dataset in transfers:
                        transfer_r2s.append(transfers[dataset]['transfer_r2'])
                    else:
                        transfer_r2s.append(0)
                
                ax2.bar(x + i * width, transfer_r2s, width, label=f'{window_size}', alpha=0.8)
            
            ax2.set_xlabel('Target Datasets')
            ax2.set_ylabel('Transfer R² Score')
            ax2.set_title('Transfer Performance by Dataset')
            ax2.set_xticks(x + width / 2)
            ax2.set_xticklabels(datasets)
            ax2.legend()
            ax2.grid(True, alpha=0.3)
            
            plt.tight_layout()
            plot_file = Path(self.output_dir) / 'window_size_impact_plot.png'
            plt.savefig(plot_file, dpi=300, bbox_inches='tight')
            plt.close()
            
            viz_files['window_size_impact'] = str(plot_file)
            logger.info(f"Created window size impact plot: {plot_file}")
            
        except Exception as e:
            logger.error(f"Error creating window size impact plot: {e}")
    
    def _create_data_leakage_plot(self, leakage_detection: dict, viz_files: dict):
        """创建数据泄露检测图."""
        try:
            fig, ax = plt.subplots(figsize=(12, 8))
            
            suspicious_models = leakage_detection.get('suspicious_models', [])
            normal_models = leakage_detection.get('normal_models', [])
            
            if suspicious_models or normal_models:
                models = []
                source_r2s = []
                transfer_r2s = []
                colors = []
                
                for model in suspicious_models:
                    models.append(f"{model['model']} ({model['window_size']})")
                    source_r2s.append(model['source_r2'])
                    transfer_r2s.append(model['transfer_r2'])
                    colors.append('red')
                
                for model in normal_models:
                    models.append(f"{model['model']} ({model['window_size']})")
                    source_r2s.append(model['source_r2'])
                    transfer_r2s.append(model['transfer_r2'])
                    colors.append('green')
                
                x = np.arange(len(models))
                width = 0.35
                
                ax.bar(x - width/2, source_r2s, width, label='Source R²', alpha=0.7)
                ax.bar(x + width/2, transfer_r2s, width, label='Transfer R²', alpha=0.7)
                
                # 标记可疑模型
                for i, color in enumerate(colors):
                    if color == 'red':
                        ax.axvspan(i - width, i + width, alpha=0.2, color='red')
                
                ax.set_xlabel('Models')
                ax.set_ylabel('R² Score')
                ax.set_title('Data Leakage Detection: Source vs Transfer Performance')
                ax.set_xticks(x)
                ax.set_xticklabels(models, rotation=45, ha='right')
                ax.legend()
                ax.grid(True, alpha=0.3)
                
                # 添加说明
                ax.text(0.02, 0.98, 'Red shading indicates potential data leakage', 
                       transform=ax.transAxes, verticalalignment='top',
                       bbox=dict(boxstyle='round', facecolor='red', alpha=0.3))
            
            plt.tight_layout()
            plot_file = Path(self.output_dir) / 'data_leakage_detection_plot.png'
            plt.savefig(plot_file, dpi=300, bbox_inches='tight')
            plt.close()
            
            viz_files['data_leakage_detection'] = str(plot_file)
            logger.info(f"Created data leakage detection plot: {plot_file}")
            
        except Exception as e:
            logger.error(f"Error creating data leakage detection plot: {e}")
    
    def generate_comprehensive_report(self, analysis: dict, viz_files: dict) -> str:
        """生成综合分析报告."""
        try:
            logger.info("Generating comprehensive analysis report...")
            
            report = []
            report.append("# Step 7: 跨数据集迁移与泛化测试 - 综合分析报告")
            report.append(f"\n**生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
            report.append(f"\n**分析范围**: DRIVE_DB作为源数据集，向CRWD、SWELL、Non_EEG的迁移测试")
            
            # 1. 执行摘要
            report.append("\n## 1. 执行摘要")
            report.append("\n### 关键发现")
            
            # 数据泄露检测结果
            leakage_detection = analysis.get('data_leakage_detection', {})
            suspicious_models = leakage_detection.get('suspicious_models', [])
            normal_models = leakage_detection.get('normal_models', [])
            
            if suspicious_models:
                report.append(f"- **数据泄露问题**: 发现{len(suspicious_models)}个模型存在数据泄露迹象")
                for model in suspicious_models:
                    report.append(f"  - {model['model']} ({model['window_size']}): {model['indicator']}")
            
            if normal_models:
                report.append(f"- **正常模型**: {len(normal_models)}个模型表现正常")
                for model in normal_models:
                    report.append(f"  - {model['model']} ({model['window_size']}): R²下降{model['r2_drop']:.3f}")
            
            # 2. 详细分析
            report.append("\n## 2. 详细分析")
            
            # 模型性能对比
            report.append("\n### 2.1 模型性能对比")
            model_comparison = analysis.get('model_comparison', {})
            for window_size, models in model_comparison.items():
                report.append(f"\n#### 时间窗口: {window_size}")
                for model_name, perf_data in models.items():
                    if perf_data['source_r2'] and perf_data['transfer_r2']:
                        avg_source = np.mean(perf_data['source_r2'])
                        avg_transfer = np.mean(perf_data['transfer_r2'])
                        avg_drop = np.mean(perf_data['r2_drop'])
                        report.append(f"- **{model_name}**: 源R²={avg_source:.3f}, 迁移R²={avg_transfer:.3f}, 下降={avg_drop:.3f}")
            
            # 时间窗口影响
            report.append("\n### 2.2 时间窗口对迁移性能的影响")
            window_impact = analysis.get('window_size_impact', {})
            for window_size, impact_data in window_impact.items():
                report.append(f"\n#### {window_size}")
                report.append(f"- 平均R²下降: {impact_data.get('avg_r2_drop', 0):.3f}")
                report.append(f"- R²下降范围: {impact_data.get('min_r2_drop', 0):.3f} - {impact_data.get('max_r2_drop', 0):.3f}")
                report.append(f"- R²下降标准差: {impact_data.get('std_r2_drop', 0):.3f}")
            
            # 数据集相似性
            report.append("\n### 2.3 数据集相似性分析")
            similarity = analysis.get('dataset_similarity', {})
            transfer_perf = similarity.get('transfer_performance_by_dataset', {})
            for dataset, perf_data in transfer_perf.items():
                report.append(f"\n#### {dataset}")
                for perf in perf_data:
                    report.append(f"- {perf['window_size']}: R²={perf['transfer_r2']:.3f}, 下降={perf['r2_drop']:.3f}")
            
            # 3. 结论和建议
            report.append("\n## 3. 结论和建议")
            
            # 数据泄露问题
            if suspicious_models:
                report.append("\n### 3.1 数据泄露问题")
                report.append("- **问题**: 多个传统机器学习模型显示异常高的R²值（接近1.0）")
                report.append("- **原因**: 特征工程中可能存在数据泄露，特征与目标变量过度相关")
                report.append("- **建议**: 重新审查特征工程过程，确保特征的独立性")
            
            # PyTorch NN表现
            pytorch_models = [m for m in normal_models if 'PyTorch' in m['model']]
            if pytorch_models:
                report.append("\n### 3.2 PyTorch神经网络表现")
                report.append("- **优势**: PyTorch NN模型表现相对正常，R²值在合理范围内")
                report.append("- **迁移性能**: 跨数据集迁移时性能下降合理，符合预期")
                report.append("- **建议**: 优先使用PyTorch NN模型进行后续分析")
            
            # 时间窗口影响
            report.append("\n### 3.3 时间窗口影响")
            if '60s' in window_impact and '300s' in window_impact:
                drops_60s = window_impact['60s'].get('avg_r2_drop', 0)
                drops_300s = window_impact['300s'].get('avg_r2_drop', 0)
                if drops_300s > drops_60s:
                    report.append("- **发现**: 较长的时间窗口（300s）导致更大的性能下降")
                    report.append("- **解释**: 长时间窗口可能捕获更多数据集特定的模式")
                    report.append("- **建议**: 对于跨数据集迁移，使用较短的时间窗口（60s）")
            
            # 4. 下一步行动
            report.append("\n## 4. 下一步行动")
            report.append("1. **修复数据泄露**: 重新设计特征工程，确保特征独立性")
            report.append("2. **扩展PyTorch分析**: 基于PyTorch NN模型进行更深入的跨数据集分析")
            report.append("3. **时间窗口优化**: 测试更多时间窗口，找到最优的跨数据集迁移窗口")
            report.append("4. **特征重要性分析**: 分析哪些特征对跨数据集迁移最重要")
            
            # 5. 可视化文件
            if viz_files:
                report.append("\n## 5. 可视化文件")
                for viz_name, viz_file in viz_files.items():
                    report.append(f"- **{viz_name}**: `{viz_file}`")
            
            report_text = '\n'.join(report)
            
            # 保存报告
            report_file = Path(self.output_dir) / 'step7_comprehensive_cross_dataset_analysis_report.md'
            with open(report_file, 'w', encoding='utf-8') as f:
                f.write(report_text)
            
            logger.info(f"Comprehensive report saved: {report_file}")
            return report_text
            
        except Exception as e:
            logger.error(f"Error generating comprehensive report: {e}")
            return ""

def main():
    """主函数."""
    try:
        logger.info("Starting Step 7.3: Comprehensive Cross-Dataset Analysis")
        
        # 初始化分析器
        analyzer = ComprehensiveCrossDatasetAnalyzer()
        
        # 加载迁移结果
        logger.info("Loading transfer results...")
        results = analyzer.load_transfer_results()
        if not results:
            logger.error("No transfer results found!")
            return
        
        logger.info(f"Loaded {len(results)} result files")
        
        # 分析模型性能模式
        logger.info("Analyzing model performance patterns...")
        analysis = analyzer.analyze_model_performance_patterns(results)
        
        # 生成可视化
        logger.info("Generating visualizations...")
        viz_files = analyzer.generate_visualizations(analysis)
        
        # 生成综合分析报告
        logger.info("Generating comprehensive report...")
        report = analyzer.generate_comprehensive_report(analysis, viz_files)
        
        # 保存分析结果
        analysis_file = Path(analyzer.output_dir) / 'step7_comprehensive_analysis_results.json'
        with open(analysis_file, 'w') as f:
            json.dump(analysis, f, indent=2, default=str)
        
        logger.info(f"Analysis results saved: {analysis_file}")
        
        # 输出关键发现
        logger.info(f"\n{'='*60}")
        logger.info("Step 7.3 Comprehensive Cross-Dataset Analysis Summary")
        logger.info(f"{'='*60}")
        
        leakage_detection = analysis.get('data_leakage_detection', {})
        suspicious_count = len(leakage_detection.get('suspicious_models', []))
        normal_count = len(leakage_detection.get('normal_models', []))
        
        logger.info(f"🔍 Data Leakage Detection:")
        logger.info(f"  - Suspicious models: {suspicious_count}")
        logger.info(f"  - Normal models: {normal_count}")
        
        window_impact = analysis.get('window_size_impact', {})
        if '60s' in window_impact and '300s' in window_impact:
            drops_60s = window_impact['60s'].get('avg_r2_drop', 0)
            drops_300s = window_impact['300s'].get('avg_r2_drop', 0)
            logger.info(f"⏱️ Window Size Impact:")
            logger.info(f"  - 60s window: avg R² drop = {drops_60s:.3f}")
            logger.info(f"  - 300s window: avg R² drop = {drops_300s:.3f}")
        
        logger.info(f"📊 Visualizations created: {len(viz_files)}")
        logger.info(f"📝 Comprehensive report generated")
        
        logger.info(f"\n{'='*60}")
        logger.info("Step 7.3 Comprehensive Cross-Dataset Analysis Completed!")
        logger.info(f"{'='*60}")
        
        logger.info("🎉 Key Achievements:")
        logger.info("  ✓ Comprehensive cross-dataset analysis")
        logger.info("  ✓ Data leakage detection and identification")
        logger.info("  ✓ Window size impact analysis")
        logger.info("  ✓ Model performance pattern analysis")
        logger.info("  ✓ Visualization generation")
        logger.info("  ✓ Detailed report with recommendations")
        
    except Exception as e:
        logger.error(f"Error in main execution: {e}")
        raise

if __name__ == "__main__":
    main()
