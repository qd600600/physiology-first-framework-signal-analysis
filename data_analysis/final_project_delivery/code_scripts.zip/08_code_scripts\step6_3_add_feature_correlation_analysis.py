#!/usr/bin/env python3
"""
Step 6.3: Add Feature Correlation Analysis
为Step 6添加特征相关性分析 - 解决审计发现的第三个严重问题
"""

import os
import sys
import logging
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from pathlib import Path
from datetime import datetime
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.svm import SVR
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from sklearn.preprocessing import StandardScaler
from sklearn.feature_selection import SelectKBest, f_regression, mutual_info_regression
from scipy.stats import pearsonr, spearmanr
from scipy.cluster.hierarchy import dendrogram, linkage
from scipy.spatial.distance import squareform
import seaborn as sns
import matplotlib.pyplot as plt
import joblib
import json
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('step6_3_feature_correlation_analysis.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class FeatureCorrelationAnalyzer:
    """特征相关性分析器."""
    
    def __init__(self, device: str = 'auto'):
        self.device = self._setup_device(device)
        self.correlation_matrix = None
        self.feature_importance = None
        
        logger.info(f"Initialized FeatureCorrelationAnalyzer on {self.device}")
    
    def _setup_device(self, device: str) -> torch.device:
        """Setup computation device."""
        if device == 'auto':
            if torch.cuda.is_available():
                device = 'cuda'
                logger.info(f"CUDA available: {torch.cuda.get_device_name()}")
            else:
                device = 'cpu'
                logger.info("CUDA not available, using CPU")
        
        return torch.device(device)
    
    def load_fixed_lri_data(self, dataset_name: str, window_size: str) -> pd.DataFrame:
        """加载修复后的LRI数据."""
        try:
            file_path = f"/mnt/d/data_analysis/processed/lri_calculation/lri_{dataset_name}_{window_size}_fixed.csv"
            df = pd.read_csv(file_path)
            logger.info(f"Loaded fixed LRI data: {df.shape} from {file_path}")
            return df
        except Exception as e:
            logger.error(f"Error loading fixed LRI data for {dataset_name}_{window_size}: {e}")
            return pd.DataFrame()
    
    def prepare_features_and_target(self, df: pd.DataFrame) -> tuple:
        """准备特征和目标变量."""
        try:
            # 特征列（排除窗口元数据）
            exclude_cols = [
                'window_id', 'window_size_seconds', 'sample_count', 
                'start_time', 'end_time'
            ]
            
            # 目标变量选择
            target_col = 'recovery_ratio'
            if target_col not in df.columns or df[target_col].nunique() <= 1:
                target_col = 'stress_intensity'
                if target_col not in df.columns:
                    target_col = 'wt_mean'
            
            feature_cols = [col for col in df.columns if col not in exclude_cols + [target_col]]
            
            X = df[feature_cols].values
            y = df[target_col].values
            
            logger.info(f"Features shape: {X.shape}, Target shape: {y.shape}")
            logger.info(f"Target: {target_col}, Range: {y.min():.3f} to {y.max():.3f}")
            
            return X, y, feature_cols, target_col
            
        except Exception as e:
            logger.error(f"Error preparing features and target: {e}")
            return None, None, None, None
    
    def analyze_feature_correlations(self, X: np.ndarray, feature_names: list, method: str = 'pearson') -> dict:
        """分析特征相关性."""
        try:
            logger.info(f"Analyzing feature correlations using {method} method")
            
            if method == 'pearson':
                corr_matrix = np.corrcoef(X.T)
            elif method == 'spearman':
                corr_matrix, _ = spearmanr(X)
            else:
                raise ValueError(f"Unknown correlation method: {method}")
            
            self.correlation_matrix = corr_matrix
            
            # 找出高相关性的特征对
            high_corr_pairs = []
            for i in range(len(feature_names)):
                for j in range(i+1, len(feature_names)):
                    corr_value = abs(corr_matrix[i, j])
                    if corr_value > 0.8:  # 高相关性阈值
                        high_corr_pairs.append({
                            'feature1': feature_names[i],
                            'feature2': feature_names[j],
                            'correlation': corr_value
                        })
            
            logger.info(f"Found {len(high_corr_pairs)} highly correlated feature pairs")
            
            # 计算相关性统计
            corr_stats = {
                'mean_correlation': np.mean(np.abs(corr_matrix)),
                'max_correlation': np.max(np.abs(corr_matrix)),
                'min_correlation': np.min(np.abs(corr_matrix)),
                'std_correlation': np.std(np.abs(corr_matrix))
            }
            
            return {
                'correlation_matrix': corr_matrix.tolist(),
                'high_correlation_pairs': high_corr_pairs,
                'correlation_statistics': corr_stats,
                'method': method
            }
            
        except Exception as e:
            logger.error(f"Error analyzing feature correlations: {e}")
            return None
    
    def detect_multicollinearity(self, X: np.ndarray, feature_names: list, vif_threshold: float = 10.0) -> dict:
        """检测多重共线性."""
        try:
            logger.info("Detecting multicollinearity using VIF")
            
            # 简化的VIF计算（避免依赖statsmodels）
            vif_data = []
            
            for i, feature_name in enumerate(feature_names):
                try:
                    # 使用当前特征作为因变量，其他特征作为自变量
                    y_var = X[:, i]
                    X_vars = np.delete(X, i, axis=1)
                    
                    # 简单线性回归计算R²
                    from sklearn.linear_model import LinearRegression
                    reg = LinearRegression()
                    reg.fit(X_vars, y_var)
                    r_squared = reg.score(X_vars, y_var)
                    
                    # 计算VIF
                    if r_squared >= 1.0:
                        vif = float('inf')
                    else:
                        vif = 1 / (1 - r_squared)
                    
                    vif_data.append({
                        'feature': feature_name,
                        'vif': vif,
                        'r_squared': r_squared
                    })
                    
                except Exception as e:
                    logger.warning(f"Error calculating VIF for {feature_name}: {e}")
                    vif_data.append({
                        'feature': feature_name,
                        'vif': float('nan'),
                        'r_squared': float('nan')
                    })
            
            # 找出高VIF特征
            high_vif_features = [
                item for item in vif_data 
                if not np.isnan(item['vif']) and item['vif'] > vif_threshold
            ]
            
            logger.info(f"Found {len(high_vif_features)} features with VIF > {vif_threshold}")
            
            return {
                'vif_data': vif_data,
                'high_vif_features': high_vif_features,
                'threshold': vif_threshold
            }
            
        except Exception as e:
            logger.error(f"Error detecting multicollinearity: {e}")
            return None
    
    def select_features(self, X: np.ndarray, y: np.ndarray, feature_names: list, 
                       method: str = 'f_regression', k: int = 10) -> dict:
        """特征选择."""
        try:
            logger.info(f"Selecting top {k} features using {method}")
            
            if method == 'f_regression':
                selector = SelectKBest(score_func=f_regression, k=k)
            elif method == 'mutual_info':
                selector = SelectKBest(score_func=mutual_info_regression, k=k)
            else:
                raise ValueError(f"Unknown feature selection method: {method}")
            
            X_selected = selector.fit_transform(X, y)
            selected_features = [feature_names[i] for i in selector.get_support(indices=True)]
            feature_scores = selector.scores_
            
            logger.info(f"Selected features: {selected_features}")
            
            return {
                'X_selected': X_selected.tolist(),
                'selected_features': selected_features,
                'feature_scores': feature_scores.tolist(),
                'method': method,
                'k': k
            }
            
        except Exception as e:
            logger.error(f"Error in feature selection: {e}")
            return None
    
    def analyze_feature_importance(self, X: np.ndarray, y: np.ndarray, feature_names: list) -> dict:
        """分析特征重要性."""
        try:
            logger.info("Analyzing feature importance")
            
            # 使用随机森林计算特征重要性
            rf = RandomForestRegressor(n_estimators=100, random_state=42)
            rf.fit(X, y)
            
            feature_importance = dict(zip(feature_names, rf.feature_importances_))
            
            # 按重要性排序
            sorted_features = sorted(
                feature_importance.items(), 
                key=lambda x: x[1], reverse=True
            )
            
            logger.info("Top 5 most important features:")
            for feature, importance in sorted_features[:5]:
                logger.info(f"  {feature}: {importance:.3f}")
            
            return {
                'feature_importance': feature_importance,
                'sorted_features': sorted_features,
                'method': 'RandomForest'
            }
            
        except Exception as e:
            logger.error(f"Error analyzing feature importance: {e}")
            return None
    
    def create_correlation_heatmap(self, corr_matrix: np.ndarray, feature_names: list, 
                                  output_dir: str, dataset_name: str, window_size: str) -> str:
        """创建相关性热图."""
        try:
            plt.figure(figsize=(12, 10))
            
            # 创建热图
            mask = np.triu(np.ones_like(corr_matrix, dtype=bool))
            sns.heatmap(
                corr_matrix, 
                mask=mask,
                annot=True, 
                cmap='coolwarm', 
                center=0,
                square=True,
                fmt='.2f',
                xticklabels=feature_names,
                yticklabels=feature_names
            )
            
            plt.title(f'Feature Correlation Matrix - {dataset_name} ({window_size})')
            plt.xticks(rotation=45, ha='right')
            plt.yticks(rotation=0)
            plt.tight_layout()
            
            # 保存图片
            output_path = Path(output_dir) / f"correlation_heatmap_{dataset_name}_{window_size}.png"
            plt.savefig(output_path, dpi=300, bbox_inches='tight')
            plt.close()
            
            logger.info(f"Saved correlation heatmap: {output_path}")
            
            return str(output_path)
            
        except Exception as e:
            logger.error(f"Error creating correlation heatmap: {e}")
            return None
    
    def validate_with_feature_correlation_analysis(self, dataset_name: str, window_size: str) -> dict:
        """带特征相关性分析的验证."""
        try:
            logger.info(f"=== Feature Correlation Analysis for {dataset_name} - {window_size}s ===")
            
            # 1. 加载数据
            df = self.load_fixed_lri_data(dataset_name, window_size)
            if df.empty:
                return {'error': 'Failed to load data'}
            
            # 2. 准备特征和目标
            X, y, feature_cols, target_col = self.prepare_features_and_target(df)
            if X is None:
                return {'error': 'Failed to prepare features'}
            
            # 3. 特征相关性分析
            logger.info("Performing feature correlation analysis...")
            
            # Pearson相关性分析
            pearson_analysis = self.analyze_feature_correlations(X, feature_cols, method='pearson')
            
            # Spearman相关性分析
            spearman_analysis = self.analyze_feature_correlations(X, feature_cols, method='spearman')
            
            # 4. 多重共线性检测
            logger.info("Detecting multicollinearity...")
            multicollinearity_analysis = self.detect_multicollinearity(X, feature_cols)
            
            # 5. 特征选择
            logger.info("Performing feature selection...")
            feature_selection_f = self.select_features(X, y, feature_cols, method='f_regression', k=min(8, len(feature_cols)))
            feature_selection_mi = self.select_features(X, y, feature_cols, method='mutual_info', k=min(8, len(feature_cols)))
            
            # 6. 特征重要性分析
            logger.info("Analyzing feature importance...")
            feature_importance_analysis = self.analyze_feature_importance(X, y, feature_cols)
            
            # 7. 创建可视化
            logger.info("Creating visualizations...")
            output_dir = '/mnt/d/data_analysis/processed/step6_feature_correlation_analysis'
            Path(output_dir).mkdir(exist_ok=True)
            
            heatmap_path = self.create_correlation_heatmap(
                np.array(pearson_analysis['correlation_matrix']), 
                feature_cols, 
                output_dir, 
                dataset_name, 
                window_size
            )
            
            # 8. 返回结果
            results = {
                'dataset_name': dataset_name,
                'window_size': window_size,
                'target_variable': target_col,
                'data_shape': X.shape,
                'feature_columns': feature_cols,
                'correlation_analysis': {
                    'pearson': pearson_analysis,
                    'spearman': spearman_analysis
                },
                'multicollinearity_analysis': multicollinearity_analysis,
                'feature_selection': {
                    'f_regression': feature_selection_f,
                    'mutual_info': feature_selection_mi
                },
                'feature_importance_analysis': feature_importance_analysis,
                'visualizations': {
                    'correlation_heatmap': heatmap_path
                },
                'validation_timestamp': datetime.now().isoformat()
            }
            
            logger.info(f"=== Completed feature correlation analysis for {dataset_name} - {window_size}s ===")
            
            return results
            
        except Exception as e:
            logger.error(f"Error in feature correlation analysis for {dataset_name}_{window_size}: {e}")
            return {'error': str(e)}

def main():
    """主函数."""
    try:
        logger.info("Starting Step 6.3: Add Feature Correlation Analysis")
        
        # 数据集配置（选择几个数据集进行测试）
        datasets = ['CRWD', 'SWELL', 'DRIVE_DB']  # 减少数据集以加快测试
        window_sizes = ['60s', '300s']
        
        output_dir = '/mnt/d/data_analysis/processed/step6_feature_correlation_analysis'
        Path(output_dir).mkdir(exist_ok=True)
        
        # 初始化特征相关性分析器
        analyzer = FeatureCorrelationAnalyzer(device='auto')
        
        # 逐个处理数据集
        all_results = {}
        
        for dataset_name in datasets:
            logger.info(f"\n{'='*60}")
            logger.info(f"Processing Dataset: {dataset_name} (FEATURE CORRELATION ANALYSIS)")
            logger.info(f"{'='*60}")
            
            dataset_results = {}
            
            for window_size in window_sizes:
                try:
                    result = analyzer.validate_with_feature_correlation_analysis(dataset_name, window_size)
                    dataset_results[window_size] = result
                    
                    # 保存结果
                    if 'error' not in result:
                        output_file = Path(output_dir) / f"feature_correlation_{dataset_name}_{window_size}.json"
                        with open(output_file, 'w') as f:
                            json.dump(result, f, indent=2, default=str)
                        logger.info(f"Saved feature correlation analysis results: {output_file}")
                    
                except Exception as e:
                    logger.error(f"Error processing {dataset_name}_{window_size}: {e}")
                    dataset_results[window_size] = {'error': str(e)}
            
            all_results[dataset_name] = dataset_results
        
        # 保存总体结果摘要
        summary_file = Path(output_dir) / "feature_correlation_analysis_summary.json"
        with open(summary_file, 'w') as f:
            json.dump(all_results, f, indent=2, default=str)
        
        logger.info(f"\n{'='*60}")
        logger.info("Step 6.3 Feature Correlation Analysis Completed Successfully!")
        logger.info(f"{'='*60}")
        
        # 打印特征相关性分析总结
        logger.info("\nFeature Correlation Analysis Results Summary:")
        for dataset_name, dataset_results in all_results.items():
            logger.info(f"\n{dataset_name}:")
            for window_size, result in dataset_results.items():
                if 'error' not in result:
                    corr_analysis = result.get('correlation_analysis', {})
                    multicollinearity = result.get('multicollinearity_analysis', {})
                    feature_importance = result.get('feature_importance_analysis', {})
                    
                    # Pearson相关性统计
                    if 'pearson' in corr_analysis:
                        pearson_stats = corr_analysis['pearson'].get('correlation_statistics', {})
                        high_corr_pairs = len(corr_analysis['pearson'].get('high_correlation_pairs', []))
                        logger.info(f"  {window_size}: High correlation pairs: {high_corr_pairs}")
                        logger.info(f"    Mean |correlation|: {pearson_stats.get('mean_correlation', 0):.3f}")
                        logger.info(f"    Max |correlation|: {pearson_stats.get('max_correlation', 0):.3f}")
                    
                    # 多重共线性
                    if multicollinearity:
                        high_vif_count = len(multicollinearity.get('high_vif_features', []))
                        logger.info(f"    High VIF features: {high_vif_count}")
                    
                    # 特征重要性
                    if feature_importance:
                        sorted_features = feature_importance.get('sorted_features', [])
                        if sorted_features:
                            top_feature = sorted_features[0]
                            logger.info(f"    Top feature: {top_feature[0]} ({top_feature[1]:.3f})")
                else:
                    logger.warning(f"  {window_size}: Error - {result['error']}")
        
        logger.info("\n✅ Feature Correlation Analysis Implementation Completed!")
        logger.info("🔍 Key Improvements:")
        logger.info("  ✓ Pearson and Spearman correlation analysis")
        logger.info("  ✓ Multicollinearity detection (VIF)")
        logger.info("  ✓ Feature selection (F-regression, Mutual Info)")
        logger.info("  ✓ Feature importance ranking")
        logger.info("  ✓ Correlation heatmap visualizations")
        logger.info("  ✓ Comprehensive feature relationship analysis")
        
    except Exception as e:
        logger.error(f"Error in main execution: {e}")
        raise

if __name__ == "__main__":
    main()
