#!/usr/bin/env python3
"""
Step 9.1: 干预策略设计与仿真框架
基于训练好的模型设计不同的干预策略，模拟对生理信号恢复的影响
"""

import os
import sys
import logging
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from pathlib import Path
from datetime import datetime, timedelta
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from sklearn.preprocessing import StandardScaler
import json
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('step9_1_intervention_strategy_design.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class PyTorchRegressionModel(nn.Module):
    """PyTorch神经网络回归模型，支持GPU加速."""
    
    def __init__(self, input_size: int, hidden_sizes: list = [64, 32, 16], dropout_rate: float = 0.2):
        super(PyTorchRegressionModel, self).__init__()
        
        layers = []
        prev_size = input_size
        
        for hidden_size in hidden_sizes:
            layers.extend([
                nn.Linear(prev_size, hidden_size),
                nn.ReLU(),
                nn.Dropout(dropout_rate)
            ])
            prev_size = hidden_size
        
        # Output layer
        layers.append(nn.Linear(prev_size, 1))
        
        self.network = nn.Sequential(*layers)
    
    def forward(self, x):
        return self.network(x)

class InterventionStrategyDesigner:
    """干预策略设计器."""
    
    def __init__(self, device: str = 'auto'):
        self.device = self._setup_device(device)
        self.intervention_strategies = {}
        logger.info(f"Initialized InterventionStrategyDesigner on {self.device}")
    
    def _setup_device(self, device: str) -> torch.device:
        """Setup computation device."""
        if device == 'auto':
            if torch.cuda.is_available():
                device = 'cuda'
                logger.info(f"CUDA available: {torch.cuda.get_device_name()}")
                logger.info(f"CUDA capability: {torch.cuda.get_device_capability()}")
                logger.info(f"CUDA memory: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB")
            else:
                device = 'cpu'
                logger.info("CUDA not available, using CPU")
        
        return torch.device(device)
    
    def load_clean_data(self, dataset_name: str, window_size: str) -> pd.DataFrame:
        """加载清理后的数据."""
        try:
            file_path = f"/mnt/d/data_analysis/processed/lri_calculation/lri_{dataset_name}_{window_size}_clean.csv"
            df = pd.read_csv(file_path)
            logger.info(f"Loaded clean data: {df.shape} from {file_path}")
            return df
        except Exception as e:
            logger.error(f"Error loading clean data for {dataset_name}_{window_size}: {e}")
            return pd.DataFrame()
    
    def prepare_features_and_target(self, df: pd.DataFrame) -> tuple:
        """准备特征和目标变量."""
        try:
            # 排除非特征列
            exclude_cols = ['window_id', 'window_size_seconds', 'sample_count']
            feature_cols = [col for col in df.columns if col not in exclude_cols]
            
            # 找到目标变量
            target_candidates = ['recovery_pattern_score', 'stress_release_efficiency', 'volatility_recovery_index', 'trend_recovery_score']
            target_col = None
            for candidate in target_candidates:
                if candidate in df.columns:
                    target_col = candidate
                    break
            
            if not target_col:
                logger.error("No target variable found")
                return None, None, None, None
            
            feature_cols = [col for col in feature_cols if col != target_col]
            
            X = df[feature_cols].values
            y = df[target_col].values
            
            return X, y, feature_cols, target_col
            
        except Exception as e:
            logger.error(f"Error preparing features and target: {e}")
            return None, None, None, None
    
    def train_baseline_model(self, X_train: np.ndarray, y_train: np.ndarray, 
                            X_test: np.ndarray, y_test: np.ndarray, 
                            feature_cols: list) -> dict:
        """训练基准模型."""
        try:
            logger.info("Training baseline model...")
            
            # 数据标准化
            scaler_X = StandardScaler()
            scaler_y = StandardScaler()
            
            X_train_scaled = scaler_X.fit_transform(X_train)
            y_train_scaled = scaler_y.fit_transform(y_train.reshape(-1, 1)).flatten()
            X_test_scaled = scaler_X.transform(X_test)
            y_test_scaled = scaler_y.transform(y_test.reshape(-1, 1)).flatten()
            
            # 转换为PyTorch张量
            X_train_tensor = torch.FloatTensor(X_train_scaled).to(self.device)
            y_train_tensor = torch.FloatTensor(y_train_scaled).to(self.device)
            X_test_tensor = torch.FloatTensor(X_test_scaled).to(self.device)
            y_test_tensor = torch.FloatTensor(y_test_scaled).to(self.device)
            
            # 创建模型
            model = PyTorchRegressionModel(
                input_size=len(feature_cols),
                hidden_sizes=[64, 32, 16],
                dropout_rate=0.2
            ).to(self.device)
            
            # 损失函数和优化器
            criterion = nn.MSELoss()
            optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
            
            # 训练循环
            model.train()
            best_loss = float('inf')
            patience = 10
            patience_counter = 0
            
            for epoch in range(50):
                optimizer.zero_grad()
                outputs = model(X_train_tensor).squeeze()
                loss = criterion(outputs, y_train_tensor)
                loss.backward()
                optimizer.step()
                
                # 早停机制
                if loss.item() < best_loss:
                    best_loss = loss.item()
                    patience_counter = 0
                else:
                    patience_counter += 1
                
                if patience_counter >= patience:
                    break
            
            # 预测
            model.eval()
            with torch.no_grad():
                y_pred_scaled = model(X_test_tensor).squeeze().cpu().numpy()
            
            # 反标准化
            y_pred = scaler_y.inverse_transform(y_pred_scaled.reshape(-1, 1)).flatten()
            
            # 计算性能指标
            mse = mean_squared_error(y_test, y_pred)
            r2 = r2_score(y_test, y_pred)
            mae = mean_absolute_error(y_test, y_pred)
            
            logger.info(f"Baseline model trained - R²: {r2:.3f}")
            
            return {
                'model': model,
                'predictions': y_pred,
                'test_actual': y_test,
                'mse': mse,
                'r2': r2,
                'mae': mae,
                'scaler_X': scaler_X,
                'scaler_y': scaler_y,
                'feature_columns': feature_cols
            }
            
        except Exception as e:
            logger.error(f"Error training baseline model: {e}")
            return None
    
    def design_intervention_strategies(self) -> dict:
        """设计干预策略."""
        try:
            logger.info("Designing intervention strategies...")
            
            strategies = {
                'stress_reduction': {
                    'name': '压力降低干预',
                    'description': '通过降低压力强度来改善恢复模式',
                    'target_features': ['stress_intensity', 'stress_volatility'],
                    'intervention_type': 'multiplicative',
                    'parameters': {
                        'intensity_reduction': [0.1, 0.2, 0.3, 0.4, 0.5],  # 压力强度降低比例
                        'volatility_reduction': [0.1, 0.2, 0.3, 0.4, 0.5]  # 压力波动降低比例
                    }
                },
                'recovery_enhancement': {
                    'name': '恢复增强干预',
                    'description': '通过改善恢复效率来提升恢复模式',
                    'target_features': ['stress_release_efficiency'],
                    'intervention_type': 'additive',
                    'parameters': {
                        'efficiency_boost': [0.05, 0.1, 0.15, 0.2, 0.25]  # 恢复效率提升
                    }
                },
                'pattern_optimization': {
                    'name': '模式优化干预',
                    'description': '通过优化恢复模式来改善整体表现',
                    'target_features': ['recovery_pattern_score.1'],
                    'intervention_type': 'additive',
                    'parameters': {
                        'pattern_improvement': [0.05, 0.1, 0.15, 0.2, 0.25]  # 模式改善
                    }
                },
                'comprehensive_intervention': {
                    'name': '综合干预',
                    'description': '同时改善多个特征的综合干预策略',
                    'target_features': ['stress_intensity', 'stress_volatility', 'stress_release_efficiency'],
                    'intervention_type': 'combined',
                    'parameters': {
                        'intensity_reduction': [0.15, 0.25, 0.35],
                        'volatility_reduction': [0.1, 0.2, 0.3],
                        'efficiency_boost': [0.08, 0.15, 0.22]
                    }
                },
                'adaptive_intervention': {
                    'name': '自适应干预',
                    'description': '根据当前状态自适应调整的干预策略',
                    'target_features': ['wt_mean', 'wt_std'],
                    'intervention_type': 'adaptive',
                    'parameters': {
                        'baseline_threshold': 0.5,  # 基线阈值
                        'intervention_strength': [0.1, 0.2, 0.3, 0.4, 0.5]
                    }
                }
            }
            
            return strategies
            
        except Exception as e:
            logger.error(f"Error designing intervention strategies: {e}")
            return {}
    
    def simulate_intervention(self, baseline_model: dict, X_data: np.ndarray, 
                            strategy: dict, intervention_params: dict) -> dict:
        """模拟干预效果."""
        try:
            model = baseline_model['model']
            scaler_X = baseline_model['scaler_X']
            scaler_y = baseline_model['scaler_y']
            feature_cols = baseline_model['feature_columns']
            
            # 复制原始数据
            X_intervened = X_data.copy()
            
            # 根据干预策略修改特征
            if strategy['intervention_type'] == 'multiplicative':
                # 乘法干预（降低压力）
                for feature_name, reduction in intervention_params.items():
                    if feature_name in feature_cols:
                        feature_idx = feature_cols.index(feature_name)
                        X_intervened[:, feature_idx] *= (1 - reduction)
            
            elif strategy['intervention_type'] == 'additive':
                # 加法干预（提升恢复）
                for feature_name, boost in intervention_params.items():
                    if feature_name in feature_cols:
                        feature_idx = feature_cols.index(feature_name)
                        X_intervened[:, feature_idx] += boost
            
            elif strategy['intervention_type'] == 'combined':
                # 组合干预
                for feature_name, value in intervention_params.items():
                    if feature_name in feature_cols:
                        feature_idx = feature_cols.index(feature_name)
                        if 'reduction' in feature_name:
                            X_intervened[:, feature_idx] *= (1 - value)
                        elif 'boost' in feature_name:
                            X_intervened[:, feature_idx] += value
            
            elif strategy['intervention_type'] == 'adaptive':
                # 自适应干预
                baseline_threshold = intervention_params['baseline_threshold']
                intervention_strength = intervention_params['intervention_strength']
                
                # 确保intervention_strength是列表
                if not isinstance(intervention_strength, list):
                    intervention_strength = [intervention_strength]
                
                for feature_name in strategy['target_features']:
                    if feature_name in feature_cols:
                        feature_idx = feature_cols.index(feature_name)
                        # 根据基线阈值决定干预强度
                        feature_values = X_intervened[:, feature_idx]
                        intervention_mask = feature_values > baseline_threshold
                        
                        # 使用第一个强度值进行干预
                        strength = intervention_strength[0] if intervention_strength else 0.2
                        X_intervened[intervention_mask, feature_idx] *= (1 - strength)
            
            # 使用模型预测干预后的结果
            X_intervened_scaled = scaler_X.transform(X_intervened)
            X_intervened_tensor = torch.FloatTensor(X_intervened_scaled).to(self.device)
            
            model.eval()
            with torch.no_grad():
                y_pred_scaled = model(X_intervened_tensor).squeeze().cpu().numpy()
            
            # 反标准化
            y_pred_intervened = scaler_y.inverse_transform(y_pred_scaled.reshape(-1, 1)).flatten()
            
            return {
                'intervened_features': X_intervened,
                'predicted_outcome': y_pred_intervened,
                'intervention_params': intervention_params
            }
            
        except Exception as e:
            logger.error(f"Error simulating intervention: {e}")
            return None
    
    def evaluate_intervention_effectiveness(self, baseline_predictions: np.ndarray, 
                                         intervened_predictions: np.ndarray) -> dict:
        """评估干预效果."""
        try:
            # 计算改善指标
            improvement = intervened_predictions - baseline_predictions
            
            evaluation = {
                'mean_improvement': np.mean(improvement),
                'std_improvement': np.std(improvement),
                'median_improvement': np.median(improvement),
                'improvement_rate': np.mean(improvement > 0),
                'significant_improvement_rate': np.mean(improvement > 0.1),
                'max_improvement': np.max(improvement),
                'min_improvement': np.min(improvement),
                'improvement_distribution': {
                    'positive': np.sum(improvement > 0),
                    'neutral': np.sum(np.abs(improvement) <= 0.01),
                    'negative': np.sum(improvement < -0.01)
                }
            }
            
            return evaluation
            
        except Exception as e:
            logger.error(f"Error evaluating intervention effectiveness: {e}")
            return {}
    
    def comprehensive_intervention_simulation(self, dataset_name: str, window_size: str) -> dict:
        """综合干预仿真."""
        try:
            logger.info(f"Starting comprehensive intervention simulation for {dataset_name}_{window_size}")
            
            # 加载数据
            df = self.load_clean_data(dataset_name, window_size)
            if df.empty:
                return {'error': 'Failed to load data'}
            
            X, y, feature_cols, target_col = self.prepare_features_and_target(df)
            if X is None:
                return {'error': 'Failed to prepare features'}
            
            # 数据分割
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42
            )
            
            # 训练基准模型
            baseline_model = self.train_baseline_model(X_train, y_train, X_test, y_test, feature_cols)
            if not baseline_model:
                return {'error': 'Failed to train baseline model'}
            
            # 获取基准预测
            baseline_predictions = baseline_model['predictions']
            
            # 设计干预策略
            strategies = self.design_intervention_strategies()
            
            # 仿真结果
            simulation_results = {
                'dataset': dataset_name,
                'window_size': window_size,
                'target_variable': target_col,
                'baseline_performance': {
                    'r2': baseline_model['r2'],
                    'mse': baseline_model['mse'],
                    'mae': baseline_model['mae']
                },
                'intervention_results': {}
            }
            
            # 对每个策略进行仿真
            for strategy_name, strategy in strategies.items():
                logger.info(f"Simulating intervention: {strategy['name']}")
                
                strategy_results = {
                    'strategy_info': strategy,
                    'parameter_results': {}
                }
                
                # 获取参数组合
                param_names = list(strategy['parameters'].keys())
                param_values = list(strategy['parameters'].values())
                
                # 过滤掉非列表参数（如baseline_threshold）
                list_params = {}
                for name, values in strategy['parameters'].items():
                    if isinstance(values, list):
                        list_params[name] = values
                
                # 生成参数组合
                if len(list_params) == 0:
                    # 没有列表参数，使用默认参数
                    param_dict = strategy['parameters']
                    result = self.simulate_intervention(baseline_model, X_test, strategy, param_dict)
                    
                    if result:
                        effectiveness = self.evaluate_intervention_effectiveness(
                            baseline_predictions, result['predicted_outcome']
                        )
                        
                        strategy_results['parameter_results'][str(param_dict)] = {
                            'intervention_result': result,
                            'effectiveness': effectiveness
                        }
                elif len(list_params) == 1:
                    # 单参数
                    list_param_name = list(list_params.keys())[0]
                    list_param_values = list_params[list_param_name]
                    
                    for param_value in list_param_values:
                        param_dict = strategy['parameters'].copy()
                        param_dict[list_param_name] = param_value
                        
                        result = self.simulate_intervention(baseline_model, X_test, strategy, param_dict)
                        
                        if result:
                            effectiveness = self.evaluate_intervention_effectiveness(
                                baseline_predictions, result['predicted_outcome']
                            )
                            
                            strategy_results['parameter_results'][str(param_dict)] = {
                                'intervention_result': result,
                                'effectiveness': effectiveness
                            }
                
                elif len(list_params) == 2:
                    # 双参数组合
                    list_param_names = list(list_params.keys())
                    list_param_values = list(list_params.values())
                    
                    for param1 in list_param_values[0]:
                        for param2 in list_param_values[1]:
                            param_dict = strategy['parameters'].copy()
                            param_dict[list_param_names[0]] = param1
                            param_dict[list_param_names[1]] = param2
                            
                            result = self.simulate_intervention(baseline_model, X_test, strategy, param_dict)
                            
                            if result:
                                effectiveness = self.evaluate_intervention_effectiveness(
                                    baseline_predictions, result['predicted_outcome']
                                )
                                
                                strategy_results['parameter_results'][str(param_dict)] = {
                                    'intervention_result': result,
                                    'effectiveness': effectiveness
                                }
                
                elif len(list_params) == 3:
                    # 三参数组合（限制组合数量）
                    list_param_names = list(list_params.keys())
                    list_param_values = list(list_params.values())
                    
                    for param1 in list_param_values[0][:3]:  # 限制前3个值
                        for param2 in list_param_values[1][:3]:
                            for param3 in list_param_values[2][:3]:
                                param_dict = strategy['parameters'].copy()
                                param_dict[list_param_names[0]] = param1
                                param_dict[list_param_names[1]] = param2
                                param_dict[list_param_names[2]] = param3
                                
                                result = self.simulate_intervention(baseline_model, X_test, strategy, param_dict)
                                
                                if result:
                                    effectiveness = self.evaluate_intervention_effectiveness(
                                        baseline_predictions, result['predicted_outcome']
                                    )
                                    
                                    strategy_results['parameter_results'][str(param_dict)] = {
                                        'intervention_result': result,
                                        'effectiveness': effectiveness
                                    }
                
                # 找到最佳参数组合
                best_params = None
                best_improvement = -float('inf')
                
                for param_str, param_result in strategy_results['parameter_results'].items():
                    improvement = param_result['effectiveness']['mean_improvement']
                    if improvement > best_improvement:
                        best_improvement = improvement
                        best_params = param_str
                
                strategy_results['best_parameters'] = best_params
                strategy_results['best_improvement'] = best_improvement
                
                simulation_results['intervention_results'][strategy_name] = strategy_results
                
                logger.info(f"  Best improvement: {best_improvement:.4f} with params: {best_params}")
            
            return simulation_results
            
        except Exception as e:
            logger.error(f"Error in comprehensive intervention simulation: {e}")
            return {'error': str(e)}

def main():
    """主函数."""
    try:
        logger.info("Starting Step 9.1: Intervention Strategy Design")
        
        # 数据集配置
        dataset = 'DRIVE_DB'  # 使用表现最好的数据集
        window_size = '60s'   # 使用最佳时间窗口
        
        output_dir = '/mnt/d/data_analysis/processed/step9_intervention_simulation'
        Path(output_dir).mkdir(exist_ok=True)
        
        # 初始化干预策略设计器
        designer = InterventionStrategyDesigner(device='auto')
        
        # 执行综合干预仿真
        logger.info(f"Executing intervention simulation for {dataset}_{window_size}")
        
        simulation_results = designer.comprehensive_intervention_simulation(dataset, window_size)
        
        if 'error' in simulation_results:
            logger.error(f"Intervention simulation failed: {simulation_results['error']}")
            return
        
        # 保存结果
        output_file = Path(output_dir) / f'intervention_simulation_{dataset}_{window_size}_results.json'
        with open(output_file, 'w') as f:
            json.dump(simulation_results, f, indent=2, default=str)
        
        logger.info(f"Intervention simulation results saved: {output_file}")
        
        # 分析结果
        logger.info(f"\n{'='*60}")
        logger.info("Intervention Simulation Results Summary")
        logger.info(f"{'='*60}")
        
        logger.info(f"Dataset: {simulation_results['dataset']}")
        logger.info(f"Window Size: {simulation_results['window_size']}")
        logger.info(f"Target Variable: {simulation_results['target_variable']}")
        
        baseline_perf = simulation_results['baseline_performance']
        logger.info(f"Baseline Performance:")
        logger.info(f"  R² = {baseline_perf['r2']:.3f}")
        logger.info(f"  MSE = {baseline_perf['mse']:.4f}")
        logger.info(f"  MAE = {baseline_perf['mae']:.4f}")
        
        logger.info(f"\nIntervention Strategy Results:")
        intervention_results = simulation_results['intervention_results']
        
        for strategy_name, strategy_result in intervention_results.items():
            strategy_info = strategy_result['strategy_info']
            best_improvement = strategy_result['best_improvement']
            
            logger.info(f"  {strategy_info['name']}:")
            logger.info(f"    Best Improvement: {best_improvement:.4f}")
            logger.info(f"    Best Parameters: {strategy_result['best_parameters']}")
            logger.info(f"    Description: {strategy_info['description']}")
        
        # 找到最有效的干预策略
        best_strategy = None
        best_overall_improvement = -float('inf')
        
        for strategy_name, strategy_result in intervention_results.items():
            improvement = strategy_result['best_improvement']
            if improvement > best_overall_improvement:
                best_overall_improvement = improvement
                best_strategy = strategy_name
        
        if best_strategy:
            logger.info(f"\n🏆 Most Effective Intervention Strategy:")
            logger.info(f"  Strategy: {intervention_results[best_strategy]['strategy_info']['name']}")
            logger.info(f"  Improvement: {best_overall_improvement:.4f}")
            logger.info(f"  Parameters: {intervention_results[best_strategy]['best_parameters']}")
        
        logger.info(f"\n{'='*60}")
        logger.info("Step 9.1 Intervention Strategy Design Completed Successfully!")
        logger.info(f"{'='*60}")
        
        logger.info("🎉 Key Achievements:")
        logger.info("  ✓ Intervention strategy design")
        logger.info("  ✓ Comprehensive parameter testing")
        logger.info("  ✓ Intervention effectiveness evaluation")
        logger.info("  ✓ Best strategy identification")
        logger.info("  ✓ GPU-accelerated simulation")
        
    except Exception as e:
        logger.error(f"Error in main execution: {e}")
        raise

if __name__ == "__main__":
    main()
