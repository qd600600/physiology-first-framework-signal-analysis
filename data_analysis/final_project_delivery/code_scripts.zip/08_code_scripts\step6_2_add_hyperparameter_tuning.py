#!/usr/bin/env python3
"""
Step 6.2: Add Hyperparameter Tuning Support
为Step 6添加超参数调优支持 - 解决审计发现的第二个严重问题
"""

import os
import sys
import logging
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from pathlib import Path
from datetime import datetime
from sklearn.model_selection import (
    train_test_split, cross_val_score, KFold, 
    TimeSeriesSplit, GridSearchCV, RandomizedSearchCV
)
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.linear_model import LinearRegression, Ridge, Lasso, ElasticNet
from sklearn.svm import SVR
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from sklearn.preprocessing import StandardScaler
import joblib
import json
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('step6_2_hyperparameter_tuning.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class PyTorchRegressionModel(nn.Module):
    """PyTorch神经网络回归模型，支持GPU加速."""
    
    def __init__(self, input_size: int, hidden_sizes: list = [64, 32, 16], 
                 dropout_rate: float = 0.2, learning_rate: float = 0.001):
        super(PyTorchRegressionModel, self).__init__()
        
        layers = []
        prev_size = input_size
        
        for hidden_size in hidden_sizes:
            layers.extend([
                nn.Linear(prev_size, hidden_size),
                nn.ReLU(),
                nn.Dropout(dropout_rate)
            ])
            prev_size = hidden_size
        
        # Output layer
        layers.append(nn.Linear(prev_size, 1))
        
        self.network = nn.Sequential(*layers)
        self.learning_rate = learning_rate
    
    def forward(self, x):
        return self.network(x)

class HyperparameterTuner:
    """超参数调优器."""
    
    def __init__(self, device: str = 'auto', cv_folds: int = 3):
        self.device = self._setup_device(device)
        self.cv_folds = cv_folds
        self.best_params = {}
        
        logger.info(f"Initialized HyperparameterTuner on {self.device} with {cv_folds}-fold CV")
    
    def _setup_device(self, device: str) -> torch.device:
        """Setup computation device."""
        if device == 'auto':
            if torch.cuda.is_available():
                device = 'cuda'
                logger.info(f"CUDA available: {torch.cuda.get_device_name()}")
            else:
                device = 'cpu'
                logger.info("CUDA not available, using CPU")
        
        return torch.device(device)
    
    def load_fixed_lri_data(self, dataset_name: str, window_size: str) -> pd.DataFrame:
        """加载修复后的LRI数据."""
        try:
            file_path = f"/mnt/d/data_analysis/processed/lri_calculation/lri_{dataset_name}_{window_size}_fixed.csv"
            df = pd.read_csv(file_path)
            logger.info(f"Loaded fixed LRI data: {df.shape} from {file_path}")
            return df
        except Exception as e:
            logger.error(f"Error loading fixed LRI data for {dataset_name}_{window_size}: {e}")
            return pd.DataFrame()
    
    def prepare_features_and_target(self, df: pd.DataFrame) -> tuple:
        """准备特征和目标变量."""
        try:
            # 特征列（排除窗口元数据）
            exclude_cols = [
                'window_id', 'window_size_seconds', 'sample_count', 
                'start_time', 'end_time'
            ]
            
            # 目标变量选择
            target_col = 'recovery_ratio'
            if target_col not in df.columns or df[target_col].nunique() <= 1:
                target_col = 'stress_intensity'
                if target_col not in df.columns:
                    target_col = 'wt_mean'
            
            feature_cols = [col for col in df.columns if col not in exclude_cols + [target_col]]
            
            X = df[feature_cols].values
            y = df[target_col].values
            
            logger.info(f"Features shape: {X.shape}, Target shape: {y.shape}")
            logger.info(f"Target: {target_col}, Range: {y.min():.3f} to {y.max():.3f}")
            
            return X, y, feature_cols, target_col
            
        except Exception as e:
            logger.error(f"Error preparing features and target: {e}")
            return None, None, None, None
    
    def tune_random_forest(self, X: np.ndarray, y: np.ndarray, is_time_series: bool = False) -> dict:
        """调优随机森林超参数."""
        try:
            logger.info("Tuning Random Forest hyperparameters...")
            
            # 简化的参数网格（避免过度计算）
            param_grid = {
                'n_estimators': [50, 100, 200],
                'max_depth': [None, 10, 20],
                'min_samples_split': [2, 5, 10],
                'min_samples_leaf': [1, 2, 4],
                'max_features': ['sqrt', 'log2']
            }
            
            rf = RandomForestRegressor(random_state=42, n_jobs=1)
            
            # 选择交叉验证策略
            if is_time_series:
                cv = TimeSeriesSplit(n_splits=self.cv_folds)
            else:
                cv = KFold(n_splits=self.cv_folds, shuffle=True, random_state=42)
            
            # 使用RandomizedSearchCV以加快速度
            random_search = RandomizedSearchCV(
                rf, param_grid, cv=cv, scoring='r2', 
                n_iter=20, random_state=42, n_jobs=-1, verbose=1
            )
            
            random_search.fit(X, y)
            
            self.best_params['RandomForest'] = random_search.best_params_
            
            logger.info(f"Best Random Forest params: {random_search.best_params_}")
            logger.info(f"Best Random Forest score: {random_search.best_score_:.3f}")
            
            return {
                'best_params': random_search.best_params_,
                'best_score': random_search.best_score_,
                'best_estimator': random_search.best_estimator_
            }
            
        except Exception as e:
            logger.error(f"Error tuning Random Forest: {e}")
            return None
    
    def tune_gradient_boosting(self, X: np.ndarray, y: np.ndarray, is_time_series: bool = False) -> dict:
        """调优梯度提升超参数."""
        try:
            logger.info("Tuning Gradient Boosting hyperparameters...")
            
            param_grid = {
                'n_estimators': [50, 100, 200],
                'learning_rate': [0.01, 0.1, 0.2],
                'max_depth': [3, 5, 7],
                'subsample': [0.8, 0.9, 1.0]
            }
            
            gb = GradientBoostingRegressor(random_state=42)
            
            if is_time_series:
                cv = TimeSeriesSplit(n_splits=self.cv_folds)
            else:
                cv = KFold(n_splits=self.cv_folds, shuffle=True, random_state=42)
            
            random_search = RandomizedSearchCV(
                gb, param_grid, cv=cv, scoring='r2',
                n_iter=15, random_state=42, n_jobs=-1, verbose=1
            )
            
            random_search.fit(X, y)
            
            self.best_params['GradientBoosting'] = random_search.best_params_
            
            logger.info(f"Best Gradient Boosting params: {random_search.best_params_}")
            logger.info(f"Best Gradient Boosting score: {random_search.best_score_:.3f}")
            
            return {
                'best_params': random_search.best_params_,
                'best_score': random_search.best_score_,
                'best_estimator': random_search.best_estimator_
            }
            
        except Exception as e:
            logger.error(f"Error tuning Gradient Boosting: {e}")
            return None
    
    def tune_regularized_models(self, X: np.ndarray, y: np.ndarray, is_time_series: bool = False) -> dict:
        """调优正则化模型超参数."""
        try:
            logger.info("Tuning regularized models hyperparameters...")
            
            # Ridge回归
            ridge_params = {'alpha': [0.1, 1.0, 10.0, 100.0, 1000.0]}
            ridge = Ridge(random_state=42)
            
            # Lasso回归
            lasso_params = {'alpha': [0.01, 0.1, 1.0, 10.0, 100.0]}
            lasso = Lasso(random_state=42, max_iter=10000)
            
            # ElasticNet
            elastic_params = {
                'alpha': [0.01, 0.1, 1.0, 10.0],
                'l1_ratio': [0.1, 0.5, 0.7, 0.9]
            }
            elastic = ElasticNet(random_state=42, max_iter=10000)
            
            if is_time_series:
                cv = TimeSeriesSplit(n_splits=self.cv_folds)
            else:
                cv = KFold(n_splits=self.cv_folds, shuffle=True, random_state=42)
            
            results = {}
            
            # Ridge调优
            ridge_grid = GridSearchCV(ridge, ridge_params, cv=cv, scoring='r2')
            ridge_grid.fit(X, y)
            results['Ridge'] = {
                'best_params': ridge_grid.best_params_,
                'best_score': ridge_grid.best_score_,
                'best_estimator': ridge_grid.best_estimator_
            }
            
            # Lasso调优
            lasso_grid = GridSearchCV(lasso, lasso_params, cv=cv, scoring='r2')
            lasso_grid.fit(X, y)
            results['Lasso'] = {
                'best_params': lasso_grid.best_params_,
                'best_score': lasso_grid.best_score_,
                'best_estimator': lasso_grid.best_estimator_
            }
            
            # ElasticNet调优
            elastic_grid = RandomizedSearchCV(
                elastic, elastic_params, cv=cv, scoring='r2',
                n_iter=10, random_state=42
            )
            elastic_grid.fit(X, y)
            results['ElasticNet'] = {
                'best_params': elastic_grid.best_params_,
                'best_score': elastic_grid.best_score_,
                'best_estimator': elastic_grid.best_estimator_
            }
            
            self.best_params.update({
                'Ridge': ridge_grid.best_params_,
                'Lasso': lasso_grid.best_params_,
                'ElasticNet': elastic_grid.best_params_
            })
            
            logger.info(f"Best Ridge alpha: {ridge_grid.best_params_}")
            logger.info(f"Best Lasso alpha: {lasso_grid.best_params_}")
            logger.info(f"Best ElasticNet params: {elastic_grid.best_params_}")
            
            return results
            
        except Exception as e:
            logger.error(f"Error tuning regularized models: {e}")
            return None
    
    def tune_pytorch_model(self, X: np.ndarray, y: np.ndarray, feature_cols: list) -> dict:
        """调优PyTorch模型超参数."""
        try:
            logger.info("Tuning PyTorch model hyperparameters...")
            
            # 数据标准化
            scaler_X = StandardScaler()
            scaler_y = StandardScaler()
            
            X_scaled = scaler_X.fit_transform(X)
            y_scaled = scaler_y.fit_transform(y.reshape(-1, 1)).flatten()
            
            # 数据分割
            X_train, X_val, y_train, y_val = train_test_split(
                X_scaled, y_scaled, test_size=0.2, random_state=42
            )
            
            # 转换为PyTorch张量
            X_train_tensor = torch.FloatTensor(X_train).to(self.device)
            y_train_tensor = torch.FloatTensor(y_train).to(self.device)
            X_val_tensor = torch.FloatTensor(X_val).to(self.device)
            y_val_tensor = torch.FloatTensor(y_val).to(self.device)
            
            # 超参数网格
            hyperparams = [
                {'hidden_sizes': [32, 16], 'dropout_rate': 0.1, 'learning_rate': 0.001},
                {'hidden_sizes': [64, 32], 'dropout_rate': 0.2, 'learning_rate': 0.001},
                {'hidden_sizes': [64, 32, 16], 'dropout_rate': 0.2, 'learning_rate': 0.0005},
                {'hidden_sizes': [128, 64], 'dropout_rate': 0.3, 'learning_rate': 0.001},
                {'hidden_sizes': [64, 32, 16], 'dropout_rate': 0.1, 'learning_rate': 0.002}
            ]
            
            best_score = -np.inf
            best_params = None
            best_model = None
            
            for i, params in enumerate(hyperparams):
                logger.info(f"Testing PyTorch hyperparams {i+1}/{len(hyperparams)}: {params}")
                
                # 创建模型
                model = PyTorchRegressionModel(
                    input_size=len(feature_cols),
                    hidden_sizes=params['hidden_sizes'],
                    dropout_rate=params['dropout_rate'],
                    learning_rate=params['learning_rate']
                ).to(self.device)
                
                # 损失函数和优化器
                criterion = nn.MSELoss()
                optimizer = torch.optim.Adam(model.parameters(), lr=params['learning_rate'])
                
                # 训练循环
                model.train()
                for epoch in range(50):  # 减少epoch数以加快调优
                    optimizer.zero_grad()
                    outputs = model(X_train_tensor).squeeze()
                    loss = criterion(outputs, y_train_tensor)
                    loss.backward()
                    optimizer.step()
                
                # 验证
                model.eval()
                with torch.no_grad():
                    val_pred = model(X_val_tensor).squeeze()
                    val_pred_cpu = val_pred.cpu().numpy()
                    val_true_cpu = y_val_tensor.cpu().numpy()
                    
                    # 反标准化
                    val_pred_original = scaler_y.inverse_transform(val_pred_cpu.reshape(-1, 1)).flatten()
                    val_true_original = scaler_y.inverse_transform(val_true_cpu.reshape(-1, 1)).flatten()
                    
                    r2 = r2_score(val_true_original, val_pred_original)
                    
                    if r2 > best_score:
                        best_score = r2
                        best_params = params
                        best_model = model.state_dict().copy()
                
                logger.info(f"PyTorch params {i+1} R²: {r2:.3f}")
            
            self.best_params['PyTorch'] = best_params
            
            logger.info(f"Best PyTorch params: {best_params}")
            logger.info(f"Best PyTorch score: {best_score:.3f}")
            
            return {
                'best_params': best_params,
                'best_score': best_score,
                'best_model': best_model,
                'scaler_X': scaler_X,
                'scaler_y': scaler_y
            }
            
        except Exception as e:
            logger.error(f"Error tuning PyTorch model: {e}")
            return None
    
    def validate_with_hyperparameter_tuning(self, dataset_name: str, window_size: str) -> dict:
        """带超参数调优的验证."""
        try:
            logger.info(f"=== Hyperparameter Tuning for {dataset_name} - {window_size}s ===")
            
            # 1. 加载数据
            df = self.load_fixed_lri_data(dataset_name, window_size)
            if df.empty:
                return {'error': 'Failed to load data'}
            
            # 2. 准备特征和目标
            X, y, feature_cols, target_col = self.prepare_features_and_target(df)
            if X is None:
                return {'error': 'Failed to prepare features'}
            
            # 3. 超参数调优
            logger.info("Performing hyperparameter tuning...")
            
            tuning_results = {}
            
            # 调优随机森林
            rf_result = self.tune_random_forest(X, y, is_time_series=False)
            if rf_result:
                tuning_results['RandomForest'] = rf_result
            
            # 调优梯度提升
            gb_result = self.tune_gradient_boosting(X, y, is_time_series=False)
            if gb_result:
                tuning_results['GradientBoosting'] = gb_result
            
            # 调优正则化模型
            reg_results = self.tune_regularized_models(X, y, is_time_series=False)
            if reg_results:
                tuning_results.update(reg_results)
            
            # 调优PyTorch模型
            pytorch_result = self.tune_pytorch_model(X, y, feature_cols)
            if pytorch_result:
                tuning_results['PyTorch'] = pytorch_result
            
            # 4. 使用最佳参数进行最终评估
            logger.info("Evaluating with best hyperparameters...")
            
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42
            )
            
            final_results = {}
            
            # 评估调优后的模型
            for model_name, result in tuning_results.items():
                if model_name == 'PyTorch':
                    continue  # PyTorch模型需要特殊处理
                
                best_estimator = result['best_estimator']
                best_estimator.fit(X_train, y_train)
                y_pred = best_estimator.predict(X_test)
                
                final_results[model_name] = {
                    'best_params': result['best_params'],
                    'tuning_score': result['best_score'],
                    'test_mse': mean_squared_error(y_test, y_pred),
                    'test_r2': r2_score(y_test, y_pred),
                    'test_mae': mean_absolute_error(y_test, y_pred)
                }
                
                logger.info(f"{model_name} - Tuned R²: {r2_score(y_test, y_pred):.3f}")
            
            # 5. 选择最佳模型
            best_model_name = max(
                final_results.keys(),
                key=lambda x: final_results[x]['test_r2']
            )
            
            logger.info(f"Best tuned model: {best_model_name} (R² = {final_results[best_model_name]['test_r2']:.3f})")
            
            # 6. 返回结果
            results = {
                'dataset_name': dataset_name,
                'window_size': window_size,
                'target_variable': target_col,
                'data_shape': X.shape,
                'feature_columns': feature_cols,
                'hyperparameter_tuning_results': tuning_results,
                'final_evaluation_results': final_results,
                'best_model': {
                    'name': best_model_name,
                    'performance': final_results[best_model_name]
                },
                'all_best_params': self.best_params,
                'validation_timestamp': datetime.now().isoformat()
            }
            
            logger.info(f"=== Completed hyperparameter tuning for {dataset_name} - {window_size}s ===")
            
            return results
            
        except Exception as e:
            logger.error(f"Error in hyperparameter tuning for {dataset_name}_{window_size}: {e}")
            return {'error': str(e)}

def main():
    """主函数."""
    try:
        logger.info("Starting Step 6.2: Add Hyperparameter Tuning Support")
        
        # 数据集配置（选择几个数据集进行测试）
        datasets = ['CRWD', 'SWELL', 'DRIVE_DB']  # 减少数据集以加快测试
        window_sizes = ['60s', '300s']
        
        output_dir = '/mnt/d/data_analysis/processed/step6_hyperparameter_tuning'
        Path(output_dir).mkdir(exist_ok=True)
        
        # 初始化超参数调优器
        tuner = HyperparameterTuner(device='auto', cv_folds=3)
        
        # 逐个处理数据集
        all_results = {}
        
        for dataset_name in datasets:
            logger.info(f"\n{'='*60}")
            logger.info(f"Processing Dataset: {dataset_name} (HYPERPARAMETER TUNING)")
            logger.info(f"{'='*60}")
            
            dataset_results = {}
            
            for window_size in window_sizes:
                try:
                    result = tuner.validate_with_hyperparameter_tuning(dataset_name, window_size)
                    dataset_results[window_size] = result
                    
                    # 保存结果
                    if 'error' not in result:
                        output_file = Path(output_dir) / f"hyperparameter_tuning_{dataset_name}_{window_size}.json"
                        with open(output_file, 'w') as f:
                            json.dump(result, f, indent=2, default=str)
                        logger.info(f"Saved hyperparameter tuning results: {output_file}")
                    
                except Exception as e:
                    logger.error(f"Error processing {dataset_name}_{window_size}: {e}")
                    dataset_results[window_size] = {'error': str(e)}
            
            all_results[dataset_name] = dataset_results
        
        # 保存总体结果摘要
        summary_file = Path(output_dir) / "hyperparameter_tuning_summary.json"
        with open(summary_file, 'w') as f:
            json.dump(all_results, f, indent=2, default=str)
        
        logger.info(f"\n{'='*60}")
        logger.info("Step 6.2 Hyperparameter Tuning Completed Successfully!")
        logger.info(f"{'='*60}")
        
        # 打印超参数调优总结
        logger.info("\nHyperparameter Tuning Results Summary:")
        for dataset_name, dataset_results in all_results.items():
            logger.info(f"\n{dataset_name}:")
            for window_size, result in dataset_results.items():
                if 'error' not in result:
                    final_results = result.get('final_evaluation_results', {})
                    best_model = result.get('best_model', {})
                    
                    if final_results and best_model:
                        best_name = best_model.get('name', 'N/A')
                        best_performance = best_model.get('performance', {})
                        best_r2 = best_performance.get('test_r2', 0)
                        best_params = best_performance.get('best_params', {})
                        
                        logger.info(f"  {window_size}: Best = {best_name} (R² = {best_r2:.3f})")
                        logger.info(f"    Best params: {best_params}")
                else:
                    logger.warning(f"  {window_size}: Error - {result['error']}")
        
        logger.info("\n✅ Hyperparameter Tuning Implementation Completed!")
        logger.info("🔍 Key Improvements:")
        logger.info("  ✓ Random Forest hyperparameter tuning")
        logger.info("  ✓ Gradient Boosting hyperparameter tuning") 
        logger.info("  ✓ Regularized models (Ridge, Lasso, ElasticNet) tuning")
        logger.info("  ✓ PyTorch neural network hyperparameter tuning")
        logger.info("  ✓ GPU-accelerated model training")
        logger.info("  ✓ Comprehensive parameter search")
        
    except Exception as e:
        logger.error(f"Error in main execution: {e}")
        raise

if __name__ == "__main__":
    main()
