#!/usr/bin/env python3
"""
Step 5: LRI Calculation and Time Aggregation
Calculate Localized Relative Index (LRI) for all datasets
"""

import pandas as pd
import numpy as np
import json
import os
import glob
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

def calculate_lri(wt_series, window_size=60, overlap=0.5):
    """
    Calculate Localized Relative Index (LRI) for W(t) time series
    
    LRI(t) = (W(t) - W_baseline(t)) / W_std(t)
    
    Where:
    - W_baseline(t) is the rolling mean over the window
    - W_std(t) is the rolling standard deviation over the window
    - window_size: window size in seconds (default 60s)
    - overlap: overlap ratio for sliding window (default 0.5)
    """
    
    # Calculate rolling statistics
    step_size = int(window_size * (1 - overlap))
    
    # Rolling mean and std with specified step size
    rolling_mean = wt_series.rolling(window=window_size, step=step_size).mean()
    rolling_std = wt_series.rolling(window=window_size, step=step_size).std()
    
    # Calculate LRI
    lri = (wt_series - rolling_mean) / rolling_std
    
    # Handle NaN values (where std is 0 or insufficient data)
    lri = lri.fillna(0)
    
    return lri, rolling_mean, rolling_std

def aggregate_to_time_windows(df, wt_col='wt', time_windows=[300, 600, 1800, 3600]):
    """
    Aggregate LRI data to different time windows
    
    Args:
        df: DataFrame with LRI data
        wt_col: Column name for W(t) data
        time_windows: List of time windows in seconds
    
    Returns:
        Dictionary with aggregated data for each time window
    """
    
    aggregated_data = {}
    
    for window in time_windows:
        # Calculate number of samples per window (assuming 1Hz sampling)
        samples_per_window = window
        
        # Group by time windows and calculate statistics
        df_window = df.copy()
        df_window['time_window'] = df_window.index // samples_per_window
        
        window_stats = df_window.groupby('time_window').agg({
            wt_col: ['mean', 'std', 'min', 'max', 'count'],
            'lri': ['mean', 'std', 'min', 'max', 'count'],
            'rolling_mean': 'mean',
            'rolling_std': 'mean'
        }).reset_index()
        
        # Flatten column names
        window_stats.columns = ['time_window'] + [f"{col[0]}_{col[1]}" for col in window_stats.columns[1:]]
        
        # Calculate additional metrics
        window_stats['lri_magnitude'] = np.abs(window_stats['lri_mean'])
        window_stats['lri_variability'] = window_stats['lri_std']
        window_stats['wt_stress_level'] = window_stats[f'{wt_col}_mean']
        window_stats['wt_stress_variability'] = window_stats[f'{wt_col}_std']
        
        # Add time window duration
        window_stats['window_duration_sec'] = window
        
        aggregated_data[f'{window}s'] = window_stats
    
    return aggregated_data

def process_dataset_lri(dataset_name, wt_file_path, output_dir="processed/lri_data"):
    """
    Process a single dataset for LRI calculation
    
    Args:
        dataset_name: Name of the dataset
        wt_file_path: Path to W(t) timeseries file
        output_dir: Output directory for LRI data
    """
    
    print(f"\n=== Processing {dataset_name} for LRI calculation ===")
    
    # Create output directory
    os.makedirs(output_dir, exist_ok=True)
    
    try:
        # Load W(t) data
        print(f"Loading W(t) data from: {wt_file_path}")
        df = pd.read_parquet(wt_file_path)
        print(f"Loaded {len(df)} rows")
        
        # Identify W(t) column
        wt_cols = [col for col in df.columns if col.lower() in ['wt', 'w_t', 'stress']]
        if not wt_cols:
            print(f"Warning: No W(t) column found in {dataset_name}")
            return False
        
        wt_col = wt_cols[0]  # Use first matching column
        print(f"Using W(t) column: {wt_col}")
        
        # Remove rows with NaN W(t) values
        initial_rows = len(df)
        df = df.dropna(subset=[wt_col])
        print(f"Removed {initial_rows - len(df)} rows with NaN W(t) values")
        
        if len(df) == 0:
            print(f"Error: No valid W(t) data for {dataset_name}")
            return False
        
        # Calculate LRI with different window sizes
        window_sizes = [30, 60, 120, 300]  # 30s, 1min, 2min, 5min
        
        for window_size in window_sizes:
            print(f"Calculating LRI with {window_size}s window...")
            
            # Calculate LRI
            lri, rolling_mean, rolling_std = calculate_lri(
                df[wt_col], 
                window_size=window_size, 
                overlap=0.5
            )
            
            # Create result dataframe
            result_df = df.copy()
            result_df['lri'] = lri
            result_df['rolling_mean'] = rolling_mean
            result_df['rolling_std'] = rolling_std
            result_df['window_size'] = window_size
            
            # Save LRI data
            output_file = os.path.join(
                output_dir, 
                f"lri_{dataset_name}_{window_size}s.parquet"
            )
            result_df.to_parquet(output_file)
            print(f"Saved LRI data to: {output_file}")
            
            # Calculate and save aggregated data
            print(f"Aggregating to time windows...")
            aggregated = aggregate_to_time_windows(
                result_df, 
                wt_col=wt_col,
                time_windows=[300, 600, 1800, 3600]  # 5min, 10min, 30min, 1hr
            )
            
            # Save aggregated data
            for time_window, agg_data in aggregated.items():
                agg_file = os.path.join(
                    output_dir,
                    f"lri_aggregated_{dataset_name}_{window_size}s_{time_window}.parquet"
                )
                agg_data.to_parquet(agg_file)
                print(f"Saved aggregated data ({time_window}): {agg_file}")
            
            # Calculate summary statistics
            lri_stats = {
                'dataset': dataset_name,
                'window_size': window_size,
                'total_samples': len(result_df),
                'valid_lri_samples': len(result_df.dropna(subset=['lri'])),
                'lri_mean': float(result_df['lri'].mean()),
                'lri_std': float(result_df['lri'].std()),
                'lri_min': float(result_df['lri'].min()),
                'lri_max': float(result_df['lri'].max()),
                'lri_range': float(result_df['lri'].max() - result_df['lri'].min()),
                'wt_mean': float(result_df[wt_col].mean()),
                'wt_std': float(result_df[wt_col].std()),
                'processing_timestamp': datetime.now().isoformat()
            }
            
            # Save statistics
            stats_file = os.path.join(
                output_dir,
                f"lri_stats_{dataset_name}_{window_size}s.json"
            )
            with open(stats_file, 'w') as f:
                json.dump(lri_stats, f, indent=2)
            print(f"Saved LRI statistics: {stats_file}")
    
    except Exception as e:
        print(f"Error processing {dataset_name}: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    return True

def main():
    """Main function to process all datasets for LRI calculation"""
    
    print("=== Step 5: LRI Calculation and Time Aggregation ===")
    print(f"Started at: {datetime.now()}")
    
    # Define datasets and their W(t) files
    datasets = {
        'CRWD': 'processed/wt_generation/wt_timeseries_CRWD.parquet',
        'DRIVE_DB': 'processed/wt_generation/wt_timeseries_DRIVE_DB_full_sample.parquet',
        'Mental_Health_Pred': 'processed/wt_generation/wt_timeseries_Mental_Health_Pred.parquet',
        'MMASH': 'processed/wt_generation/wt_timeseries_MMASH.parquet',
        'Non_EEG': 'processed/wt_generation/wt_timeseries_Non_EEG_full_sample.parquet',
        'Nurses': 'processed/wt_generation/wt_timeseries_Nurses_full_sample.parquet',
        'SWELL': 'processed/wt_generation/wt_timeseries_SWELL_complete.parquet',
        'WESAD': 'processed/wt_generation/wt_timeseries_WESAD_full_sample.parquet'
    }
    
    # Process each dataset
    results = {}
    for dataset_name, wt_file in datasets.items():
        if os.path.exists(wt_file):
            success = process_dataset_lri(dataset_name, wt_file)
            results[dataset_name] = success
        else:
            print(f"Warning: W(t) file not found for {dataset_name}: {wt_file}")
            results[dataset_name] = False
    
    # Generate summary report
    summary = {
        'step': 'Step 5: LRI Calculation and Time Aggregation',
        'timestamp': datetime.now().isoformat(),
        'datasets_processed': sum(results.values()),
        'datasets_total': len(datasets),
        'results': results,
        'output_directory': 'processed/lri_data'
    }
    
    summary_file = 'processed/lri_data/step5_lri_calculation_summary.json'
    os.makedirs(os.path.dirname(summary_file), exist_ok=True)
    with open(summary_file, 'w') as f:
        json.dump(summary, f, indent=2)
    
    print(f"\n=== Step 5 Summary ===")
    print(f"Processed {summary['datasets_processed']}/{summary['datasets_total']} datasets")
    print(f"Results: {results}")
    print(f"Summary saved to: {summary_file}")
    print(f"Completed at: {datetime.now()}")

if __name__ == "__main__":
    main()






