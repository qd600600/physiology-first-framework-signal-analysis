#!/usr/bin/env python3
"""
Step 6.4: Add Model Interpretability Analysis
为Step 6添加模型解释性分析 - 解决审计发现的第四个问题
"""

import os
import sys
import logging
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from pathlib import Path
from datetime import datetime
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.svm import SVR
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from sklearn.preprocessing import StandardScaler
import joblib
import json
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('step6_4_model_interpretability.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class PyTorchRegressionModel(nn.Module):
    """PyTorch神经网络回归模型，支持GPU加速."""
    
    def __init__(self, input_size: int, hidden_sizes: list = [64, 32, 16], dropout_rate: float = 0.2):
        super(PyTorchRegressionModel, self).__init__()
        
        layers = []
        prev_size = input_size
        
        for hidden_size in hidden_sizes:
            layers.extend([
                nn.Linear(prev_size, hidden_size),
                nn.ReLU(),
                nn.Dropout(dropout_rate)
            ])
            prev_size = hidden_size
        
        # Output layer
        layers.append(nn.Linear(prev_size, 1))
        
        self.network = nn.Sequential(*layers)
    
    def forward(self, x):
        return self.network(x)

class ModelInterpretabilityAnalyzer:
    """模型解释性分析器."""
    
    def __init__(self, device: str = 'auto'):
        self.device = self._setup_device(device)
        self.models = {}
        
        logger.info(f"Initialized ModelInterpretabilityAnalyzer on {self.device}")
    
    def _setup_device(self, device: str) -> torch.device:
        """Setup computation device."""
        if device == 'auto':
            if torch.cuda.is_available():
                device = 'cuda'
                logger.info(f"CUDA available: {torch.cuda.get_device_name()}")
            else:
                device = 'cpu'
                logger.info("CUDA not available, using CPU")
        
        return torch.device(device)
    
    def load_fixed_lri_data(self, dataset_name: str, window_size: str) -> pd.DataFrame:
        """加载修复后的LRI数据."""
        try:
            file_path = f"/mnt/d/data_analysis/processed/lri_calculation/lri_{dataset_name}_{window_size}_fixed.csv"
            df = pd.read_csv(file_path)
            logger.info(f"Loaded fixed LRI data: {df.shape} from {file_path}")
            return df
        except Exception as e:
            logger.error(f"Error loading fixed LRI data for {dataset_name}_{window_size}: {e}")
            return pd.DataFrame()
    
    def prepare_features_and_target(self, df: pd.DataFrame) -> tuple:
        """准备特征和目标变量."""
        try:
            # 特征列（排除窗口元数据）
            exclude_cols = [
                'window_id', 'window_size_seconds', 'sample_count', 
                'start_time', 'end_time'
            ]
            
            # 目标变量选择
            target_col = 'recovery_ratio'
            if target_col not in df.columns or df[target_col].nunique() <= 1:
                target_col = 'stress_intensity'
                if target_col not in df.columns:
                    target_col = 'wt_mean'
            
            feature_cols = [col for col in df.columns if col not in exclude_cols + [target_col]]
            
            X = df[feature_cols].values
            y = df[target_col].values
            
            logger.info(f"Features shape: {X.shape}, Target shape: {y.shape}")
            logger.info(f"Target: {target_col}, Range: {y.min():.3f} to {y.max():.3f}")
            
            return X, y, feature_cols, target_col
            
        except Exception as e:
            logger.error(f"Error preparing features and target: {e}")
            return None, None, None, None
    
    def train_models(self, X: np.ndarray, y: np.ndarray, feature_names: list) -> dict:
        """训练多种模型."""
        try:
            logger.info("Training multiple models for interpretability analysis...")
            
            # 数据分割
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42
            )
            
            # 数据标准化
            scaler = StandardScaler()
            X_train_scaled = scaler.fit_transform(X_train)
            X_test_scaled = scaler.transform(X_test)
            
            trained_models = {}
            
            # 1. 线性回归模型
            logger.info("Training Linear Regression...")
            lr = LinearRegression()
            lr.fit(X_train_scaled, y_train)
            y_pred_lr = lr.predict(X_test_scaled)
            
            trained_models['LinearRegression'] = {
                'model': lr,
                'predictions': y_pred_lr,
                'test_actual': y_test,
                'r2': r2_score(y_test, y_pred_lr),
                'mse': mean_squared_error(y_test, y_pred_lr)
            }
            
            # 2. 随机森林模型
            logger.info("Training Random Forest...")
            rf = RandomForestRegressor(n_estimators=100, random_state=42)
            rf.fit(X_train, y_train)
            y_pred_rf = rf.predict(X_test)
            
            trained_models['RandomForest'] = {
                'model': rf,
                'predictions': y_pred_rf,
                'test_actual': y_test,
                'r2': r2_score(y_test, y_pred_rf),
                'mse': mean_squared_error(y_test, y_pred_rf)
            }
            
            # 3. 梯度提升模型
            logger.info("Training Gradient Boosting...")
            gb = GradientBoostingRegressor(n_estimators=100, random_state=42)
            gb.fit(X_train, y_train)
            y_pred_gb = gb.predict(X_test)
            
            trained_models['GradientBoosting'] = {
                'model': gb,
                'predictions': y_pred_gb,
                'test_actual': y_test,
                'r2': r2_score(y_test, y_pred_gb),
                'mse': mean_squared_error(y_test, y_pred_gb)
            }
            
            # 4. PyTorch神经网络模型
            logger.info("Training PyTorch Neural Network...")
            pytorch_model = self.train_pytorch_model(X_train_scaled, y_train, X_test_scaled, y_test, len(feature_names))
            if pytorch_model:
                trained_models['PyTorchNN'] = pytorch_model
            
            self.models = trained_models
            
            logger.info("All models trained successfully")
            
            return {
                'models': trained_models,
                'feature_names': feature_names,
                'scaler': scaler
            }
            
        except Exception as e:
            logger.error(f"Error training models: {e}")
            return None
    
    def train_pytorch_model(self, X_train: np.ndarray, y_train: np.ndarray, 
                           X_test: np.ndarray, y_test: np.ndarray, input_size: int) -> dict:
        """训练PyTorch模型."""
        try:
            # 转换为PyTorch张量
            X_train_tensor = torch.FloatTensor(X_train).to(self.device)
            y_train_tensor = torch.FloatTensor(y_train).to(self.device)
            X_test_tensor = torch.FloatTensor(X_test).to(self.device)
            y_test_tensor = torch.FloatTensor(y_test).to(self.device)
            
            # 创建模型
            model = PyTorchRegressionModel(input_size=input_size).to(self.device)
            
            # 损失函数和优化器
            criterion = nn.MSELoss()
            optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
            
            # 训练循环
            model.train()
            for epoch in range(100):
                optimizer.zero_grad()
                outputs = model(X_train_tensor).squeeze()
                loss = criterion(outputs, y_train_tensor)
                loss.backward()
                optimizer.step()
            
            # 预测
            model.eval()
            with torch.no_grad():
                y_pred = model(X_test_tensor).squeeze().cpu().numpy()
            
            return {
                'model': model,
                'predictions': y_pred,
                'test_actual': y_test,
                'r2': r2_score(y_test, y_pred),
                'mse': mean_squared_error(y_test, y_pred)
            }
            
        except Exception as e:
            logger.error(f"Error training PyTorch model: {e}")
            return None
    
    def analyze_feature_importance(self, models: dict, feature_names: list) -> dict:
        """分析特征重要性."""
        try:
            logger.info("Analyzing feature importance...")
            
            importance_analysis = {}
            
            for model_name, model_data in models.items():
                if model_name == 'PyTorchNN':
                    continue  # PyTorch模型需要特殊处理
                
                model = model_data['model']
                
                if hasattr(model, 'feature_importances_'):
                    # 树模型特征重要性
                    importance = model.feature_importances_
                    importance_analysis[model_name] = {
                        'type': 'feature_importance',
                        'importance': dict(zip(feature_names, importance)),
                        'sorted_features': sorted(
                            zip(feature_names, importance), 
                            key=lambda x: x[1], reverse=True
                        )
                    }
                    
                    logger.info(f"{model_name} top 3 features:")
                    for feature, imp in importance_analysis[model_name]['sorted_features'][:3]:
                        logger.info(f"  {feature}: {imp:.3f}")
                
                elif hasattr(model, 'coef_'):
                    # 线性模型系数
                    coef = model.coef_
                    importance_analysis[model_name] = {
                        'type': 'coefficients',
                        'coefficients': dict(zip(feature_names, coef)),
                        'sorted_features': sorted(
                            zip(feature_names, coef), 
                            key=lambda x: abs(x[1]), reverse=True
                        )
                    }
                    
                    logger.info(f"{model_name} top 3 coefficients:")
                    for feature, coef_val in importance_analysis[model_name]['sorted_features'][:3]:
                        logger.info(f"  {feature}: {coef_val:.3f}")
            
            return importance_analysis
            
        except Exception as e:
            logger.error(f"Error analyzing feature importance: {e}")
            return None
    
    def analyze_prediction_errors(self, models: dict, feature_names: list) -> dict:
        """分析预测误差."""
        try:
            logger.info("Analyzing prediction errors...")
            
            error_analysis = {}
            
            for model_name, model_data in models.items():
                y_actual = model_data['test_actual']
                y_pred = model_data['predictions']
                
                # 计算误差
                errors = y_actual - y_pred
                abs_errors = np.abs(errors)
                
                # 找出误差最大的样本
                max_error_idx = np.argmax(abs_errors)
                min_error_idx = np.argmin(abs_errors)
                
                error_analysis[model_name] = {
                    'mean_absolute_error': np.mean(abs_errors),
                    'std_absolute_error': np.std(abs_errors),
                    'max_error': np.max(abs_errors),
                    'min_error': np.min(abs_errors),
                    'worst_prediction': {
                        'index': int(max_error_idx),
                        'actual': float(y_actual[max_error_idx]),
                        'predicted': float(y_pred[max_error_idx]),
                        'error': float(errors[max_error_idx])
                    },
                    'best_prediction': {
                        'index': int(min_error_idx),
                        'actual': float(y_actual[min_error_idx]),
                        'predicted': float(y_pred[min_error_idx]),
                        'error': float(errors[min_error_idx])
                    }
                }
                
                logger.info(f"{model_name} error analysis:")
                logger.info(f"  MAE: {error_analysis[model_name]['mean_absolute_error']:.3f}")
                logger.info(f"  Max error: {error_analysis[model_name]['max_error']:.3f}")
            
            return error_analysis
            
        except Exception as e:
            logger.error(f"Error analyzing prediction errors: {e}")
            return None
    
    def create_interpretability_plots(self, models: dict, feature_names: list, 
                                    output_dir: str, dataset_name: str, window_size: str) -> dict:
        """创建解释性图表."""
        try:
            logger.info("Creating interpretability plots...")
            
            plots = {}
            
            # 1. 特征重要性图
            importance_analysis = self.analyze_feature_importance(models, feature_names)
            
            for model_name, importance_data in importance_analysis.items():
                if importance_data['type'] == 'feature_importance':
                    plt.figure(figsize=(10, 6))
                    
                    features = [item[0] for item in importance_data['sorted_features']]
                    importances = [item[1] for item in importance_data['sorted_features']]
                    
                    plt.barh(features, importances)
                    plt.title(f'Feature Importance - {model_name}')
                    plt.xlabel('Importance')
                    
                    plot_path = Path(output_dir) / f"feature_importance_{model_name}_{dataset_name}_{window_size}.png"
                    plt.savefig(plot_path, dpi=300, bbox_inches='tight')
                    plt.close()
                    
                    plots[f'feature_importance_{model_name}'] = str(plot_path)
                    
                elif importance_data['type'] == 'coefficients':
                    plt.figure(figsize=(10, 6))
                    
                    features = [item[0] for item in importance_data['sorted_features']]
                    coefficients = [item[1] for item in importance_data['sorted_features']]
                    
                    colors = ['red' if c < 0 else 'blue' for c in coefficients]
                    plt.barh(features, coefficients, color=colors)
                    plt.title(f'Feature Coefficients - {model_name}')
                    plt.xlabel('Coefficient Value')
                    plt.axvline(x=0, color='black', linestyle='--', alpha=0.5)
                    
                    plot_path = Path(output_dir) / f"feature_coefficients_{model_name}_{dataset_name}_{window_size}.png"
                    plt.savefig(plot_path, dpi=300, bbox_inches='tight')
                    plt.close()
                    
                    plots[f'feature_coefficients_{model_name}'] = str(plot_path)
            
            # 2. 预测vs实际值散点图
            plt.figure(figsize=(12, 8))
            
            for i, (model_name, model_data) in enumerate(models.items()):
                plt.subplot(2, 2, i+1)
                
                y_actual = model_data['test_actual']
                y_pred = model_data['predictions']
                r2 = model_data['r2']
                
                plt.scatter(y_actual, y_pred, alpha=0.6)
                plt.plot([y_actual.min(), y_actual.max()], [y_actual.min(), y_actual.max()], 'r--', lw=2)
                plt.xlabel('Actual Values')
                plt.ylabel('Predicted Values')
                plt.title(f'{model_name} (R² = {r2:.3f})')
                plt.grid(True, alpha=0.3)
            
            plt.tight_layout()
            
            plot_path = Path(output_dir) / f"prediction_scatter_{dataset_name}_{window_size}.png"
            plt.savefig(plot_path, dpi=300, bbox_inches='tight')
            plt.close()
            
            plots['prediction_scatter'] = str(plot_path)
            
            # 3. 模型性能比较图
            plt.figure(figsize=(10, 6))
            
            model_names = list(models.keys())
            r2_scores = [models[name]['r2'] for name in model_names]
            
            plt.bar(model_names, r2_scores)
            plt.title('Model Performance Comparison (R² Score)')
            plt.ylabel('R² Score')
            plt.xticks(rotation=45)
            
            plot_path = Path(output_dir) / f"model_performance_{dataset_name}_{window_size}.png"
            plt.savefig(plot_path, dpi=300, bbox_inches='tight')
            plt.close()
            
            plots['model_performance'] = str(plot_path)
            
            logger.info(f"Created {len(plots)} interpretability plots")
            
            return plots
            
        except Exception as e:
            logger.error(f"Error creating interpretability plots: {e}")
            return {}
    
    def validate_with_model_interpretability_analysis(self, dataset_name: str, window_size: str) -> dict:
        """带模型解释性分析的验证."""
        try:
            logger.info(f"=== Model Interpretability Analysis for {dataset_name} - {window_size}s ===")
            
            # 1. 加载数据
            df = self.load_fixed_lri_data(dataset_name, window_size)
            if df.empty:
                return {'error': 'Failed to load data'}
            
            # 2. 准备特征和目标
            X, y, feature_cols, target_col = self.prepare_features_and_target(df)
            if X is None:
                return {'error': 'Failed to prepare features'}
            
            # 3. 训练模型
            logger.info("Training models for interpretability analysis...")
            training_results = self.train_models(X, y, feature_cols)
            if not training_results:
                return {'error': 'Failed to train models'}
            
            # 4. 特征重要性分析
            logger.info("Analyzing feature importance...")
            importance_analysis = self.analyze_feature_importance(training_results['models'], feature_cols)
            
            # 5. 预测误差分析
            logger.info("Analyzing prediction errors...")
            error_analysis = self.analyze_prediction_errors(training_results['models'], feature_cols)
            
            # 6. 创建可视化
            logger.info("Creating interpretability visualizations...")
            output_dir = '/mnt/d/data_analysis/processed/step6_model_interpretability'
            Path(output_dir).mkdir(exist_ok=True)
            
            plots = self.create_interpretability_plots(
                training_results['models'], feature_cols, 
                output_dir, dataset_name, window_size
            )
            
            # 7. 模型性能总结
            model_performance = {}
            for model_name, model_data in training_results['models'].items():
                model_performance[model_name] = {
                    'r2': model_data['r2'],
                    'mse': model_data['mse']
                }
            
            # 8. 返回结果
            results = {
                'dataset_name': dataset_name,
                'window_size': window_size,
                'target_variable': target_col,
                'data_shape': X.shape,
                'feature_columns': feature_cols,
                'model_performance': model_performance,
                'feature_importance_analysis': importance_analysis,
                'prediction_error_analysis': error_analysis,
                'interpretability_plots': plots,
                'validation_timestamp': datetime.now().isoformat()
            }
            
            logger.info(f"=== Completed model interpretability analysis for {dataset_name} - {window_size}s ===")
            
            return results
            
        except Exception as e:
            logger.error(f"Error in model interpretability analysis for {dataset_name}_{window_size}: {e}")
            return {'error': str(e)}

def main():
    """主函数."""
    try:
        logger.info("Starting Step 6.4: Add Model Interpretability Analysis")
        
        # 数据集配置（选择几个数据集进行测试）
        datasets = ['CRWD', 'SWELL', 'DRIVE_DB']  # 减少数据集以加快测试
        window_sizes = ['60s', '300s']
        
        output_dir = '/mnt/d/data_analysis/processed/step6_model_interpretability'
        Path(output_dir).mkdir(exist_ok=True)
        
        # 初始化模型解释性分析器
        analyzer = ModelInterpretabilityAnalyzer(device='auto')
        
        # 逐个处理数据集
        all_results = {}
        
        for dataset_name in datasets:
            logger.info(f"\n{'='*60}")
            logger.info(f"Processing Dataset: {dataset_name} (MODEL INTERPRETABILITY)")
            logger.info(f"{'='*60}")
            
            dataset_results = {}
            
            for window_size in window_sizes:
                try:
                    result = analyzer.validate_with_model_interpretability_analysis(dataset_name, window_size)
                    dataset_results[window_size] = result
                    
                    # 保存结果
                    if 'error' not in result:
                        output_file = Path(output_dir) / f"model_interpretability_{dataset_name}_{window_size}.json"
                        with open(output_file, 'w') as f:
                            json.dump(result, f, indent=2, default=str)
                        logger.info(f"Saved model interpretability analysis results: {output_file}")
                    
                except Exception as e:
                    logger.error(f"Error processing {dataset_name}_{window_size}: {e}")
                    dataset_results[window_size] = {'error': str(e)}
            
            all_results[dataset_name] = dataset_results
        
        # 保存总体结果摘要
        summary_file = Path(output_dir) / "model_interpretability_analysis_summary.json"
        with open(summary_file, 'w') as f:
            json.dump(all_results, f, indent=2, default=str)
        
        logger.info(f"\n{'='*60}")
        logger.info("Step 6.4 Model Interpretability Analysis Completed Successfully!")
        logger.info(f"{'='*60}")
        
        # 打印模型解释性分析总结
        logger.info("\nModel Interpretability Analysis Results Summary:")
        for dataset_name, dataset_results in all_results.items():
            logger.info(f"\n{dataset_name}:")
            for window_size, result in dataset_results.items():
                if 'error' not in result:
                    model_performance = result.get('model_performance', {})
                    importance_analysis = result.get('feature_importance_analysis', {})
                    
                    logger.info(f"  {window_size}:")
                    
                    # 模型性能
                    for model_name, performance in model_performance.items():
                        logger.info(f"    {model_name}: R² = {performance.get('r2', 0):.3f}")
                    
                    # 特征重要性
                    if importance_analysis:
                        for model_name, importance_data in importance_analysis.items():
                            if 'sorted_features' in importance_data:
                                top_feature = importance_data['sorted_features'][0]
                                logger.info(f"    {model_name} top feature: {top_feature[0]} ({top_feature[1]:.3f})")
                else:
                    logger.warning(f"  {window_size}: Error - {result['error']}")
        
        logger.info("\n✅ Model Interpretability Analysis Implementation Completed!")
        logger.info("🔍 Key Improvements:")
        logger.info("  ✓ Feature importance analysis")
        logger.info("  ✓ Prediction error analysis")
        logger.info("  ✓ Model performance comparison")
        logger.info("  ✓ Interpretability visualizations")
        logger.info("  ✓ Multiple model interpretation methods")
        logger.info("  ✓ GPU-accelerated PyTorch model training")
        
    except Exception as e:
        logger.error(f"Error in main execution: {e}")
        raise

if __name__ == "__main__":
    main()
