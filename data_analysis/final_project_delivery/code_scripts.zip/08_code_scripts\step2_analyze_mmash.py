#!/usr/bin/env python3
"""
Step 2: Analyze MMASH Dataset
"""

import pandas as pd
import numpy as np
from pathlib import Path

def analyze_mmash_dataset():
    """Analyze MMASH dataset files."""
    print("Analyzing MMASH Dataset")
    print("="*60)
    
    # MMASH data path
    mmash_path = Path('processed/MMASH_extracted/MMASH_data/DataPaper')
    
    if not mmash_path.exists():
        print(f"❌ MMASH path does not exist: {mmash_path}")
        return None
    
    results = {}
    
    # Find user directories
    user_dirs = [d for d in mmash_path.iterdir() if d.is_dir() and d.name.startswith('user_')]
    print(f"Found {len(user_dirs)} user directories")
    
    # Analyze first few users as sample
    sample_users = user_dirs[:3]  # Analyze first 3 users
    
    for user_dir in sample_users:
        user_id = user_dir.name
        print(f"\nAnalyzing: {user_id}")
        print("-" * 40)
        
        user_results = {}
        
        # Define expected files
        expected_files = {
            'RR.csv': 'rr_data',
            'Actigraph.csv': 'activity_data', 
            'questionnaire.csv': 'questionnaire_data',
            'sleep.csv': 'sleep_data',
            'saliva.csv': 'saliva_data',
            'Activity.csv': 'activity_data2',
            'user_info.csv': 'user_info'
        }
        
        for filename, file_type in expected_files.items():
            file_path = user_dir / filename
            
            if file_path.exists():
                try:
                    df = pd.read_csv(file_path)
                    print(f"✅ {filename}: {df.shape[0]} rows, {df.shape[1]} columns")
                    print(f"   Columns: {list(df.columns)}")
                    
                    # Show sample data
                    if len(df) > 0:
                        print(f"   Sample data (first row): {dict(df.iloc[0])}")
                    
                    user_results[filename] = {
                        'shape': df.shape,
                        'columns': list(df.columns),
                        'sample_data': dict(df.iloc[0]) if len(df) > 0 else {}
                    }
                    
                except Exception as e:
                    print(f"❌ Error reading {filename}: {e}")
                    user_results[filename] = {'error': str(e)}
            else:
                print(f"❌ {filename}: File not found")
                user_results[filename] = {'error': 'File not found'}
        
        results[user_id] = user_results
    
    # Analyze RR.csv files for theoretical parameters
    print(f"\n{'='*60}")
    print("THEORETICAL PARAMETER ANALYSIS")
    print(f"{'='*60}")
    
    theoretical_params = {
        'hrv_rmssd': ['rmssd', 'RMSSD', 'hrv_rmssd'],
        'hrv_sdnn': ['sdnn', 'SDNN', 'hrv_sdnn'],
        'hr_mean': ['hr', 'HR', 'heart_rate'],
        'ibi': ['ibi', 'IBI', 'rr_interval', 'rr'],
        'activity': ['activity', 'actigraph', 'acceleration'],
        'sleep': ['sleep', 'sleep_duration'],
        'stress_label': ['stress', 'condition', 'state']
    }
    
    # Check RR.csv files for HRV parameters
    rr_files_analyzed = 0
    found_params = {}
    
    for user_dir in sample_users:
        rr_file = user_dir / 'RR.csv'
        if rr_file.exists():
            try:
                df = pd.read_csv(rr_file)
                rr_files_analyzed += 1
                
                print(f"\nRR.csv from {user_dir.name}:")
                print(f"  Shape: {df.shape}")
                print(f"  Columns: {list(df.columns)}")
                
                # Check for theoretical parameters
                for param_name, aliases in theoretical_params.items():
                    found_columns = []
                    for col in df.columns:
                        col_lower = str(col).lower()
                        for alias in aliases:
                            if alias.lower() in col_lower:
                                found_columns.append(col)
                    if found_columns:
                        if param_name not in found_params:
                            found_params[param_name] = []
                        found_params[param_name].extend(found_columns)
                        print(f"  ✅ {param_name}: {found_columns}")
                
            except Exception as e:
                print(f"  ❌ Error reading RR.csv: {e}")
    
    # Summary
    print(f"\n{'='*60}")
    print("MMASH ANALYSIS SUMMARY")
    print(f"{'='*60}")
    
    print(f"✅ Analyzed {len(sample_users)} users")
    print(f"✅ Analyzed {rr_files_analyzed} RR.csv files")
    print(f"✅ Found {len(found_params)} theoretical parameters")
    
    for param, columns in found_params.items():
        print(f"   - {param}: {list(set(columns))}")
    
    # Calculate theoretical relevance score
    high_priority_params = ['hrv_rmssd', 'hrv_sdnn', 'hr_mean', 'ibi']
    relevance_score = len([p for p in high_priority_params if p in found_params])
    relevance_percentage = (relevance_score / len(high_priority_params)) * 100
    
    print(f"\n⭐ Theoretical relevance: {relevance_percentage:.1f}%")
    print(f"   High-priority parameters found: {[p for p in high_priority_params if p in found_params]}")
    
    results['summary'] = {
        'users_analyzed': len(sample_users),
        'rr_files_analyzed': rr_files_analyzed,
        'theoretical_params_found': found_params,
        'relevance_score': relevance_score,
        'relevance_percentage': relevance_percentage
    }
    
    return results

if __name__ == "__main__":
    results = analyze_mmash_dataset()
    
    if results:
        print(f"\n✅ MMASH analysis completed")
        print(f"Found {len(results['summary']['theoretical_params_found'])} theoretical parameters")
        print(f"Theoretical relevance: {results['summary']['relevance_percentage']:.1f}%")
    else:
        print(f"\n❌ MMASH analysis failed")








