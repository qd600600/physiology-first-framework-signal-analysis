#!/usr/bin/env python3
"""
Step 2: Analyze SWELL Dataset Train File
"""

import pandas as pd
import numpy as np
from pathlib import Path

def analyze_swell_train():
    """Analyze SWELL train.csv file."""
    file_path = "processed/SWELL_extracted/hrv dataset/data/final/train.csv"
    
    print(f"Analyzing: {file_path}")
    print("="*60)
    
    # Check if file exists
    if not Path(file_path).exists():
        print(f"❌ File does not exist: {file_path}")
        return None
    
    try:
        # Read the file
        df = pd.read_csv(file_path)
        print(f"✅ Successfully read file")
        print(f"📊 Shape: {df.shape[0]} rows, {df.shape[1]} columns")
        print(f"📋 Columns: {list(df.columns)}")
        
        # Show data types
        print(f"🔍 Data types:")
        for col, dtype in df.dtypes.items():
            print(f"   - {col}: {dtype}")
        
        # Show first few rows
        print(f"📄 First 3 rows:")
        print(df.head(3).to_string())
        
        # Check for missing data
        print(f"⚠️ Missing data:")
        missing = df.isnull().sum()
        for col, count in missing.items():
            if count > 0:
                pct = (count / len(df)) * 100
                print(f"   - {col}: {count} ({pct:.1f}%)")
        
        # Check theoretical parameters
        theoretical_params = {
            'hrv_rmssd': ['rmssd', 'RMSSD', 'hrv_rmssd'],
            'hrv_sdnn': ['sdnn', 'SDNN', 'hrv_sdnn', 'SDRR'],
            'hr_mean': ['hr', 'HR', 'heart_rate'],
            'eda': ['eda', 'EDA', 'gsr', 'GSR'],
            'ibi': ['ibi', 'IBI', 'rr_interval', 'MEAN_RR', 'MEDIAN_RR'],
            'stress_label': ['stress', 'condition', 'state']
        }
        
        print(f"🎯 Theoretical parameter mapping:")
        found_params = {}
        for param_name, aliases in theoretical_params.items():
            found_columns = []
            for col in df.columns:
                col_lower = str(col).lower()
                for alias in aliases:
                    if alias.lower() in col_lower:
                        found_columns.append(col)
            if found_columns:
                found_params[param_name] = found_columns
                print(f"   - {param_name}: {found_columns}")
        
        # Show unique values in condition column
        if 'condition' in df.columns:
            print(f"📊 Condition values:")
            condition_counts = df['condition'].value_counts()
            for condition, count in condition_counts.items():
                print(f"   - {condition}: {count} ({count/len(df)*100:.1f}%)")
        
        return {
            'file_path': file_path,
            'shape': df.shape,
            'columns': list(df.columns),
            'dtypes': dict(df.dtypes),
            'missing_data': dict(missing),
            'theoretical_params': found_params,
            'condition_distribution': dict(df['condition'].value_counts()) if 'condition' in df.columns else {}
        }
        
    except Exception as e:
        print(f"❌ Error reading file: {e}")
        return None

if __name__ == "__main__":
    result = analyze_swell_train()
    
    if result:
        print(f"\n✅ SWELL train.csv analysis completed successfully")
        print(f"Found {len(result['theoretical_params'])} theoretical parameters")
        print(f"Data quality: {result['shape'][0]} rows with {len(result['missing_data'])} columns having missing data")
    else:
        print(f"\n❌ SWELL analysis failed")








