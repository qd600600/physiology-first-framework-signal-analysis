#!/usr/bin/env python3
"""
Step 2: Parameter Selection Based on Theoretical Framework
Selects and standardizes parameters across 8 datasets based on stress-cognition-behavior entanglement theory.
"""

import os
import json
import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime
import warnings
from sklearn.feature_selection import VarianceThreshold
from sklearn.preprocessing import StandardScaler
from statsmodels.stats.outliers_influence import variance_inflation_factor
import matplotlib.pyplot as plt
import seaborn as sns
warnings.filterwarnings('ignore')

# Set random seed for reproducibility
np.random.seed(42)

class ParameterSelector:
    def __init__(self, processed_root="processed", output_root="step2_output"):
        self.processed_root = Path(processed_root)
        self.output_root = Path(output_root)
        self.output_root.mkdir(exist_ok=True)
        
        # Theoretical parameter priorities based on stress-cognition-behavior entanglement framework
        self.theoretical_priorities = {
            'priority_1_core_physiological': {
                'description': 'Core physiological indicators of autonomic nervous system state',
                'parameters': {
                    'hrv_rmssd': {
                        'importance': 'highest',
                        'description': 'Root Mean Square of Successive Differences - primary HRV metric',
                        'aliases': ['rmssd', 'HRV_RMSSD', 'rmssd_ms', 'RMSSD_REL_RR']
                    },
                    'hrv_sdnn': {
                        'importance': 'highest', 
                        'description': 'Standard Deviation of NN intervals - time domain HRV',
                        'aliases': ['sdnn', 'HRV_SDNN', 'sdnn_ms']
                    },
                    'hr_mean': {
                        'importance': 'high',
                        'description': 'Mean heart rate - baseline cardiovascular state',
                        'aliases': ['hr', 'heart_rate', 'HR', 'heartrate', 'hr_mean']
                    },
                    'eda': {
                        'importance': 'highest',
                        'description': 'Electrodermal activity - acute stress response indicator',
                        'aliases': ['eda', 'EDA', 'gsr', 'GSR', 'skin_conductance']
                    },
                    'ibi': {
                        'importance': 'high',
                        'description': 'Inter-beat intervals - HRV calculation basis',
                        'aliases': ['ibi', 'IBI', 'rr_interval', 'rr_intervals']
                    }
                }
            },
            'priority_2_regulatory': {
                'description': 'Regulatory variables affecting autonomic responses',
                'parameters': {
                    'temperature': {
                        'importance': 'medium',
                        'description': 'Body temperature - thermoregulation effects',
                        'aliases': ['temp', 'temperature', 'TEMP', 'body_temp']
                    },
                    'acceleration': {
                        'importance': 'medium',
                        'description': 'Physical activity - distinguishes exercise-induced HR changes',
                        'aliases': ['acc_x', 'acc_y', 'acc_z', 'acc_magnitude', 'activity']
                    }
                }
            },
            'priority_3_clinical': {
                'description': 'Clinical validation and subjective measures for LRI calculation',
                'parameters': {
                    'phq_15': {
                        'importance': 'critical',
                        'description': 'PHQ-15 somatic symptom scale - core driver of functional impairment',
                        'aliases': ['phq15', 'PHQ15', 'PHQ-15', 'somatic_symptoms']
                    },
                    'phq_9': {
                        'importance': 'high',
                        'description': 'PHQ-9 depression scale',
                        'aliases': ['phq9', 'PHQ9', 'PHQ-9', 'depression']
                    },
                    'gad_7': {
                        'importance': 'high',
                        'description': 'GAD-7 anxiety scale',
                        'aliases': ['gad7', 'GAD7', 'GAD-7', 'anxiety']
                    },
                    'stress_label': {
                        'importance': 'high',
                        'description': 'Stress condition labels for validation',
                        'aliases': ['stress', 'stress_label', 'label', 'condition', 'state']
                    }
                }
            }
        }
        
        # Dataset-specific configurations
        self.dataset_configs = {
            'WESAD': {
                'path': 'data/WESAD/raw',
                'subjects': ['S2', 'S3', 'S4', 'S5', 'S6', 'S7', 'S8', 'S9', 'S10', 'S11', 'S13', 'S14', 'S15', 'S16', 'S17'],
                'file_structure': 'subject/{subject}_E4_Data/{sensor}.csv',
                'sensors': ['ACC', 'BVP', 'EDA', 'HR', 'IBI', 'TEMP'],
                'sampling_rates': {'ACC': 32, 'BVP': 64, 'EDA': 4, 'HR': 1, 'IBI': 1, 'TEMP': 4}
            },
            'MMASH': {
                'path': 'processed/MMASH_extracted/MMASH_data/DataPaper',
                'subjects': [f'user_{i}' for i in range(1, 23)],
                'file_structure': 'user_{subject}/{file}.csv',
                'files': ['RR', 'Actigraph', 'questionnaire'],
                'sampling_rates': {'RR': 1, 'Actigraph': 1, 'questionnaire': 1}
            },
            'CRWD': {
                'path': 'processed/CRWD_extracted',
                'files': ['sensor_hrv.csv', 'survey.csv'],
                'sampling_rates': {'sensor_hrv': 1, 'survey': 1}
            },
            'Nurses': {
                'path': 'processed/Nurses_extracted/nurses_data',
                'subjects': ['15', '5C', '6B', '6D', '7A', '7E', '83', '8B', '94', 'BG', 'CE', 'DF', 'E4', 'EG', 'F5'],
                'file_structure': '{subject}/extracted/{session}/{sensor}.csv',
                'sensors': ['ACC', 'BVP', 'EDA', 'HR', 'IBI', 'TEMP'],
                'sampling_rates': {'ACC': 32, 'BVP': 64, 'EDA': 4, 'HR': 1, 'IBI': 1, 'TEMP': 4}
            },
            'SWELL': {
                'path': 'processed/SWELL_extracted',
                'files': ['hrv dataset/data/final/train.csv', 'hrv dataset/data/final/test.csv'],
                'sampling_rates': {'train': 1, 'test': 1}
            },
            'Mental_Health_Pred': {
                'path': 'processed/Mental_Health_Pred_extracted',
                'files': ['mental_health_wearable_data.csv'],
                'sampling_rates': {'mental_health_wearable_data': 1}
            }
        }
        
        self.selection_results = {}

    def map_columns_to_standard(self, df, dataset_name):
        """Map dataset columns to standard parameter names."""
        column_mapping = {}
        
        # Create a flat list of all aliases with their standard names
        all_aliases = {}
        for priority, params in self.theoretical_priorities.items():
            for param_name, param_info in params['parameters'].items():
                for alias in param_info['aliases']:
                    all_aliases[alias.lower()] = param_name
        
        # Map columns - handle both string and integer column names
        for col in df.columns:
            try:
                col_lower = str(col).lower().replace(' ', '_').replace('-', '_')
                if col_lower in all_aliases:
                    column_mapping[col] = all_aliases[col_lower]
            except:
                # Skip columns that can't be processed
                continue
        
        return column_mapping

    def calculate_vif(self, df, target_col='target'):
        """Calculate Variance Inflation Factor for multicollinearity detection."""
        # Select numeric columns only
        numeric_df = df.select_dtypes(include=[np.number])
        
        if len(numeric_df.columns) < 2:
            return {}
        
        # Remove columns with all NaN or infinite values
        numeric_df = numeric_df.replace([np.inf, -np.inf], np.nan)
        numeric_df = numeric_df.dropna(axis=1, how='all')
        
        if len(numeric_df.columns) < 2:
            return {}
        
        # Add a small amount of noise to avoid perfect correlation issues
        numeric_df = numeric_df.fillna(numeric_df.mean()) + np.random.normal(0, 1e-6, numeric_df.shape)
        
        try:
            vif_data = {}
            for i, col in enumerate(numeric_df.columns):
                if col != target_col:
                    vif_value = variance_inflation_factor(numeric_df.values, i)
                    if not np.isnan(vif_value) and not np.isinf(vif_value):
                        vif_data[col] = vif_value
            return vif_data
        except Exception as e:
            print(f"VIF calculation error: {e}")
            return {}

    def assess_data_quality(self, df, dataset_name, subject_id=None):
        """Assess data quality metrics."""
        quality_metrics = {
            'dataset': dataset_name,
            'subject_id': subject_id,
            'total_rows': len(df),
            'total_columns': len(df.columns),
            'missing_data_percentage': (df.isnull().sum().sum() / (len(df) * len(df.columns))) * 100,
            'columns_with_high_missing': {},
            'data_types': df.dtypes.to_dict(),
            'basic_stats': {}
        }
        
        # Check for columns with >20% missing data
        for col in df.columns:
            missing_pct = (df[col].isnull().sum() / len(df)) * 100
            if missing_pct > 20:
                quality_metrics['columns_with_high_missing'][col] = missing_pct
        
        # Basic statistics for numeric columns
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        if len(numeric_cols) > 0:
            quality_metrics['basic_stats'] = df[numeric_cols].describe().to_dict()
        
        return quality_metrics

    def process_wesad_dataset(self):
        """Process WESAD dataset parameter selection."""
        print("Processing WESAD dataset...")
        wesad_results = {
            'dataset': 'WESAD',
            'subjects_processed': [],
            'selected_features': [],
            'quality_assessment': {}
        }
        
        config = self.dataset_configs['WESAD']
        wesad_path = Path(config['path'])
        
        all_subject_data = []
        
        for subject in config['subjects']:
            print(f"  Processing subject: {subject}")
            subject_data = {}
            subject_quality = {}
            
            # Process each sensor file
            for sensor in config['sensors']:
                sensor_path = wesad_path / subject / f'{subject}_E4_Data' / f'{sensor}.csv'
                if sensor_path.exists():
                    try:
                        df = pd.read_csv(sensor_path, header=None)
                        
                        # For WESAD, assign meaningful column names based on sensor type
                        if sensor == 'ACC':
                            df.columns = ['timestamp', 'acc_x', 'acc_y', 'acc_z']
                        elif sensor == 'BVP':
                            df.columns = ['bvp']
                        elif sensor == 'EDA':
                            df.columns = ['eda']
                        elif sensor == 'HR':
                            df.columns = ['hr']
                        elif sensor == 'IBI':
                            df.columns = ['timestamp', 'ibi']
                        elif sensor == 'TEMP':
                            df.columns = ['temp']
                        
                        # Map columns to standard names
                        column_mapping = self.map_columns_to_standard(df, 'WESAD')
                        
                        # Assess quality
                        quality = self.assess_data_quality(df, 'WESAD', f'{subject}_{sensor}')
                        subject_quality[f'{sensor}'] = quality
                        
                        # Store data for this sensor
                        subject_data[f'{sensor}'] = {
                            'data': df,
                            'column_mapping': column_mapping,
                            'quality': quality,
                            'sampling_rate': config['sampling_rates'][sensor]
                        }
                        
                    except Exception as e:
                        print(f"    Error processing {sensor}: {e}")
            
            # Process questionnaire data
            quest_path = wesad_path / subject / f'{subject}_quest.csv'
            if quest_path.exists():
                try:
                    quest_df = pd.read_csv(quest_path)
                    quest_quality = self.assess_data_quality(quest_df, 'WESAD', f'{subject}_quest')
                    subject_quality['quest'] = quest_quality
                    subject_data['quest'] = {
                        'data': quest_df,
                        'column_mapping': self.map_columns_to_standard(quest_df, 'WESAD'),
                        'quality': quest_quality
                    }
                except Exception as e:
                    print(f"    Error processing questionnaire: {e}")
            
            wesad_results['subjects_processed'].append({
                'subject_id': subject,
                'sensors_available': list(subject_data.keys()),
                'data_summary': {k: len(v['data']) if 'data' in v else 0 for k, v in subject_data.items()}
            })
            
            all_subject_data.append(subject_data)
        
        wesad_results['quality_assessment'] = subject_quality
        return wesad_results, all_subject_data

    def process_crwd_dataset(self):
        """Process CRWD dataset parameter selection."""
        print("Processing CRWD dataset...")
        crwd_results = {
            'dataset': 'CRWD',
            'selected_features': [],
            'quality_assessment': {}
        }
        
        config = self.dataset_configs['CRWD']
        crwd_path = Path(config['path'])
        
        # Process sensor data
        sensor_file = crwd_path / 'sensor_hrv.csv'
        if sensor_file.exists():
            try:
                df = pd.read_csv(sensor_file)
                column_mapping = self.map_columns_to_standard(df, 'CRWD')
                quality = self.assess_data_quality(df, 'CRWD')
                
                # Calculate VIF for multicollinearity
                vif_results = self.calculate_vif(df)
                
                crwd_results['quality_assessment']['sensor_data'] = quality
                crwd_results['column_mapping'] = column_mapping
                crwd_results['vif_results'] = vif_results
                
                # Select features based on theoretical priority and VIF
                try:
                    selected_features = self.select_features_by_priority(df, column_mapping, vif_results)
                    crwd_results['selected_features'] = selected_features
                except Exception as e:
                    print(f"Error in feature selection: {e}")
                    crwd_results['selected_features'] = {'error': str(e)}
                
            except Exception as e:
                print(f"Error processing CRWD sensor data: {e}")
        
        # Process survey data
        survey_file = crwd_path / 'survey.csv'
        if survey_file.exists():
            try:
                survey_df = pd.read_csv(survey_file)
                survey_quality = self.assess_data_quality(survey_df, 'CRWD')
                crwd_results['quality_assessment']['survey_data'] = survey_quality
            except Exception as e:
                print(f"Error processing CRWD survey data: {e}")
        
        return crwd_results

    def process_swell_dataset(self):
        """Process SWELL dataset parameter selection."""
        print("Processing SWELL dataset...")
        swell_results = {
            'dataset': 'SWELL',
            'selected_features': [],
            'quality_assessment': {}
        }
        
        config = self.dataset_configs['SWELL']
        swell_path = Path(config['path'])
        
        # Process train data
        train_file = swell_path / config['files'][0]
        if train_file.exists():
            try:
                df = pd.read_csv(train_file)
                column_mapping = self.map_columns_to_standard(df, 'SWELL')
                quality = self.assess_data_quality(df, 'SWELL')
                
                vif_results = self.calculate_vif(df)
                
                swell_results['quality_assessment']['train_data'] = quality
                swell_results['column_mapping'] = column_mapping
                swell_results['vif_results'] = vif_results
                
                selected_features = self.select_features_by_priority(df, column_mapping, vif_results)
                swell_results['selected_features'] = selected_features
                
            except Exception as e:
                print(f"Error processing SWELL train data: {e}")
        
        return swell_results

    def calculate_parameter_correlations(self, df, column_mapping):
        """Calculate correlations between parameters to assess associations."""
        correlation_results = {}
        
        # Map columns to standard names
        df_mapped = df.copy()
        for old_col, new_col in column_mapping.items():
            if old_col in df_mapped.columns:
                df_mapped = df_mapped.rename(columns={old_col: new_col})
        
        # Select only numeric columns
        numeric_cols = df_mapped.select_dtypes(include=[np.number]).columns
        if len(numeric_cols) > 1:
            try:
                correlation_matrix = df_mapped[numeric_cols].corr()
                correlation_results['correlation_matrix'] = correlation_matrix.to_dict()
                
                # Find strong correlations (|r| > 0.7)
                strong_correlations = []
                for i in range(len(correlation_matrix.columns)):
                    for j in range(i+1, len(correlation_matrix.columns)):
                        corr_value = correlation_matrix.iloc[i, j]
                        if abs(corr_value) > 0.7:
                            strong_correlations.append({
                                'param1': correlation_matrix.columns[i],
                                'param2': correlation_matrix.columns[j],
                                'correlation': corr_value,
                                'strength': 'strong' if abs(corr_value) > 0.8 else 'moderate'
                            })
                
                correlation_results['strong_correlations'] = strong_correlations
                
            except Exception as e:
                correlation_results['error'] = str(e)
        
        return correlation_results

    def select_features_by_priority(self, df, column_mapping, vif_results):
        """Select features based on theoretical priority, technical criteria, and associations."""
        selected_features = {
            'priority_1_core': [],
            'priority_2_regulatory': [],
            'priority_3_clinical': [],
            'excluded_high_vif': [],
            'excluded_missing': [],
            'parameter_associations': {}
        }
        
        # Map columns to standard names
        df_mapped = df.copy()
        for old_col, new_col in column_mapping.items():
            if old_col in df_mapped.columns:
                df_mapped = df_mapped.rename(columns={old_col: new_col})
        
        # Calculate parameter correlations for association analysis
        correlation_results = self.calculate_parameter_correlations(df, column_mapping)
        selected_features['parameter_associations'] = correlation_results
        
        # Check each theoretical priority group
        for priority_name, priority_info in self.theoretical_priorities.items():
            for param_name, param_info in priority_info['parameters'].items():
                if param_name in df_mapped.columns:
                    # Check VIF (if available)
                    if param_name in vif_results and vif_results[param_name] > 5:
                        selected_features['excluded_high_vif'].append({
                            'parameter': param_name,
                            'vif': vif_results[param_name],
                            'reason': 'High multicollinearity'
                        })
                        continue
                    
                    # Check missing data
                    missing_pct = (df_mapped[param_name].isnull().sum() / len(df_mapped)) * 100
                    if missing_pct > 20:
                        selected_features['excluded_missing'].append({
                            'parameter': param_name,
                            'missing_percentage': missing_pct,
                            'reason': 'High missing data'
                        })
                        continue
                    
                    # Add to appropriate priority group
                    selected_features[priority_name].append({
                        'parameter': param_name,
                        'importance': param_info['importance'],
                        'description': param_info['description'],
                        'missing_percentage': missing_pct,
                        'vif': vif_results.get(param_name, 'N/A')
                    })
        
        return selected_features

    def generate_selection_summary(self):
        """Generate comprehensive parameter selection summary."""
        summary = {
            'parameter_selection_summary': {
                'timestamp': datetime.now().isoformat(),
                'total_datasets_processed': len(self.selection_results),
                'theoretical_framework_applied': True,
                'selection_criteria': {
                    'vif_threshold': 5,
                    'missing_data_threshold': 20,
                    'priority_based_selection': True
                }
            },
            'dataset_results': self.selection_results,
            'cross_dataset_analysis': self.analyze_cross_dataset_consistency(),
            'recommendations': self.generate_recommendations()
        }
        
        return summary

    def analyze_cross_dataset_consistency(self):
        """Analyze consistency of parameter availability across datasets."""
        consistency_analysis = {
            'parameter_availability': {},
            'sampling_rate_consistency': {},
            'data_quality_comparison': {}
        }
        
        # Analyze parameter availability
        all_parameters = set()
        for dataset_result in self.selection_results.values():
            if 'selected_features' in dataset_result:
                for priority_group, features in dataset_result['selected_features'].items():
                    if isinstance(features, list):
                        for feature in features:
                            if isinstance(feature, dict) and 'parameter' in feature:
                                all_parameters.add(feature['parameter'])
        
        for param in all_parameters:
            availability = []
            for dataset_name, dataset_result in self.selection_results.items():
                available = False
                if 'selected_features' in dataset_result:
                    for priority_group, features in dataset_result['selected_features'].items():
                        if isinstance(features, list):
                            for feature in features:
                                if isinstance(feature, dict) and feature.get('parameter') == param:
                                    available = True
                                    break
                availability.append({'dataset': dataset_name, 'available': available})
            
            consistency_analysis['parameter_availability'][param] = availability
        
        return consistency_analysis

    def generate_recommendations(self):
        """Generate recommendations based on parameter selection results."""
        recommendations = []
        
        # Check for datasets with very few selected parameters
        for dataset_name, dataset_result in self.selection_results.items():
            if 'selected_features' in dataset_result:
                total_selected = 0
                for priority_group, features in dataset_result['selected_features'].items():
                    if isinstance(features, list):
                        total_selected += len(features)
                
                if total_selected < 3:
                    recommendations.append(f"{dataset_name}: Very few parameters selected ({total_selected}). Consider data cleaning or different preprocessing.")
        
        # Check for high VIF issues
        high_vif_datasets = []
        for dataset_name, dataset_result in self.selection_results.items():
            if 'selected_features' in dataset_result and 'excluded_high_vif' in dataset_result['selected_features']:
                if len(dataset_result['selected_features']['excluded_high_vif']) > 0:
                    high_vif_datasets.append(dataset_name)
        
        if high_vif_datasets:
            recommendations.append(f"High multicollinearity detected in: {', '.join(high_vif_datasets)}. Consider dimensionality reduction.")
        
        return recommendations

    def run_parameter_selection(self):
        """Run complete parameter selection process."""
        print("="*60)
        print("STEP 2: PARAMETER SELECTION BASED ON THEORETICAL FRAMEWORK")
        print("="*60)
        
        # Process each dataset
        print("\nProcessing datasets...")
        
        # Process WESAD
        wesad_results, wesad_data = self.process_wesad_dataset()
        self.selection_results['WESAD'] = wesad_results
        
        # Process CRWD
        crwd_results = self.process_crwd_dataset()
        self.selection_results['CRWD'] = crwd_results
        
        # Process SWELL
        swell_results = self.process_swell_dataset()
        self.selection_results['SWELL'] = swell_results
        
        # Generate comprehensive summary
        summary = self.generate_selection_summary()
        
        # Save results
        summary_path = self.output_root / 'parameter_selection_summary.json'
        with open(summary_path, 'w') as f:
            json.dump(summary, f, indent=2)
        
        # Generate CSV files for selected features
        self.save_selected_features_csv()
        
        print(f"\nParameter selection complete!")
        print(f"Results saved to: {summary_path}")
        print(f"Selected features CSV saved to: {self.output_root}")
        
        return summary

    def save_selected_features_csv(self):
        """Save selected features to CSV files for each dataset."""
        for dataset_name, dataset_result in self.selection_results.items():
            if 'selected_features' in dataset_result:
                # Create a summary DataFrame
                features_data = []
                
                for priority_group, features in dataset_result['selected_features'].items():
                    if isinstance(features, list):
                        for feature in features:
                            if isinstance(feature, dict):
                                row = {
                                    'dataset': dataset_name,
                                    'priority_group': priority_group,
                                    'parameter': feature.get('parameter', ''),
                                    'importance': feature.get('importance', ''),
                                    'description': feature.get('description', ''),
                                    'missing_percentage': feature.get('missing_percentage', ''),
                                    'vif': feature.get('vif', ''),
                                    'selection_reason': 'Selected'
                                }
                                features_data.append(row)
                
                # Add excluded features
                for exclusion_type in ['excluded_high_vif', 'excluded_missing']:
                    if exclusion_type in dataset_result['selected_features']:
                        for feature in dataset_result['selected_features'][exclusion_type]:
                            if isinstance(feature, dict):
                                row = {
                                    'dataset': dataset_name,
                                    'priority_group': exclusion_type,
                                    'parameter': feature.get('parameter', ''),
                                    'importance': '',
                                    'description': '',
                                    'missing_percentage': feature.get('missing_percentage', ''),
                                    'vif': feature.get('vif', ''),
                                    'selection_reason': feature.get('reason', '')
                                }
                                features_data.append(row)
                
                if features_data:
                    df = pd.DataFrame(features_data)
                    csv_path = self.output_root / f'selected_features_{dataset_name}.csv'
                    df.to_csv(csv_path, index=False)

def main():
    selector = ParameterSelector()
    results = selector.run_parameter_selection()
    return results

if __name__ == "__main__":
    main()
