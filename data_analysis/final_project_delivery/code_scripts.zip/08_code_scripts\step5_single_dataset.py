#!/usr/bin/env python3
"""
Step 5: LRI Calculation for Single Dataset
针对单个数据集进行LRI计算，避免复杂错误
"""

import os
import sys
import logging
import pandas as pd
import numpy as np
import torch
from pathlib import Path
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('step5_single_dataset.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

def load_and_fix_data(file_path: str) -> pd.DataFrame:
    """Load W(t) data and fix timestamp issues."""
    try:
        df = pd.read_parquet(file_path)
        logger.info(f"Loaded data: {df.shape} from {file_path}")
        
        # Handle timestamp
        if 'timestamp' not in df.columns:
            # Create sequential timestamps
            df['timestamp'] = pd.date_range(start='2023-01-01', periods=len(df), freq='1S')
            logger.info(f"Created sequential timestamps")
        else:
            # Convert to datetime if numeric
            if pd.api.types.is_numeric_dtype(df['timestamp']):
                start_time = pd.Timestamp('2023-01-01')
                df['timestamp'] = start_time + pd.to_timedelta(df['timestamp'], unit='s')
                logger.info("Converted numeric timestamp to datetime")
        
        # Check W_t column
        if 'W_t' not in df.columns:
            logger.error(f"No W_t column found!")
            return pd.DataFrame()
        
        logger.info(f"Data ready: {df.shape}, W_t range: {df['W_t'].min():.3f} to {df['W_t'].max():.3f}")
        return df
        
    except Exception as e:
        logger.error(f"Error loading data: {e}")
        return pd.DataFrame()

def simple_time_aggregation(df: pd.DataFrame, window_seconds: int = 60) -> pd.DataFrame:
    """Simple time aggregation without resampling."""
    try:
        # Set timestamp as index
        df_indexed = df.set_index('timestamp').copy()
        
        # Calculate number of windows
        total_seconds = (df_indexed.index.max() - df_indexed.index.min()).total_seconds()
        n_windows = int(total_seconds // window_seconds)
        
        if n_windows == 0:
            logger.warning(f"No complete windows of {window_seconds}s")
            return pd.DataFrame()
        
        logger.info(f"Total time: {total_seconds:.0f}s, creating {n_windows} windows of {window_seconds}s")
        
        # Simple windowing - take every N rows
        rows_per_window = len(df_indexed) // n_windows
        if rows_per_window == 0:
            rows_per_window = 1
        
        aggregated_data = []
        
        for i in range(n_windows):
            start_idx = i * rows_per_window
            end_idx = min((i + 1) * rows_per_window, len(df_indexed))
            
            if start_idx >= len(df_indexed):
                break
                
            window_data = df_indexed.iloc[start_idx:end_idx]
            wt_values = window_data['W_t'].values
            
            # Simple statistics
            window_stats = {
                'window_id': i,
                'window_size_seconds': window_seconds,
                'sample_count': len(window_data),
                'wt_mean': np.mean(wt_values),
                'wt_std': np.std(wt_values),
                'wt_min': np.min(wt_values),
                'wt_max': np.max(wt_values),
                'wt_median': np.median(wt_values),
                'recovery_ratio': np.mean(wt_values < np.percentile(wt_values, 70)),
                'start_time': window_data.index[0] if len(window_data) > 0 else None,
                'end_time': window_data.index[-1] if len(window_data) > 0 else None
            }
            
            aggregated_data.append(window_stats)
        
        result_df = pd.DataFrame(aggregated_data)
        logger.info(f"Created {len(result_df)} aggregated windows")
        return result_df
        
    except Exception as e:
        logger.error(f"Error in time aggregation: {e}")
        return pd.DataFrame()

def process_single_dataset(dataset_name: str, file_path: str, output_dir: str):
    """Process a single dataset."""
    try:
        logger.info(f"=== Processing {dataset_name} ===")
        
        # Load data
        df = load_and_fix_data(file_path)
        if df.empty:
            logger.error(f"Failed to load {dataset_name}")
            return
        
        # Process different window sizes
        window_sizes = [60, 300, 900]  # 1min, 5min, 15min
        
        for window_size in window_sizes:
            logger.info(f"Processing {window_size}s windows...")
            
            # Time aggregation
            aggregated_df = simple_time_aggregation(df, window_size)
            
            if aggregated_df.empty:
                logger.warning(f"No data for {window_size}s windows")
                continue
            
            # Save results
            output_file = Path(output_dir) / f"lri_{dataset_name}_{window_size}s.csv"
            output_file.parent.mkdir(exist_ok=True)
            
            aggregated_df.to_csv(output_file, index=False)
            logger.info(f"Saved {len(aggregated_df)} windows to {output_file}")
            
            # Print summary
            logger.info(f"Summary for {window_size}s windows:")
            logger.info(f"  Mean W(t): {aggregated_df['wt_mean'].mean():.3f}")
            logger.info(f"  Recovery ratio: {aggregated_df['recovery_ratio'].mean():.3f}")
            logger.info(f"  Total windows: {len(aggregated_df)}")
        
        logger.info(f"=== Completed {dataset_name} ===")
        
    except Exception as e:
        logger.error(f"Error processing {dataset_name}: {e}")

def main():
    """Main function."""
    try:
        # Dataset mapping
        datasets = {
            'CRWD': '/mnt/d/data_analysis/processed/wt_generation/wt_timeseries_CRWD.parquet',
            'SWELL': '/mnt/d/data_analysis/processed/wt_generation/wt_timeseries_SWELL_complete.parquet',
            'WESAD': '/mnt/d/data_analysis/processed/wt_generation/wt_timeseries_WESAD_full_sample.parquet',
            'Nurses': '/mnt/d/data_analysis/processed/wt_generation/wt_timeseries_Nurses_wsl_gpu.parquet',
            'MMASH': '/mnt/d/data_analysis/processed/wt_generation/wt_timeseries_MMASH.parquet',
            'Mental_Health_Pred': '/mnt/d/data_analysis/processed/wt_generation/wt_timeseries_Mental_Health_Pred.parquet',
            'DRIVE_DB': '/mnt/d/data_analysis/processed/wt_generation/wt_timeseries_DRIVE_DB_full_sample.parquet',
            'Non_EEG': '/mnt/d/data_analysis/processed/wt_generation/wt_timeseries_Non_EEG_full_sample.parquet'
        }
        
        output_dir = '/mnt/d/data_analysis/processed/lri_calculation'
        
        # Process each dataset
        for dataset_name, file_path in datasets.items():
            if os.path.exists(file_path):
                process_single_dataset(dataset_name, file_path, output_dir)
            else:
                logger.warning(f"File not found: {file_path}")
        
        logger.info("All datasets processed!")
        
    except Exception as e:
        logger.error(f"Error in main: {e}")

if __name__ == "__main__":
    main()
