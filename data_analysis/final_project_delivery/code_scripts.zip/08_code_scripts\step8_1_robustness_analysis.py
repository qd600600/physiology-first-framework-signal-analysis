#!/usr/bin/env python3
"""
Step 8.1: 模型稳健性分析（基于PyTorch NN）
进行噪声鲁棒性、数据扰动敏感性、超参数敏感性等分析
"""

import os
import sys
import logging
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from pathlib import Path
from datetime import datetime
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from sklearn.preprocessing import StandardScaler
import json
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('step8_1_robustness_analysis.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class PyTorchRegressionModel(nn.Module):
    """PyTorch神经网络回归模型，支持GPU加速."""
    
    def __init__(self, input_size: int, hidden_sizes: list = [64, 32, 16], dropout_rate: float = 0.2):
        super(PyTorchRegressionModel, self).__init__()
        
        layers = []
        prev_size = input_size
        
        for hidden_size in hidden_sizes:
            layers.extend([
                nn.Linear(prev_size, hidden_size),
                nn.ReLU(),
                nn.Dropout(dropout_rate)
            ])
            prev_size = hidden_size
        
        # Output layer
        layers.append(nn.Linear(prev_size, 1))
        
        self.network = nn.Sequential(*layers)
    
    def forward(self, x):
        return self.network(x)

class ModelRobustnessAnalyzer:
    """模型稳健性分析器."""
    
    def __init__(self, device: str = 'auto', n_trials: int = 10):
        self.device = self._setup_device(device)
        self.n_trials = n_trials
        logger.info(f"Initialized ModelRobustnessAnalyzer on {self.device} with {n_trials} trials")
    
    def _setup_device(self, device: str) -> torch.device:
        """Setup computation device."""
        if device == 'auto':
            if torch.cuda.is_available():
                device = 'cuda'
                logger.info(f"CUDA available: {torch.cuda.get_device_name()}")
                logger.info(f"CUDA capability: {torch.cuda.get_device_capability()}")
                logger.info(f"CUDA memory: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB")
            else:
                device = 'cpu'
                logger.info("CUDA not available, using CPU")
        
        return torch.device(device)
    
    def load_clean_data(self, dataset_name: str, window_size: str) -> pd.DataFrame:
        """加载清理后的数据."""
        try:
            file_path = f"/mnt/d/data_analysis/processed/lri_calculation/lri_{dataset_name}_{window_size}_clean.csv"
            df = pd.read_csv(file_path)
            logger.info(f"Loaded clean data: {df.shape} from {file_path}")
            return df
        except Exception as e:
            logger.error(f"Error loading clean data for {dataset_name}_{window_size}: {e}")
            return pd.DataFrame()
    
    def prepare_features_and_target(self, df: pd.DataFrame) -> tuple:
        """准备特征和目标变量."""
        try:
            # 排除非特征列
            exclude_cols = ['window_id', 'window_size_seconds', 'sample_count']
            feature_cols = [col for col in df.columns if col not in exclude_cols]
            
            # 找到目标变量
            target_candidates = ['recovery_pattern_score', 'stress_release_efficiency', 'volatility_recovery_index', 'trend_recovery_score']
            target_col = None
            for candidate in target_candidates:
                if candidate in df.columns:
                    target_col = candidate
                    break
            
            if not target_col:
                logger.error("No target variable found")
                return None, None, None, None
            
            feature_cols = [col for col in feature_cols if col != target_col]
            
            X = df[feature_cols].values
            y = df[target_col].values
            
            return X, y, feature_cols, target_col
            
        except Exception as e:
            logger.error(f"Error preparing features and target: {e}")
            return None, None, None, None
    
    def train_pytorch_model(self, X_train: np.ndarray, y_train: np.ndarray, 
                           X_test: np.ndarray, y_test: np.ndarray, 
                           feature_cols: list, model_config: dict = None) -> dict:
        """训练PyTorch神经网络模型."""
        try:
            if model_config is None:
                model_config = {
                    'hidden_sizes': [64, 32, 16],
                    'dropout_rate': 0.2,
                    'learning_rate': 0.001,
                    'epochs': 50
                }
            
            # 数据标准化
            scaler_X = StandardScaler()
            scaler_y = StandardScaler()
            
            X_train_scaled = scaler_X.fit_transform(X_train)
            y_train_scaled = scaler_y.fit_transform(y_train.reshape(-1, 1)).flatten()
            X_test_scaled = scaler_X.transform(X_test)
            y_test_scaled = scaler_y.transform(y_test.reshape(-1, 1)).flatten()
            
            # 转换为PyTorch张量
            X_train_tensor = torch.FloatTensor(X_train_scaled).to(self.device)
            y_train_tensor = torch.FloatTensor(y_train_scaled).to(self.device)
            X_test_tensor = torch.FloatTensor(X_test_scaled).to(self.device)
            y_test_tensor = torch.FloatTensor(y_test_scaled).to(self.device)
            
            # 创建模型
            model = PyTorchRegressionModel(
                input_size=len(feature_cols),
                hidden_sizes=model_config['hidden_sizes'],
                dropout_rate=model_config['dropout_rate']
            ).to(self.device)
            
            # 损失函数和优化器
            criterion = nn.MSELoss()
            optimizer = torch.optim.Adam(model.parameters(), lr=model_config['learning_rate'])
            
            # 训练循环
            model.train()
            best_loss = float('inf')
            patience = 10
            patience_counter = 0
            
            for epoch in range(model_config['epochs']):
                optimizer.zero_grad()
                outputs = model(X_train_tensor).squeeze()
                loss = criterion(outputs, y_train_tensor)
                loss.backward()
                optimizer.step()
                
                # 早停机制
                if loss.item() < best_loss:
                    best_loss = loss.item()
                    patience_counter = 0
                else:
                    patience_counter += 1
                
                if patience_counter >= patience:
                    break
            
            # 预测
            model.eval()
            with torch.no_grad():
                y_pred_scaled = model(X_test_tensor).squeeze().cpu().numpy()
            
            # 反标准化
            y_pred = scaler_y.inverse_transform(y_pred_scaled.reshape(-1, 1)).flatten()
            
            # 计算性能指标
            mse = mean_squared_error(y_test, y_pred)
            r2 = r2_score(y_test, y_pred)
            mae = mean_absolute_error(y_test, y_pred)
            
            return {
                'model': model,
                'predictions': y_pred,
                'test_actual': y_test,
                'mse': mse,
                'r2': r2,
                'mae': mae,
                'scaler_X': scaler_X,
                'scaler_y': scaler_y,
                'feature_columns': feature_cols,
                'model_config': model_config
            }
            
        except Exception as e:
            logger.error(f"Error training PyTorch model: {e}")
            return None
    
    def noise_robustness_analysis(self, dataset_name: str, window_size: str) -> dict:
        """噪声鲁棒性分析."""
        try:
            logger.info(f"Starting noise robustness analysis for {dataset_name}_{window_size}")
            
            # 加载数据
            df = self.load_clean_data(dataset_name, window_size)
            if df.empty:
                return {'error': 'Failed to load data'}
            
            X, y, feature_cols, target_col = self.prepare_features_and_target(df)
            if X is None:
                return {'error': 'Failed to prepare features'}
            
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42
            )
            
            # 训练基准模型
            baseline_model = self.train_pytorch_model(X_train, y_train, X_test, y_test, feature_cols)
            if not baseline_model:
                return {'error': 'Failed to train baseline model'}
            
            baseline_r2 = baseline_model['r2']
            logger.info(f"Baseline R²: {baseline_r2:.3f}")
            
            # 不同噪声水平的测试
            noise_levels = [0.01, 0.05, 0.1, 0.2, 0.3]  # 噪声标准差
            noise_results = {}
            
            for noise_level in noise_levels:
                logger.info(f"Testing noise level: {noise_level}")
                
                r2_scores = []
                mse_scores = []
                
                for trial in range(self.n_trials):
                    # 添加高斯噪声到训练数据
                    np.random.seed(42 + trial)
                    noise = np.random.normal(0, noise_level, X_train.shape)
                    X_train_noisy = X_train + noise
                    
                    # 训练模型
                    noisy_model = self.train_pytorch_model(
                        X_train_noisy, y_train, X_test, y_test, feature_cols
                    )
                    
                    if noisy_model:
                        r2_scores.append(noisy_model['r2'])
                        mse_scores.append(noisy_model['mse'])
                
                if r2_scores:
                    noise_results[noise_level] = {
                        'mean_r2': np.mean(r2_scores),
                        'std_r2': np.std(r2_scores),
                        'mean_mse': np.mean(mse_scores),
                        'std_mse': np.std(mse_scores),
                        'r2_drop': baseline_r2 - np.mean(r2_scores),
                        'r2_scores': r2_scores,
                        'mse_scores': mse_scores
                    }
                    
                    logger.info(f"  Noise {noise_level}: R² = {np.mean(r2_scores):.3f} ± {np.std(r2_scores):.3f}")
            
            return {
                'dataset': dataset_name,
                'window_size': window_size,
                'baseline_r2': baseline_r2,
                'noise_results': noise_results,
                'target_variable': target_col
            }
            
        except Exception as e:
            logger.error(f"Error in noise robustness analysis: {e}")
            return {'error': str(e)}
    
    def data_perturbation_sensitivity(self, dataset_name: str, window_size: str) -> dict:
        """数据扰动敏感性分析."""
        try:
            logger.info(f"Starting data perturbation sensitivity analysis for {dataset_name}_{window_size}")
            
            # 加载数据
            df = self.load_clean_data(dataset_name, window_size)
            if df.empty:
                return {'error': 'Failed to load data'}
            
            X, y, feature_cols, target_col = self.prepare_features_and_target(df)
            if X is None:
                return {'error': 'Failed to prepare features'}
            
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42
            )
            
            # 训练基准模型
            baseline_model = self.train_pytorch_model(X_train, y_train, X_test, y_test, feature_cols)
            if not baseline_model:
                return {'error': 'Failed to train baseline model'}
            
            baseline_r2 = baseline_model['r2']
            
            # 不同的扰动策略
            perturbation_results = {}
            
            # 1. 特征缺失
            logger.info("Testing feature dropout sensitivity...")
            dropout_rates = [0.1, 0.2, 0.3, 0.5]
            dropout_results = {}
            
            for dropout_rate in dropout_rates:
                r2_scores = []
                
                for trial in range(self.n_trials):
                    # 随机丢弃特征
                    np.random.seed(42 + trial)
                    n_features = X_train.shape[1]
                    n_drop = int(n_features * dropout_rate)
                    drop_indices = np.random.choice(n_features, n_drop, replace=False)
                    
                    X_train_perturbed = X_train.copy()
                    X_train_perturbed[:, drop_indices] = 0  # 设置为0
                    
                    # 训练模型
                    perturbed_model = self.train_pytorch_model(
                        X_train_perturbed, y_train, X_test, y_test, feature_cols
                    )
                    
                    if perturbed_model:
                        r2_scores.append(perturbed_model['r2'])
                
                if r2_scores:
                    dropout_results[dropout_rate] = {
                        'mean_r2': np.mean(r2_scores),
                        'std_r2': np.std(r2_scores),
                        'r2_drop': baseline_r2 - np.mean(r2_scores)
                    }
            
            perturbation_results['feature_dropout'] = dropout_results
            
            # 2. 数据采样扰动
            logger.info("Testing data sampling sensitivity...")
            sampling_rates = [0.8, 0.6, 0.4, 0.2]
            sampling_results = {}
            
            for sampling_rate in sampling_rates:
                r2_scores = []
                
                for trial in range(self.n_trials):
                    # 随机采样
                    np.random.seed(42 + trial)
                    n_samples = int(len(X_train) * sampling_rate)
                    sample_indices = np.random.choice(len(X_train), n_samples, replace=False)
                    
                    X_train_sampled = X_train[sample_indices]
                    y_train_sampled = y_train[sample_indices]
                    
                    # 训练模型
                    sampled_model = self.train_pytorch_model(
                        X_train_sampled, y_train_sampled, X_test, y_test, feature_cols
                    )
                    
                    if sampled_model:
                        r2_scores.append(sampled_model['r2'])
                
                if r2_scores:
                    sampling_results[sampling_rate] = {
                        'mean_r2': np.mean(r2_scores),
                        'std_r2': np.std(r2_scores),
                        'r2_drop': baseline_r2 - np.mean(r2_scores)
                    }
            
            perturbation_results['data_sampling'] = sampling_results
            
            return {
                'dataset': dataset_name,
                'window_size': window_size,
                'baseline_r2': baseline_r2,
                'perturbation_results': perturbation_results,
                'target_variable': target_col
            }
            
        except Exception as e:
            logger.error(f"Error in data perturbation sensitivity analysis: {e}")
            return {'error': str(e)}
    
    def hyperparameter_sensitivity(self, dataset_name: str, window_size: str) -> dict:
        """超参数敏感性分析."""
        try:
            logger.info(f"Starting hyperparameter sensitivity analysis for {dataset_name}_{window_size}")
            
            # 加载数据
            df = self.load_clean_data(dataset_name, window_size)
            if df.empty:
                return {'error': 'Failed to load data'}
            
            X, y, feature_cols, target_col = self.prepare_features_and_target(df)
            if X is None:
                return {'error': 'Failed to prepare features'}
            
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42
            )
            
            # 基准配置
            baseline_config = {
                'hidden_sizes': [64, 32, 16],
                'dropout_rate': 0.2,
                'learning_rate': 0.001,
                'epochs': 50
            }
            
            baseline_model = self.train_pytorch_model(X_train, y_train, X_test, y_test, feature_cols, baseline_config)
            if not baseline_model:
                return {'error': 'Failed to train baseline model'}
            
            baseline_r2 = baseline_model['r2']
            
            # 超参数敏感性测试
            sensitivity_results = {}
            
            # 1. 学习率敏感性
            logger.info("Testing learning rate sensitivity...")
            learning_rates = [0.0001, 0.0005, 0.001, 0.005, 0.01]
            lr_results = {}
            
            for lr in learning_rates:
                config = baseline_config.copy()
                config['learning_rate'] = lr
                
                model = self.train_pytorch_model(X_train, y_train, X_test, y_test, feature_cols, config)
                if model:
                    lr_results[lr] = {
                        'r2': model['r2'],
                        'mse': model['mse'],
                        'r2_drop': baseline_r2 - model['r2']
                    }
            
            sensitivity_results['learning_rate'] = lr_results
            
            # 2. Dropout敏感性
            logger.info("Testing dropout rate sensitivity...")
            dropout_rates = [0.0, 0.1, 0.2, 0.3, 0.5]
            dropout_results = {}
            
            for dropout_rate in dropout_rates:
                config = baseline_config.copy()
                config['dropout_rate'] = dropout_rate
                
                model = self.train_pytorch_model(X_train, y_train, X_test, y_test, feature_cols, config)
                if model:
                    dropout_results[dropout_rate] = {
                        'r2': model['r2'],
                        'mse': model['mse'],
                        'r2_drop': baseline_r2 - model['r2']
                    }
            
            sensitivity_results['dropout_rate'] = dropout_results
            
            # 3. 网络结构敏感性
            logger.info("Testing network architecture sensitivity...")
            architectures = [
                [32, 16],      # 更小
                [64, 32, 16],  # 基准
                [128, 64, 32], # 更大
                [64, 64, 32, 16]  # 更深
            ]
            arch_results = {}
            
            for i, hidden_sizes in enumerate(architectures):
                config = baseline_config.copy()
                config['hidden_sizes'] = hidden_sizes
                
                model = self.train_pytorch_model(X_train, y_train, X_test, y_test, feature_cols, config)
                if model:
                    arch_results[f'arch_{i}'] = {
                        'hidden_sizes': hidden_sizes,
                        'r2': model['r2'],
                        'mse': model['mse'],
                        'r2_drop': baseline_r2 - model['r2']
                    }
            
            sensitivity_results['architecture'] = arch_results
            
            return {
                'dataset': dataset_name,
                'window_size': window_size,
                'baseline_r2': baseline_r2,
                'baseline_config': baseline_config,
                'sensitivity_results': sensitivity_results,
                'target_variable': target_col
            }
            
        except Exception as e:
            logger.error(f"Error in hyperparameter sensitivity analysis: {e}")
            return {'error': str(e)}
    
    def comprehensive_robustness_analysis(self, datasets: list, window_sizes: list) -> dict:
        """综合稳健性分析."""
        try:
            logger.info("Starting comprehensive robustness analysis...")
            
            all_results = {}
            
            for dataset in datasets:
                logger.info(f"\n{'='*60}")
                logger.info(f"Analyzing dataset: {dataset}")
                logger.info(f"{'='*60}")
                
                dataset_results = {}
                
                for window_size in window_sizes:
                    logger.info(f"\nWindow size: {window_size}")
                    
                    window_results = {}
                    
                    # 噪声鲁棒性分析
                    logger.info("1. Noise robustness analysis...")
                    noise_result = self.noise_robustness_analysis(dataset, window_size)
                    window_results['noise_robustness'] = noise_result
                    
                    # 数据扰动敏感性分析
                    logger.info("2. Data perturbation sensitivity analysis...")
                    perturbation_result = self.data_perturbation_sensitivity(dataset, window_size)
                    window_results['data_perturbation'] = perturbation_result
                    
                    # 超参数敏感性分析
                    logger.info("3. Hyperparameter sensitivity analysis...")
                    hyperparameter_result = self.hyperparameter_sensitivity(dataset, window_size)
                    window_results['hyperparameter_sensitivity'] = hyperparameter_result
                    
                    dataset_results[window_size] = window_results
                
                all_results[dataset] = dataset_results
            
            return {
                'datasets': datasets,
                'window_sizes': window_sizes,
                'analysis_results': all_results,
                'analysis_timestamp': datetime.now().isoformat(),
                'n_trials': self.n_trials
            }
            
        except Exception as e:
            logger.error(f"Error in comprehensive robustness analysis: {e}")
            return {'error': str(e)}

def main():
    """主函数."""
    try:
        logger.info("Starting Step 8.1: Model Robustness Analysis")
        
        # 数据集配置 - 选择表现正常的数据集
        datasets = ['DRIVE_DB']  # 先分析一个数据集
        window_sizes = ['60s']   # 先分析一个时间窗口
        
        output_dir = '/mnt/d/data_analysis/processed/step8_robustness_analysis'
        Path(output_dir).mkdir(exist_ok=True)
        
        # 初始化稳健性分析器
        analyzer = ModelRobustnessAnalyzer(device='auto', n_trials=5)  # 减少试验次数以加快速度
        
        # 执行综合稳健性分析
        logger.info(f"Executing robustness analysis for {datasets} with window sizes {window_sizes}")
        
        robustness_results = analyzer.comprehensive_robustness_analysis(datasets, window_sizes)
        
        if 'error' in robustness_results:
            logger.error(f"Robustness analysis failed: {robustness_results['error']}")
            return
        
        # 保存结果
        output_file = Path(output_dir) / 'model_robustness_analysis_results.json'
        with open(output_file, 'w') as f:
            json.dump(robustness_results, f, indent=2, default=str)
        
        logger.info(f"Robustness analysis results saved: {output_file}")
        
        # 分析结果
        logger.info(f"\n{'='*60}")
        logger.info("Model Robustness Analysis Summary")
        logger.info(f"{'='*60}")
        
        for dataset, dataset_results in robustness_results['analysis_results'].items():
            logger.info(f"\nDataset: {dataset}")
            
            for window_size, window_data in dataset_results.items():
                logger.info(f"\nWindow Size: {window_size}")
                
                # 噪声鲁棒性
                noise_data = window_data.get('noise_robustness', {})
                if 'baseline_r2' in noise_data:
                    logger.info(f"  Baseline R²: {noise_data['baseline_r2']:.3f}")
                    
                    noise_results = noise_data.get('noise_results', {})
                    for noise_level, result in noise_results.items():
                        logger.info(f"  Noise {noise_level}: R² = {result['mean_r2']:.3f} ± {result['std_r2']:.3f} (drop: {result['r2_drop']:.3f})")
                
                # 超参数敏感性
                hyper_data = window_data.get('hyperparameter_sensitivity', {})
                if 'baseline_r2' in hyper_data:
                    logger.info(f"  Hyperparameter sensitivity:")
                    
                    lr_results = hyper_data.get('sensitivity_results', {}).get('learning_rate', {})
                    for lr, result in lr_results.items():
                        logger.info(f"    LR {lr}: R² = {result['r2']:.3f} (drop: {result['r2_drop']:.3f})")
        
        logger.info(f"\n{'='*60}")
        logger.info("Step 8.1 Model Robustness Analysis Completed Successfully!")
        logger.info(f"{'='*60}")
        
        logger.info("🎉 Key Achievements:")
        logger.info("  ✓ GPU-accelerated PyTorch NN training")
        logger.info("  ✓ Noise robustness analysis")
        logger.info("  ✓ Data perturbation sensitivity analysis")
        logger.info("  ✓ Hyperparameter sensitivity analysis")
        logger.info("  ✓ Comprehensive robustness evaluation")
        
    except Exception as e:
        logger.error(f"Error in main execution: {e}")
        raise

if __name__ == "__main__":
    main()
