#!/usr/bin/env python3
"""
Step 9.2: 干预效果深入分析与可视化
分析干预结果，生成可视化图表和深入分析报告
"""

import os
import sys
import logging
import pandas as pd
import numpy as np
import json
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('step9_2_intervention_analysis_and_visualization.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class InterventionAnalyzer:
    """干预效果分析器."""
    
    def __init__(self):
        self.base_dir = '/mnt/d/data_analysis/processed/step9_intervention_simulation'
        self.output_dir = '/mnt/d/data_analysis/processed/step9_intervention_simulation'
        Path(self.output_dir).mkdir(exist_ok=True)
        
        # 设置中文字体
        plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
        plt.rcParams['axes.unicode_minus'] = False
        
        logger.info("Initialized InterventionAnalyzer")
    
    def load_intervention_results(self, dataset_name: str, window_size: str) -> dict:
        """加载干预仿真结果."""
        try:
            file_path = Path(self.base_dir) / f'intervention_simulation_{dataset_name}_{window_size}_results.json'
            
            if not file_path.exists():
                logger.error(f"Intervention results file not found: {file_path}")
                return {}
            
            with open(file_path, 'r') as f:
                results = json.load(f)
            
            logger.info(f"Loaded intervention results from {file_path}")
            return results
            
        except Exception as e:
            logger.error(f"Error loading intervention results: {e}")
            return {}
    
    def analyze_intervention_effectiveness(self, results: dict) -> dict:
        """分析干预效果."""
        try:
            logger.info("Analyzing intervention effectiveness...")
            
            analysis = {
                'strategy_comparison': {},
                'parameter_sensitivity': {},
                'effectiveness_distribution': {},
                'recommendations': []
            }
            
            intervention_results = results.get('intervention_results', {})
            
            # 策略比较分析
            strategy_performance = []
            for strategy_name, strategy_data in intervention_results.items():
                strategy_info = strategy_data['strategy_info']
                best_improvement = strategy_data['best_improvement']
                
                strategy_performance.append({
                    'strategy_name': strategy_info['name'],
                    'strategy_type': strategy_info['intervention_type'],
                    'best_improvement': best_improvement,
                    'best_parameters': strategy_data['best_parameters'],
                    'description': strategy_info['description']
                })
            
            # 按改善效果排序
            strategy_performance.sort(key=lambda x: x['best_improvement'], reverse=True)
            analysis['strategy_comparison'] = strategy_performance
            
            # 参数敏感性分析
            for strategy_name, strategy_data in intervention_results.items():
                parameter_results = strategy_data.get('parameter_results', {})
                
                if parameter_results:
                    improvements = []
                    parameters = []
                    
                    for param_str, param_result in parameter_results.items():
                        effectiveness = param_result.get('effectiveness', {})
                        mean_improvement = effectiveness.get('mean_improvement', 0)
                        improvements.append(mean_improvement)
                        parameters.append(param_str)
                    
                    analysis['parameter_sensitivity'][strategy_name] = {
                        'improvements': improvements,
                        'parameters': parameters,
                        'improvement_range': [min(improvements), max(improvements)],
                        'improvement_std': np.std(improvements) if improvements else 0
                    }
            
            # 效果分布分析
            all_improvements = []
            for strategy_data in intervention_results.values():
                parameter_results = strategy_data.get('parameter_results', {})
                for param_result in parameter_results.values():
                    effectiveness = param_result.get('effectiveness', {})
                    mean_improvement = effectiveness.get('mean_improvement', 0)
                    all_improvements.append(mean_improvement)
            
            if all_improvements:
                analysis['effectiveness_distribution'] = {
                    'mean_improvement': np.mean(all_improvements),
                    'std_improvement': np.std(all_improvements),
                    'median_improvement': np.median(all_improvements),
                    'positive_improvements': np.sum(np.array(all_improvements) > 0),
                    'negative_improvements': np.sum(np.array(all_improvements) < 0),
                    'neutral_improvements': np.sum(np.abs(np.array(all_improvements)) <= 0.001)
                }
            
            # 生成建议
            if strategy_performance:
                best_strategy = strategy_performance[0]
                analysis['recommendations'].append(f"最佳干预策略: {best_strategy['strategy_name']} (改善: {best_strategy['best_improvement']:.4f})")
                
                if best_strategy['best_improvement'] > 0:
                    analysis['recommendations'].append("建议实施该干预策略以获得积极效果")
                elif best_strategy['best_improvement'] < 0:
                    analysis['recommendations'].append("警告: 当前干预策略可能产生负面影响")
                else:
                    analysis['recommendations'].append("当前系统可能已达到最优状态，无需额外干预")
            
            return analysis
            
        except Exception as e:
            logger.error(f"Error analyzing intervention effectiveness: {e}")
            return {}
    
    def create_intervention_visualizations(self, results: dict, analysis: dict) -> dict:
        """创建干预效果可视化图表."""
        try:
            logger.info("Creating intervention visualizations...")
            
            viz_files = {}
            
            # 1. 策略效果对比图
            self._create_strategy_comparison_plot(analysis, viz_files)
            
            # 2. 参数敏感性分析图
            self._create_parameter_sensitivity_plot(analysis, viz_files)
            
            # 3. 干预效果分布图
            self._create_effectiveness_distribution_plot(analysis, viz_files)
            
            # 4. 干预前后对比图
            self._create_before_after_comparison_plot(results, viz_files)
            
            return viz_files
            
        except Exception as e:
            logger.error(f"Error creating visualizations: {e}")
            return {}
    
    def _create_strategy_comparison_plot(self, analysis: dict, viz_files: dict):
        """创建策略效果对比图."""
        try:
            strategy_performance = analysis.get('strategy_comparison', [])
            
            if not strategy_performance:
                return
            
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
            fig.suptitle('Intervention Strategy Comparison', fontsize=16)
            
            # 策略改善效果条形图
            strategy_names = [s['strategy_name'] for s in strategy_performance]
            improvements = [s['best_improvement'] for s in strategy_performance]
            
            colors = ['green' if imp > 0 else 'red' if imp < 0 else 'gray' for imp in improvements]
            
            bars = ax1.bar(range(len(strategy_names)), improvements, color=colors, alpha=0.7)
            ax1.set_xlabel('Intervention Strategies')
            ax1.set_ylabel('Improvement Score')
            ax1.set_title('Best Improvement by Strategy')
            ax1.set_xticks(range(len(strategy_names)))
            ax1.set_xticklabels(strategy_names, rotation=45, ha='right')
            ax1.axhline(y=0, color='black', linestyle='--', alpha=0.5)
            ax1.grid(True, alpha=0.3)
            
            # 添加数值标签
            for i, (bar, imp) in enumerate(zip(bars, improvements)):
                ax1.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.0001 if imp >= 0 else bar.get_height() - 0.0001,
                        f'{imp:.4f}', ha='center', va='bottom' if imp >= 0 else 'top', fontsize=9)
            
            # 策略类型分布饼图
            strategy_types = [s['strategy_type'] for s in strategy_performance]
            type_counts = {}
            for stype in strategy_types:
                type_counts[stype] = type_counts.get(stype, 0) + 1
            
            ax2.pie(type_counts.values(), labels=type_counts.keys(), autopct='%1.1f%%', startangle=90)
            ax2.set_title('Distribution of Intervention Types')
            
            plt.tight_layout()
            plot_file = Path(self.output_dir) / 'intervention_strategy_comparison.png'
            plt.savefig(plot_file, dpi=300, bbox_inches='tight')
            plt.close()
            
            viz_files['strategy_comparison'] = str(plot_file)
            logger.info(f"Created strategy comparison plot: {plot_file}")
            
        except Exception as e:
            logger.error(f"Error creating strategy comparison plot: {e}")
    
    def _create_parameter_sensitivity_plot(self, analysis: dict, viz_files: dict):
        """创建参数敏感性分析图."""
        try:
            parameter_sensitivity = analysis.get('parameter_sensitivity', {})
            
            if not parameter_sensitivity:
                return
            
            n_strategies = len(parameter_sensitivity)
            if n_strategies == 0:
                return
            
            fig, axes = plt.subplots(2, 3, figsize=(18, 12))
            fig.suptitle('Parameter Sensitivity Analysis', fontsize=16)
            
            axes = axes.flatten()
            
            for i, (strategy_name, sens_data) in enumerate(parameter_sensitivity.items()):
                if i >= len(axes):
                    break
                
                ax = axes[i]
                improvements = sens_data['improvements']
                parameters = sens_data['parameters']
                
                # 简化参数标签
                param_labels = [f"Param {j+1}" for j in range(len(parameters))]
                
                ax.plot(range(len(improvements)), improvements, 'o-', linewidth=2, markersize=6)
                ax.set_xlabel('Parameter Combinations')
                ax.set_ylabel('Improvement Score')
                ax.set_title(f'{strategy_name}')
                ax.grid(True, alpha=0.3)
                ax.axhline(y=0, color='black', linestyle='--', alpha=0.5)
                
                # 添加改善范围信息
                imp_range = sens_data['improvement_range']
                ax.text(0.02, 0.98, f'Range: [{imp_range[0]:.4f}, {imp_range[1]:.4f}]', 
                       transform=ax.transAxes, verticalalignment='top',
                       bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
            
            # 隐藏多余的子图
            for j in range(i+1, len(axes)):
                axes[j].set_visible(False)
            
            plt.tight_layout()
            plot_file = Path(self.output_dir) / 'parameter_sensitivity_analysis.png'
            plt.savefig(plot_file, dpi=300, bbox_inches='tight')
            plt.close()
            
            viz_files['parameter_sensitivity'] = str(plot_file)
            logger.info(f"Created parameter sensitivity plot: {plot_file}")
            
        except Exception as e:
            logger.error(f"Error creating parameter sensitivity plot: {e}")
    
    def _create_effectiveness_distribution_plot(self, analysis: dict, viz_files: dict):
        """创建干预效果分布图."""
        try:
            effectiveness_dist = analysis.get('effectiveness_distribution', {})
            
            if not effectiveness_dist:
                return
            
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
            fig.suptitle('Intervention Effectiveness Distribution', fontsize=16)
            
            # 效果统计条形图
            categories = ['Positive', 'Neutral', 'Negative']
            counts = [
                effectiveness_dist.get('positive_improvements', 0),
                effectiveness_dist.get('neutral_improvements', 0),
                effectiveness_dist.get('negative_improvements', 0)
            ]
            
            colors = ['green', 'gray', 'red']
            bars = ax1.bar(categories, counts, color=colors, alpha=0.7)
            ax1.set_ylabel('Number of Interventions')
            ax1.set_title('Distribution of Intervention Effects')
            ax1.grid(True, alpha=0.3)
            
            # 添加数值标签
            for bar, count in zip(bars, counts):
                ax1.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.5,
                        str(count), ha='center', va='bottom')
            
            # 统计信息文本
            stats_text = f"""
Mean Improvement: {effectiveness_dist.get('mean_improvement', 0):.4f}
Std Improvement: {effectiveness_dist.get('std_improvement', 0):.4f}
Median Improvement: {effectiveness_dist.get('median_improvement', 0):.4f}
            """.strip()
            
            ax2.text(0.1, 0.5, stats_text, transform=ax2.transAxes, fontsize=12,
                    verticalalignment='center', bbox=dict(boxstyle='round', facecolor='lightblue', alpha=0.8))
            ax2.set_xlim(0, 1)
            ax2.set_ylim(0, 1)
            ax2.axis('off')
            ax2.set_title('Effectiveness Statistics')
            
            plt.tight_layout()
            plot_file = Path(self.output_dir) / 'effectiveness_distribution.png'
            plt.savefig(plot_file, dpi=300, bbox_inches='tight')
            plt.close()
            
            viz_files['effectiveness_distribution'] = str(plot_file)
            logger.info(f"Created effectiveness distribution plot: {plot_file}")
            
        except Exception as e:
            logger.error(f"Error creating effectiveness distribution plot: {e}")
    
    def _create_before_after_comparison_plot(self, results: dict, viz_files: dict):
        """创建干预前后对比图."""
        try:
            baseline_perf = results.get('baseline_performance', {})
            intervention_results = results.get('intervention_results', {})
            
            if not baseline_perf or not intervention_results:
                return
            
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
            fig.suptitle('Before vs After Intervention Comparison', fontsize=16)
            
            # 基准性能指标
            baseline_r2 = baseline_perf.get('r2', 0)
            baseline_mse = baseline_perf.get('mse', 0)
            baseline_mae = baseline_perf.get('mae', 0)
            
            # 收集所有干预后的性能
            intervention_r2s = []
            intervention_mses = []
            intervention_maes = []
            strategy_names = []
            
            for strategy_name, strategy_data in intervention_results.items():
                strategy_info = strategy_data['strategy_info']
                parameter_results = strategy_data.get('parameter_results', {})
                
                if parameter_results:
                    # 取最佳参数的结果
                    best_params = strategy_data.get('best_parameters', '')
                    if best_params in parameter_results:
                        param_result = parameter_results[best_params]
                        intervention_result = param_result.get('intervention_result', {})
                        
                        # 这里需要从干预结果中计算性能指标
                        # 由于我们没有直接的R²等指标，我们使用改善效果来近似
                        best_improvement = strategy_data.get('best_improvement', 0)
                        
                        # 假设改善效果反映在R²上
                        estimated_r2 = baseline_r2 + best_improvement
                        estimated_mse = baseline_mse * (1 - best_improvement) if best_improvement > 0 else baseline_mse
                        estimated_mae = baseline_mae * (1 - best_improvement) if best_improvement > 0 else baseline_mae
                        
                        intervention_r2s.append(estimated_r2)
                        intervention_mses.append(estimated_mse)
                        intervention_maes.append(estimated_mae)
                        strategy_names.append(strategy_info['name'])
            
            if intervention_r2s:
                # R²对比
                x_pos = np.arange(len(strategy_names) + 1)
                r2_values = [baseline_r2] + intervention_r2s
                labels = ['Baseline'] + strategy_names
                
                bars = ax1.bar(x_pos, r2_values, color=['blue'] + ['green' if r > baseline_r2 else 'red' if r < baseline_r2 else 'gray' for r in intervention_r2s], alpha=0.7)
                ax1.set_xlabel('Strategies')
                ax1.set_ylabel('R² Score')
                ax1.set_title('R² Score Comparison')
                ax1.set_xticks(x_pos)
                ax1.set_xticklabels(labels, rotation=45, ha='right')
                ax1.grid(True, alpha=0.3)
                
                # 添加数值标签
                for bar, value in zip(bars, r2_values):
                    ax1.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.001,
                            f'{value:.3f}', ha='center', va='bottom', fontsize=9)
                
                # MSE对比
                mse_values = [baseline_mse] + intervention_mses
                bars2 = ax2.bar(x_pos, mse_values, color=['blue'] + ['green' if m < baseline_mse else 'red' if m > baseline_mse else 'gray' for m in intervention_mses], alpha=0.7)
                ax2.set_xlabel('Strategies')
                ax2.set_ylabel('MSE')
                ax2.set_title('MSE Comparison')
                ax2.set_xticks(x_pos)
                ax2.set_xticklabels(labels, rotation=45, ha='right')
                ax2.grid(True, alpha=0.3)
                
                # 添加数值标签
                for bar, value in zip(bars2, mse_values):
                    ax2.text(bar.get_x() + bar.get_width()/2, bar.get_height() + max(mse_values) * 0.01,
                            f'{value:.4f}', ha='center', va='bottom', fontsize=9)
            
            plt.tight_layout()
            plot_file = Path(self.output_dir) / 'before_after_comparison.png'
            plt.savefig(plot_file, dpi=300, bbox_inches='tight')
            plt.close()
            
            viz_files['before_after_comparison'] = str(plot_file)
            logger.info(f"Created before/after comparison plot: {plot_file}")
            
        except Exception as e:
            logger.error(f"Error creating before/after comparison plot: {e}")
    
    def generate_intervention_report(self, results: dict, analysis: dict, viz_files: dict) -> str:
        """生成干预分析报告."""
        try:
            logger.info("Generating intervention analysis report...")
            
            report = []
            report.append("# 干预仿真分析报告")
            report.append(f"\n**生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
            
            # 基本信息
            dataset = results.get('dataset', 'Unknown')
            window_size = results.get('window_size', 'Unknown')
            target_variable = results.get('target_variable', 'Unknown')
            
            report.append(f"\n**数据集**: {dataset}")
            report.append(f"\n**时间窗口**: {window_size}")
            report.append(f"\n**目标变量**: {target_variable}")
            
            # 基准性能
            baseline_perf = results.get('baseline_performance', {})
            report.append("\n## 1. 基准性能")
            report.append(f"- **R² 分数**: {baseline_perf.get('r2', 'N/A'):.3f}")
            report.append(f"- **均方误差**: {baseline_perf.get('mse', 'N/A'):.4f}")
            report.append(f"- **平均绝对误差**: {baseline_perf.get('mae', 'N/A'):.4f}")
            
            # 策略比较
            strategy_comparison = analysis.get('strategy_comparison', [])
            report.append("\n## 2. 干预策略比较")
            
            if strategy_comparison:
                report.append("\n### 2.1 策略效果排序")
                for i, strategy in enumerate(strategy_comparison, 1):
                    report.append(f"{i}. **{strategy['strategy_name']}**")
                    report.append(f"   - 改善效果: {strategy['best_improvement']:.4f}")
                    report.append(f"   - 策略类型: {strategy['strategy_type']}")
                    report.append(f"   - 描述: {strategy['description']}")
                    report.append(f"   - 最佳参数: {strategy['best_parameters']}")
                    report.append("")
            
            # 效果分布分析
            effectiveness_dist = analysis.get('effectiveness_distribution', {})
            report.append("\n## 3. 干预效果分布分析")
            
            if effectiveness_dist:
                report.append(f"- **平均改善**: {effectiveness_dist.get('mean_improvement', 0):.4f}")
                report.append(f"- **改善标准差**: {effectiveness_dist.get('std_improvement', 0):.4f}")
                report.append(f"- **改善中位数**: {effectiveness_dist.get('median_improvement', 0):.4f}")
                report.append(f"- **正面效果干预**: {effectiveness_dist.get('positive_improvements', 0)} 个")
                report.append(f"- **中性效果干预**: {effectiveness_dist.get('neutral_improvements', 0)} 个")
                report.append(f"- **负面效果干预**: {effectiveness_dist.get('negative_improvements', 0)} 个")
            
            # 参数敏感性分析
            parameter_sensitivity = analysis.get('parameter_sensitivity', {})
            report.append("\n## 4. 参数敏感性分析")
            
            for strategy_name, sens_data in parameter_sensitivity.items():
                report.append(f"\n### 4.1 {strategy_name}")
                report.append(f"- **改善范围**: [{sens_data['improvement_range'][0]:.4f}, {sens_data['improvement_range'][1]:.4f}]")
                report.append(f"- **改善标准差**: {sens_data['improvement_std']:.4f}")
                
                if sens_data['improvement_std'] < 0.001:
                    report.append("- **敏感性评估**: 低敏感性，参数变化对效果影响较小")
                elif sens_data['improvement_std'] < 0.01:
                    report.append("- **敏感性评估**: 中等敏感性，参数选择有一定影响")
                else:
                    report.append("- **敏感性评估**: 高敏感性，参数选择对效果影响显著")
            
            # 建议
            recommendations = analysis.get('recommendations', [])
            report.append("\n## 5. 建议与结论")
            
            for i, rec in enumerate(recommendations, 1):
                report.append(f"{i}. {rec}")
            
            # 可视化文件
            if viz_files:
                report.append("\n## 6. 可视化文件")
                for viz_name, viz_file in viz_files.items():
                    report.append(f"- **{viz_name}**: `{viz_file}`")
            
            report.append("\n---")
            report.append(f"\n*报告生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*")
            
            report_text = '\n'.join(report)
            
            # 保存报告
            report_file = Path(self.output_dir) / 'intervention_analysis_report.md'
            with open(report_file, 'w', encoding='utf-8') as f:
                f.write(report_text)
            
            logger.info(f"Intervention analysis report saved: {report_file}")
            return report_text
            
        except Exception as e:
            logger.error(f"Error generating intervention report: {e}")
            return ""

def main():
    """主函数."""
    try:
        logger.info("Starting Step 9.2: Intervention Analysis and Visualization")
        
        # 配置
        dataset = 'DRIVE_DB'
        window_size = '60s'
        
        # 初始化分析器
        analyzer = InterventionAnalyzer()
        
        # 加载干预结果
        logger.info(f"Loading intervention results for {dataset}_{window_size}")
        results = analyzer.load_intervention_results(dataset, window_size)
        
        if not results:
            logger.error("No intervention results found!")
            return
        
        # 分析干预效果
        logger.info("Analyzing intervention effectiveness...")
        analysis = analyzer.analyze_intervention_effectiveness(results)
        
        # 创建可视化
        logger.info("Creating visualizations...")
        viz_files = analyzer.create_intervention_visualizations(results, analysis)
        
        # 生成报告
        logger.info("Generating intervention analysis report...")
        report = analyzer.generate_intervention_report(results, analysis, viz_files)
        
        # 保存分析结果
        analysis_file = Path(analyzer.output_dir) / 'intervention_analysis_results.json'
        with open(analysis_file, 'w') as f:
            json.dump(analysis, f, indent=2, default=str)
        
        logger.info(f"Analysis results saved: {analysis_file}")
        
        # 输出关键发现
        logger.info(f"\n{'='*60}")
        logger.info("Intervention Analysis Summary")
        logger.info(f"{'='*60}")
        
        # 基准性能
        baseline_perf = results.get('baseline_performance', {})
        logger.info(f"📊 Baseline Performance:")
        logger.info(f"  R² = {baseline_perf.get('r2', 0):.3f}")
        logger.info(f"  MSE = {baseline_perf.get('mse', 0):.4f}")
        logger.info(f"  MAE = {baseline_perf.get('mae', 0):.4f}")
        
        # 最佳策略
        strategy_comparison = analysis.get('strategy_comparison', [])
        if strategy_comparison:
            best_strategy = strategy_comparison[0]
            logger.info(f"🏆 Best Intervention Strategy:")
            logger.info(f"  Strategy: {best_strategy['strategy_name']}")
            logger.info(f"  Improvement: {best_strategy['best_improvement']:.4f}")
            logger.info(f"  Type: {best_strategy['strategy_type']}")
        
        # 效果分布
        effectiveness_dist = analysis.get('effectiveness_distribution', {})
        if effectiveness_dist:
            logger.info(f"📈 Effectiveness Distribution:")
            logger.info(f"  Positive: {effectiveness_dist.get('positive_improvements', 0)} interventions")
            logger.info(f"  Neutral: {effectiveness_dist.get('neutral_improvements', 0)} interventions")
            logger.info(f"  Negative: {effectiveness_dist.get('negative_improvements', 0)} interventions")
            logger.info(f"  Mean improvement: {effectiveness_dist.get('mean_improvement', 0):.4f}")
        
        # 可视化文件
        logger.info(f"📊 Visualizations created: {len(viz_files)}")
        for viz_name, viz_file in viz_files.items():
            logger.info(f"  - {viz_name}: {viz_file}")
        
        logger.info(f"\n{'='*60}")
        logger.info("Step 9.2 Intervention Analysis and Visualization Completed!")
        logger.info(f"{'='*60}")
        
        logger.info("🎉 Key Achievements:")
        logger.info("  ✓ Comprehensive intervention effectiveness analysis")
        logger.info("  ✓ Strategy comparison and ranking")
        logger.info("  ✓ Parameter sensitivity analysis")
        logger.info("  ✓ Effectiveness distribution analysis")
        logger.info("  ✓ Multiple visualization charts")
        logger.info("  ✓ Detailed analysis report")
        
    except Exception as e:
        logger.error(f"Error in main execution: {e}")
        raise

if __name__ == "__main__":
    main()
