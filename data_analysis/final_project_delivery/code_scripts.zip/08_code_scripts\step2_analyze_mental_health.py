#!/usr/bin/env python3
"""
Step 2: Analyze Mental Health Prediction Dataset
"""

import pandas as pd
import numpy as np
from pathlib import Path

def analyze_mental_health():
    """Analyze Mental Health Prediction dataset file."""
    file_path = "processed/Mental_Health_Pred_extracted/mental_health_wearable_data.csv"
    
    print(f"Analyzing: {file_path}")
    print("="*60)
    
    # Check if file exists
    if not Path(file_path).exists():
        print(f"❌ File does not exist: {file_path}")
        return None
    
    try:
        # Read the file
        df = pd.read_csv(file_path)
        print(f"✅ Successfully read file")
        print(f"📊 Shape: {df.shape[0]} rows, {df.shape[1]} columns")
        print(f"📋 Columns: {list(df.columns)}")
        
        # Show data types
        print(f"🔍 Data types:")
        for col, dtype in df.dtypes.items():
            print(f"   - {col}: {dtype}")
        
        # Show first few rows
        print(f"📄 First 3 rows:")
        print(df.head(3).to_string())
        
        # Check for missing data
        print(f"⚠️ Missing data:")
        missing = df.isnull().sum()
        missing_found = False
        for col, count in missing.items():
            if count > 0:
                missing_found = True
                pct = (count / len(df)) * 100
                print(f"   - {col}: {count} ({pct:.1f}%)")
        if not missing_found:
            print("   ✅ No missing data found")
        
        # Check theoretical parameters
        theoretical_params = {
            'hrv_rmssd': ['rmssd', 'RMSSD', 'hrv_rmssd'],
            'hrv_sdnn': ['sdnn', 'SDNN', 'hrv_sdnn'],
            'hr_mean': ['hr', 'HR', 'heart_rate', 'Heart_Rate_BPM'],
            'eda': ['eda', 'EDA', 'gsr', 'GSR', 'skin_conductance'],
            'ibi': ['ibi', 'IBI', 'rr_interval'],
            'temperature': ['temp', 'temperature', 'body_temp'],
            'acceleration': ['acc', 'activity', 'Physical_Activity_Steps'],
            'stress_label': ['stress', 'condition', 'state', 'Mental_Health_Condition'],
            'phq_9': ['phq9', 'PHQ9', 'depression', 'Mood_Rating'],
            'sleep': ['sleep', 'Sleep_Duration_Hours']
        }
        
        print(f"🎯 Theoretical parameter mapping:")
        found_params = {}
        for param_name, aliases in theoretical_params.items():
            found_columns = []
            for col in df.columns:
                col_lower = str(col).lower()
                for alias in aliases:
                    if alias.lower() in col_lower:
                        found_columns.append(col)
            if found_columns:
                found_params[param_name] = found_columns
                print(f"   - {param_name}: {found_columns}")
        
        # Show unique values in categorical columns
        print(f"📊 Categorical column distributions:")
        for col in df.columns:
            if df[col].dtype == 'object':
                unique_vals = df[col].unique()
                if len(unique_vals) <= 10:  # Only show if reasonable number of unique values
                    value_counts = df[col].value_counts()
                    print(f"   - {col}:")
                    for val, count in value_counts.items():
                        print(f"     * {val}: {count} ({count/len(df)*100:.1f}%)")
        
        # Basic statistics for numeric columns
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        if len(numeric_cols) > 0:
            print(f"📈 Numeric column statistics:")
            stats = df[numeric_cols].describe()
            print(stats.to_string())
        
        return {
            'file_path': file_path,
            'shape': df.shape,
            'columns': list(df.columns),
            'dtypes': dict(df.dtypes),
            'missing_data': dict(missing),
            'theoretical_params': found_params,
            'categorical_distributions': {col: dict(df[col].value_counts()) for col in df.columns if df[col].dtype == 'object' and df[col].nunique() <= 10},
            'numeric_statistics': stats.to_dict() if len(numeric_cols) > 0 else {}
        }
        
    except Exception as e:
        print(f"❌ Error reading file: {e}")
        return None

if __name__ == "__main__":
    result = analyze_mental_health()
    
    if result:
        print(f"\n✅ Mental Health dataset analysis completed successfully")
        print(f"Found {len(result['theoretical_params'])} theoretical parameters")
        print(f"Data quality: {result['shape'][0]} rows with {len([k for k, v in result['missing_data'].items() if v > 0])} columns having missing data")
    else:
        print(f"\n❌ Mental Health analysis failed")








