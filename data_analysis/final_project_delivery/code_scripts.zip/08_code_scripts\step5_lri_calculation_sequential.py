#!/usr/bin/env python3
"""
Step 5: LRI Calculation and Time Aggregation - Sequential Processing
逐个处理数据集，避免资源竞争和hang问题
"""

import os
import sys
import logging
import pandas as pd
import numpy as np
import torch
from pathlib import Path
from datetime import datetime
from sklearn.cluster import KMeans
from sklearn.mixture import GaussianMixture
from sklearn.metrics import silhouette_score, calinski_harabasz_score
import multiprocessing as mp
import warnings
warnings.filterwarnings('ignore')

# Set pandas display options
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('step5_lri_calculation_sequential.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class LRICalculator:
    """GPU-accelerated LRI calculator with sequential processing."""
    
    def __init__(self, device: str = 'auto', n_threads: int = None):
        """
        Initialize LRI calculator.
        
        Args:
            device: Device to use ('auto', 'cuda', 'cpu')
            n_threads: Number of threads for parallel processing
        """
        self.device = self._setup_device(device)
        self.n_threads = n_threads or min(mp.cpu_count(), 8)
        
        # Time aggregation windows (in seconds)
        self.window_sizes = [60, 300, 900]  # 1min, 5min, 15min
        
        # Clustering parameters
        self.cluster_range = range(2, 11)  # 2 to 10 clusters
        self.bootstrap_samples = 100
        
        logger.info(f"Initialized LRI Calculator on {self.device} with {self.n_threads} threads")
    
    def _setup_device(self, device: str) -> torch.device:
        """Setup computation device with RTX 5080 compatibility."""
        if device == 'auto':
            if torch.cuda.is_available():
                device = 'cuda'
                logger.info(f"CUDA available: {torch.cuda.get_device_name()}")
                logger.info(f"CUDA capability: {torch.cuda.get_device_capability()}")
                
                # RTX 5080 with PyTorch nightly should be compatible
                capability = torch.cuda.get_device_capability()
                if capability >= (12, 0):  # RTX 5080 has sm_120
                    logger.info(f"RTX 5080 detected (sm_{capability[0]}{capability[1]}) - PyTorch nightly should support this")
                    # Keep using CUDA - PyTorch nightly supports RTX 5080
            else:
                device = 'cpu'
                logger.info("CUDA not available, using CPU")
        
        return torch.device(device)
    
    def load_wt_data(self, file_path: str) -> pd.DataFrame:
        """Load W(t) time series data."""
        try:
            df = pd.read_parquet(file_path)
            logger.info(f"Loaded W(t) data: {df.shape} from {file_path}")
            
            # Handle timestamp column issues
            if 'timestamp' not in df.columns:
                # For datasets without timestamp, create sequential timestamps
                df['timestamp'] = pd.date_range(start='2023-01-01', periods=len(df), freq='1S')
                logger.info(f"Created sequential timestamps for {len(df)} records")
            else:
                # Convert timestamp to datetime if it's not already
                if not pd.api.types.is_datetime64_any_dtype(df['timestamp']):
                    # If timestamp is numeric (seconds since start), convert to datetime
                    if pd.api.types.is_numeric_dtype(df['timestamp']):
                        start_time = pd.Timestamp('2023-01-01')
                        df['timestamp'] = start_time + pd.to_timedelta(df['timestamp'], unit='s')
                        logger.info("Converted numeric timestamp to datetime")
                    else:
                        # Try to parse as datetime
                        df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce')
                        logger.info("Parsed timestamp as datetime")
            
            # Ensure W_t column exists
            if 'W_t' not in df.columns:
                logger.error(f"Missing W_t column in {file_path}")
                return pd.DataFrame()
            
            return df
            
        except Exception as e:
            logger.error(f"Error loading {file_path}: {e}")
            return pd.DataFrame()
    
    def extract_recovery_features(self, wt_series: pd.Series) -> dict:
        """
        Extract recovery-related features from W(t) time series.
        
        Args:
            wt_series: W(t) time series data
            
        Returns:
            Dictionary of recovery features
        """
        try:
            # Convert to tensor for GPU processing
            wt_tensor = torch.tensor(wt_series.values, dtype=torch.float32, device=self.device)
            
            # Calculate recovery ratio (time spent in low stress vs high stress)
            threshold = torch.quantile(wt_tensor, 0.7)  # 70th percentile as threshold
            recovery_time = torch.sum(wt_tensor < threshold).item()
            total_time = len(wt_tensor)
            recovery_ratio = recovery_time / total_time if total_time > 0 else 0.0
            
            # Find peaks and calculate peak frequency
            peaks, _ = self._find_peaks_gpu(wt_tensor)
            peak_frequency = len(peaks) / (total_time / 60) if total_time > 0 else 0.0  # peaks per minute
            
            # Calculate average recovery time (time between peaks)
            if len(peaks) > 1:
                peak_intervals = torch.diff(peaks.float())
                avg_recovery_time = torch.mean(peak_intervals).item()
                recovery_variance = torch.var(peak_intervals).item()
            else:
                avg_recovery_time = 0.0
                recovery_variance = 0.0
            
            # Calculate trend (slope of linear regression)
            x = np.arange(len(wt_series))
            wt_np = wt_series.values
            slope = np.polyfit(x, wt_np, 1)[0]
            
            return {
                'recovery_ratio': recovery_ratio,
                'peak_frequency': abs(peak_frequency),
                'avg_recovery_time': avg_recovery_time,
                'recovery_variance': recovery_variance,
                'trend_slope': slope
            }
            
        except Exception as e:
            logger.error(f"Error extracting recovery features: {e}")
            return {
                'recovery_ratio': 0.0,
                'peak_frequency': 0.0,
                'avg_recovery_time': 0.0,
                'recovery_variance': 0.0,
                'trend_slope': 0.0
            }
    
    def _find_peaks_gpu(self, signal: torch.Tensor, height: float = None) -> tuple:
        """Find peaks in signal using GPU operations."""
        try:
            if height is None:
                height = torch.quantile(signal, 0.8)
            
            # Simple peak detection: local maxima above threshold
            diff = torch.diff(signal)
            sign_changes = torch.diff(torch.sign(diff))
            peaks = torch.where((sign_changes < 0) & (signal[1:-1] > height))[0] + 1
            
            return peaks, torch.tensor([])
            
        except Exception as e:
            logger.warning(f"Error in peak detection: {e}")
            return torch.tensor([]), torch.tensor([])
    
    def time_aggregation(self, df: pd.DataFrame, window_size: int) -> pd.DataFrame:
        """
        Perform time aggregation of W(t) data.
        
        Args:
            df: DataFrame with timestamp and W_t columns
            window_size: Window size in seconds
            
        Returns:
            Aggregated DataFrame with LRI features
        """
        try:
            # Set timestamp as index
            df_indexed = df.set_index('timestamp').copy()
            
            # Resample to window_size intervals
            resampled = df_indexed.resample(f'{window_size}S')
            
            # Aggregate W(t) data
            aggregated_data = []
            
            for window_start, window_data in resampled:
                if len(window_data) == 0:
                    continue
                
                # Extract recovery features for this window
                wt_series = window_data['W_t']
                features = self.extract_recovery_features(wt_series)
                
                # Add window metadata
                features.update({
                    'window_start': window_start,
                    'window_size': window_size,
                    'sample_count': len(window_data),
                    'wt_mean': wt_series.mean(),
                    'wt_std': wt_series.std(),
                    'wt_min': wt_series.min(),
                    'wt_max': wt_series.max()
                })
                
                aggregated_data.append(features)
            
            if not aggregated_data:
                logger.warning(f"No data after aggregation for {window_size}s window")
                return pd.DataFrame()
            
            result_df = pd.DataFrame(aggregated_data)
            logger.info(f"Time aggregation completed: {len(result_df)} windows of {window_size}s")
            
            return result_df
            
        except Exception as e:
            logger.error(f"Error in time aggregation: {e}")
            return pd.DataFrame()
    
    def clustering_analysis(self, aggregated_df: pd.DataFrame, dataset_name: str) -> dict:
        """
        Perform clustering analysis on aggregated features.
        
        Args:
            aggregated_df: DataFrame with LRI features
            dataset_name: Name of the dataset for logging
            
        Returns:
            Dictionary with clustering results
        """
        try:
            if len(aggregated_df) < 2:
                logger.warning(f"Insufficient data for clustering: {len(aggregated_df)} samples")
                return {'error': 'Insufficient data for clustering'}
            
            # Prepare features for clustering
            feature_cols = ['recovery_ratio', 'peak_frequency', 'avg_recovery_time', 
                          'recovery_variance', 'trend_slope', 'wt_mean', 'wt_std']
            
            available_cols = [col for col in feature_cols if col in aggregated_df.columns]
            if len(available_cols) < 2:
                logger.warning(f"Insufficient features for clustering: {available_cols}")
                return {'error': 'Insufficient features for clustering'}
            
            X = aggregated_df[available_cols].values
            
            # Try different numbers of clusters
            clustering_results = {}
            
            for n_clusters in self.cluster_range:
                if n_clusters >= len(aggregated_df):
                    continue
                
                try:
                    # KMeans clustering
                    kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
                    kmeans_labels = kmeans.fit_predict(X)
                    
                    # Calculate metrics
                    silhouette_avg = silhouette_score(X, kmeans_labels)
                    calinski_harabasz = calinski_harabasz_score(X, kmeans_labels)
                    
                    clustering_results[f'kmeans_{n_clusters}'] = {
                        'n_clusters': n_clusters,
                        'silhouette_score': silhouette_avg,
                        'calinski_harabasz_score': calinski_harabasz,
                        'labels': kmeans_labels.tolist()
                    }
                    
                    logger.info(f"KMeans {n_clusters} clusters - Silhouette: {silhouette_avg:.3f}, CH: {calinski_harabasz:.3f}")
                    
                    # GMM clustering
                    gmm = GaussianMixture(n_components=n_clusters, random_state=42)
                    gmm_labels = gmm.fit_predict(X)
                    
                    if len(set(gmm_labels)) > 1:  # Check if we have more than 1 cluster
                        gmm_silhouette = silhouette_score(X, gmm_labels)
                        gmm_calinski_harabasz = calinski_harabasz_score(X, gmm_labels)
                        
                        clustering_results[f'gmm_{n_clusters}'] = {
                            'n_clusters': n_clusters,
                            'silhouette_score': gmm_silhouette,
                            'calinski_harabasz_score': gmm_calinski_harabasz,
                            'labels': gmm_labels.tolist()
                        }
                        
                        logger.info(f"GMM {n_clusters} clusters - Silhouette: {gmm_silhouette:.3f}, CH: {gmm_calinski_harabasz:.3f}")
                
                except Exception as e:
                    logger.warning(f"Error clustering with {n_clusters} clusters: {e}")
                    continue
            
            return clustering_results
            
        except Exception as e:
            logger.error(f"Error in clustering analysis: {e}")
            return {'error': str(e)}
    
    def process_dataset(self, dataset_name: str, wt_file: str) -> dict:
        """
        Process a single dataset for LRI calculation.
        
        Args:
            dataset_name: Name of the dataset
            wt_file: Path to W(t) time series file
            
        Returns:
            Dictionary with LRI results for the dataset
        """
        try:
            logger.info(f"Processing dataset: {dataset_name}")
            
            # Load W(t) data
            wt_df = self.load_wt_data(wt_file)
            
            if wt_df.empty:
                logger.warning(f"Empty dataset: {dataset_name}")
                return {'error': 'Empty dataset'}
            
            results = {
                'dataset_name': dataset_name,
                'processing_timestamp': datetime.now().isoformat(),
                'original_data_shape': wt_df.shape,
                'window_results': {},
                'clustering_results': {}
            }
            
            # Process each window size
            for window_size in self.window_sizes:
                logger.info(f"Processing window size: {window_size}s for {dataset_name}")
                
                # Time aggregation
                aggregated_df = self.time_aggregation(wt_df, window_size)
                
                if aggregated_df.empty:
                    logger.warning(f"No data after aggregation for {window_size}s window")
                    continue
                
                # Clustering analysis
                clustering_results = self.clustering_analysis(aggregated_df, 
                                                            f"{dataset_name}_{window_size}s")
                
                # Store results
                results['window_results'][f'{window_size}s'] = {
                    'aggregated_data_shape': aggregated_df.shape,
                    'clustering_results': clustering_results
                }
            
            logger.info(f"Completed processing: {dataset_name}")
            return results
            
        except Exception as e:
            logger.error(f"Error processing {dataset_name}: {e}")
            return {'error': str(e), 'dataset_name': dataset_name}
    
    def save_results(self, results: dict, output_dir: str):
        """Save LRI calculation results."""
        try:
            output_path = Path(output_dir)
            output_path.mkdir(exist_ok=True)
            
            # Save individual dataset results
            for dataset_name, result in results.items():
                if 'error' in result:
                    continue
                
                # Save LRI data for each window
                for window_size, window_result in result.get('window_results', {}).items():
                    filename = f"lri_{dataset_name}_{window_size}.csv"
                    filepath = output_path / filename
                    
                    # Create summary data
                    summary_data = {
                        'dataset_name': [dataset_name],
                        'window_size': [window_size],
                        'processing_timestamp': [result['processing_timestamp']],
                        'original_data_shape': [str(result['original_data_shape'])],
                        'aggregated_samples': [window_result['aggregated_data_shape'][0]]
                    }
                    
                    summary_df = pd.DataFrame(summary_data)
                    summary_df.to_csv(filepath, index=False)
                    logger.info(f"Saved LRI results: {filepath}")
            
            # Save processing summary
            summary_file = output_path / "lri_processing_summary.json"
            summary_data = {
                'processing_timestamp': datetime.now().isoformat(),
                'datasets_processed': len([r for r in results.values() if 'error' not in r]),
                'window_sizes': self.window_sizes,
                'cluster_range': list(self.cluster_range),
                'bootstrap_samples': self.bootstrap_samples,
                'device_used': str(self.device),
                'n_threads': self.n_threads,
                'results_summary': results
            }
            
            import json
            with open(summary_file, 'w') as f:
                json.dump(summary_data, f, indent=2, default=str)
            
            logger.info(f"Saved processing summary: {summary_file}")
            
        except Exception as e:
            logger.error(f"Error saving results: {e}")

def main():
    """Main execution function."""
    try:
        logger.info("Starting Step 5: LRI Calculation and Time Aggregation (Sequential)")
        
        # Setup paths - use absolute path for WSL environment
        processed_dir = Path("/mnt/d/data_analysis/processed")
        wt_dir = processed_dir / "wt_generation"
        output_dir = processed_dir / "lri_calculation"
        
        # Define correct W(t) files based on complete data processing log
        wt_file_mapping = {
            'CRWD': 'wt_timeseries_CRWD.parquet',
            'SWELL': 'wt_timeseries_SWELL_complete.parquet',
            'WESAD': 'wt_timeseries_WESAD_full_sample.parquet',
            'Nurses': 'wt_timeseries_Nurses_wsl_gpu.parquet',
            'MMASH': 'wt_timeseries_MMASH.parquet',
            'Mental_Health_Pred': 'wt_timeseries_Mental_Health_Pred.parquet',
            'DRIVE_DB': 'wt_timeseries_DRIVE_DB_full_sample.parquet',
            'Non_EEG': 'wt_timeseries_Non_EEG_full_sample.parquet'
        }
        
        # Find existing files
        wt_files = []
        for dataset_name, filename in wt_file_mapping.items():
            file_path = wt_dir / filename
            if file_path.exists():
                wt_files.append((dataset_name, str(file_path)))
                logger.info(f"Found {dataset_name}: {filename}")
            else:
                logger.warning(f"Missing {dataset_name}: {filename}")
        
        if not wt_files:
            logger.error("No valid W(t) time series files found!")
            return
        
        logger.info(f"Processing {len(wt_files)} complete W(t) datasets sequentially")
        
        # Initialize LRI calculator
        calculator = LRICalculator(device='auto', n_threads=8)
        
        # Process datasets sequentially (one by one)
        results = {}
        
        for i, (dataset_name, wt_file) in enumerate(wt_files, 1):
            logger.info(f"Processing dataset {i}/{len(wt_files)}: {dataset_name}")
            
            try:
                result = calculator.process_dataset(dataset_name, wt_file)
                results[dataset_name] = result
                logger.info(f"Completed: {dataset_name}")
                
                # Save intermediate results after each dataset
                calculator.save_results({dataset_name: result}, str(output_dir))
                
            except Exception as e:
                logger.error(f"Error processing {dataset_name}: {e}")
                results[dataset_name] = {'error': str(e), 'dataset_name': dataset_name}
        
        # Save final results
        calculator.save_results(results, str(output_dir))
        
        # Print summary
        successful = len([r for r in results.values() if 'error' not in r])
        failed = len([r for r in results.values() if 'error' in r])
        
        logger.info(f"Step 5 completed successfully!")
        logger.info(f"Datasets processed: {successful}/{len(wt_files)}")
        logger.info(f"Successful: {successful}, Failed: {failed}")
        
        if failed > 0:
            logger.warning("Failed datasets:")
            for dataset_name, result in results.items():
                if 'error' in result:
                    logger.warning(f"  {dataset_name}: {result['error']}")
        
    except Exception as e:
        logger.error(f"Error in main execution: {e}")
        raise

if __name__ == "__main__":
    main()

