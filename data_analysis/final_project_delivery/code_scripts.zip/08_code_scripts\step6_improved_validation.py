#!/usr/bin/env python3
"""
Step 6 Improved: Enhanced Single Dataset Validation Modeling
改进版Step 6：解决审计发现的关键问题
- 交叉验证
- 超参数调优
- 特征相关性分析
- 时间序列特性
- 模型解释性
"""

import os
import sys
import logging
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from pathlib import Path
from datetime import datetime
from sklearn.model_selection import train_test_split, cross_val_score, KFold, TimeSeriesSplit
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.linear_model import LinearRegression, Ridge, Lasso, ElasticNet
from sklearn.svm import SVR
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from sklearn.preprocessing import StandardScaler
from sklearn.feature_selection import SelectKBest, f_regression, mutual_info_regression
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV
import joblib
import seaborn as sns
import matplotlib.pyplot as plt
from scipy.stats import pearsonr, spearmanr
from scipy.cluster.hierarchy import dendrogram, linkage
from scipy.spatial.distance import squareform
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('step6_improved_validation.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class FeatureAnalyzer:
    """特征分析器 - 解决特征相关性分析问题."""
    
    def __init__(self):
        self.correlation_matrix = None
        self.feature_importance = None
    
    def analyze_feature_correlations(self, X, feature_names, method='pearson'):
        """分析特征相关性."""
        try:
            logger.info(f"Analyzing feature correlations using {method} method")
            
            if method == 'pearson':
                corr_matrix = np.corrcoef(X.T)
            elif method == 'spearman':
                corr_matrix, _ = spearmanr(X)
            else:
                raise ValueError(f"Unknown correlation method: {method}")
            
            self.correlation_matrix = corr_matrix
            
            # 找出高相关性的特征对
            high_corr_pairs = []
            for i in range(len(feature_names)):
                for j in range(i+1, len(feature_names)):
                    corr_value = abs(corr_matrix[i, j])
                    if corr_value > 0.8:  # 高相关性阈值
                        high_corr_pairs.append({
                            'feature1': feature_names[i],
                            'feature2': feature_names[j],
                            'correlation': corr_value
                        })
            
            logger.info(f"Found {len(high_corr_pairs)} highly correlated feature pairs")
            
            return {
                'correlation_matrix': corr_matrix,
                'high_correlation_pairs': high_corr_pairs,
                'method': method
            }
            
        except Exception as e:
            logger.error(f"Error analyzing feature correlations: {e}")
            return None
    
    def detect_multicollinearity(self, X, feature_names, vif_threshold=10):
        """检测多重共线性."""
        try:
            from statsmodels.stats.outliers_influence import variance_inflation_factor
            
            logger.info("Detecting multicollinearity using VIF")
            
            vif_data = pd.DataFrame()
            vif_data["Feature"] = feature_names
            vif_data["VIF"] = [variance_inflation_factor(X, i) for i in range(len(feature_names))]
            
            high_vif_features = vif_data[vif_data["VIF"] > vif_threshold]
            
            logger.info(f"Found {len(high_vif_features)} features with VIF > {vif_threshold}")
            
            return {
                'vif_data': vif_data,
                'high_vif_features': high_vif_features,
                'threshold': vif_threshold
            }
            
        except ImportError:
            logger.warning("statsmodels not available, skipping VIF analysis")
            return None
        except Exception as e:
            logger.error(f"Error detecting multicollinearity: {e}")
            return None
    
    def select_features(self, X, y, feature_names, method='f_regression', k=10):
        """特征选择."""
        try:
            logger.info(f"Selecting top {k} features using {method}")
            
            if method == 'f_regression':
                selector = SelectKBest(score_func=f_regression, k=k)
            elif method == 'mutual_info':
                selector = SelectKBest(score_func=mutual_info_regression, k=k)
            else:
                raise ValueError(f"Unknown feature selection method: {method}")
            
            X_selected = selector.fit_transform(X, y)
            selected_features = [feature_names[i] for i in selector.get_support(indices=True)]
            
            logger.info(f"Selected features: {selected_features}")
            
            return {
                'X_selected': X_selected,
                'selected_features': selected_features,
                'selector': selector,
                'method': method
            }
            
        except Exception as e:
            logger.error(f"Error in feature selection: {e}")
            return None

class HyperparameterOptimizer:
    """超参数优化器 - 解决超参数调优问题."""
    
    def __init__(self, cv_folds=5, random_state=42):
        self.cv_folds = cv_folds
        self.random_state = random_state
        self.best_params = {}
    
    def optimize_random_forest(self, X, y, is_time_series=False):
        """优化随机森林超参数."""
        try:
            logger.info("Optimizing Random Forest hyperparameters")
            
            param_grid = {
                'n_estimators': [50, 100, 200],
                'max_depth': [None, 10, 20, 30],
                'min_samples_split': [2, 5, 10],
                'min_samples_leaf': [1, 2, 4],
                'max_features': ['sqrt', 'log2', None]
            }
            
            rf = RandomForestRegressor(random_state=self.random_state)
            
            if is_time_series:
                cv = TimeSeriesSplit(n_splits=self.cv_folds)
            else:
                cv = KFold(n_splits=self.cv_folds, shuffle=True, random_state=self.random_state)
            
            grid_search = GridSearchCV(
                rf, param_grid, cv=cv, scoring='r2', 
                n_jobs=-1, verbose=1
            )
            
            grid_search.fit(X, y)
            
            self.best_params['RandomForest'] = grid_search.best_params_
            
            logger.info(f"Best Random Forest params: {grid_search.best_params_}")
            logger.info(f"Best Random Forest score: {grid_search.best_score_:.3f}")
            
            return grid_search.best_estimator_, grid_search.best_params_
            
        except Exception as e:
            logger.error(f"Error optimizing Random Forest: {e}")
            return None, None
    
    def optimize_gradient_boosting(self, X, y, is_time_series=False):
        """优化梯度提升超参数."""
        try:
            logger.info("Optimizing Gradient Boosting hyperparameters")
            
            param_grid = {
                'n_estimators': [50, 100, 200],
                'learning_rate': [0.01, 0.1, 0.2],
                'max_depth': [3, 5, 7],
                'subsample': [0.8, 0.9, 1.0]
            }
            
            gb = GradientBoostingRegressor(random_state=self.random_state)
            
            if is_time_series:
                cv = TimeSeriesSplit(n_splits=self.cv_folds)
            else:
                cv = KFold(n_splits=self.cv_folds, shuffle=True, random_state=self.random_state)
            
            grid_search = GridSearchCV(
                gb, param_grid, cv=cv, scoring='r2',
                n_jobs=-1, verbose=1
            )
            
            grid_search.fit(X, y)
            
            self.best_params['GradientBoosting'] = grid_search.best_params_
            
            logger.info(f"Best Gradient Boosting params: {grid_search.best_params_}")
            logger.info(f"Best Gradient Boosting score: {grid_search.best_score_:.3f}")
            
            return grid_search.best_estimator_, grid_search.best_params_
            
        except Exception as e:
            logger.error(f"Error optimizing Gradient Boosting: {e}")
            return None, None
    
    def optimize_regularized_models(self, X, y, is_time_series=False):
        """优化正则化模型超参数."""
        try:
            logger.info("Optimizing regularized models hyperparameters")
            
            # Ridge回归
            ridge_params = {'alpha': [0.1, 1.0, 10.0, 100.0]}
            ridge = Ridge(random_state=self.random_state)
            
            # Lasso回归
            lasso_params = {'alpha': [0.01, 0.1, 1.0, 10.0]}
            lasso = Lasso(random_state=self.random_state, max_iter=10000)
            
            # ElasticNet
            elastic_params = {
                'alpha': [0.01, 0.1, 1.0],
                'l1_ratio': [0.1, 0.5, 0.7, 0.9]
            }
            elastic = ElasticNet(random_state=self.random_state, max_iter=10000)
            
            if is_time_series:
                cv = TimeSeriesSplit(n_splits=self.cv_folds)
            else:
                cv = KFold(n_splits=self.cv_folds, shuffle=True, random_state=self.random_state)
            
            # Ridge优化
            ridge_grid = GridSearchCV(ridge, ridge_params, cv=cv, scoring='r2')
            ridge_grid.fit(X, y)
            
            # Lasso优化
            lasso_grid = GridSearchCV(lasso, lasso_params, cv=cv, scoring='r2')
            lasso_grid.fit(X, y)
            
            # ElasticNet优化
            elastic_grid = GridSearchCV(elastic, elastic_params, cv=cv, scoring='r2')
            elastic_grid.fit(X, y)
            
            self.best_params['Ridge'] = ridge_grid.best_params_
            self.best_params['Lasso'] = lasso_grid.best_params_
            self.best_params['ElasticNet'] = elastic_grid.best_params_
            
            logger.info(f"Best Ridge alpha: {ridge_grid.best_params_}")
            logger.info(f"Best Lasso alpha: {lasso_grid.best_params_}")
            logger.info(f"Best ElasticNet params: {elastic_grid.best_params_}")
            
            return {
                'Ridge': (ridge_grid.best_estimator_, ridge_grid.best_params_),
                'Lasso': (lasso_grid.best_estimator_, lasso_grid.best_params_),
                'ElasticNet': (elastic_grid.best_estimator_, elastic_grid.best_params_)
            }
            
        except Exception as e:
            logger.error(f"Error optimizing regularized models: {e}")
            return None

class CrossValidator:
    """交叉验证器 - 解决交叉验证问题."""
    
    def __init__(self, cv_folds=5, random_state=42):
        self.cv_folds = cv_folds
        self.random_state = random_state
    
    def time_series_cross_validation(self, X, y, models, feature_names):
        """时间序列交叉验证."""
        try:
            logger.info("Performing time series cross validation")
            
            tscv = TimeSeriesSplit(n_splits=self.cv_folds)
            results = {}
            
            for model_name, model in models.items():
                logger.info(f"Cross validating {model_name}")
                
                cv_scores = cross_val_score(
                    model, X, y, cv=tscv, scoring='r2', n_jobs=-1
                )
                
                results[model_name] = {
                    'cv_scores': cv_scores.tolist(),
                    'cv_mean': cv_scores.mean(),
                    'cv_std': cv_scores.std(),
                    'cv_method': 'TimeSeriesSplit'
                }
                
                logger.info(f"{model_name} - CV Mean: {cv_scores.mean():.3f} ± {cv_scores.std():.3f}")
            
            return results
            
        except Exception as e:
            logger.error(f"Error in time series cross validation: {e}")
            return None
    
    def kfold_cross_validation(self, X, y, models, feature_names):
        """K折交叉验证."""
        try:
            logger.info("Performing K-fold cross validation")
            
            kf = KFold(n_splits=self.cv_folds, shuffle=True, random_state=self.random_state)
            results = {}
            
            for model_name, model in models.items():
                logger.info(f"Cross validating {model_name}")
                
                cv_scores = cross_val_score(
                    model, X, y, cv=kf, scoring='r2', n_jobs=-1
                )
                
                results[model_name] = {
                    'cv_scores': cv_scores.tolist(),
                    'cv_mean': cv_scores.mean(),
                    'cv_std': cv_scores.std(),
                    'cv_method': 'KFold'
                }
                
                logger.info(f"{model_name} - CV Mean: {cv_scores.mean():.3f} ± {cv_scores.std():.3f}")
            
            return results
            
        except Exception as e:
            logger.error(f"Error in K-fold cross validation: {e}")
            return None

class ModelInterpreter:
    """模型解释器 - 解决模型解释性问题."""
    
    def __init__(self):
        self.feature_importance = {}
        self.model_explanations = {}
    
    def analyze_feature_importance(self, models, feature_names):
        """分析特征重要性."""
        try:
            logger.info("Analyzing feature importance")
            
            for model_name, model in models.items():
                if hasattr(model, 'feature_importances_'):
                    importance = model.feature_importances_
                    self.feature_importance[model_name] = dict(zip(feature_names, importance))
                    
                    logger.info(f"{model_name} top 5 features:")
                    sorted_features = sorted(
                        zip(feature_names, importance), 
                        key=lambda x: x[1], reverse=True
                    )[:5]
                    for feature, imp in sorted_features:
                        logger.info(f"  {feature}: {imp:.3f}")
                
                elif hasattr(model, 'coef_'):
                    coef = model.coef_
                    self.feature_importance[model_name] = dict(zip(feature_names, coef))
                    
                    logger.info(f"{model_name} top 5 coefficients:")
                    sorted_features = sorted(
                        zip(feature_names, coef), 
                        key=lambda x: abs(x[1]), reverse=True
                    )[:5]
                    for feature, coef_val in sorted_features:
                        logger.info(f"  {feature}: {coef_val:.3f}")
            
            return self.feature_importance
            
        except Exception as e:
            logger.error(f"Error analyzing feature importance: {e}")
            return None
    
    def generate_model_summary(self, models, cv_results, feature_importance):
        """生成模型总结."""
        try:
            logger.info("Generating model summary")
            
            summary = {}
            
            for model_name in models.keys():
                summary[model_name] = {
                    'cv_performance': cv_results.get(model_name, {}),
                    'feature_importance': feature_importance.get(model_name, {}),
                    'model_type': type(models[model_name]).__name__
                }
            
            return summary
            
        except Exception as e:
            logger.error(f"Error generating model summary: {e}")
            return None

class ImprovedDatasetValidator:
    """改进版数据集验证器."""
    
    def __init__(self, device='auto', n_threads=8):
        self.device = self._setup_device(device)
        self.n_threads = n_threads
        
        # 初始化组件
        self.feature_analyzer = FeatureAnalyzer()
        self.hyperparameter_optimizer = HyperparameterOptimizer()
        self.cross_validator = CrossValidator()
        self.model_interpreter = ModelInterpreter()
        
        logger.info(f"Initialized Improved DatasetValidator on {self.device}")
    
    def _setup_device(self, device):
        """设置计算设备."""
        if device == 'auto':
            if torch.cuda.is_available():
                device = 'cuda'
                logger.info(f"CUDA available: {torch.cuda.get_device_name()}")
            else:
                device = 'cpu'
                logger.info("CUDA not available, using CPU")
        return torch.device(device)
    
    def load_fixed_lri_data(self, dataset_name, window_size):
        """加载修复后的LRI数据."""
        try:
            file_path = f"/mnt/d/data_analysis/processed/lri_calculation/lri_{dataset_name}_{window_size}_fixed.csv"
            df = pd.read_csv(file_path)
            logger.info(f"Loaded fixed LRI data: {df.shape} from {file_path}")
            return df
        except Exception as e:
            logger.error(f"Error loading fixed LRI data: {e}")
            return pd.DataFrame()
    
    def prepare_features_and_target(self, df):
        """准备特征和目标变量."""
        try:
            # 特征列（排除窗口元数据）
            exclude_cols = [
                'window_id', 'window_size_seconds', 'sample_count', 
                'start_time', 'end_time'
            ]
            
            # 目标变量选择
            target_col = 'recovery_ratio'
            if target_col not in df.columns or df[target_col].nunique() <= 1:
                target_col = 'stress_intensity'
                if target_col not in df.columns:
                    target_col = 'wt_mean'
            
            feature_cols = [col for col in df.columns if col not in exclude_cols + [target_col]]
            
            X = df[feature_cols].values
            y = df[target_col].values
            
            logger.info(f"Features shape: {X.shape}, Target shape: {y.shape}")
            logger.info(f"Target: {target_col}, Range: {y.min():.3f} to {y.max():.3f}")
            
            return X, y, feature_cols, target_col
            
        except Exception as e:
            logger.error(f"Error preparing features and target: {e}")
            return None, None, None, None
    
    def comprehensive_validation(self, dataset_name, window_size):
        """综合验证 - 包含所有改进."""
        try:
            logger.info(f"=== Comprehensive Validation: {dataset_name} - {window_size}s ===")
            
            # 1. 加载数据
            df = self.load_fixed_lri_data(dataset_name, window_size)
            if df.empty:
                return {'error': 'Failed to load data'}
            
            # 2. 准备特征和目标
            X, y, feature_names, target_col = self.prepare_features_and_target(df)
            if X is None:
                return {'error': 'Failed to prepare features'}
            
            # 3. 特征相关性分析
            logger.info("Step 1: Feature correlation analysis")
            correlation_analysis = self.feature_analyzer.analyze_feature_correlations(
                X, feature_names, method='pearson'
            )
            
            # 4. 多重共线性检测
            multicollinearity_analysis = self.feature_analyzer.detect_multicollinearity(
                X, feature_names
            )
            
            # 5. 特征选择
            feature_selection_result = self.feature_analyzer.select_features(
                X, y, feature_names, method='f_regression', k=min(10, len(feature_names))
            )
            
            if feature_selection_result:
                X_selected = feature_selection_result['X_selected']
                selected_features = feature_selection_result['selected_features']
            else:
                X_selected = X
                selected_features = feature_names
            
            # 6. 数据分割
            X_train, X_test, y_train, y_test = train_test_split(
                X_selected, y, test_size=0.2, random_state=42
            )
            
            # 7. 超参数优化
            logger.info("Step 2: Hyperparameter optimization")
            
            # 优化随机森林
            rf_best, rf_params = self.hyperparameter_optimizer.optimize_random_forest(
                X_train, y_train, is_time_series=False
            )
            
            # 优化梯度提升
            gb_best, gb_params = self.hyperparameter_optimizer.optimize_gradient_boosting(
                X_train, y_train, is_time_series=False
            )
            
            # 优化正则化模型
            reg_models = self.hyperparameter_optimizer.optimize_regularized_models(
                X_train, y_train, is_time_series=False
            )
            
            # 8. 构建最终模型集合
            models = {}
            if rf_best:
                models['RandomForest_Optimized'] = rf_best
            if gb_best:
                models['GradientBoosting_Optimized'] = gb_best
            if reg_models:
                for name, (model, params) in reg_models.items():
                    models[f'{name}_Optimized'] = model
            
            # 添加基础模型用于比较
            models['LinearRegression'] = LinearRegression()
            models['Ridge_Basic'] = Ridge()
            models['Lasso_Basic'] = Lasso()
            
            # 9. 交叉验证
            logger.info("Step 3: Cross validation")
            
            # K折交叉验证
            kfold_results = self.cross_validator.kfold_cross_validation(
                X_selected, y, models, selected_features
            )
            
            # 时间序列交叉验证
            timeseries_results = self.cross_validator.time_series_cross_validation(
                X_selected, y, models, selected_features
            )
            
            # 10. 最终评估
            logger.info("Step 4: Final evaluation")
            
            final_results = {}
            for model_name, model in models.items():
                model.fit(X_train, y_train)
                y_pred = model.predict(X_test)
                
                final_results[model_name] = {
                    'mse': mean_squared_error(y_test, y_pred),
                    'r2': r2_score(y_test, y_pred),
                    'mae': mean_absolute_error(y_test, y_pred),
                    'kfold_cv': kfold_results.get(model_name, {}),
                    'timeseries_cv': timeseries_results.get(model_name, {})
                }
            
            # 11. 模型解释性分析
            logger.info("Step 5: Model interpretability analysis")
            
            feature_importance = self.model_interpreter.analyze_feature_importance(
                models, selected_features
            )
            
            model_summary = self.model_interpreter.generate_model_summary(
                models, kfold_results, feature_importance
            )
            
            # 12. 选择最佳模型
            best_model_name = max(
                final_results.keys(),
                key=lambda x: final_results[x]['r2']
            )
            
            logger.info(f"Best model: {best_model_name} with R² = {final_results[best_model_name]['r2']:.3f}")
            
            # 13. 返回综合结果
            comprehensive_results = {
                'dataset_name': dataset_name,
                'window_size': window_size,
                'target_variable': target_col,
                'data_shape': X.shape,
                'selected_features': selected_features,
                'correlation_analysis': correlation_analysis,
                'multicollinearity_analysis': multicollinearity_analysis,
                'feature_selection': feature_selection_result,
                'hyperparameter_optimization': self.hyperparameter_optimizer.best_params,
                'final_model_performance': final_results,
                'cross_validation_results': {
                    'kfold': kfold_results,
                    'timeseries': timeseries_results
                },
                'feature_importance': feature_importance,
                'model_summary': model_summary,
                'best_model': {
                    'name': best_model_name,
                    'performance': final_results[best_model_name]
                },
                'validation_timestamp': datetime.now().isoformat()
            }
            
            logger.info(f"=== Completed comprehensive validation: {dataset_name} - {window_size}s ===")
            
            return comprehensive_results
            
        except Exception as e:
            logger.error(f"Error in comprehensive validation: {e}")
            return {'error': str(e)}

def main():
    """主函数."""
    try:
        logger.info("Starting Step 6 Improved: Enhanced Validation with Methodological Improvements")
        
        # 数据集配置
        datasets = ['CRWD', 'SWELL', 'WESAD', 'Nurses', 'MMASH', 
                   'Mental_Health_Pred', 'DRIVE_DB', 'Non_EEG']
        window_sizes = ['60s', '300s', '900s']
        
        output_dir = '/mnt/d/data_analysis/processed/step6_improved_validation'
        Path(output_dir).mkdir(exist_ok=True)
        
        # 初始化改进版验证器
        validator = ImprovedDatasetValidator(device='auto', n_threads=8)
        
        # 逐个处理数据集
        all_results = {}
        
        for dataset_name in datasets:
            logger.info(f"\n{'='*60}")
            logger.info(f"Processing Dataset: {dataset_name} (IMPROVED)")
            logger.info(f"{'='*60}")
            
            dataset_results = {}
            
            for window_size in window_sizes:
                try:
                    result = validator.comprehensive_validation(dataset_name, window_size)
                    dataset_results[window_size] = result
                    
                    # 保存结果
                    if 'error' not in result:
                        output_file = Path(output_dir) / f"improved_validation_{dataset_name}_{window_size}.json"
                        with open(output_file, 'w') as f:
                            import json
                            json.dump(result, f, indent=2, default=str)
                        logger.info(f"Saved improved validation results: {output_file}")
                    
                except Exception as e:
                    logger.error(f"Error processing {dataset_name}_{window_size}: {e}")
                    dataset_results[window_size] = {'error': str(e)}
            
            all_results[dataset_name] = dataset_results
        
        # 保存总体结果摘要
        summary_file = Path(output_dir) / "improved_validation_summary_all_datasets.json"
        with open(summary_file, 'w') as f:
            import json
            json.dump(all_results, f, indent=2, default=str)
        
        logger.info(f"\n{'='*60}")
        logger.info("Step 6 Improved Validation Completed Successfully!")
        logger.info(f"{'='*60}")
        
        # 打印改进总结
        logger.info("\nMethodological Improvements Implemented:")
        logger.info("✓ Cross validation (K-fold + Time series)")
        logger.info("✓ Hyperparameter optimization")
        logger.info("✓ Feature correlation analysis")
        logger.info("✓ Multicollinearity detection (VIF)")
        logger.info("✓ Feature selection")
        logger.info("✓ Model interpretability analysis")
        logger.info("✓ Time series considerations")
        
        # 打印性能总结
        for dataset_name, dataset_results in all_results.items():
            logger.info(f"\n{dataset_name} (IMPROVED):")
            for window_size, result in dataset_results.items():
                if 'error' not in result:
                    best_model = result.get('best_model', {})
                    performance = best_model.get('performance', {})
                    logger.info(f"  {window_size}: Best model = {best_model.get('name', 'N/A')}")
                    logger.info(f"    R² = {performance.get('r2', 0):.3f}")
                    logger.info(f"    CV R² = {result.get('cross_validation_results', {}).get('kfold', {}).get(best_model.get('name', ''), {}).get('cv_mean', 0):.3f}")
                else:
                    logger.warning(f"  {window_size}: Error - {result['error']}")
        
    except Exception as e:
        logger.error(f"Error in main execution: {e}")
        raise

if __name__ == "__main__":
    main()
