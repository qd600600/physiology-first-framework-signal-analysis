#!/usr/bin/env python3
"""
Step 7.2: 扩展到更多数据集的跨数据集迁移测试
专注于PyTorch NN模型（因为它是唯一表现正常的模型）
"""

import os
import sys
import logging
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from pathlib import Path
from datetime import datetime
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from sklearn.preprocessing import StandardScaler
import json
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('step7_2_extended_cross_dataset_transfer.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class PyTorchRegressionModel(nn.Module):
    """PyTorch神经网络回归模型，支持GPU加速."""
    
    def __init__(self, input_size: int, hidden_sizes: list = [64, 32, 16], dropout_rate: float = 0.2):
        super(PyTorchRegressionModel, self).__init__()
        
        layers = []
        prev_size = input_size
        
        for hidden_size in hidden_sizes:
            layers.extend([
                nn.Linear(prev_size, hidden_size),
                nn.ReLU(),
                nn.Dropout(dropout_rate)
            ])
            prev_size = hidden_size
        
        # Output layer
        layers.append(nn.Linear(prev_size, 1))
        
        self.network = nn.Sequential(*layers)
    
    def forward(self, x):
        return self.network(x)

class ExtendedCrossDatasetTransferValidator:
    """扩展的跨数据集迁移验证器，专注于PyTorch NN模型."""
    
    def __init__(self, device: str = 'auto'):
        self.device = self._setup_device(device)
        logger.info(f"Initialized ExtendedCrossDatasetTransferValidator on {self.device}")
    
    def _setup_device(self, device: str) -> torch.device:
        """Setup computation device."""
        if device == 'auto':
            if torch.cuda.is_available():
                device = 'cuda'
                logger.info(f"CUDA available: {torch.cuda.get_device_name()}")
                logger.info(f"CUDA capability: {torch.cuda.get_device_capability()}")
                logger.info(f"CUDA memory: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB")
            else:
                device = 'cpu'
                logger.info("CUDA not available, using CPU")
        
        return torch.device(device)
    
    def load_clean_data(self, dataset_name: str, window_size: str) -> pd.DataFrame:
        """加载清理后的数据."""
        try:
            file_path = f"/mnt/d/data_analysis/processed/lri_calculation/lri_{dataset_name}_{window_size}_clean.csv"
            df = pd.read_csv(file_path)
            logger.info(f"Loaded clean data: {df.shape} from {file_path}")
            return df
        except Exception as e:
            logger.error(f"Error loading clean data for {dataset_name}_{window_size}: {e}")
            return pd.DataFrame()
    
    def prepare_features_and_target(self, df: pd.DataFrame) -> tuple:
        """准备特征和目标变量."""
        try:
            # 排除非特征列
            exclude_cols = ['window_id', 'window_size_seconds', 'sample_count']
            feature_cols = [col for col in df.columns if col not in exclude_cols]
            
            # 找到目标变量
            target_candidates = ['recovery_pattern_score', 'stress_release_efficiency', 'volatility_recovery_index', 'trend_recovery_score']
            target_col = None
            for candidate in target_candidates:
                if candidate in df.columns:
                    target_col = candidate
                    break
            
            if not target_col:
                logger.error("No target variable found")
                return None, None, None, None
            
            feature_cols = [col for col in feature_cols if col != target_col]
            
            X = df[feature_cols].values
            y = df[target_col].values
            
            logger.info(f"Features shape: {X.shape}, Target shape: {y.shape}")
            logger.info(f"Feature columns: {feature_cols}")
            logger.info(f"Target: {target_col}")
            
            return X, y, feature_cols, target_col
            
        except Exception as e:
            logger.error(f"Error preparing features and target: {e}")
            return None, None, None, None
    
    def train_pytorch_model(self, X_train: np.ndarray, y_train: np.ndarray, 
                           X_test: np.ndarray, y_test: np.ndarray, 
                           feature_cols: list, model_name: str = "PyTorch_NN") -> dict:
        """训练PyTorch神经网络模型."""
        try:
            logger.info(f"Training {model_name} on {X_train.shape[0]} samples...")
            
            # 数据标准化
            scaler_X = StandardScaler()
            scaler_y = StandardScaler()
            
            X_train_scaled = scaler_X.fit_transform(X_train)
            y_train_scaled = scaler_y.fit_transform(y_train.reshape(-1, 1)).flatten()
            X_test_scaled = scaler_X.transform(X_test)
            y_test_scaled = scaler_y.transform(y_test.reshape(-1, 1)).flatten()
            
            # 转换为PyTorch张量
            X_train_tensor = torch.FloatTensor(X_train_scaled).to(self.device)
            y_train_tensor = torch.FloatTensor(y_train_scaled).to(self.device)
            X_test_tensor = torch.FloatTensor(X_test_scaled).to(self.device)
            y_test_tensor = torch.FloatTensor(y_test_scaled).to(self.device)
            
            # 创建模型
            model = PyTorchRegressionModel(
                input_size=len(feature_cols),
                hidden_sizes=[64, 32, 16],
                dropout_rate=0.2
            ).to(self.device)
            
            # 损失函数和优化器
            criterion = nn.MSELoss()
            optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
            
            # 训练循环
            model.train()
            best_loss = float('inf')
            patience = 10
            patience_counter = 0
            
            for epoch in range(100):
                optimizer.zero_grad()
                outputs = model(X_train_tensor).squeeze()
                loss = criterion(outputs, y_train_tensor)
                loss.backward()
                optimizer.step()
                
                # 早停机制
                if loss.item() < best_loss:
                    best_loss = loss.item()
                    patience_counter = 0
                else:
                    patience_counter += 1
                
                if patience_counter >= patience:
                    logger.info(f"Early stopping at epoch {epoch}")
                    break
                
                if epoch % 20 == 0:
                    logger.info(f"  Epoch {epoch}, loss: {loss.item():.4f}")
            
            # 预测
            model.eval()
            with torch.no_grad():
                y_pred_scaled = model(X_test_tensor).squeeze().cpu().numpy()
            
            # 反标准化
            y_pred = scaler_y.inverse_transform(y_pred_scaled.reshape(-1, 1)).flatten()
            
            # 计算性能指标
            mse = mean_squared_error(y_test, y_pred)
            r2 = r2_score(y_test, y_pred)
            mae = mean_absolute_error(y_test, y_pred)
            
            logger.info(f"✓ {model_name} trained - R²: {r2:.3f}, MSE: {mse:.4f}")
            
            return {
                'model': model,
                'predictions': y_pred,
                'test_actual': y_test,
                'mse': mse,
                'r2': r2,
                'mae': mae,
                'scaler_X': scaler_X,
                'scaler_y': scaler_y,
                'feature_columns': feature_cols
            }
            
        except Exception as e:
            logger.error(f"Error training {model_name}: {e}")
            return None
    
    def test_pytorch_model(self, trained_model_data: dict, X_test: np.ndarray, y_test: np.ndarray) -> dict:
        """在测试数据上测试PyTorch模型."""
        try:
            model = trained_model_data['model']
            scaler_X = trained_model_data['scaler_X']
            scaler_y = trained_model_data['scaler_y']
            
            # 标准化测试数据
            X_test_scaled = scaler_X.transform(X_test)
            X_test_tensor = torch.FloatTensor(X_test_scaled).to(self.device)
            
            # 预测
            model.eval()
            with torch.no_grad():
                y_pred_scaled = model(X_test_tensor).squeeze().cpu().numpy()
            
            # 反标准化
            y_pred = scaler_y.inverse_transform(y_pred_scaled.reshape(-1, 1)).flatten()
            
            # 计算性能指标
            mse = mean_squared_error(y_test, y_pred)
            r2 = r2_score(y_test, y_pred)
            mae = mean_absolute_error(y_test, y_pred)
            
            return {
                'predictions': y_pred,
                'actual': y_test,
                'mse': mse,
                'r2': r2,
                'mae': mae
            }
            
        except Exception as e:
            logger.error(f"Error testing PyTorch model: {e}")
            return None
    
    def cross_dataset_transfer_pytorch(self, source_dataset: str, target_datasets: list, window_sizes: list) -> dict:
        """执行PyTorch模型的跨数据集迁移测试."""
        try:
            logger.info(f"Starting extended cross-dataset transfer: {source_dataset} -> {target_datasets}")
            
            all_results = {}
            
            for window_size in window_sizes:
                logger.info(f"\n{'='*60}")
                logger.info(f"Processing window size: {window_size}")
                logger.info(f"{'='*60}")
                
                # 在源数据集上训练PyTorch模型
                source_df = self.load_clean_data(source_dataset, window_size)
                if source_df.empty:
                    continue
                
                X_source, y_source, feature_cols, target_col = self.prepare_features_and_target(source_df)
                if X_source is None:
                    continue
                
                X_train, X_test, y_train, y_test = train_test_split(
                    X_source, y_source, test_size=0.2, random_state=42
                )
                
                # 训练源模型
                source_model = self.train_pytorch_model(
                    X_train, y_train, X_test, y_test, feature_cols, 
                    f"{source_dataset}_{window_size}_source"
                )
                
                if not source_model:
                    continue
                
                # 在目标数据集上测试模型
                window_results = {
                    'source_dataset': source_dataset,
                    'window_size': window_size,
                    'target_variable': target_col,
                    'source_performance': source_model,
                    'target_performance': {}
                }
                
                for target_dataset in target_datasets:
                    if target_dataset == source_dataset:
                        continue
                    
                    logger.info(f"\nTesting transfer: {source_dataset} -> {target_dataset}")
                    
                    # 加载目标数据
                    target_df = self.load_clean_data(target_dataset, window_size)
                    if target_df.empty:
                        continue
                    
                    X_target, y_target, target_features, target_target_col = self.prepare_features_and_target(target_df)
                    if X_target is None:
                        continue
                    
                    # 检查特征匹配
                    if feature_cols != target_features:
                        logger.warning(f"Feature mismatch: source={feature_cols}, target={target_features}")
                        # 尝试匹配特征
                        common_features = [f for f in feature_cols if f in target_features]
                        if len(common_features) < len(feature_cols):
                            logger.error("Insufficient common features for transfer")
                            continue
                        
                        # 重新排列特征
                        feature_indices = [target_features.index(f) for f in feature_cols]
                        X_target = X_target[:, feature_indices]
                    
                    # 测试迁移性能
                    transfer_result = self.test_pytorch_model(source_model, X_target, y_target)
                    if transfer_result:
                        window_results['target_performance'][target_dataset] = {
                            'performance': transfer_result,
                            'data_shape': X_target.shape,
                            'target_variable': target_target_col
                        }
                        
                        # 计算性能下降
                        source_r2 = source_model['r2']
                        target_r2 = transfer_result['r2']
                        r2_drop = source_r2 - target_r2
                        
                        logger.info(f"✓ {source_dataset} -> {target_dataset}: R² = {target_r2:.3f} (drop: {r2_drop:.3f})")
                
                all_results[window_size] = window_results
            
            return {
                'source_dataset': source_dataset,
                'target_datasets': target_datasets,
                'window_sizes': window_sizes,
                'transfer_results': all_results,
                'analysis_timestamp': datetime.now().isoformat(),
                'model_type': 'PyTorch_NN_only'
            }
            
        except Exception as e:
            logger.error(f"Error in cross-dataset transfer: {e}")
            return {'error': str(e)}

def main():
    """主函数."""
    try:
        logger.info("Starting Step 7.2: Extended Cross-Dataset Transfer (PyTorch NN Only)")
        
        # 数据集配置 - 扩展到更多数据集
        source_dataset = 'DRIVE_DB'  # 以DRIVE_DB为基准
        target_datasets = ['CRWD', 'SWELL', 'Non_EEG']  # 扩展到3个目标数据集
        window_sizes = ['60s', '300s']  # 测试两个时间窗口
        
        output_dir = '/mnt/d/data_analysis/processed/step7_cross_dataset_transfer'
        Path(output_dir).mkdir(exist_ok=True)
        
        # 初始化扩展的跨数据集迁移验证器
        validator = ExtendedCrossDatasetTransferValidator(device='auto')
        
        # 执行跨数据集迁移测试
        logger.info(f"Executing extended cross-dataset transfer: {source_dataset} -> {target_datasets}")
        
        transfer_results = validator.cross_dataset_transfer_pytorch(source_dataset, target_datasets, window_sizes)
        
        if 'error' in transfer_results:
            logger.error(f"Transfer failed: {transfer_results['error']}")
            return
        
        # 保存结果
        output_file = Path(output_dir) / f"extended_cross_dataset_transfer_{source_dataset}_pytorch_only.json"
        with open(output_file, 'w') as f:
            json.dump(transfer_results, f, indent=2, default=str)
        
        logger.info(f"Transfer results saved: {output_file}")
        
        # 分析结果
        logger.info(f"\n{'='*60}")
        logger.info("Extended Cross-Dataset Transfer Results Summary")
        logger.info(f"{'='*60}")
        
        for window_size, window_data in transfer_results['transfer_results'].items():
            logger.info(f"\nWindow Size: {window_size}")
            
            # 源数据集性能
            source_perf = window_data['source_performance']
            logger.info(f"Source Dataset ({source_dataset}) Performance:")
            logger.info(f"  PyTorch_NN: R² = {source_perf['r2']:.3f}, MSE = {source_perf['mse']:.4f}")
            
            # 迁移性能
            logger.info("Transfer Performance:")
            for target_dataset, target_data in window_data['target_performance'].items():
                perf = target_data['performance']
                source_r2 = source_perf['r2']
                target_r2 = perf['r2']
                r2_drop = source_r2 - target_r2
                
                logger.info(f"  {source_dataset} -> {target_dataset}:")
                logger.info(f"    R² = {target_r2:.3f} (drop: {r2_drop:.3f})")
                logger.info(f"    MSE = {perf['mse']:.4f}")
                logger.info(f"    Data shape: {target_data['data_shape']}")
        
        # 计算平均性能下降
        all_drops = []
        for window_size, window_data in transfer_results['transfer_results'].items():
            source_r2 = window_data['source_performance']['r2']
            for target_dataset, target_data in window_data['target_performance'].items():
                target_r2 = target_data['performance']['r2']
                r2_drop = source_r2 - target_r2
                all_drops.append(r2_drop)
        
        if all_drops:
            avg_drop = np.mean(all_drops)
            logger.info(f"\nAverage R² drop across all transfers: {avg_drop:.3f}")
            logger.info(f"Transfer performance range: {min(all_drops):.3f} to {max(all_drops):.3f}")
        
        logger.info(f"\n{'='*60}")
        logger.info("Step 7.2 Extended Cross-Dataset Transfer Completed Successfully!")
        logger.info(f"{'='*60}")
        
        logger.info("🎉 Key Achievements:")
        logger.info("  ✓ GPU-accelerated PyTorch NN training")
        logger.info("  ✓ Extended to 3 target datasets")
        logger.info("  ✓ Cross-dataset transfer validation")
        logger.info("  ✓ Performance drop analysis")
        logger.info("  ✓ Focused on realistic model performance")
        
    except Exception as e:
        logger.error(f"Error in main execution: {e}")
        raise

if __name__ == "__main__":
    main()
