#!/usr/bin/env python3
"""
Step 3: Data Cleaning Pipeline
基于Step 2参数选择结果进行数据清洗
"""

import pandas as pd
import numpy as np
import json
import os
from pathlib import Path
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

class DataCleaner:
    def __init__(self):
        self.cleaning_rules = {
            'artifact_removal': {
                'hrv_thresholds': {'min_ibi': 300, 'max_ibi': 2000},  # ms
                'hrv_outlier_zscore': 3.0,
                'eda_outlier_zscore': 3.0,
                'local_median_filter_window': 5
            },
            'missingness_criteria': {
                'subject_exclusion_threshold': 0.20,  # 20%
                'feature_exclusion_threshold': 0.50   # 50%
            },
            'resampling': {
                'target_frequency': 1.0,  # 1 Hz
                'aggregation_windows': [1, 5, 60, 300, 900]  # seconds
            },
            'baseline_normalization': {
                'baseline_periods': ['night', 'rest', 'baseline'],
                'normalization_method': 'zscore'  # zscore or minmax
            }
        }
        
        # 从Step 2结果加载参数选择信息
        self.load_parameter_selection_results()
    
    def load_parameter_selection_results(self):
        """加载Step 2的参数选择结果"""
        try:
            with open('step2_comprehensive_parameter_summary.json', 'r', encoding='utf-8') as f:
                self.param_results = json.load(f)
            
            # 提取数据集信息
            self.dataset_info = self.param_results['dataset_analysis']
            self.recommended_datasets = {
                'primary': self.param_results['quality_assessment']['recommended_primary_datasets'],
                'secondary': self.param_results['quality_assessment']['recommended_secondary_datasets'],
                'specialized': self.param_results['quality_assessment']['specialized_datasets']
            }
            
            print(f"✅ Loaded parameter selection results for {len(self.dataset_info)} datasets")
            
        except FileNotFoundError:
            print("❌ Step 2 parameter selection results not found. Please run Step 2 first.")
            raise
    
    def clean_dataset(self, dataset_name):
        """清洗单个数据集"""
        print(f"\n{'='*60}")
        print(f"Cleaning Dataset: {dataset_name}")
        print(f"{'='*60}")
        
        if dataset_name not in self.dataset_info:
            print(f"❌ Dataset {dataset_name} not found in parameter selection results")
            return None
        
        dataset_info = self.dataset_info[dataset_name]
        cleaning_audit = {
            'dataset_name': dataset_name,
            'cleaning_timestamp': datetime.now().isoformat(),
            'original_parameters': dataset_info['found_parameters'],
            'data_quality': dataset_info['data_quality'],
            'steps_completed': [],
            'statistics': {},
            'issues_found': [],
            'files_processed': []
        }
        
        try:
            # Step 1: 加载和验证数据
            raw_data = self.load_dataset_data(dataset_name)
            if raw_data is None:
                cleaning_audit['issues_found'].append("Failed to load raw data")
                return cleaning_audit
            
            cleaning_audit['statistics']['original_shape'] = raw_data.shape
            cleaning_audit['steps_completed'].append("data_loading")
            
            # Step 2: Artifact removal
            cleaned_data = self.remove_artifacts(raw_data, dataset_name, cleaning_audit)
            cleaning_audit['steps_completed'].append("artifact_removal")
            
            # Step 3: Missingness analysis
            missingness_stats = self.analyze_missingness(cleaned_data, cleaning_audit)
            cleaning_audit['statistics']['missingness'] = missingness_stats
            
            # Step 4: Resampling and aggregation
            resampled_data = self.resample_data(cleaned_data, dataset_name, cleaning_audit)
            cleaning_audit['steps_completed'].append("resampling")
            
            # Step 5: Baseline normalization
            normalized_data = self.baseline_normalization(resampled_data, dataset_name, cleaning_audit)
            cleaning_audit['steps_completed'].append("baseline_normalization")
            
            # Step 6: 保存清洗后的数据
            self.save_cleaned_data(normalized_data, dataset_name, cleaning_audit)
            cleaning_audit['steps_completed'].append("data_saving")
            
            # 最终统计
            cleaning_audit['statistics']['final_shape'] = normalized_data.shape
            cleaning_audit['statistics']['data_retention_rate'] = (
                normalized_data.shape[0] / raw_data.shape[0] * 100
            )
            
            print(f"✅ Dataset {dataset_name} cleaning completed successfully")
            print(f"   Original: {raw_data.shape[0]} rows")
            print(f"   Final: {normalized_data.shape[0]} rows")
            print(f"   Retention: {cleaning_audit['statistics']['data_retention_rate']:.1f}%")
            
        except Exception as e:
            print(f"❌ Error cleaning dataset {dataset_name}: {e}")
            cleaning_audit['issues_found'].append(f"Cleaning error: {str(e)}")
        
        return cleaning_audit
    
    def load_dataset_data(self, dataset_name):
        """加载数据集原始数据"""
        dataset_paths = {
            'CRWD': 'processed/CRWD_extracted/sensor_hrv.csv',
            'SWELL': 'processed/SWELL_extracted/hrv dataset/data/final/train.csv',
            'Mental_Health_Pred': 'processed/Mental_Health_Pred_extracted/mental_health_wearable_data.csv',
            'WESAD': 'data/WESAD/raw',  # 需要特殊处理
            'MMASH': 'processed/MMASH_extracted/MMASH_data/DataPaper',
            'Nurses': 'processed/Nurses_extracted/nurses_data',
            'DRIVE_DB': 'processed/DRIVE_DB_extracted/stress-recognition-in-automobile-drivers-1.0.0',
            'Non_EEG': 'processed/Non_EEG_extracted/non-eeg-dataset-for-assessment-of-neurological-status-1.0.0'
        }
        
        if dataset_name not in dataset_paths:
            print(f"❌ No path defined for dataset: {dataset_name}")
            return None
        
        path = Path(dataset_paths[dataset_name])
        
        try:
            if dataset_name in ['CRWD', 'SWELL', 'Mental_Health_Pred']:
                # 直接CSV文件
                df = pd.read_csv(path)
                print(f"✅ Loaded {dataset_name}: {df.shape}")
                return df
                
            elif dataset_name == 'WESAD':
                # WESAD需要特殊处理，加载一个样本
                return self.load_wesad_sample()
                
            elif dataset_name in ['MMASH', 'Nurses']:
                # 多文件数据集，加载第一个用户/被试
                return self.load_multi_file_sample(dataset_name, path)
                
            else:
                # 其他数据集（DRIVE_DB, Non_EEG）暂时跳过
                print(f"⚠️ Dataset {dataset_name} requires special handling, skipping for now")
                return None
                
        except Exception as e:
            print(f"❌ Error loading {dataset_name}: {e}")
            return None
    
    def load_wesad_sample(self):
        """加载WESAD样本数据"""
        wesad_path = Path('data/WESAD/raw/S2')
        if not wesad_path.exists():
            print(f"❌ WESAD sample path not found: {wesad_path}")
            return None
        
        # 加载传感器数据
        sensors = {}
        e4_path = wesad_path / 'S2_E4_Data'
        
        if e4_path.exists():
            # 加载BVP数据（用于HRV计算）
            bvp_file = e4_path / 'BVP.csv'
            if bvp_file.exists():
                bvp_data = pd.read_csv(bvp_file, header=None, names=['bvp'])
                sensors['bvp'] = bvp_data['bvp'].values
            
            # 加载EDA数据
            eda_file = e4_path / 'EDA.csv'
            if eda_file.exists():
                eda_data = pd.read_csv(eda_file, header=None, names=['eda'])
                sensors['eda'] = eda_data['eda'].values
            
            # 加载HR数据
            hr_file = e4_path / 'HR.csv'
            if hr_file.exists():
                hr_data = pd.read_csv(hr_file, header=None, names=['hr'])
                sensors['hr'] = hr_data['hr'].values
        
        if sensors:
            # 创建统一的时间序列数据
            max_length = max(len(v) for v in sensors.values())
            df_data = {}
            
            for sensor, values in sensors.items():
                # 填充到相同长度
                padded_values = np.pad(values, (0, max_length - len(values)), mode='constant', constant_values=np.nan)
                df_data[sensor] = padded_values
            
            df_data['timestamp'] = np.arange(max_length)
            df = pd.DataFrame(df_data)
            
            print(f"✅ Loaded WESAD sample: {df.shape}")
            return df
        else:
            print("❌ No sensor data found in WESAD sample")
            return None
    
    def load_multi_file_sample(self, dataset_name, base_path):
        """加载多文件数据集的样本"""
        if dataset_name == 'MMASH':
            # 找到第一个用户目录
            user_dirs = [d for d in base_path.iterdir() if d.is_dir() and d.name.startswith('user_')]
            if not user_dirs:
                print("❌ No user directories found in MMASH")
                return None
            
            user_dir = user_dirs[0]
            print(f"Loading MMASH sample from: {user_dir.name}")
            
            # 加载RR数据
            rr_file = user_dir / 'RR.csv'
            if rr_file.exists():
                df = pd.read_csv(rr_file)
                print(f"✅ Loaded MMASH sample: {df.shape}")
                return df
        
        elif dataset_name == 'Nurses':
            # 找到第一个被试目录
            subject_dirs = [d for d in base_path.iterdir() if d.is_dir()]
            if not subject_dirs:
                print("❌ No subject directories found in Nurses")
                return None
            
            subject_dir = subject_dirs[0]
            extracted_path = subject_dir / 'extracted'
            
            if extracted_path.exists():
                session_dirs = [d for d in extracted_path.iterdir() if d.is_dir()]
                if session_dirs:
                    session_dir = session_dirs[0]
                    
                    # 加载多个传感器数据
                    sensor_data = {}
                    
                    # BVP数据
                    bvp_file = session_dir / 'BVP.csv'
                    if bvp_file.exists():
                        bvp_df = pd.read_csv(bvp_file, header=None, names=['bvp'])
                        sensor_data['bvp'] = bvp_df['bvp'].values
                    
                    # EDA数据
                    eda_file = session_dir / 'EDA.csv'
                    if eda_file.exists():
                        eda_df = pd.read_csv(eda_file, header=None, names=['eda'])
                        sensor_data['eda'] = eda_df['eda'].values
                    
                    if sensor_data:
                        max_length = max(len(v) for v in sensor_data.values())
                        df_data = {}
                        
                        for sensor, values in sensor_data.items():
                            padded_values = np.pad(values, (0, max_length - len(values)), mode='constant', constant_values=np.nan)
                            df_data[sensor] = padded_values
                        
                        df_data['timestamp'] = np.arange(max_length)
                        df = pd.DataFrame(df_data)
                        
                        print(f"✅ Loaded Nurses sample: {df.shape}")
                        return df
        
        print(f"❌ Failed to load sample data for {dataset_name}")
        return None
    
    def remove_artifacts(self, data, dataset_name, audit):
        """移除数据中的伪影"""
        print(f"🔧 Removing artifacts from {dataset_name}...")
        
        cleaned_data = data.copy()
        artifact_stats = {}
        
        # 处理数值列
        numeric_cols = cleaned_data.select_dtypes(include=[np.number]).columns
        
        for col in numeric_cols:
            if col == 'timestamp':
                continue
                
            original_count = len(cleaned_data[col])
            
            # 1. 移除无穷大值
            cleaned_data[col] = cleaned_data[col].replace([np.inf, -np.inf], np.nan)
            
            # 2. Z-score异常值检测
            if col in ['hr_mean', 'hr', 'bvp', 'eda']:
                # 对生理信号进行更严格的异常值检测
                z_threshold = self.cleaning_rules['artifact_removal']['eda_outlier_zscore']
                
                # 计算Z-score（忽略NaN）
                valid_data = cleaned_data[col].dropna()
                if len(valid_data) > 10:  # 需要足够的数据点
                    z_scores = np.abs((valid_data - valid_data.mean()) / valid_data.std())
                    outlier_mask = z_scores > z_threshold
                    
                    # 将异常值设为NaN
                    outlier_indices = valid_data[outlier_mask].index
                    cleaned_data.loc[outlier_indices, col] = np.nan
            
            # 3. 局部中值滤波（用于平滑）
            window_size = self.cleaning_rules['artifact_removal']['local_median_filter_window']
            if len(cleaned_data[col].dropna()) > window_size:
                # 对非NaN值进行中值滤波
                valid_mask = ~cleaned_data[col].isna()
                if valid_mask.sum() > window_size:
                    valid_values = cleaned_data.loc[valid_mask, col].values
                    smoothed_values = pd.Series(valid_values).rolling(window=window_size, center=True).median()
                    
                    # 只更新非NaN的部分
                    cleaned_data.loc[valid_mask, col] = smoothed_values.values
            
            final_count = len(cleaned_data[col].dropna())
            artifact_stats[col] = {
                'original_count': original_count,
                'final_count': final_count,
                'removed_count': original_count - final_count,
                'removal_rate': (original_count - final_count) / original_count * 100
            }
        
        audit['statistics']['artifact_removal'] = artifact_stats
        print(f"   Artifact removal completed for {len(numeric_cols)} columns")
        
        return cleaned_data
    
    def analyze_missingness(self, data, audit):
        """分析缺失数据"""
        print(f"📊 Analyzing missingness...")
        
        missingness_stats = {}
        
        # 按列分析缺失率
        missing_by_column = data.isnull().sum() / len(data) * 100
        missingness_stats['by_column'] = missing_by_column.to_dict()
        
        # 识别高缺失率的列
        high_missing_cols = missing_by_column[missing_by_column > 
                                            self.cleaning_rules['missingness_criteria']['feature_exclusion_threshold'] * 100]
        
        if len(high_missing_cols) > 0:
            audit['issues_found'].append(f"High missingness columns: {list(high_missing_cols.index)}")
            print(f"   ⚠️ High missingness columns: {list(high_missing_cols.index)}")
        
        # 按行分析缺失率
        missing_by_row = data.isnull().sum(axis=1) / len(data.columns) * 100
        missingness_stats['by_row'] = {
            'mean_missing_per_row': missing_by_row.mean(),
            'max_missing_per_row': missing_by_row.max(),
            'rows_with_high_missing': (missing_by_row > 50).sum()
        }
        
        print(f"   Mean missingness per row: {missing_by_row.mean():.1f}%")
        
        return missingness_stats
    
    def resample_data(self, data, dataset_name, audit):
        """重采样数据到统一频率"""
        print(f"🔄 Resampling data...")
        
        if 'timestamp' not in data.columns:
            # 如果没有时间戳，创建虚拟时间戳
            data = data.copy()
            data['timestamp'] = np.arange(len(data))
        
        # 设置时间戳为索引
        data_indexed = data.set_index('timestamp')
        
        # 重采样到目标频率
        target_freq = self.cleaning_rules['resampling']['target_frequency']
        
        try:
            # 重采样（向前填充）
            resampled = data_indexed.resample(f'{1/target_freq}S').mean()
            
            # 向前填充缺失值
            resampled = resampled.fillna(method='ffill').fillna(method='bfill')
            
            # 重置索引
            resampled = resampled.reset_index()
            
            print(f"   Resampled from {len(data)} to {len(resampled)} rows")
            audit['statistics']['resampling'] = {
                'original_length': len(data),
                'resampled_length': len(resampled),
                'target_frequency': target_freq
            }
            
            return resampled
            
        except Exception as e:
            print(f"   ⚠️ Resampling failed: {e}, keeping original data")
            audit['issues_found'].append(f"Resampling failed: {str(e)}")
            return data
    
    def baseline_normalization(self, data, dataset_name, audit):
        """基线归一化"""
        print(f"📏 Applying baseline normalization...")
        
        normalized_data = data.copy()
        normalization_stats = {}
        
        numeric_cols = normalized_data.select_dtypes(include=[np.number]).columns
        numeric_cols = [col for col in numeric_cols if col != 'timestamp']
        
        for col in numeric_cols:
            if normalized_data[col].isna().all():
                continue
            
            # Z-score归一化
            valid_data = normalized_data[col].dropna()
            if len(valid_data) > 1:
                mean_val = valid_data.mean()
                std_val = valid_data.std()
                
                if std_val > 0:
                    normalized_data[col] = (normalized_data[col] - mean_val) / std_val
                    
                    normalization_stats[col] = {
                        'original_mean': mean_val,
                        'original_std': std_val,
                        'normalized_mean': 0.0,
                        'normalized_std': 1.0
                    }
        
        audit['statistics']['normalization'] = normalization_stats
        print(f"   Normalized {len(normalization_stats)} columns")
        
        return normalized_data
    
    def save_cleaned_data(self, data, dataset_name, audit):
        """保存清洗后的数据"""
        print(f"💾 Saving cleaned data...")
        
        # 创建输出目录
        output_dir = Path('processed/cleaned_data')
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # 保存为Parquet格式
        parquet_file = output_dir / f'cleaned_{dataset_name}.parquet'
        data.to_parquet(parquet_file, index=False)
        
        # 保存审计日志
        audit_file = output_dir / f'cleaning_audit_{dataset_name}.json'
        with open(audit_file, 'w', encoding='utf-8') as f:
            json.dump(audit, f, indent=2, ensure_ascii=False, default=str)
        
        audit['files_processed'] = [str(parquet_file), str(audit_file)]
        
        print(f"   Saved to: {parquet_file}")
        print(f"   Audit log: {audit_file}")
    
    def clean_all_datasets(self):
        """清洗所有数据集"""
        print("Starting Step 3: Data Cleaning Pipeline")
        print("="*60)
        
        # 按优先级清洗数据集
        all_datasets = (
            self.recommended_datasets['primary'] + 
            self.recommended_datasets['secondary'] + 
            self.recommended_datasets['specialized']
        )
        
        cleaning_results = {}
        
        for dataset_name in all_datasets:
            if dataset_name in self.dataset_info:
                audit = self.clean_dataset(dataset_name)
                cleaning_results[dataset_name] = audit
            else:
                print(f"⚠️ Skipping {dataset_name}: not in parameter selection results")
        
        # 生成综合报告
        self.generate_cleaning_summary(cleaning_results)
        
        return cleaning_results
    
    def generate_cleaning_summary(self, cleaning_results):
        """生成清洗综合报告"""
        print(f"\n{'='*60}")
        print("DATA CLEANING SUMMARY")
        print(f"{'='*60}")
        
        summary = {
            'cleaning_timestamp': datetime.now().isoformat(),
            'total_datasets_processed': len(cleaning_results),
            'datasets_successfully_cleaned': len([r for r in cleaning_results.values() if 'data_saving' in r.get('steps_completed', [])]),
            'datasets_with_issues': len([r for r in cleaning_results.values() if r.get('issues_found', [])]),
            'overall_statistics': {},
            'dataset_details': cleaning_results
        }
        
        # 计算总体统计
        if cleaning_results:
            retention_rates = [
                r.get('statistics', {}).get('data_retention_rate', 0) 
                for r in cleaning_results.values() 
                if 'data_retention_rate' in r.get('statistics', {})
            ]
            
            if retention_rates:
                summary['overall_statistics'] = {
                    'average_retention_rate': np.mean(retention_rates),
                    'min_retention_rate': np.min(retention_rates),
                    'max_retention_rate': np.max(retention_rates)
                }
        
        # 打印摘要
        print(f"📊 Overall Statistics:")
        print(f"   Total datasets: {summary['total_datasets_processed']}")
        print(f"   Successfully cleaned: {summary['datasets_successfully_cleaned']}")
        print(f"   With issues: {summary['datasets_with_issues']}")
        
        if 'average_retention_rate' in summary['overall_statistics']:
            stats = summary['overall_statistics']
            print(f"   Average data retention: {stats['average_retention_rate']:.1f}%")
        
        # 保存综合报告
        summary_file = Path('processed/cleaned_data/cleaning_summary.json')
        with open(summary_file, 'w', encoding='utf-8') as f:
            json.dump(summary, f, indent=2, ensure_ascii=False, default=str)
        
        print(f"\n✅ Cleaning summary saved to: {summary_file}")

def main():
    """主函数"""
    cleaner = DataCleaner()
    results = cleaner.clean_all_datasets()
    
    print(f"\n🎉 Step 3 Data Cleaning completed!")
    print(f"Ready for Step 4: W(t) Generation")

if __name__ == "__main__":
    main()








