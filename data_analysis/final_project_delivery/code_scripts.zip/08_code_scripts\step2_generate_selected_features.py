#!/usr/bin/env python3
"""
Step 2: 生成selected_features_{dataset}.csv文件
基于理论优先的参数筛选，为每个数据集生成参数选择报告
"""

import pandas as pd
import numpy as np
import json
from pathlib import Path
from datetime import datetime

def generate_selected_features():
    """
    为所有8个数据集生成selected_features_{dataset}.csv文件
    """
    print("生成Step 2参数筛选文件")
    print("="*50)
    
    # 理论参数优先级定义
    theoretical_priorities = {
        'priority_1_core_physiological': {
            'description': '核心生理标记，直接反映ANS活动和急性压力',
            'parameters': {
                'hrv_rmssd': {'aliases': ['rmssd', 'rmssd_rel_rr', 'sd1'], 'weight': 1.0},
                'hrv_sdnn': {'aliases': ['sdnn', 'sdrr', 'sd2'], 'weight': 1.0},
                'hr_mean': {'aliases': ['hr', 'heart_rate_bpm'], 'weight': 0.9},
                'ibi': {'aliases': ['ibi', 'rr', 'ibi_s', 'mean_rr', 'median_rr'], 'weight': 0.9},
                'eda': {'aliases': ['eda', 'gsr'], 'weight': 0.8}
            }
        },
        'priority_2_regulatory_variables': {
            'description': '调节变量，提供压力响应的上下文',
            'parameters': {
                'temperature': {'aliases': ['temp', 'temperature'], 'weight': 0.6},
                'acceleration': {'aliases': ['acc', 'activity', 'steps', 'vector_magnitude', 'ax', 'ay', 'az'], 'weight': 0.5},
                'respiration': {'aliases': ['resp', 'respiration'], 'weight': 0.4}
            }
        },
        'priority_3_clinical_subjective': {
            'description': '主观报告和临床量表，用于验证',
            'parameters': {
                'phq_9': {'aliases': ['phq_9', 'phq9', 'mood_rating'], 'weight': 0.7},
                'gad_7': {'aliases': ['gad_7', 'gad7'], 'weight': 0.7},
                'bdi': {'aliases': ['bdi', 'bdi_ii'], 'weight': 0.7},
                'stress_label': {'aliases': ['condition', 'stress_level', 'mental_health_condition'], 'weight': 0.8},
                'sleep': {'aliases': ['sleep_duration_hours', 'total_sleep_time_(tst)', 'sleep_efficiency'], 'weight': 0.5}
            }
        }
    }
    
    # 数据集列表
    datasets = [
        'CRWD_complete',
        'SWELL_complete', 
        'WESAD_full_sample',
        'Nurses_full_sample',
        'MMASH',
        'Mental_Health_Pred',
        'DRIVE_DB_full_sample',
        'Non_EEG_full_sample'
    ]
    
    output_dir = Path('processed/parameter_selection')
    output_dir.mkdir(parents=True, exist_ok=True)
    
    for dataset_name in datasets:
        print(f"\n📊 处理数据集: {dataset_name}")
        
        # 查找对应的清洗后数据文件
        cleaned_file = Path(f'processed/cleaned_data/cleaned_{dataset_name}.parquet')
        if not cleaned_file.exists():
            print(f"  ❌ 未找到清洗后数据: {cleaned_file}")
            continue
        
        try:
            # 加载数据
            df = pd.read_parquet(cleaned_file)
            print(f"  ✅ 数据加载: {df.shape[0]:,} 行, {df.shape[1]} 列")
            
            # 分析可用列
            available_columns = df.columns.tolist()
            print(f"  📋 可用列: {available_columns}")
            
            # 基于理论优先级选择参数
            selected_features = []
            
            for priority_level, priority_info in theoretical_priorities.items():
                print(f"  🔍 检查 {priority_level}...")
                
                for param_name, param_info in priority_info['parameters'].items():
                    # 检查是否有匹配的列
                    matching_columns = []
                    for alias in param_info['aliases']:
                        matching_columns.extend([col for col in available_columns if alias.lower() in col.lower()])
                    
                    if matching_columns:
                        for col in matching_columns:
                            # 计算数据质量指标
                            nan_count = df[col].isna().sum()
                            nan_percentage = (nan_count / len(df)) * 100
                            
                            # 计算基本统计
                            if pd.api.types.is_numeric_dtype(df[col]):
                                mean_val = df[col].mean()
                                std_val = df[col].std()
                                min_val = df[col].min()
                                max_val = df[col].max()
                            else:
                                mean_val = std_val = min_val = max_val = "N/A"
                            
                            selected_features.append({
                                'parameter_name': param_name,
                                'column_name': col,
                                'priority_level': priority_level,
                                'theoretical_weight': param_info['weight'],
                                'description': priority_info['description'],
                                'data_type': str(df[col].dtype),
                                'nan_count': nan_count,
                                'nan_percentage': round(nan_percentage, 2),
                                'mean_value': mean_val if isinstance(mean_val, (int, float)) else "N/A",
                                'std_value': std_val if isinstance(std_val, (int, float)) else "N/A",
                                'min_value': min_val if isinstance(min_val, (int, float)) else "N/A",
                                'max_value': max_val if isinstance(max_val, (int, float)) else "N/A",
                                'selection_reason': f"理论优先级匹配: {param_info['aliases']}",
                                'vif_status': "未计算",  # 简化版本不计算VIF
                                'recommended': "是" if nan_percentage < 20 else "否"
                            })
            
            # 创建DataFrame并保存
            if selected_features:
                features_df = pd.DataFrame(selected_features)
                
                # 按理论权重排序
                features_df = features_df.sort_values(['theoretical_weight', 'nan_percentage'], ascending=[False, True])
                
                # 保存到CSV
                output_file = output_dir / f'selected_features_{dataset_name}.csv'
                features_df.to_csv(output_file, index=False)
                print(f"  💾 保存参数选择文件: {output_file}")
                print(f"  📊 选择了 {len(selected_features)} 个参数")
                
                # 显示前5个最重要的参数
                top_params = features_df.head(5)
                print(f"  🏆 前5个重要参数:")
                for _, row in top_params.iterrows():
                    print(f"    - {row['column_name']}: 权重={row['theoretical_weight']}, 缺失率={row['nan_percentage']}%")
            else:
                print(f"  ⚠️ 未找到匹配的理论参数")
                
        except Exception as e:
            print(f"  ❌ 处理失败: {e}")
            continue
    
    print(f"\n✅ Step 2参数筛选文件生成完成!")
    print(f"📁 输出目录: {output_dir}")

if __name__ == "__main__":
    generate_selected_features()








